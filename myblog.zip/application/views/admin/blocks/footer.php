    <div id="footer">
        <div class="footer_left"><a href="<?=base_url();?>">Main</a></div>
        <div class="footer_right"><a href="<?=base_url();?>auth/logout">exit</a></div>
    </div>
</body>
</html>
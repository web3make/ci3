<!DOCTYPE html>
<html>
<head>

    <link href="<?=base_url();?>css/style.css" rel="stylesheet" type="text/css" />
	<title>Admin</title>
</head>
<body>
    <div id="header">
        <div id="header_left">
            <h1><a href="<?=base_url();?>admin">Admin</a></h1>
        </div>

    </div>
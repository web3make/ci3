<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-12 00:00:00 --> Config Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:00:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:00:00 --> URI Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Router Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Output Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Security Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Input Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:00:00 --> Language Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Loader Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:00:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Session Class Initialized
DEBUG - 2012-01-12 00:00:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:00:00 --> Session routines successfully run
DEBUG - 2012-01-12 00:00:00 --> Controller Class Initialized
DEBUG - 2012-01-12 00:00:00 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:00:00 --> Final output sent to browser
DEBUG - 2012-01-12 00:00:00 --> Total execution time: 0.4164
DEBUG - 2012-01-12 00:00:03 --> Config Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:00:03 --> URI Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Router Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Output Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Security Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Input Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:00:03 --> Language Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Loader Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:00:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Session Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:00:03 --> Session routines successfully run
DEBUG - 2012-01-12 00:00:03 --> Controller Class Initialized
DEBUG - 2012-01-12 00:00:03 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:00:03 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:00:03 --> Final output sent to browser
DEBUG - 2012-01-12 00:00:03 --> Total execution time: 0.5974
DEBUG - 2012-01-12 00:00:05 --> Config Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:00:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:00:05 --> URI Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Router Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Output Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Security Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Input Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:00:05 --> Language Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Loader Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:00:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Session Class Initialized
DEBUG - 2012-01-12 00:00:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:00:05 --> Session routines successfully run
DEBUG - 2012-01-12 00:00:05 --> Controller Class Initialized
DEBUG - 2012-01-12 00:00:05 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:00:05 --> Final output sent to browser
DEBUG - 2012-01-12 00:00:05 --> Total execution time: 0.4741
DEBUG - 2012-01-12 00:06:47 --> Config Class Initialized
DEBUG - 2012-01-12 00:06:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:06:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:06:47 --> URI Class Initialized
DEBUG - 2012-01-12 00:06:47 --> Router Class Initialized
DEBUG - 2012-01-12 00:06:47 --> Output Class Initialized
DEBUG - 2012-01-12 00:06:47 --> Security Class Initialized
DEBUG - 2012-01-12 00:06:47 --> Input Class Initialized
DEBUG - 2012-01-12 00:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:06:48 --> Language Class Initialized
DEBUG - 2012-01-12 00:06:48 --> Loader Class Initialized
DEBUG - 2012-01-12 00:06:48 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:06:48 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:06:48 --> Session Class Initialized
DEBUG - 2012-01-12 00:06:48 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:06:48 --> Session routines successfully run
DEBUG - 2012-01-12 00:06:48 --> Controller Class Initialized
DEBUG - 2012-01-12 00:06:48 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:06:48 --> Final output sent to browser
DEBUG - 2012-01-12 00:06:48 --> Total execution time: 0.3681
DEBUG - 2012-01-12 00:07:46 --> Config Class Initialized
DEBUG - 2012-01-12 00:07:46 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:07:46 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:07:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:07:46 --> URI Class Initialized
DEBUG - 2012-01-12 00:07:46 --> Router Class Initialized
DEBUG - 2012-01-12 00:07:46 --> Output Class Initialized
DEBUG - 2012-01-12 00:07:46 --> Security Class Initialized
DEBUG - 2012-01-12 00:07:46 --> Input Class Initialized
DEBUG - 2012-01-12 00:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:07:47 --> Language Class Initialized
DEBUG - 2012-01-12 00:07:47 --> Loader Class Initialized
DEBUG - 2012-01-12 00:07:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:07:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:07:47 --> Session Class Initialized
DEBUG - 2012-01-12 00:07:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:07:47 --> Session routines successfully run
DEBUG - 2012-01-12 00:07:47 --> Controller Class Initialized
DEBUG - 2012-01-12 00:07:47 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:07:47 --> Final output sent to browser
DEBUG - 2012-01-12 00:07:47 --> Total execution time: 0.3766
DEBUG - 2012-01-12 00:07:56 --> Config Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:07:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:07:56 --> URI Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Router Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Output Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Security Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Input Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:07:56 --> Language Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Loader Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:07:56 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Session Class Initialized
DEBUG - 2012-01-12 00:07:56 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:07:56 --> Session routines successfully run
DEBUG - 2012-01-12 00:07:56 --> Controller Class Initialized
DEBUG - 2012-01-12 00:07:56 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:07:56 --> Final output sent to browser
DEBUG - 2012-01-12 00:07:56 --> Total execution time: 0.5498
DEBUG - 2012-01-12 00:08:02 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:02 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:02 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:02 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:02 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:02 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:08:02 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:02 --> Total execution time: 0.4771
DEBUG - 2012-01-12 00:08:05 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:05 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:05 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:05 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:05 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:05 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:08:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:08:05 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:05 --> Total execution time: 0.4780
DEBUG - 2012-01-12 00:08:06 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:06 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:06 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:06 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:06 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:07 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:07 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:07 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:07 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:07 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:07 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:08:07 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:07 --> Total execution time: 0.4354
DEBUG - 2012-01-12 00:08:13 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:13 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:13 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:13 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:13 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:14 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:14 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:14 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:14 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:14 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:14 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:14 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:14 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:08:14 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:14 --> Total execution time: 0.4346
DEBUG - 2012-01-12 00:08:20 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:20 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:20 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:20 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:20 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:20 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:20 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:20 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:08:20 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:20 --> Total execution time: 0.4557
DEBUG - 2012-01-12 00:08:38 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:38 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:38 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:38 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:38 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:38 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:08:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:08:38 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:38 --> Total execution time: 0.4608
DEBUG - 2012-01-12 00:08:40 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:40 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:40 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:40 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:40 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:40 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:40 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:40 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:08:40 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:40 --> Total execution time: 0.9862
DEBUG - 2012-01-12 00:08:44 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:44 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:44 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:44 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:44 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:44 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:44 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:44 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:45 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:45 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:45 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:45 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:45 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:45 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:45 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:08:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:08:45 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:45 --> Total execution time: 0.5865
DEBUG - 2012-01-12 00:08:47 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:47 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:47 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:47 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:48 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:48 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:48 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:48 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:48 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:48 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:08:48 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:48 --> Total execution time: 0.5068
DEBUG - 2012-01-12 00:08:55 --> Config Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:08:55 --> URI Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Router Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Output Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Security Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Input Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:08:55 --> Language Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Loader Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:08:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Session Class Initialized
DEBUG - 2012-01-12 00:08:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:08:56 --> Session routines successfully run
DEBUG - 2012-01-12 00:08:56 --> Controller Class Initialized
DEBUG - 2012-01-12 00:08:56 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:08:56 --> Final output sent to browser
DEBUG - 2012-01-12 00:08:56 --> Total execution time: 0.4733
DEBUG - 2012-01-12 00:09:28 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:28 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:28 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:28 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:29 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:29 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:29 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:29 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:29 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:29 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:29 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:29 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:29 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:29 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:29 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:09:29 --> Final output sent to browser
DEBUG - 2012-01-12 00:09:29 --> Total execution time: 0.3903
DEBUG - 2012-01-12 00:09:31 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:31 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:31 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:31 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:31 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:32 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:32 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:32 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:09:32 --> Final output sent to browser
DEBUG - 2012-01-12 00:09:32 --> Total execution time: 0.4083
DEBUG - 2012-01-12 00:09:34 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:34 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:34 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:34 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:34 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:34 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:34 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:35 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:35 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:35 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:35 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:35 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:35 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:09:35 --> Final output sent to browser
DEBUG - 2012-01-12 00:09:35 --> Total execution time: 1.0598
DEBUG - 2012-01-12 00:09:39 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:39 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:39 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:39 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:39 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:39 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:09:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:09:39 --> Final output sent to browser
DEBUG - 2012-01-12 00:09:39 --> Total execution time: 0.6116
DEBUG - 2012-01-12 00:09:41 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:41 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:41 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:41 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:41 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:41 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:09:41 --> Final output sent to browser
DEBUG - 2012-01-12 00:09:41 --> Total execution time: 0.4968
DEBUG - 2012-01-12 00:09:54 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:54 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:54 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:54 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:54 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:54 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:54 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:55 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:55 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:55 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:09:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:09:55 --> Final output sent to browser
DEBUG - 2012-01-12 00:09:55 --> Total execution time: 0.4085
DEBUG - 2012-01-12 00:09:57 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:57 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Security Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Input Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:09:57 --> Language Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Loader Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:09:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Session Class Initialized
DEBUG - 2012-01-12 00:09:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:09:57 --> Session routines successfully run
DEBUG - 2012-01-12 00:09:57 --> Controller Class Initialized
DEBUG - 2012-01-12 00:09:57 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:09:57 --> Final output sent to browser
DEBUG - 2012-01-12 00:09:57 --> Total execution time: 0.4163
DEBUG - 2012-01-12 00:09:59 --> Config Class Initialized
DEBUG - 2012-01-12 00:09:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:09:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:09:59 --> URI Class Initialized
DEBUG - 2012-01-12 00:09:59 --> Router Class Initialized
DEBUG - 2012-01-12 00:09:59 --> Output Class Initialized
DEBUG - 2012-01-12 00:09:59 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:00 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:00 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:00 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:00 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:00 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:00 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:00 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:10:00 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:00 --> Total execution time: 1.0557
DEBUG - 2012-01-12 00:10:02 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:02 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:02 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:02 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:02 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:02 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:03 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:03 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:03 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:03 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:03 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:03 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:10:03 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:03 --> Total execution time: 0.4605
DEBUG - 2012-01-12 00:10:05 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:05 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:05 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:05 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:05 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:05 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:10:06 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:06 --> Total execution time: 0.9853
DEBUG - 2012-01-12 00:10:08 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:08 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:08 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:09 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:09 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:09 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:09 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:09 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:09 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:10:09 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:10:09 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:09 --> Total execution time: 0.4986
DEBUG - 2012-01-12 00:10:20 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:20 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:20 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:20 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:20 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:20 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:20 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:20 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:10:20 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:20 --> Total execution time: 0.4853
DEBUG - 2012-01-12 00:10:33 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:33 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:33 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:33 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:33 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:33 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:33 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:33 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:34 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:34 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:34 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:34 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:34 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:34 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:34 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:34 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:10:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:10:34 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:34 --> Total execution time: 0.4084
DEBUG - 2012-01-12 00:10:36 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:37 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:37 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:37 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:37 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:37 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:37 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:37 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:10:37 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:37 --> Total execution time: 0.4371
DEBUG - 2012-01-12 00:10:39 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:39 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:39 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:39 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:39 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:10:39 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:39 --> Total execution time: 0.6065
DEBUG - 2012-01-12 00:10:42 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:42 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:42 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:42 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:42 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:42 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:42 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:10:42 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:10:42 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:42 --> Total execution time: 0.4220
DEBUG - 2012-01-12 00:10:45 --> Config Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:10:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:10:45 --> URI Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Router Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Output Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Security Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Input Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:10:45 --> Language Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Loader Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:10:45 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Session Class Initialized
DEBUG - 2012-01-12 00:10:45 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:10:45 --> Session routines successfully run
DEBUG - 2012-01-12 00:10:45 --> Controller Class Initialized
DEBUG - 2012-01-12 00:10:45 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:10:45 --> Final output sent to browser
DEBUG - 2012-01-12 00:10:45 --> Total execution time: 0.5001
DEBUG - 2012-01-12 00:11:37 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:37 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:37 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:37 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:37 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:37 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:37 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:38 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:38 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:38 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:38 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:38 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:11:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:11:38 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:38 --> Total execution time: 0.4437
DEBUG - 2012-01-12 00:11:40 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:40 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:40 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:41 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:41 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:41 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:41 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:11:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:11:41 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:41 --> Total execution time: 0.5056
DEBUG - 2012-01-12 00:11:43 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:43 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:43 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:43 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:43 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:44 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:44 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:11:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:11:44 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:44 --> Total execution time: 0.5859
DEBUG - 2012-01-12 00:11:45 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:45 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:45 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:45 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:45 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:46 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:46 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:46 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:46 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:46 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:11:46 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:46 --> Total execution time: 0.4919
DEBUG - 2012-01-12 00:11:47 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:47 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:47 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:47 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:47 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:11:48 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:48 --> Total execution time: 0.4430
DEBUG - 2012-01-12 00:11:51 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:51 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:51 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:51 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:51 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:51 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:51 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:51 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:11:51 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:51 --> Total execution time: 0.4638
DEBUG - 2012-01-12 00:11:53 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:53 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:53 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:53 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:53 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:53 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:53 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:11:53 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:53 --> Total execution time: 0.4652
DEBUG - 2012-01-12 00:11:58 --> Config Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:11:58 --> URI Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Router Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Output Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Security Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Input Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:11:58 --> Language Class Initialized
DEBUG - 2012-01-12 00:11:58 --> Loader Class Initialized
DEBUG - 2012-01-12 00:11:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:11:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:11:59 --> Session Class Initialized
DEBUG - 2012-01-12 00:11:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:11:59 --> Session routines successfully run
DEBUG - 2012-01-12 00:11:59 --> Controller Class Initialized
DEBUG - 2012-01-12 00:11:59 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:11:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:11:59 --> Final output sent to browser
DEBUG - 2012-01-12 00:11:59 --> Total execution time: 0.6101
DEBUG - 2012-01-12 00:12:00 --> Config Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:12:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:12:00 --> URI Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Router Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Output Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Security Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Input Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:12:00 --> Language Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Loader Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:12:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Session Class Initialized
DEBUG - 2012-01-12 00:12:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:12:00 --> Session routines successfully run
DEBUG - 2012-01-12 00:12:00 --> Controller Class Initialized
DEBUG - 2012-01-12 00:12:00 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:12:00 --> Final output sent to browser
DEBUG - 2012-01-12 00:12:00 --> Total execution time: 0.5163
DEBUG - 2012-01-12 00:12:17 --> Config Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:12:17 --> URI Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Router Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Output Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Security Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Input Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:12:17 --> Language Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Loader Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:12:17 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Session Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:12:17 --> Session routines successfully run
DEBUG - 2012-01-12 00:12:17 --> Controller Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Config Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:12:17 --> URI Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Router Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Output Class Initialized
DEBUG - 2012-01-12 00:12:17 --> Security Class Initialized
DEBUG - 2012-01-12 00:12:18 --> Input Class Initialized
DEBUG - 2012-01-12 00:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:12:18 --> Language Class Initialized
DEBUG - 2012-01-12 00:12:18 --> Loader Class Initialized
DEBUG - 2012-01-12 00:12:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:12:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:12:18 --> Session Class Initialized
DEBUG - 2012-01-12 00:12:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:12:18 --> Session routines successfully run
DEBUG - 2012-01-12 00:12:18 --> Controller Class Initialized
DEBUG - 2012-01-12 00:12:18 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:12:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:12:18 --> Final output sent to browser
DEBUG - 2012-01-12 00:12:18 --> Total execution time: 0.4229
DEBUG - 2012-01-12 00:12:20 --> Config Class Initialized
DEBUG - 2012-01-12 00:12:20 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:12:20 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:12:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:12:20 --> URI Class Initialized
DEBUG - 2012-01-12 00:12:20 --> Router Class Initialized
DEBUG - 2012-01-12 00:12:20 --> Output Class Initialized
DEBUG - 2012-01-12 00:12:20 --> Security Class Initialized
DEBUG - 2012-01-12 00:12:20 --> Input Class Initialized
DEBUG - 2012-01-12 00:12:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:12:20 --> Language Class Initialized
DEBUG - 2012-01-12 00:12:21 --> Loader Class Initialized
DEBUG - 2012-01-12 00:12:21 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:12:21 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:12:21 --> Session Class Initialized
DEBUG - 2012-01-12 00:12:21 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:12:21 --> Session routines successfully run
DEBUG - 2012-01-12 00:12:21 --> Controller Class Initialized
DEBUG - 2012-01-12 00:12:21 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:12:21 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:12:21 --> Final output sent to browser
DEBUG - 2012-01-12 00:12:21 --> Total execution time: 0.5006
DEBUG - 2012-01-12 00:12:43 --> Config Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:12:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:12:43 --> URI Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Router Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Output Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Security Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Input Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:12:43 --> Language Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Loader Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:12:43 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Session Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:12:43 --> Session routines successfully run
DEBUG - 2012-01-12 00:12:43 --> Controller Class Initialized
DEBUG - 2012-01-12 00:12:43 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:12:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:12:43 --> Final output sent to browser
DEBUG - 2012-01-12 00:12:43 --> Total execution time: 0.5700
DEBUG - 2012-01-12 00:12:45 --> Config Class Initialized
DEBUG - 2012-01-12 00:12:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:12:45 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:12:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:12:46 --> URI Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Router Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Output Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Security Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Input Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:12:46 --> Language Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Loader Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:12:46 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Session Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:12:46 --> Session routines successfully run
DEBUG - 2012-01-12 00:12:46 --> Controller Class Initialized
DEBUG - 2012-01-12 00:12:46 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:12:46 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:12:46 --> Final output sent to browser
DEBUG - 2012-01-12 00:12:46 --> Total execution time: 0.4980
DEBUG - 2012-01-12 00:13:03 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:03 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:03 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:03 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:03 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:03 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:13:03 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:13:03 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:03 --> Total execution time: 0.4061
DEBUG - 2012-01-12 00:13:05 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:05 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:05 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:05 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:05 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:06 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:06 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:06 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:06 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:06 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:06 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:06 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:06 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:06 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:13:06 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:13:06 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:06 --> Total execution time: 1.0250
DEBUG - 2012-01-12 00:13:08 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:08 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:08 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:08 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:08 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:08 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:08 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:13:08 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:13:08 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:08 --> Total execution time: 0.5168
DEBUG - 2012-01-12 00:13:10 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:10 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:10 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:10 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:10 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:11 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:11 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:11 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:13:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:13:11 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:11 --> Total execution time: 0.7434
DEBUG - 2012-01-12 00:13:13 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:13 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:13 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:13 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:13 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:13 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:13 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:13:13 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:13 --> Total execution time: 0.4823
DEBUG - 2012-01-12 00:13:15 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:15 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:15 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:15 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:16 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:16 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:16 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:16 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:13:16 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:16 --> Total execution time: 0.7193
DEBUG - 2012-01-12 00:13:17 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:17 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:17 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:17 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:17 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:17 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:17 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:18 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:18 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:18 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:18 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:18 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:13:18 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:18 --> Total execution time: 0.4252
DEBUG - 2012-01-12 00:13:19 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:19 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:19 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:19 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:19 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:20 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:20 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:20 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:20 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:20 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:13:20 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:20 --> Total execution time: 0.4573
DEBUG - 2012-01-12 00:13:21 --> Config Class Initialized
DEBUG - 2012-01-12 00:13:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:13:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:13:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:13:21 --> URI Class Initialized
DEBUG - 2012-01-12 00:13:21 --> Router Class Initialized
DEBUG - 2012-01-12 00:13:21 --> Output Class Initialized
DEBUG - 2012-01-12 00:13:22 --> Security Class Initialized
DEBUG - 2012-01-12 00:13:22 --> Input Class Initialized
DEBUG - 2012-01-12 00:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:13:22 --> Language Class Initialized
DEBUG - 2012-01-12 00:13:22 --> Loader Class Initialized
DEBUG - 2012-01-12 00:13:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:13:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:13:22 --> Session Class Initialized
DEBUG - 2012-01-12 00:13:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:13:22 --> Session routines successfully run
DEBUG - 2012-01-12 00:13:22 --> Controller Class Initialized
DEBUG - 2012-01-12 00:13:22 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:13:22 --> Final output sent to browser
DEBUG - 2012-01-12 00:13:22 --> Total execution time: 1.1098
DEBUG - 2012-01-12 00:14:05 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:05 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:05 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:05 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:05 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:05 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:05 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:06 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:06 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:06 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:06 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:06 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:14:06 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:14:06 --> Final output sent to browser
DEBUG - 2012-01-12 00:14:06 --> Total execution time: 0.4432
DEBUG - 2012-01-12 00:14:08 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:08 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:08 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:08 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:09 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:09 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:09 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:09 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:09 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:09 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:14:09 --> Final output sent to browser
DEBUG - 2012-01-12 00:14:09 --> Total execution time: 0.4178
DEBUG - 2012-01-12 00:14:14 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:14 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:14 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:14 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:14 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:14 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:14:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:14:14 --> Final output sent to browser
DEBUG - 2012-01-12 00:14:14 --> Total execution time: 0.4833
DEBUG - 2012-01-12 00:14:22 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:22 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:22 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:22 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:22 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:22 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:14:22 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:14:22 --> Final output sent to browser
DEBUG - 2012-01-12 00:14:22 --> Total execution time: 0.4797
DEBUG - 2012-01-12 00:14:24 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:24 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:24 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:24 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:24 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:24 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:24 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:14:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:14:25 --> Final output sent to browser
DEBUG - 2012-01-12 00:14:25 --> Total execution time: 0.3933
DEBUG - 2012-01-12 00:14:26 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:26 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:26 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:26 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:26 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:26 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:26 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:14:26 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:14:26 --> Final output sent to browser
DEBUG - 2012-01-12 00:14:26 --> Total execution time: 0.4389
DEBUG - 2012-01-12 00:14:27 --> Config Class Initialized
DEBUG - 2012-01-12 00:14:27 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:14:27 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:14:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:14:27 --> URI Class Initialized
DEBUG - 2012-01-12 00:14:27 --> Router Class Initialized
DEBUG - 2012-01-12 00:14:27 --> Output Class Initialized
DEBUG - 2012-01-12 00:14:28 --> Security Class Initialized
DEBUG - 2012-01-12 00:14:28 --> Input Class Initialized
DEBUG - 2012-01-12 00:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:14:28 --> Language Class Initialized
DEBUG - 2012-01-12 00:14:28 --> Loader Class Initialized
DEBUG - 2012-01-12 00:14:28 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:14:28 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:14:28 --> Session Class Initialized
DEBUG - 2012-01-12 00:14:28 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:14:28 --> Session routines successfully run
DEBUG - 2012-01-12 00:14:28 --> Controller Class Initialized
DEBUG - 2012-01-12 00:14:28 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 00:14:28 --> Final output sent to browser
DEBUG - 2012-01-12 00:14:28 --> Total execution time: 0.9106
DEBUG - 2012-01-12 00:15:03 --> Config Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:15:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:15:03 --> URI Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Router Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Output Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Security Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Input Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:15:03 --> Language Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Loader Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:15:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Session Class Initialized
DEBUG - 2012-01-12 00:15:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:15:03 --> Session routines successfully run
DEBUG - 2012-01-12 00:15:03 --> Controller Class Initialized
DEBUG - 2012-01-12 00:15:03 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:15:03 --> Final output sent to browser
DEBUG - 2012-01-12 00:15:03 --> Total execution time: 0.3859
DEBUG - 2012-01-12 00:15:33 --> Config Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:15:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:15:33 --> URI Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Router Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Output Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Security Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Input Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:15:33 --> Language Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Loader Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:15:33 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Session Class Initialized
DEBUG - 2012-01-12 00:15:33 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:15:33 --> Session routines successfully run
DEBUG - 2012-01-12 00:15:33 --> Controller Class Initialized
DEBUG - 2012-01-12 00:15:33 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:15:33 --> Final output sent to browser
DEBUG - 2012-01-12 00:15:33 --> Total execution time: 0.4323
DEBUG - 2012-01-12 00:15:35 --> Config Class Initialized
DEBUG - 2012-01-12 00:15:35 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:15:35 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:15:35 --> URI Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Router Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Output Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Security Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Input Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:15:36 --> Language Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Loader Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:15:36 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Session Class Initialized
DEBUG - 2012-01-12 00:15:36 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:15:36 --> Session routines successfully run
DEBUG - 2012-01-12 00:15:36 --> Controller Class Initialized
DEBUG - 2012-01-12 00:15:36 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 00:15:36 --> Final output sent to browser
DEBUG - 2012-01-12 00:15:36 --> Total execution time: 0.4913
DEBUG - 2012-01-12 00:15:40 --> Config Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:15:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:15:40 --> URI Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Router Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Output Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Security Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Input Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:15:40 --> Language Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Loader Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:15:40 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Session Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:15:40 --> Session routines successfully run
DEBUG - 2012-01-12 00:15:40 --> Controller Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Config Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:15:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:15:40 --> URI Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Router Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Output Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Security Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Input Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:15:40 --> Language Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Loader Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:15:40 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Session Class Initialized
DEBUG - 2012-01-12 00:15:40 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:15:40 --> Session routines successfully run
DEBUG - 2012-01-12 00:15:40 --> Controller Class Initialized
DEBUG - 2012-01-12 00:15:40 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 00:15:40 --> Final output sent to browser
DEBUG - 2012-01-12 00:15:40 --> Total execution time: 0.3548
DEBUG - 2012-01-12 00:15:43 --> Config Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:15:43 --> URI Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Router Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Output Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Security Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Input Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:15:43 --> Language Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Loader Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:15:43 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Session Class Initialized
DEBUG - 2012-01-12 00:15:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:15:43 --> Session routines successfully run
DEBUG - 2012-01-12 00:15:43 --> Controller Class Initialized
DEBUG - 2012-01-12 00:15:43 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:15:43 --> Final output sent to browser
DEBUG - 2012-01-12 00:15:43 --> Total execution time: 0.4754
DEBUG - 2012-01-12 00:15:47 --> Config Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:15:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:15:47 --> URI Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Router Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Output Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Security Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Input Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:15:47 --> Language Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Loader Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:15:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Session Class Initialized
DEBUG - 2012-01-12 00:15:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:15:47 --> Session routines successfully run
DEBUG - 2012-01-12 00:15:47 --> Controller Class Initialized
DEBUG - 2012-01-12 00:15:47 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:15:47 --> Final output sent to browser
DEBUG - 2012-01-12 00:15:47 --> Total execution time: 0.4070
DEBUG - 2012-01-12 00:39:33 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:33 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:33 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:33 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:33 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:33 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:33 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:33 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:39:33 --> Final output sent to browser
DEBUG - 2012-01-12 00:39:33 --> Total execution time: 0.4158
DEBUG - 2012-01-12 00:39:42 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:42 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:42 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:42 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:42 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:42 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:42 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:42 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:42 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:42 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:43 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:43 --> A session cookie was not found.
DEBUG - 2012-01-12 00:39:43 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:43 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:43 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 00:39:43 --> Final output sent to browser
DEBUG - 2012-01-12 00:39:43 --> Total execution time: 0.3716
DEBUG - 2012-01-12 00:39:50 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:50 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:51 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:51 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:51 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:51 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:51 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:51 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:51 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:51 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:51 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:51 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:51 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:51 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 00:39:51 --> Final output sent to browser
DEBUG - 2012-01-12 00:39:51 --> Total execution time: 0.3396
DEBUG - 2012-01-12 00:39:54 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:54 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:54 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:54 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:54 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:54 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:55 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:55 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:55 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:39:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:39:55 --> Final output sent to browser
DEBUG - 2012-01-12 00:39:55 --> Total execution time: 0.3451
DEBUG - 2012-01-12 00:39:57 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:57 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:57 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:57 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:57 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:57 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:39:57 --> Final output sent to browser
DEBUG - 2012-01-12 00:39:57 --> Total execution time: 0.4184
DEBUG - 2012-01-12 00:39:59 --> Config Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:39:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:39:59 --> URI Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Router Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Output Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Security Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Input Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:39:59 --> Language Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Loader Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:39:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Session Class Initialized
DEBUG - 2012-01-12 00:39:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:39:59 --> Session routines successfully run
DEBUG - 2012-01-12 00:39:59 --> Controller Class Initialized
DEBUG - 2012-01-12 00:39:59 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:39:59 --> Final output sent to browser
DEBUG - 2012-01-12 00:39:59 --> Total execution time: 0.3753
DEBUG - 2012-01-12 00:40:00 --> Config Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:40:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:40:00 --> URI Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Router Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Output Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Security Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Input Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:40:00 --> Language Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Loader Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:40:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Session Class Initialized
DEBUG - 2012-01-12 00:40:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:40:00 --> Session routines successfully run
DEBUG - 2012-01-12 00:40:00 --> Controller Class Initialized
DEBUG - 2012-01-12 00:40:00 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:40:00 --> Final output sent to browser
DEBUG - 2012-01-12 00:40:00 --> Total execution time: 0.4319
DEBUG - 2012-01-12 00:40:06 --> Config Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:40:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:40:06 --> URI Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Router Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Output Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Security Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Input Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:40:06 --> Language Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Loader Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:40:06 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Session Class Initialized
DEBUG - 2012-01-12 00:40:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:40:07 --> Session routines successfully run
DEBUG - 2012-01-12 00:40:07 --> Controller Class Initialized
DEBUG - 2012-01-12 00:40:07 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:40:07 --> Final output sent to browser
DEBUG - 2012-01-12 00:40:07 --> Total execution time: 0.4137
DEBUG - 2012-01-12 00:41:43 --> Config Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:41:43 --> URI Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Router Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Output Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Security Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Input Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:41:43 --> Language Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Loader Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:41:43 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Session Class Initialized
DEBUG - 2012-01-12 00:41:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:41:43 --> Session routines successfully run
DEBUG - 2012-01-12 00:41:43 --> Controller Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Config Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:41:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:41:44 --> URI Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Router Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Output Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Security Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Input Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:41:44 --> Language Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Loader Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:41:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Session Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:41:44 --> Session routines successfully run
DEBUG - 2012-01-12 00:41:44 --> Controller Class Initialized
DEBUG - 2012-01-12 00:41:44 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:41:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:41:44 --> Final output sent to browser
DEBUG - 2012-01-12 00:41:44 --> Total execution time: 0.3799
DEBUG - 2012-01-12 00:41:50 --> Config Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:41:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:41:50 --> URI Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Router Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Output Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Security Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Input Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:41:50 --> Language Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Loader Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:41:50 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Session Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:41:50 --> Session routines successfully run
DEBUG - 2012-01-12 00:41:50 --> Controller Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Config Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:41:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:41:50 --> URI Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Router Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Output Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Security Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Input Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:41:50 --> Language Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Loader Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:41:50 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Session Class Initialized
DEBUG - 2012-01-12 00:41:50 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:41:50 --> A session cookie was not found.
DEBUG - 2012-01-12 00:41:50 --> Session routines successfully run
DEBUG - 2012-01-12 00:41:50 --> Controller Class Initialized
DEBUG - 2012-01-12 00:41:50 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 00:41:51 --> Final output sent to browser
DEBUG - 2012-01-12 00:41:51 --> Total execution time: 0.3779
DEBUG - 2012-01-12 00:42:01 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:01 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:01 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:01 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:01 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:01 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:01 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:02 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:02 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:02 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:02 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:02 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 00:42:02 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:02 --> Total execution time: 0.3192
DEBUG - 2012-01-12 00:42:07 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:07 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:07 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:07 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:07 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:07 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:07 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:07 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:08 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:08 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:08 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:08 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:08 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:08 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:08 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:08 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:08 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 00:42:08 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:08 --> Total execution time: 0.3212
DEBUG - 2012-01-12 00:42:12 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:12 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:12 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:12 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:12 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:12 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:12 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:12 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:13 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:13 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:13 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:13 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:13 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:42:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:42:13 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:13 --> Total execution time: 0.8357
DEBUG - 2012-01-12 00:42:17 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:17 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:17 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:18 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:18 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:18 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:18 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:42:18 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:18 --> Total execution time: 0.7841
DEBUG - 2012-01-12 00:42:21 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:21 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:21 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:21 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:21 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:21 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:21 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:21 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:42:21 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:21 --> Total execution time: 0.4206
DEBUG - 2012-01-12 00:42:25 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:25 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:25 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:25 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:25 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:25 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:25 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:25 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 00:42:25 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:25 --> Total execution time: 0.3450
DEBUG - 2012-01-12 00:42:28 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:28 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:28 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:28 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:28 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:28 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:28 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:28 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:42:28 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:28 --> Total execution time: 0.3954
DEBUG - 2012-01-12 00:42:29 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:29 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:30 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:30 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:30 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:30 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:30 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:30 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:30 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:42:30 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:30 --> Total execution time: 0.5665
DEBUG - 2012-01-12 00:42:32 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:32 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:32 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:32 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:32 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:32 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 00:42:32 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:32 --> Total execution time: 0.5067
DEBUG - 2012-01-12 00:42:36 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:36 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:36 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:36 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:36 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:36 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:36 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:36 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:42:36 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:36 --> Total execution time: 0.4100
DEBUG - 2012-01-12 00:42:54 --> Config Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:42:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:42:54 --> URI Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Router Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Output Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Security Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Input Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:42:54 --> Language Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Loader Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:42:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Session Class Initialized
DEBUG - 2012-01-12 00:42:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:42:54 --> Session routines successfully run
DEBUG - 2012-01-12 00:42:54 --> Controller Class Initialized
DEBUG - 2012-01-12 00:42:54 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 00:42:54 --> Final output sent to browser
DEBUG - 2012-01-12 00:42:54 --> Total execution time: 0.4113
DEBUG - 2012-01-12 00:43:00 --> Config Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:43:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:43:00 --> URI Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Router Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Output Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Security Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Input Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:43:00 --> Language Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Loader Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:43:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Session Class Initialized
DEBUG - 2012-01-12 00:43:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:43:00 --> Session routines successfully run
DEBUG - 2012-01-12 00:43:00 --> Controller Class Initialized
DEBUG - 2012-01-12 00:43:00 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-12 00:43:00 --> Final output sent to browser
DEBUG - 2012-01-12 00:43:00 --> Total execution time: 0.3876
DEBUG - 2012-01-12 00:43:03 --> Config Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:43:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:43:03 --> URI Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Router Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Output Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Security Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Input Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:43:03 --> Language Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Loader Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:43:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Session Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:43:03 --> Session routines successfully run
DEBUG - 2012-01-12 00:43:03 --> Controller Class Initialized
DEBUG - 2012-01-12 00:43:03 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:43:03 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:43:03 --> Final output sent to browser
DEBUG - 2012-01-12 00:43:03 --> Total execution time: 0.4595
DEBUG - 2012-01-12 00:52:52 --> Config Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:52:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:52:52 --> URI Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Router Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Output Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Security Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Input Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:52:52 --> Language Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Loader Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:52:52 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Session Class Initialized
DEBUG - 2012-01-12 00:52:52 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:52:52 --> Session routines successfully run
DEBUG - 2012-01-12 00:52:52 --> Controller Class Initialized
DEBUG - 2012-01-12 00:52:52 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:52:52 --> Final output sent to browser
DEBUG - 2012-01-12 00:52:52 --> Total execution time: 0.1966
DEBUG - 2012-01-12 00:52:54 --> Config Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:52:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:52:54 --> URI Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Router Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Output Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Security Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Input Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:52:54 --> Language Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Loader Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:52:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Session Class Initialized
DEBUG - 2012-01-12 00:52:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:52:54 --> Session routines successfully run
DEBUG - 2012-01-12 00:52:54 --> Controller Class Initialized
DEBUG - 2012-01-12 00:52:55 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:52:55 --> Final output sent to browser
DEBUG - 2012-01-12 00:52:55 --> Total execution time: 0.1420
DEBUG - 2012-01-12 00:52:58 --> Config Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:52:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:52:58 --> URI Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Router Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Output Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Security Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Input Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:52:58 --> Language Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Loader Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:52:58 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Session Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:52:58 --> Session routines successfully run
DEBUG - 2012-01-12 00:52:58 --> Controller Class Initialized
DEBUG - 2012-01-12 00:52:58 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:52:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:52:58 --> Final output sent to browser
DEBUG - 2012-01-12 00:52:58 --> Total execution time: 0.1963
DEBUG - 2012-01-12 00:53:01 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:01 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:01 --> No URI present. Default controller set.
DEBUG - 2012-01-12 00:53:01 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:01 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:01 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:01 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:02 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:02 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:02 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:02 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:53:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 00:53:02 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:02 --> Total execution time: 0.1644
DEBUG - 2012-01-12 00:53:04 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:04 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:04 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:04 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:04 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:04 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:53:04 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:04 --> Total execution time: 0.3098
DEBUG - 2012-01-12 00:53:06 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:06 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:06 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:06 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:06 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:06 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:06 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:53:06 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:06 --> Total execution time: 0.1675
DEBUG - 2012-01-12 00:53:26 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:26 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:26 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:26 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:26 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:26 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:26 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:26 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:26 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:26 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:26 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:26 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:26 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:53:26 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:26 --> Total execution time: 0.1707
DEBUG - 2012-01-12 00:53:30 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:30 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:30 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:30 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:30 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:30 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:30 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:30 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:53:30 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:30 --> Total execution time: 0.1398
DEBUG - 2012-01-12 00:53:33 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:33 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:33 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:33 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:33 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:33 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:33 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:33 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:53:33 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:33 --> Total execution time: 0.1552
DEBUG - 2012-01-12 00:53:35 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:35 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:35 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:35 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:35 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:35 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:53:35 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:35 --> Total execution time: 0.1388
DEBUG - 2012-01-12 00:53:45 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:45 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:45 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:45 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:45 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:45 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:45 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:45 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:53:45 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:45 --> Total execution time: 0.1509
DEBUG - 2012-01-12 00:53:46 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:46 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:46 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:46 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:46 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:46 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:46 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:46 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:53:46 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:46 --> Total execution time: 0.1345
DEBUG - 2012-01-12 00:53:48 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:48 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:48 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:48 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:48 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:48 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:48 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:48 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:49 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:49 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:49 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:49 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:49 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:49 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:53:49 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:49 --> Total execution time: 0.1386
DEBUG - 2012-01-12 00:53:52 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:52 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:52 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:52 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:52 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:52 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:52 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:52 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:53:52 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:52 --> Total execution time: 0.2030
DEBUG - 2012-01-12 00:53:53 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:53 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:53 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:53 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:53 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:53 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:53 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:53:53 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:53 --> Total execution time: 0.1829
DEBUG - 2012-01-12 00:53:55 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:55 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:55 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:55 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:55 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:53:55 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:55 --> Total execution time: 0.1694
DEBUG - 2012-01-12 00:53:56 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:56 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:56 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:56 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:56 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:56 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:56 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:56 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:53:56 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:56 --> Total execution time: 0.1937
DEBUG - 2012-01-12 00:53:59 --> Config Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:53:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:53:59 --> URI Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Router Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Output Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Security Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Input Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:53:59 --> Language Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Loader Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:53:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Session Class Initialized
DEBUG - 2012-01-12 00:53:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:53:59 --> Session routines successfully run
DEBUG - 2012-01-12 00:53:59 --> Controller Class Initialized
DEBUG - 2012-01-12 00:53:59 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:53:59 --> Final output sent to browser
DEBUG - 2012-01-12 00:53:59 --> Total execution time: 0.1419
DEBUG - 2012-01-12 00:54:00 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:00 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:00 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:00 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:00 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:00 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:54:00 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:00 --> Total execution time: 0.1368
DEBUG - 2012-01-12 00:54:02 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:02 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:02 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:02 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:02 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:02 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:54:02 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:02 --> Total execution time: 0.1623
DEBUG - 2012-01-12 00:54:04 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:04 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:04 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:04 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:04 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:04 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:54:04 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:04 --> Total execution time: 0.2886
DEBUG - 2012-01-12 00:54:06 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:06 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:06 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:06 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:06 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:06 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:06 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:54:06 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:06 --> Total execution time: 0.1411
DEBUG - 2012-01-12 00:54:08 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:08 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:08 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:08 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:08 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:08 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:08 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:08 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:54:08 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:08 --> Total execution time: 0.1677
DEBUG - 2012-01-12 00:54:28 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:28 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:28 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:28 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:28 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:28 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:28 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:29 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:29 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:29 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:29 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:29 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:29 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:29 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:54:29 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:29 --> Total execution time: 0.1486
DEBUG - 2012-01-12 00:54:31 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:31 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:31 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:31 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:31 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:31 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:31 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:31 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:54:31 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:31 --> Total execution time: 0.1479
DEBUG - 2012-01-12 00:54:34 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:34 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:34 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:34 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:35 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:35 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:35 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:35 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:54:35 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:35 --> Total execution time: 0.1842
DEBUG - 2012-01-12 00:54:37 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:37 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:37 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:37 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:37 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:37 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:37 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:37 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:54:37 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:37 --> Total execution time: 0.2704
DEBUG - 2012-01-12 00:54:38 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:38 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:39 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:39 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:39 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:39 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 00:54:39 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:39 --> Total execution time: 0.1794
DEBUG - 2012-01-12 00:54:43 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:43 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:43 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:43 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:43 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:43 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:43 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:54:43 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:43 --> Total execution time: 0.1884
DEBUG - 2012-01-12 00:54:46 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:46 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:46 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:46 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:46 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:46 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:46 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:46 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:54:46 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:46 --> Total execution time: 0.1500
DEBUG - 2012-01-12 00:54:48 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:48 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:48 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:48 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:48 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:48 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:48 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:54:48 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:48 --> Total execution time: 0.2961
DEBUG - 2012-01-12 00:54:51 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:51 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:51 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:51 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:51 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:51 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:51 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:51 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:54:51 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:51 --> Total execution time: 0.1450
DEBUG - 2012-01-12 00:54:54 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:54 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:54 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:54 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:54 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:54:54 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:54 --> Total execution time: 0.3003
DEBUG - 2012-01-12 00:54:55 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:55 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:55 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:55 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:55 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:55 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:54:55 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:55 --> Total execution time: 0.1407
DEBUG - 2012-01-12 00:54:57 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:57 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:57 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:57 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:57 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:58 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:58 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:58 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:58 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:58 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:58 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:58 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:54:58 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:58 --> Total execution time: 0.1880
DEBUG - 2012-01-12 00:54:59 --> Config Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:54:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:54:59 --> URI Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Router Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Output Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Security Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Input Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:54:59 --> Language Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Loader Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:54:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Session Class Initialized
DEBUG - 2012-01-12 00:54:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:54:59 --> Session routines successfully run
DEBUG - 2012-01-12 00:54:59 --> Controller Class Initialized
DEBUG - 2012-01-12 00:54:59 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:54:59 --> Final output sent to browser
DEBUG - 2012-01-12 00:54:59 --> Total execution time: 0.2220
DEBUG - 2012-01-12 00:55:01 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:01 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:01 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:01 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:01 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:01 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:01 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:01 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:55:01 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:01 --> Total execution time: 0.1681
DEBUG - 2012-01-12 00:55:02 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:02 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:02 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:02 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:02 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:02 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:02 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:03 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:03 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:03 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:03 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:55:03 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:03 --> Total execution time: 0.1631
DEBUG - 2012-01-12 00:55:03 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:03 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:03 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:03 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:03 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:04 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 00:55:04 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:04 --> Total execution time: 0.1464
DEBUG - 2012-01-12 00:55:05 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:05 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:05 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:05 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:05 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:05 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:55:05 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:05 --> Total execution time: 0.2143
DEBUG - 2012-01-12 00:55:06 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:06 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:06 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:06 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:06 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:06 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:07 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:07 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:07 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:07 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:07 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:07 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:07 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 00:55:07 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:07 --> Total execution time: 0.1445
DEBUG - 2012-01-12 00:55:11 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:11 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:11 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:11 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:11 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:11 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:11 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:11 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:55:11 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:11 --> Total execution time: 0.1399
DEBUG - 2012-01-12 00:55:13 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:13 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:13 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:13 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:13 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:13 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:13 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:55:13 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:13 --> Total execution time: 0.1447
DEBUG - 2012-01-12 00:55:14 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:14 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:14 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:14 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:14 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:14 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:14 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:14 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:15 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:15 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:15 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:15 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:15 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:15 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:15 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:55:15 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:15 --> Total execution time: 0.2342
DEBUG - 2012-01-12 00:55:24 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:24 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:24 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:24 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:24 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:24 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:24 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:24 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:24 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:24 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:24 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:24 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:24 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:55:24 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:24 --> Total execution time: 0.1656
DEBUG - 2012-01-12 00:55:37 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:37 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:37 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:37 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:37 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:37 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:37 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:37 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:55:37 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:37 --> Total execution time: 0.1440
DEBUG - 2012-01-12 00:55:38 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:38 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:38 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:38 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:38 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:55:38 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:38 --> Total execution time: 0.1364
DEBUG - 2012-01-12 00:55:38 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:38 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:39 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:39 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:39 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:55:39 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:39 --> Total execution time: 0.1758
DEBUG - 2012-01-12 00:55:39 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:39 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:39 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:39 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:39 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:55:39 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:39 --> Total execution time: 0.1773
DEBUG - 2012-01-12 00:55:45 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:45 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:45 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:45 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:45 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:45 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:45 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:45 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 00:55:45 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:45 --> Total execution time: 0.1398
DEBUG - 2012-01-12 00:55:47 --> Config Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:55:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:55:47 --> URI Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Router Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Output Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Security Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Input Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:55:47 --> Language Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Loader Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:55:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Session Class Initialized
DEBUG - 2012-01-12 00:55:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:55:47 --> Session routines successfully run
DEBUG - 2012-01-12 00:55:47 --> Controller Class Initialized
DEBUG - 2012-01-12 00:55:47 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:55:47 --> Final output sent to browser
DEBUG - 2012-01-12 00:55:47 --> Total execution time: 0.1411
DEBUG - 2012-01-12 00:57:38 --> Config Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:57:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:57:38 --> URI Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Router Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Output Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Security Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Input Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:57:38 --> Language Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Loader Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:57:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Session Class Initialized
DEBUG - 2012-01-12 00:57:38 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:57:38 --> Session routines successfully run
DEBUG - 2012-01-12 00:57:38 --> Controller Class Initialized
DEBUG - 2012-01-12 00:57:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:57:38 --> Final output sent to browser
DEBUG - 2012-01-12 00:57:38 --> Total execution time: 0.7641
DEBUG - 2012-01-12 00:57:57 --> Config Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:57:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:57:57 --> URI Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Router Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Output Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Security Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Input Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:57:57 --> Language Class Initialized
DEBUG - 2012-01-12 00:57:57 --> Loader Class Initialized
DEBUG - 2012-01-12 00:57:58 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:57:58 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:57:58 --> Session Class Initialized
DEBUG - 2012-01-12 00:57:58 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:57:58 --> Session routines successfully run
DEBUG - 2012-01-12 00:57:58 --> Controller Class Initialized
DEBUG - 2012-01-12 00:57:58 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 00:57:58 --> Final output sent to browser
DEBUG - 2012-01-12 00:57:58 --> Total execution time: 0.2902
DEBUG - 2012-01-12 00:58:00 --> Config Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:58:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:58:00 --> URI Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Router Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Output Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Security Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Input Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:58:00 --> Language Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Loader Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:58:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Session Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:58:00 --> Session routines successfully run
DEBUG - 2012-01-12 00:58:00 --> Controller Class Initialized
DEBUG - 2012-01-12 00:58:00 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:58:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:58:01 --> Final output sent to browser
DEBUG - 2012-01-12 00:58:01 --> Total execution time: 0.3634
DEBUG - 2012-01-12 00:59:12 --> Config Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:59:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:59:12 --> URI Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Router Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Output Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Security Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Input Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:59:12 --> Language Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Loader Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:59:12 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Session Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:59:12 --> Session routines successfully run
DEBUG - 2012-01-12 00:59:12 --> Controller Class Initialized
DEBUG - 2012-01-12 00:59:12 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:59:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:59:12 --> Final output sent to browser
DEBUG - 2012-01-12 00:59:12 --> Total execution time: 0.3662
DEBUG - 2012-01-12 00:59:44 --> Config Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 00:59:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 00:59:44 --> URI Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Router Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Output Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Security Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Input Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 00:59:44 --> Language Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Loader Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 00:59:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Session Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 00:59:44 --> Session routines successfully run
DEBUG - 2012-01-12 00:59:44 --> Controller Class Initialized
DEBUG - 2012-01-12 00:59:44 --> Pagination Class Initialized
DEBUG - 2012-01-12 00:59:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 00:59:44 --> Final output sent to browser
DEBUG - 2012-01-12 00:59:44 --> Total execution time: 1.1652
DEBUG - 2012-01-12 01:01:01 --> Config Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:01:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:01:01 --> URI Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Router Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Output Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Security Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Input Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:01:01 --> Language Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Loader Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:01:01 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Session Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:01:01 --> Session routines successfully run
DEBUG - 2012-01-12 01:01:01 --> Controller Class Initialized
DEBUG - 2012-01-12 01:01:01 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:01:01 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:01:01 --> Final output sent to browser
DEBUG - 2012-01-12 01:01:01 --> Total execution time: 0.3552
DEBUG - 2012-01-12 01:01:06 --> Config Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:01:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:01:06 --> URI Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Router Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Output Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Security Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Input Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:01:06 --> Language Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Loader Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:01:06 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Session Class Initialized
DEBUG - 2012-01-12 01:01:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:01:06 --> Session routines successfully run
DEBUG - 2012-01-12 01:01:06 --> Controller Class Initialized
DEBUG - 2012-01-12 01:01:06 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:01:06 --> Final output sent to browser
DEBUG - 2012-01-12 01:01:06 --> Total execution time: 0.3406
DEBUG - 2012-01-12 01:01:08 --> Config Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:01:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:01:08 --> URI Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Router Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Output Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Security Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Input Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:01:08 --> Language Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Loader Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:01:08 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Session Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:01:08 --> Session routines successfully run
DEBUG - 2012-01-12 01:01:08 --> Controller Class Initialized
DEBUG - 2012-01-12 01:01:08 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:01:08 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:01:08 --> Final output sent to browser
DEBUG - 2012-01-12 01:01:08 --> Total execution time: 0.4477
DEBUG - 2012-01-12 01:01:10 --> Config Class Initialized
DEBUG - 2012-01-12 01:01:10 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:01:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:01:11 --> URI Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Router Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Output Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Security Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Input Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:01:11 --> Language Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Loader Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:01:11 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Session Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:01:11 --> Session routines successfully run
DEBUG - 2012-01-12 01:01:11 --> Controller Class Initialized
DEBUG - 2012-01-12 01:01:11 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:01:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:01:11 --> Final output sent to browser
DEBUG - 2012-01-12 01:01:11 --> Total execution time: 0.5789
DEBUG - 2012-01-12 01:01:12 --> Config Class Initialized
DEBUG - 2012-01-12 01:01:12 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:01:12 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:01:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:01:13 --> URI Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Router Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Output Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Security Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Input Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:01:13 --> Language Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Loader Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:01:13 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Session Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:01:13 --> Session routines successfully run
DEBUG - 2012-01-12 01:01:13 --> Controller Class Initialized
DEBUG - 2012-01-12 01:01:13 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:01:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:01:13 --> Final output sent to browser
DEBUG - 2012-01-12 01:01:13 --> Total execution time: 0.3914
DEBUG - 2012-01-12 01:01:17 --> Config Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:01:17 --> URI Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Router Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Output Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Security Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Input Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:01:17 --> Config Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Language Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:01:17 --> Loader Class Initialized
DEBUG - 2012-01-12 01:01:17 --> URI Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Router Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:01:17 --> Output Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Security Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Input Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:01:17 --> Session Class Initialized
DEBUG - 2012-01-12 01:01:17 --> Language Class Initialized
DEBUG - 2012-01-12 01:01:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:01:18 --> Session routines successfully run
DEBUG - 2012-01-12 01:01:18 --> Loader Class Initialized
DEBUG - 2012-01-12 01:01:18 --> Controller Class Initialized
DEBUG - 2012-01-12 01:01:18 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:01:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:01:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:01:18 --> Final output sent to browser
DEBUG - 2012-01-12 01:01:18 --> Total execution time: 1.1189
DEBUG - 2012-01-12 01:01:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:01:18 --> Session Class Initialized
DEBUG - 2012-01-12 01:01:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:01:18 --> Session routines successfully run
DEBUG - 2012-01-12 01:01:18 --> Controller Class Initialized
DEBUG - 2012-01-12 01:01:18 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:01:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:01:18 --> Final output sent to browser
DEBUG - 2012-01-12 01:01:18 --> Total execution time: 1.1266
DEBUG - 2012-01-12 01:02:04 --> Config Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:02:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:02:04 --> URI Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Router Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Output Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Security Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Input Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:02:04 --> Language Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Loader Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:02:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Session Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:02:04 --> Session routines successfully run
DEBUG - 2012-01-12 01:02:04 --> Controller Class Initialized
DEBUG - 2012-01-12 01:02:04 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:02:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:02:04 --> Final output sent to browser
DEBUG - 2012-01-12 01:02:04 --> Total execution time: 0.4786
DEBUG - 2012-01-12 01:03:57 --> Config Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:03:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:03:57 --> URI Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Router Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Output Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Security Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Input Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:03:57 --> Language Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Loader Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:03:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Session Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:03:57 --> Session routines successfully run
DEBUG - 2012-01-12 01:03:57 --> Controller Class Initialized
DEBUG - 2012-01-12 01:03:57 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:03:57 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:03:57 --> Final output sent to browser
DEBUG - 2012-01-12 01:03:57 --> Total execution time: 0.4406
DEBUG - 2012-01-12 01:04:02 --> Config Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:04:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:04:02 --> URI Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Router Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Output Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Security Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Input Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:04:02 --> Language Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Loader Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:04:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Session Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:04:02 --> Session routines successfully run
DEBUG - 2012-01-12 01:04:02 --> Controller Class Initialized
DEBUG - 2012-01-12 01:04:02 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:04:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:04:02 --> Final output sent to browser
DEBUG - 2012-01-12 01:04:02 --> Total execution time: 0.5001
DEBUG - 2012-01-12 01:04:04 --> Config Class Initialized
DEBUG - 2012-01-12 01:04:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:04:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:04:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:04:05 --> URI Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Router Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Output Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Security Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Input Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:04:05 --> Language Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Loader Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:04:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Session Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:04:05 --> Session routines successfully run
DEBUG - 2012-01-12 01:04:05 --> Controller Class Initialized
DEBUG - 2012-01-12 01:04:05 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:04:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:04:05 --> Final output sent to browser
DEBUG - 2012-01-12 01:04:05 --> Total execution time: 0.4549
DEBUG - 2012-01-12 01:05:12 --> Config Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:05:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:05:12 --> URI Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Router Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Output Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Security Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Input Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:05:12 --> Language Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Loader Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:05:12 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Session Class Initialized
DEBUG - 2012-01-12 01:05:12 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:05:12 --> Session routines successfully run
DEBUG - 2012-01-12 01:05:12 --> Controller Class Initialized
DEBUG - 2012-01-12 01:05:12 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:05:12 --> Final output sent to browser
DEBUG - 2012-01-12 01:05:12 --> Total execution time: 0.4915
DEBUG - 2012-01-12 01:05:16 --> Config Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:05:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:05:16 --> URI Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Router Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Output Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Security Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Input Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:05:16 --> Language Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Loader Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:05:16 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Session Class Initialized
DEBUG - 2012-01-12 01:05:16 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:05:16 --> Session routines successfully run
DEBUG - 2012-01-12 01:05:16 --> Controller Class Initialized
DEBUG - 2012-01-12 01:05:16 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:05:16 --> Final output sent to browser
DEBUG - 2012-01-12 01:05:16 --> Total execution time: 0.4014
DEBUG - 2012-01-12 01:07:03 --> Config Class Initialized
DEBUG - 2012-01-12 01:07:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:07:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:07:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:07:04 --> URI Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Router Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Output Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Security Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Input Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:07:04 --> Language Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Loader Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:07:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Session Class Initialized
DEBUG - 2012-01-12 01:07:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:07:04 --> Session routines successfully run
DEBUG - 2012-01-12 01:07:04 --> Controller Class Initialized
DEBUG - 2012-01-12 01:07:04 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 01:07:04 --> Final output sent to browser
DEBUG - 2012-01-12 01:07:04 --> Total execution time: 0.4558
DEBUG - 2012-01-12 01:07:07 --> Config Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:07:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:07:07 --> URI Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Router Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Output Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Security Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Input Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:07:07 --> Language Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Loader Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:07:07 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Session Class Initialized
DEBUG - 2012-01-12 01:07:07 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:07:07 --> Session routines successfully run
DEBUG - 2012-01-12 01:07:07 --> Controller Class Initialized
DEBUG - 2012-01-12 01:07:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 01:07:07 --> Final output sent to browser
DEBUG - 2012-01-12 01:07:07 --> Total execution time: 0.4262
DEBUG - 2012-01-12 01:07:09 --> Config Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:07:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:07:09 --> URI Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Router Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Output Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Security Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Input Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:07:09 --> Language Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Loader Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:07:09 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Session Class Initialized
DEBUG - 2012-01-12 01:07:09 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:07:09 --> Session routines successfully run
DEBUG - 2012-01-12 01:07:09 --> Controller Class Initialized
DEBUG - 2012-01-12 01:07:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 01:07:09 --> Final output sent to browser
DEBUG - 2012-01-12 01:07:09 --> Total execution time: 0.4722
DEBUG - 2012-01-12 01:07:14 --> Config Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:07:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:07:14 --> URI Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Router Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Output Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Security Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Input Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:07:14 --> Language Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Loader Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:07:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Session Class Initialized
DEBUG - 2012-01-12 01:07:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:07:14 --> Session routines successfully run
DEBUG - 2012-01-12 01:07:14 --> Controller Class Initialized
DEBUG - 2012-01-12 01:07:14 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:07:14 --> Final output sent to browser
DEBUG - 2012-01-12 01:07:14 --> Total execution time: 0.4216
DEBUG - 2012-01-12 01:07:17 --> Config Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:07:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:07:17 --> URI Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Router Class Initialized
DEBUG - 2012-01-12 01:07:17 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:07:17 --> Output Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Security Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Input Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:07:17 --> Language Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Loader Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:07:17 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Session Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:07:17 --> Session routines successfully run
DEBUG - 2012-01-12 01:07:17 --> Controller Class Initialized
DEBUG - 2012-01-12 01:07:17 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:07:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:07:17 --> Final output sent to browser
DEBUG - 2012-01-12 01:07:17 --> Total execution time: 0.4862
DEBUG - 2012-01-12 01:08:19 --> Config Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:08:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:08:19 --> URI Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Router Class Initialized
DEBUG - 2012-01-12 01:08:19 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:08:19 --> Output Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Security Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Input Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:08:19 --> Language Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Loader Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:08:19 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Session Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:08:19 --> Session routines successfully run
DEBUG - 2012-01-12 01:08:19 --> Controller Class Initialized
DEBUG - 2012-01-12 01:08:19 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:08:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:08:19 --> Final output sent to browser
DEBUG - 2012-01-12 01:08:19 --> Total execution time: 0.5079
DEBUG - 2012-01-12 01:08:24 --> Config Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:08:24 --> URI Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Router Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Output Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Security Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Input Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:08:24 --> Language Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Loader Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:08:24 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Session Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:08:24 --> Session routines successfully run
DEBUG - 2012-01-12 01:08:24 --> Controller Class Initialized
DEBUG - 2012-01-12 01:08:24 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:08:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:08:24 --> Final output sent to browser
DEBUG - 2012-01-12 01:08:24 --> Total execution time: 0.4880
DEBUG - 2012-01-12 01:08:26 --> Config Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:08:26 --> URI Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Router Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Output Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Security Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Input Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:08:26 --> Language Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Loader Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:08:26 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Session Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:08:26 --> Session routines successfully run
DEBUG - 2012-01-12 01:08:26 --> Controller Class Initialized
DEBUG - 2012-01-12 01:08:26 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:08:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:08:26 --> Final output sent to browser
DEBUG - 2012-01-12 01:08:26 --> Total execution time: 0.4594
DEBUG - 2012-01-12 01:08:28 --> Config Class Initialized
DEBUG - 2012-01-12 01:08:28 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:08:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:08:29 --> URI Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Router Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Output Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Security Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Input Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:08:29 --> Language Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Loader Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:08:29 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Session Class Initialized
DEBUG - 2012-01-12 01:08:29 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:08:29 --> Session routines successfully run
DEBUG - 2012-01-12 01:08:29 --> Controller Class Initialized
DEBUG - 2012-01-12 01:08:29 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:08:29 --> Final output sent to browser
DEBUG - 2012-01-12 01:08:29 --> Total execution time: 0.7722
DEBUG - 2012-01-12 01:08:32 --> Config Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:08:32 --> URI Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Router Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Output Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Security Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Input Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:08:32 --> Language Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Loader Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:08:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Session Class Initialized
DEBUG - 2012-01-12 01:08:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:08:32 --> Session routines successfully run
DEBUG - 2012-01-12 01:08:32 --> Controller Class Initialized
DEBUG - 2012-01-12 01:08:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 01:08:32 --> Final output sent to browser
DEBUG - 2012-01-12 01:08:32 --> Total execution time: 0.4142
DEBUG - 2012-01-12 01:08:34 --> Config Class Initialized
DEBUG - 2012-01-12 01:08:34 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:08:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:08:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:08:34 --> URI Class Initialized
DEBUG - 2012-01-12 01:08:34 --> Router Class Initialized
DEBUG - 2012-01-12 01:08:34 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:08:34 --> Output Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Security Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Input Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:08:35 --> Language Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Loader Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:08:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Session Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:08:35 --> Session routines successfully run
DEBUG - 2012-01-12 01:08:35 --> Controller Class Initialized
DEBUG - 2012-01-12 01:08:35 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:08:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:08:35 --> Final output sent to browser
DEBUG - 2012-01-12 01:08:35 --> Total execution time: 1.0827
DEBUG - 2012-01-12 01:09:16 --> Config Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:09:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:09:16 --> URI Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Router Class Initialized
DEBUG - 2012-01-12 01:09:16 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:09:16 --> Output Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Security Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Input Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:09:16 --> Language Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Loader Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:09:16 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Session Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:09:16 --> Session routines successfully run
DEBUG - 2012-01-12 01:09:16 --> Controller Class Initialized
DEBUG - 2012-01-12 01:09:16 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:09:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:09:16 --> Final output sent to browser
DEBUG - 2012-01-12 01:09:16 --> Total execution time: 0.4572
DEBUG - 2012-01-12 01:09:18 --> Config Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:09:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:09:18 --> URI Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Router Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Output Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Security Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Input Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:09:18 --> Language Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Loader Class Initialized
DEBUG - 2012-01-12 01:09:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:09:19 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:09:19 --> Session Class Initialized
DEBUG - 2012-01-12 01:09:19 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:09:19 --> Session routines successfully run
DEBUG - 2012-01-12 01:09:19 --> Controller Class Initialized
ERROR - 2012-01-12 01:09:19 --> Severity: Notice  --> Undefined property: stdClass::$category A:\home\codeigniter.blog\www\application\views\user\article.php 30
DEBUG - 2012-01-12 01:09:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:09:19 --> Final output sent to browser
DEBUG - 2012-01-12 01:09:19 --> Total execution time: 1.2907
DEBUG - 2012-01-12 01:09:35 --> Config Class Initialized
DEBUG - 2012-01-12 01:09:35 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:09:35 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:09:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:09:35 --> URI Class Initialized
DEBUG - 2012-01-12 01:09:35 --> Router Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Output Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Security Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Input Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:09:36 --> Language Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Loader Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:09:36 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Session Class Initialized
DEBUG - 2012-01-12 01:09:36 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:09:36 --> Session routines successfully run
DEBUG - 2012-01-12 01:09:36 --> Controller Class Initialized
ERROR - 2012-01-12 01:09:36 --> Severity: Notice  --> Undefined property: stdClass::$category A:\home\codeigniter.blog\www\application\views\user\article.php 30
DEBUG - 2012-01-12 01:09:36 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:09:36 --> Final output sent to browser
DEBUG - 2012-01-12 01:09:36 --> Total execution time: 1.6265
DEBUG - 2012-01-12 01:09:38 --> Config Class Initialized
DEBUG - 2012-01-12 01:09:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:09:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:09:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:09:38 --> URI Class Initialized
DEBUG - 2012-01-12 01:09:38 --> Router Class Initialized
DEBUG - 2012-01-12 01:09:38 --> Output Class Initialized
DEBUG - 2012-01-12 01:09:38 --> Security Class Initialized
DEBUG - 2012-01-12 01:09:38 --> Input Class Initialized
DEBUG - 2012-01-12 01:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:09:38 --> Language Class Initialized
DEBUG - 2012-01-12 01:09:39 --> Loader Class Initialized
DEBUG - 2012-01-12 01:09:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:09:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:09:39 --> Session Class Initialized
DEBUG - 2012-01-12 01:09:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:09:39 --> Session routines successfully run
DEBUG - 2012-01-12 01:09:39 --> Controller Class Initialized
ERROR - 2012-01-12 01:09:39 --> Severity: Notice  --> Undefined property: stdClass::$category A:\home\codeigniter.blog\www\application\views\user\article.php 30
DEBUG - 2012-01-12 01:09:39 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:09:39 --> Final output sent to browser
DEBUG - 2012-01-12 01:09:39 --> Total execution time: 0.9299
DEBUG - 2012-01-12 01:09:57 --> Config Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:09:57 --> URI Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Router Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Output Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Security Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Input Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:09:57 --> Language Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Loader Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:09:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Session Class Initialized
DEBUG - 2012-01-12 01:09:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:09:58 --> Session routines successfully run
DEBUG - 2012-01-12 01:09:58 --> Controller Class Initialized
DEBUG - 2012-01-12 01:09:58 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:09:58 --> Final output sent to browser
DEBUG - 2012-01-12 01:09:58 --> Total execution time: 1.4226
DEBUG - 2012-01-12 01:10:04 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:04 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:04 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:10:04 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:04 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:04 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:04 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:04 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:10:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:10:04 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:04 --> Total execution time: 0.5420
DEBUG - 2012-01-12 01:10:16 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:16 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:16 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:16 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:17 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:17 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:17 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:17 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:17 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:17 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:10:17 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:17 --> Total execution time: 0.7514
DEBUG - 2012-01-12 01:10:18 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:18 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:18 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:18 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:18 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:18 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:19 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:19 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:19 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:19 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:19 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:19 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:19 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:19 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:19 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:19 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:10:19 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:19 --> Total execution time: 0.7962
DEBUG - 2012-01-12 01:10:21 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:22 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:22 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:10:22 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:22 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:22 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:22 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:22 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:10:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:10:23 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:23 --> Total execution time: 1.0976
DEBUG - 2012-01-12 01:10:24 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:24 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:24 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:25 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:25 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:25 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:25 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:25 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:25 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:10:25 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:25 --> Total execution time: 0.5442
DEBUG - 2012-01-12 01:10:33 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:33 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:33 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:10:33 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:33 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:33 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:33 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:33 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:33 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:10:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:10:33 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:33 --> Total execution time: 0.5280
DEBUG - 2012-01-12 01:10:38 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:38 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:38 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:39 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:39 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:39 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:39 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:10:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:10:39 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:39 --> Total execution time: 0.9688
DEBUG - 2012-01-12 01:10:41 --> Config Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:10:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:10:41 --> URI Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Router Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Output Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Security Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Input Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:10:41 --> Language Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Loader Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:10:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Session Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:10:41 --> Session routines successfully run
DEBUG - 2012-01-12 01:10:41 --> Controller Class Initialized
DEBUG - 2012-01-12 01:10:41 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:10:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:10:41 --> Final output sent to browser
DEBUG - 2012-01-12 01:10:41 --> Total execution time: 0.4934
DEBUG - 2012-01-12 01:11:41 --> Config Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:11:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:11:41 --> URI Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Router Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Output Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Security Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Input Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:11:41 --> Language Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Loader Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:11:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Session Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:11:41 --> Session routines successfully run
DEBUG - 2012-01-12 01:11:41 --> Controller Class Initialized
DEBUG - 2012-01-12 01:11:41 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:11:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:11:41 --> Final output sent to browser
DEBUG - 2012-01-12 01:11:41 --> Total execution time: 0.4699
DEBUG - 2012-01-12 01:11:43 --> Config Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:11:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:11:43 --> URI Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Router Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Output Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Security Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Input Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:11:43 --> Language Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Loader Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:11:43 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Session Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:11:43 --> Session routines successfully run
DEBUG - 2012-01-12 01:11:43 --> Controller Class Initialized
DEBUG - 2012-01-12 01:11:43 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:11:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:11:43 --> Final output sent to browser
DEBUG - 2012-01-12 01:11:43 --> Total execution time: 0.5215
DEBUG - 2012-01-12 01:11:45 --> Config Class Initialized
DEBUG - 2012-01-12 01:11:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:11:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:11:46 --> URI Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Router Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Output Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Security Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Input Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:11:46 --> Language Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Loader Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:11:46 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Session Class Initialized
DEBUG - 2012-01-12 01:11:46 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:11:46 --> Session routines successfully run
DEBUG - 2012-01-12 01:11:46 --> Controller Class Initialized
DEBUG - 2012-01-12 01:11:46 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 01:11:46 --> Final output sent to browser
DEBUG - 2012-01-12 01:11:46 --> Total execution time: 0.5636
DEBUG - 2012-01-12 01:11:48 --> Config Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:11:48 --> URI Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Router Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Output Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Security Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Input Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:11:48 --> Language Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Loader Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:11:48 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Session Class Initialized
DEBUG - 2012-01-12 01:11:48 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:11:48 --> Session routines successfully run
DEBUG - 2012-01-12 01:11:48 --> Controller Class Initialized
DEBUG - 2012-01-12 01:11:48 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-12 01:11:49 --> Final output sent to browser
DEBUG - 2012-01-12 01:11:49 --> Total execution time: 0.4282
DEBUG - 2012-01-12 01:11:51 --> Config Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:11:51 --> URI Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Router Class Initialized
DEBUG - 2012-01-12 01:11:51 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:11:51 --> Output Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Security Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Input Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:11:51 --> Language Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Loader Class Initialized
DEBUG - 2012-01-12 01:11:51 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:11:52 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:11:52 --> Session Class Initialized
DEBUG - 2012-01-12 01:11:52 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:11:52 --> Session routines successfully run
DEBUG - 2012-01-12 01:11:52 --> Controller Class Initialized
DEBUG - 2012-01-12 01:11:52 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:11:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:11:52 --> Final output sent to browser
DEBUG - 2012-01-12 01:11:52 --> Total execution time: 1.1509
DEBUG - 2012-01-12 01:12:53 --> Config Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:12:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:12:53 --> URI Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Router Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Output Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Security Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Input Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:12:53 --> Language Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Loader Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:12:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Session Class Initialized
DEBUG - 2012-01-12 01:12:53 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:12:53 --> Session routines successfully run
DEBUG - 2012-01-12 01:12:53 --> Controller Class Initialized
DEBUG - 2012-01-12 01:12:53 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:12:53 --> Final output sent to browser
DEBUG - 2012-01-12 01:12:53 --> Total execution time: 0.4658
DEBUG - 2012-01-12 01:14:10 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:10 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:10 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:10 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:10 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:10 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:10 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:10 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:10 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:11 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:11 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:11 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:11 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:11 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:11 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:11 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:11 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:14:11 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:11 --> Total execution time: 0.4353
DEBUG - 2012-01-12 01:14:26 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:26 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:26 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:26 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:26 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:26 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:26 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:26 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:14:26 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:26 --> Total execution time: 0.6921
DEBUG - 2012-01-12 01:14:30 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:30 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:30 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:30 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:30 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:30 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:30 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:30 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:14:30 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:30 --> Total execution time: 0.6178
DEBUG - 2012-01-12 01:14:34 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:34 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:34 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:34 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:34 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:34 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:34 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:35 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:14:35 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:35 --> Total execution time: 0.5933
DEBUG - 2012-01-12 01:14:39 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:39 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:39 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:39 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:40 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:40 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:40 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:40 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:40 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:40 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:14:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:14:40 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:40 --> Total execution time: 0.5367
DEBUG - 2012-01-12 01:14:42 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:42 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:42 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:42 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:42 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:42 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:42 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:14:42 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:14:42 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:42 --> Total execution time: 0.4965
DEBUG - 2012-01-12 01:14:44 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:44 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:44 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:44 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:44 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:44 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:14:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:14:44 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:44 --> Total execution time: 0.5167
DEBUG - 2012-01-12 01:14:46 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:46 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:46 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:46 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:46 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:46 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:46 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:47 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:47 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:47 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:47 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:47 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:47 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:47 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:14:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:14:47 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:47 --> Total execution time: 0.4905
DEBUG - 2012-01-12 01:14:49 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:49 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:49 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:49 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:49 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:49 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:14:49 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:49 --> Total execution time: 0.4892
DEBUG - 2012-01-12 01:14:53 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:53 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:53 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:54 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:54 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:54 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:54 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:54 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:54 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:54 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:14:54 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:54 --> Total execution time: 0.4239
DEBUG - 2012-01-12 01:14:57 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:57 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:57 --> Router Class Initialized
DEBUG - 2012-01-12 01:14:57 --> Output Class Initialized
DEBUG - 2012-01-12 01:14:57 --> Security Class Initialized
DEBUG - 2012-01-12 01:14:57 --> Input Class Initialized
DEBUG - 2012-01-12 01:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:14:57 --> Language Class Initialized
DEBUG - 2012-01-12 01:14:58 --> Loader Class Initialized
DEBUG - 2012-01-12 01:14:58 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:14:58 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:14:58 --> Session Class Initialized
DEBUG - 2012-01-12 01:14:58 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:14:58 --> Session routines successfully run
DEBUG - 2012-01-12 01:14:58 --> Controller Class Initialized
DEBUG - 2012-01-12 01:14:58 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:14:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:14:58 --> Final output sent to browser
DEBUG - 2012-01-12 01:14:58 --> Total execution time: 0.4428
DEBUG - 2012-01-12 01:14:59 --> Config Class Initialized
DEBUG - 2012-01-12 01:14:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:14:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:14:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:14:59 --> URI Class Initialized
DEBUG - 2012-01-12 01:14:59 --> Router Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Output Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Security Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Input Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:15:00 --> Language Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Loader Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:15:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Session Class Initialized
DEBUG - 2012-01-12 01:15:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:15:00 --> Session routines successfully run
DEBUG - 2012-01-12 01:15:00 --> Controller Class Initialized
DEBUG - 2012-01-12 01:15:00 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:15:00 --> Final output sent to browser
DEBUG - 2012-01-12 01:15:00 --> Total execution time: 1.1139
DEBUG - 2012-01-12 01:15:02 --> Config Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:15:02 --> URI Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Router Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Output Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Security Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Input Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:15:02 --> Language Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Loader Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:15:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Session Class Initialized
DEBUG - 2012-01-12 01:15:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:15:02 --> Session routines successfully run
DEBUG - 2012-01-12 01:15:02 --> Controller Class Initialized
DEBUG - 2012-01-12 01:15:02 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 01:15:02 --> Final output sent to browser
DEBUG - 2012-01-12 01:15:02 --> Total execution time: 0.5192
DEBUG - 2012-01-12 01:15:58 --> Config Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:15:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:15:58 --> URI Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Router Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Output Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Security Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Input Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:15:58 --> Language Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Loader Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:15:58 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Session Class Initialized
DEBUG - 2012-01-12 01:15:58 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:15:58 --> Session routines successfully run
DEBUG - 2012-01-12 01:15:58 --> Controller Class Initialized
DEBUG - 2012-01-12 01:15:58 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-12 01:15:58 --> Final output sent to browser
DEBUG - 2012-01-12 01:15:58 --> Total execution time: 0.4401
DEBUG - 2012-01-12 01:16:03 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:03 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:04 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:04 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:04 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:05 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:05 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:05 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:05 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:05 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 01:16:05 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:05 --> Total execution time: 0.9211
DEBUG - 2012-01-12 01:16:08 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:08 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:08 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:08 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:08 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:08 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:08 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:08 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:16:08 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:08 --> Total execution time: 0.4727
DEBUG - 2012-01-12 01:16:16 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:17 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:17 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:17 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:17 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:17 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:17 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:16:17 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:17 --> Total execution time: 0.3771
DEBUG - 2012-01-12 01:16:17 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:17 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:17 --> Router Class Initialized
ERROR - 2012-01-12 01:16:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 01:16:19 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:19 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:19 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:19 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:19 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:19 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:19 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:19 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:16:19 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:19 --> Total execution time: 0.3730
DEBUG - 2012-01-12 01:16:20 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:20 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Router Class Initialized
ERROR - 2012-01-12 01:16:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 01:16:20 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:20 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:20 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:20 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:20 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:20 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:20 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:20 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:16:20 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:20 --> Total execution time: 0.3855
DEBUG - 2012-01-12 01:16:21 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:21 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:21 --> Router Class Initialized
ERROR - 2012-01-12 01:16:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 01:16:21 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:22 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:22 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:22 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:22 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:22 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:16:22 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:22 --> Total execution time: 0.7420
DEBUG - 2012-01-12 01:16:23 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:23 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:23 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:23 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:23 --> Router Class Initialized
ERROR - 2012-01-12 01:16:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 01:16:23 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:23 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:23 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:24 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:24 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:24 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:24 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:24 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:16:24 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:16:24 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:24 --> Total execution time: 0.5413
DEBUG - 2012-01-12 01:16:24 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:24 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:24 --> Router Class Initialized
ERROR - 2012-01-12 01:16:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 01:16:25 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:25 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:25 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:25 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:25 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:25 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:25 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:25 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:16:25 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:25 --> Total execution time: 0.6341
DEBUG - 2012-01-12 01:16:26 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:26 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:26 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:26 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:26 --> Router Class Initialized
ERROR - 2012-01-12 01:16:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 01:16:27 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:27 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:28 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Router Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Output Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Security Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Input Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:16:28 --> Language Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Loader Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:16:28 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Session Class Initialized
DEBUG - 2012-01-12 01:16:28 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:16:28 --> Session routines successfully run
DEBUG - 2012-01-12 01:16:28 --> Controller Class Initialized
DEBUG - 2012-01-12 01:16:28 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 01:16:28 --> Final output sent to browser
DEBUG - 2012-01-12 01:16:28 --> Total execution time: 0.9796
DEBUG - 2012-01-12 01:16:29 --> Config Class Initialized
DEBUG - 2012-01-12 01:16:29 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:16:29 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:16:29 --> URI Class Initialized
DEBUG - 2012-01-12 01:16:29 --> Router Class Initialized
ERROR - 2012-01-12 01:16:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 01:25:47 --> Config Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:25:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:25:47 --> URI Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Router Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Output Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Security Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Input Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:25:47 --> Language Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Loader Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:25:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Session Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:25:47 --> Session routines successfully run
DEBUG - 2012-01-12 01:25:47 --> Controller Class Initialized
DEBUG - 2012-01-12 01:25:47 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:25:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:25:47 --> Final output sent to browser
DEBUG - 2012-01-12 01:25:47 --> Total execution time: 0.3486
DEBUG - 2012-01-12 01:26:18 --> Config Class Initialized
DEBUG - 2012-01-12 01:26:18 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:26:18 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:26:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:26:19 --> URI Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Router Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Output Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Security Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Input Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:26:19 --> Language Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Loader Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:26:19 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Session Class Initialized
DEBUG - 2012-01-12 01:26:19 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:26:19 --> Session routines successfully run
DEBUG - 2012-01-12 01:26:19 --> Controller Class Initialized
DEBUG - 2012-01-12 01:26:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-12 01:26:19 --> Final output sent to browser
DEBUG - 2012-01-12 01:26:19 --> Total execution time: 0.4002
DEBUG - 2012-01-12 01:26:23 --> Config Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:26:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:26:23 --> URI Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Router Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Output Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Security Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Input Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:26:23 --> Language Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Loader Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:26:23 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Session Class Initialized
DEBUG - 2012-01-12 01:26:23 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:26:23 --> Session routines successfully run
DEBUG - 2012-01-12 01:26:23 --> Controller Class Initialized
DEBUG - 2012-01-12 01:26:23 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:26:23 --> Final output sent to browser
DEBUG - 2012-01-12 01:26:23 --> Total execution time: 0.4027
DEBUG - 2012-01-12 01:26:35 --> Config Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:26:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:26:35 --> URI Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Router Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Output Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Security Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Input Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:26:35 --> Language Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Loader Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:26:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Session Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:26:35 --> Session routines successfully run
DEBUG - 2012-01-12 01:26:35 --> Controller Class Initialized
DEBUG - 2012-01-12 01:26:35 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:26:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:26:35 --> Final output sent to browser
DEBUG - 2012-01-12 01:26:35 --> Total execution time: 0.3576
DEBUG - 2012-01-12 01:26:39 --> Config Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:26:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:26:39 --> URI Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Router Class Initialized
DEBUG - 2012-01-12 01:26:39 --> No URI present. Default controller set.
DEBUG - 2012-01-12 01:26:39 --> Output Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Security Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Input Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:26:39 --> Language Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Loader Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:26:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Session Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:26:39 --> Session routines successfully run
DEBUG - 2012-01-12 01:26:39 --> Controller Class Initialized
DEBUG - 2012-01-12 01:26:39 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:26:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:26:39 --> Final output sent to browser
DEBUG - 2012-01-12 01:26:39 --> Total execution time: 0.3746
DEBUG - 2012-01-12 01:26:42 --> Config Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:26:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:26:42 --> URI Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Router Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Output Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Security Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Input Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:26:42 --> Language Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Loader Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:26:42 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Session Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:26:42 --> Session routines successfully run
DEBUG - 2012-01-12 01:26:42 --> Controller Class Initialized
DEBUG - 2012-01-12 01:26:42 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:26:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 01:26:42 --> Final output sent to browser
DEBUG - 2012-01-12 01:26:42 --> Total execution time: 0.3966
DEBUG - 2012-01-12 01:26:47 --> Config Class Initialized
DEBUG - 2012-01-12 01:26:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:26:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:26:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:26:48 --> URI Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Router Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Output Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Security Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Input Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:26:48 --> Language Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Loader Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:26:48 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Session Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:26:48 --> Session routines successfully run
DEBUG - 2012-01-12 01:26:48 --> Controller Class Initialized
DEBUG - 2012-01-12 01:26:48 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:26:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:26:48 --> Final output sent to browser
DEBUG - 2012-01-12 01:26:48 --> Total execution time: 0.3977
DEBUG - 2012-01-12 01:26:59 --> Config Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:26:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:26:59 --> URI Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Router Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Output Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Security Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Input Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:26:59 --> Language Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Loader Class Initialized
DEBUG - 2012-01-12 01:26:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:26:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:00 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:00 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:00 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:00 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:27:00 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:00 --> Total execution time: 0.3841
DEBUG - 2012-01-12 01:27:09 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:09 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:09 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:09 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:09 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:09 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:09 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:09 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 01:27:09 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:09 --> Total execution time: 0.3424
DEBUG - 2012-01-12 01:27:18 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:18 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:18 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:18 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:18 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:18 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-12 01:27:18 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:18 --> Total execution time: 0.3431
DEBUG - 2012-01-12 01:27:26 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:26 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:26 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:26 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:27 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:27 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:27 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:27 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:27 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:27 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:27 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:27 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:27 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:27 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:27 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 01:27:27 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:27 --> Total execution time: 0.3364
DEBUG - 2012-01-12 01:27:41 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:41 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:41 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:41 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:41 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:41 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:27:41 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:41 --> Total execution time: 0.3366
DEBUG - 2012-01-12 01:27:44 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:44 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:44 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:44 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:44 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:44 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 01:27:44 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:44 --> Total execution time: 0.3454
DEBUG - 2012-01-12 01:27:47 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:47 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:47 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:47 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:47 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:47 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:47 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:48 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:48 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:48 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:48 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:48 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:48 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:48 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:48 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:27:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:27:48 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:48 --> Total execution time: 0.3764
DEBUG - 2012-01-12 01:27:55 --> Config Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:27:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:27:55 --> URI Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Router Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Output Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Security Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Input Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:27:55 --> Language Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Loader Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:27:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Session Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:27:55 --> Session routines successfully run
DEBUG - 2012-01-12 01:27:55 --> Controller Class Initialized
DEBUG - 2012-01-12 01:27:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:27:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:27:55 --> Final output sent to browser
DEBUG - 2012-01-12 01:27:55 --> Total execution time: 0.3760
DEBUG - 2012-01-12 01:28:02 --> Config Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:28:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:28:02 --> URI Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Router Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Output Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Security Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Input Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:28:02 --> Language Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Loader Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:28:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Session Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:28:02 --> Session routines successfully run
DEBUG - 2012-01-12 01:28:02 --> Controller Class Initialized
DEBUG - 2012-01-12 01:28:02 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:28:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:28:02 --> Final output sent to browser
DEBUG - 2012-01-12 01:28:02 --> Total execution time: 0.3625
DEBUG - 2012-01-12 01:28:07 --> Config Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:28:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:28:07 --> URI Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Router Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Output Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Security Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Input Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:28:07 --> Language Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Loader Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:28:07 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Session Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:28:07 --> Session routines successfully run
DEBUG - 2012-01-12 01:28:07 --> Controller Class Initialized
DEBUG - 2012-01-12 01:28:07 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:28:08 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:28:08 --> Final output sent to browser
DEBUG - 2012-01-12 01:28:08 --> Total execution time: 0.8190
DEBUG - 2012-01-12 01:28:27 --> Config Class Initialized
DEBUG - 2012-01-12 01:28:27 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:28:27 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:28:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:28:27 --> URI Class Initialized
DEBUG - 2012-01-12 01:28:27 --> Router Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Output Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Security Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Input Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:28:28 --> Language Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Loader Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:28:28 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Session Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:28:28 --> Session routines successfully run
DEBUG - 2012-01-12 01:28:28 --> Controller Class Initialized
DEBUG - 2012-01-12 01:28:28 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:28:28 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:28:28 --> Final output sent to browser
DEBUG - 2012-01-12 01:28:28 --> Total execution time: 0.3698
DEBUG - 2012-01-12 01:28:33 --> Config Class Initialized
DEBUG - 2012-01-12 01:28:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:28:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:28:34 --> URI Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Router Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Output Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Security Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Input Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:28:34 --> Language Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Loader Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:28:34 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Session Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:28:34 --> Session routines successfully run
DEBUG - 2012-01-12 01:28:34 --> Controller Class Initialized
DEBUG - 2012-01-12 01:28:34 --> Pagination Class Initialized
DEBUG - 2012-01-12 01:28:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 01:28:34 --> Final output sent to browser
DEBUG - 2012-01-12 01:28:34 --> Total execution time: 0.3733
DEBUG - 2012-01-12 01:29:21 --> Config Class Initialized
DEBUG - 2012-01-12 01:29:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 01:29:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 01:29:21 --> URI Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Router Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Output Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Security Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Input Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 01:29:22 --> Language Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Loader Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 01:29:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Session Class Initialized
DEBUG - 2012-01-12 01:29:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 01:29:22 --> Session routines successfully run
DEBUG - 2012-01-12 01:29:22 --> Controller Class Initialized
DEBUG - 2012-01-12 01:29:22 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 01:29:22 --> Final output sent to browser
DEBUG - 2012-01-12 01:29:22 --> Total execution time: 0.3654
DEBUG - 2012-01-12 08:29:48 --> Config Class Initialized
DEBUG - 2012-01-12 08:29:48 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:29:48 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:29:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:29:48 --> URI Class Initialized
DEBUG - 2012-01-12 08:29:48 --> Router Class Initialized
DEBUG - 2012-01-12 08:29:48 --> Output Class Initialized
DEBUG - 2012-01-12 08:29:48 --> Security Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Input Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:29:49 --> Language Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Loader Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:29:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Session Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:29:49 --> A session cookie was not found.
DEBUG - 2012-01-12 08:29:49 --> Session routines successfully run
DEBUG - 2012-01-12 08:29:49 --> Controller Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Config Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:29:49 --> URI Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Router Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Output Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Security Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Input Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:29:49 --> Language Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Loader Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:29:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Session Class Initialized
DEBUG - 2012-01-12 08:29:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:29:49 --> Session routines successfully run
DEBUG - 2012-01-12 08:29:49 --> Controller Class Initialized
DEBUG - 2012-01-12 08:29:49 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 08:29:49 --> Final output sent to browser
DEBUG - 2012-01-12 08:29:49 --> Total execution time: 0.3457
DEBUG - 2012-01-12 08:29:55 --> Config Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:29:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:29:55 --> URI Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Router Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Output Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Security Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Input Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:29:55 --> Language Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Loader Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:29:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Session Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:29:55 --> Session routines successfully run
DEBUG - 2012-01-12 08:29:55 --> Controller Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Config Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:29:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:29:55 --> URI Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Router Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Output Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Security Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Input Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:29:55 --> Language Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Loader Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:29:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Session Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:29:55 --> Session routines successfully run
DEBUG - 2012-01-12 08:29:55 --> Controller Class Initialized
DEBUG - 2012-01-12 08:29:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 08:29:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 08:29:55 --> Final output sent to browser
DEBUG - 2012-01-12 08:29:55 --> Total execution time: 0.3486
DEBUG - 2012-01-12 08:29:58 --> Config Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:29:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:29:58 --> URI Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Router Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Output Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Security Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Input Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:29:58 --> Language Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Loader Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:29:58 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Session Class Initialized
DEBUG - 2012-01-12 08:29:58 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:29:58 --> Session routines successfully run
DEBUG - 2012-01-12 08:29:58 --> Controller Class Initialized
DEBUG - 2012-01-12 08:29:58 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 08:29:58 --> Final output sent to browser
DEBUG - 2012-01-12 08:29:58 --> Total execution time: 0.3335
DEBUG - 2012-01-12 08:30:02 --> Config Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:30:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:30:02 --> URI Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Router Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Output Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Security Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Input Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:30:02 --> Language Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Loader Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:30:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Session Class Initialized
DEBUG - 2012-01-12 08:30:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:30:02 --> Session routines successfully run
DEBUG - 2012-01-12 08:30:02 --> Controller Class Initialized
DEBUG - 2012-01-12 08:30:02 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 08:30:02 --> Final output sent to browser
DEBUG - 2012-01-12 08:30:02 --> Total execution time: 0.3393
DEBUG - 2012-01-12 08:30:20 --> Config Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:30:20 --> URI Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Router Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Output Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Security Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Input Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:30:20 --> Language Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Loader Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:30:20 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Session Class Initialized
DEBUG - 2012-01-12 08:30:20 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:30:20 --> Session routines successfully run
DEBUG - 2012-01-12 08:30:20 --> Controller Class Initialized
DEBUG - 2012-01-12 08:30:20 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 08:30:20 --> Final output sent to browser
DEBUG - 2012-01-12 08:30:20 --> Total execution time: 0.3353
DEBUG - 2012-01-12 08:30:25 --> Config Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:30:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:30:25 --> URI Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Router Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Output Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Security Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Input Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:30:25 --> Language Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Loader Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:30:25 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Session Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:30:25 --> Session routines successfully run
DEBUG - 2012-01-12 08:30:25 --> Controller Class Initialized
DEBUG - 2012-01-12 08:30:25 --> Pagination Class Initialized
DEBUG - 2012-01-12 08:30:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 08:30:25 --> Final output sent to browser
DEBUG - 2012-01-12 08:30:25 --> Total execution time: 0.3841
DEBUG - 2012-01-12 08:30:35 --> Config Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:30:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:30:35 --> URI Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Router Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Output Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Security Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Input Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:30:35 --> Language Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Loader Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:30:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Session Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:30:35 --> Session routines successfully run
DEBUG - 2012-01-12 08:30:35 --> Controller Class Initialized
DEBUG - 2012-01-12 08:30:35 --> Pagination Class Initialized
DEBUG - 2012-01-12 08:30:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 08:30:35 --> Final output sent to browser
DEBUG - 2012-01-12 08:30:35 --> Total execution time: 0.3732
DEBUG - 2012-01-12 08:30:39 --> Config Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:30:39 --> URI Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Router Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Output Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Security Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Input Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:30:39 --> Language Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Loader Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:30:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Session Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:30:39 --> Session routines successfully run
DEBUG - 2012-01-12 08:30:39 --> Controller Class Initialized
DEBUG - 2012-01-12 08:30:39 --> Pagination Class Initialized
DEBUG - 2012-01-12 08:30:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 08:30:39 --> Final output sent to browser
DEBUG - 2012-01-12 08:30:39 --> Total execution time: 0.3774
DEBUG - 2012-01-12 08:30:43 --> Config Class Initialized
DEBUG - 2012-01-12 08:30:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 08:30:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 08:30:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 08:30:43 --> URI Class Initialized
DEBUG - 2012-01-12 08:30:43 --> Router Class Initialized
DEBUG - 2012-01-12 08:30:43 --> Output Class Initialized
DEBUG - 2012-01-12 08:30:43 --> Security Class Initialized
DEBUG - 2012-01-12 08:30:44 --> Input Class Initialized
DEBUG - 2012-01-12 08:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 08:30:44 --> Language Class Initialized
DEBUG - 2012-01-12 08:30:44 --> Loader Class Initialized
DEBUG - 2012-01-12 08:30:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 08:30:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 08:30:44 --> Session Class Initialized
DEBUG - 2012-01-12 08:30:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 08:30:44 --> Session routines successfully run
DEBUG - 2012-01-12 08:30:44 --> Controller Class Initialized
DEBUG - 2012-01-12 08:30:44 --> Pagination Class Initialized
DEBUG - 2012-01-12 08:30:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 08:30:44 --> Final output sent to browser
DEBUG - 2012-01-12 08:30:44 --> Total execution time: 0.4361
DEBUG - 2012-01-12 21:38:31 --> Config Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Hooks Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Utf8 Class Initialized
DEBUG - 2012-01-12 21:38:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 21:38:31 --> URI Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Router Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Output Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Security Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Input Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 21:38:31 --> Language Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Loader Class Initialized
DEBUG - 2012-01-12 21:38:31 --> Helper loaded: url_helper
DEBUG - 2012-01-12 21:38:31 --> Database Driver Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Session Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 21:38:32 --> A session cookie was not found.
DEBUG - 2012-01-12 21:38:32 --> Session routines successfully run
DEBUG - 2012-01-12 21:38:32 --> Controller Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Config Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Hooks Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Utf8 Class Initialized
DEBUG - 2012-01-12 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 21:38:32 --> URI Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Router Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Output Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Security Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Input Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 21:38:32 --> Language Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Loader Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 21:38:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Session Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 21:38:32 --> Session routines successfully run
DEBUG - 2012-01-12 21:38:32 --> Controller Class Initialized
DEBUG - 2012-01-12 21:38:32 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 21:38:32 --> Final output sent to browser
DEBUG - 2012-01-12 21:38:32 --> Total execution time: 0.1768
DEBUG - 2012-01-12 21:38:32 --> Config Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Hooks Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Utf8 Class Initialized
DEBUG - 2012-01-12 21:38:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 21:38:32 --> URI Class Initialized
DEBUG - 2012-01-12 21:38:32 --> Router Class Initialized
ERROR - 2012-01-12 21:38:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 22:53:15 --> Config Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:53:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:53:15 --> URI Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Router Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Output Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Security Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Input Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:53:15 --> Language Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Loader Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:53:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Session Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:53:15 --> Session routines successfully run
DEBUG - 2012-01-12 22:53:15 --> Controller Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Config Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:53:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:53:15 --> URI Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Router Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Output Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Security Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Input Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:53:15 --> Language Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Loader Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:53:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Session Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:53:15 --> Session routines successfully run
DEBUG - 2012-01-12 22:53:15 --> Controller Class Initialized
DEBUG - 2012-01-12 22:53:15 --> Pagination Class Initialized
DEBUG - 2012-01-12 22:53:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 22:53:15 --> Final output sent to browser
DEBUG - 2012-01-12 22:53:15 --> Total execution time: 0.2726
DEBUG - 2012-01-12 22:53:16 --> Config Class Initialized
DEBUG - 2012-01-12 22:53:16 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:53:16 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:53:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:53:16 --> URI Class Initialized
DEBUG - 2012-01-12 22:53:16 --> Router Class Initialized
ERROR - 2012-01-12 22:53:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 22:53:44 --> Config Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:53:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:53:44 --> URI Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Router Class Initialized
DEBUG - 2012-01-12 22:53:44 --> No URI present. Default controller set.
DEBUG - 2012-01-12 22:53:44 --> Output Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Security Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Input Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:53:44 --> Language Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Loader Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:53:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Session Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:53:44 --> A session cookie was not found.
DEBUG - 2012-01-12 22:53:44 --> Session routines successfully run
DEBUG - 2012-01-12 22:53:44 --> Controller Class Initialized
DEBUG - 2012-01-12 22:53:44 --> Pagination Class Initialized
DEBUG - 2012-01-12 22:53:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 22:53:44 --> Final output sent to browser
DEBUG - 2012-01-12 22:53:44 --> Total execution time: 0.5944
DEBUG - 2012-01-12 22:53:55 --> Config Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:53:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:53:55 --> URI Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Router Class Initialized
DEBUG - 2012-01-12 22:53:55 --> No URI present. Default controller set.
DEBUG - 2012-01-12 22:53:55 --> Output Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Security Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Input Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:53:55 --> Language Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Loader Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:53:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Session Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:53:55 --> Session routines successfully run
DEBUG - 2012-01-12 22:53:55 --> Controller Class Initialized
DEBUG - 2012-01-12 22:53:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 22:53:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-12 22:53:55 --> Final output sent to browser
DEBUG - 2012-01-12 22:53:55 --> Total execution time: 0.1604
DEBUG - 2012-01-12 22:53:59 --> Config Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:53:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:53:59 --> URI Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Router Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Output Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Security Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Input Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:53:59 --> Language Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Loader Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:53:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Session Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:53:59 --> Session routines successfully run
DEBUG - 2012-01-12 22:53:59 --> Controller Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Config Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:53:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:53:59 --> URI Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Router Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Output Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Security Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Input Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:53:59 --> Language Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Loader Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:53:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Session Class Initialized
DEBUG - 2012-01-12 22:53:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:53:59 --> Session routines successfully run
DEBUG - 2012-01-12 22:53:59 --> Controller Class Initialized
DEBUG - 2012-01-12 22:53:59 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-12 22:53:59 --> Final output sent to browser
DEBUG - 2012-01-12 22:53:59 --> Total execution time: 0.1904
DEBUG - 2012-01-12 22:54:02 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:02 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:02 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:02 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:02 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:02 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:02 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:02 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:02 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:02 --> Pagination Class Initialized
DEBUG - 2012-01-12 22:54:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 22:54:02 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:02 --> Total execution time: 0.2043
DEBUG - 2012-01-12 22:54:11 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:11 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:11 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:11 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:11 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:11 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:11 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:12 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 22:54:12 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:12 --> Total execution time: 0.2562
DEBUG - 2012-01-12 22:54:14 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:14 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:14 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:14 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:14 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:14 --> Pagination Class Initialized
DEBUG - 2012-01-12 22:54:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 22:54:14 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:14 --> Total execution time: 0.1561
DEBUG - 2012-01-12 22:54:41 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:41 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:41 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:41 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:41 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:41 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 22:54:41 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:41 --> Total execution time: 0.1986
DEBUG - 2012-01-12 22:54:49 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:49 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:49 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:49 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:49 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:50 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 22:54:50 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:50 --> Total execution time: 0.2434
DEBUG - 2012-01-12 22:54:51 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:51 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:51 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:51 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:51 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:51 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:51 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:51 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 22:54:51 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:51 --> Total execution time: 0.2077
DEBUG - 2012-01-12 22:54:53 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:53 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:53 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:53 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:53 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:53 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:53 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 22:54:53 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:53 --> Total execution time: 0.1346
DEBUG - 2012-01-12 22:54:57 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:57 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:57 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:57 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:57 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:57 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 22:54:57 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:57 --> Total execution time: 0.1510
DEBUG - 2012-01-12 22:54:59 --> Config Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:54:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:54:59 --> URI Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Router Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Output Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Security Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Input Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:54:59 --> Language Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Loader Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:54:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Session Class Initialized
DEBUG - 2012-01-12 22:54:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:54:59 --> Session routines successfully run
DEBUG - 2012-01-12 22:54:59 --> Controller Class Initialized
DEBUG - 2012-01-12 22:54:59 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 22:54:59 --> Final output sent to browser
DEBUG - 2012-01-12 22:54:59 --> Total execution time: 0.1540
DEBUG - 2012-01-12 22:55:00 --> Config Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:55:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:55:00 --> URI Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Router Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Output Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Security Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Input Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:55:00 --> Language Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Loader Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:55:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Session Class Initialized
DEBUG - 2012-01-12 22:55:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:55:00 --> Session routines successfully run
DEBUG - 2012-01-12 22:55:00 --> Controller Class Initialized
DEBUG - 2012-01-12 22:55:00 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 22:55:00 --> Final output sent to browser
DEBUG - 2012-01-12 22:55:00 --> Total execution time: 0.1333
DEBUG - 2012-01-12 22:55:02 --> Config Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:55:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:55:02 --> URI Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Router Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Output Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Security Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Input Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:55:02 --> Language Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Loader Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:55:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Session Class Initialized
DEBUG - 2012-01-12 22:55:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:55:02 --> Session routines successfully run
DEBUG - 2012-01-12 22:55:02 --> Controller Class Initialized
DEBUG - 2012-01-12 22:55:02 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-12 22:55:02 --> Final output sent to browser
DEBUG - 2012-01-12 22:55:02 --> Total execution time: 0.1685
DEBUG - 2012-01-12 22:56:12 --> Config Class Initialized
DEBUG - 2012-01-12 22:56:12 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:56:12 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:56:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:56:12 --> URI Class Initialized
DEBUG - 2012-01-12 22:56:12 --> Router Class Initialized
DEBUG - 2012-01-12 22:56:12 --> Output Class Initialized
DEBUG - 2012-01-12 22:56:12 --> Security Class Initialized
DEBUG - 2012-01-12 22:56:13 --> Input Class Initialized
DEBUG - 2012-01-12 22:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:56:13 --> Language Class Initialized
DEBUG - 2012-01-12 22:56:13 --> Loader Class Initialized
DEBUG - 2012-01-12 22:56:13 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:56:13 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:56:13 --> Session Class Initialized
DEBUG - 2012-01-12 22:56:13 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:56:13 --> Session routines successfully run
DEBUG - 2012-01-12 22:56:13 --> Controller Class Initialized
DEBUG - 2012-01-12 22:56:13 --> Pagination Class Initialized
DEBUG - 2012-01-12 22:56:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 22:56:13 --> Final output sent to browser
DEBUG - 2012-01-12 22:56:13 --> Total execution time: 0.1978
DEBUG - 2012-01-12 22:59:32 --> Config Class Initialized
DEBUG - 2012-01-12 22:59:32 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:59:32 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:59:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:59:33 --> URI Class Initialized
DEBUG - 2012-01-12 22:59:33 --> Router Class Initialized
DEBUG - 2012-01-12 22:59:33 --> Output Class Initialized
DEBUG - 2012-01-12 22:59:33 --> Security Class Initialized
DEBUG - 2012-01-12 22:59:33 --> Input Class Initialized
DEBUG - 2012-01-12 22:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:59:33 --> Language Class Initialized
DEBUG - 2012-01-12 22:59:33 --> Loader Class Initialized
DEBUG - 2012-01-12 22:59:33 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:59:34 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:59:34 --> Session Class Initialized
DEBUG - 2012-01-12 22:59:34 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:59:34 --> Session routines successfully run
DEBUG - 2012-01-12 22:59:34 --> Controller Class Initialized
DEBUG - 2012-01-12 22:59:34 --> Pagination Class Initialized
DEBUG - 2012-01-12 22:59:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 22:59:34 --> Final output sent to browser
DEBUG - 2012-01-12 22:59:34 --> Total execution time: 2.4478
DEBUG - 2012-01-12 22:59:37 --> Config Class Initialized
DEBUG - 2012-01-12 22:59:37 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:59:37 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:59:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:59:37 --> URI Class Initialized
DEBUG - 2012-01-12 22:59:37 --> Router Class Initialized
DEBUG - 2012-01-12 22:59:37 --> Output Class Initialized
DEBUG - 2012-01-12 22:59:37 --> Security Class Initialized
DEBUG - 2012-01-12 22:59:37 --> Input Class Initialized
DEBUG - 2012-01-12 22:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:59:37 --> Language Class Initialized
DEBUG - 2012-01-12 22:59:38 --> Loader Class Initialized
DEBUG - 2012-01-12 22:59:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:59:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:59:38 --> Session Class Initialized
DEBUG - 2012-01-12 22:59:38 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:59:38 --> Session routines successfully run
DEBUG - 2012-01-12 22:59:38 --> Controller Class Initialized
DEBUG - 2012-01-12 22:59:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 22:59:39 --> Final output sent to browser
DEBUG - 2012-01-12 22:59:39 --> Total execution time: 1.7322
DEBUG - 2012-01-12 22:59:40 --> Config Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:59:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:59:40 --> URI Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Router Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Output Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Security Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Input Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:59:40 --> Language Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Loader Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:59:40 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Session Class Initialized
DEBUG - 2012-01-12 22:59:40 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:59:40 --> Session routines successfully run
DEBUG - 2012-01-12 22:59:40 --> Controller Class Initialized
DEBUG - 2012-01-12 22:59:40 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 22:59:40 --> Final output sent to browser
DEBUG - 2012-01-12 22:59:40 --> Total execution time: 0.4124
DEBUG - 2012-01-12 22:59:42 --> Config Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Hooks Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Utf8 Class Initialized
DEBUG - 2012-01-12 22:59:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 22:59:42 --> URI Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Router Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Output Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Security Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Input Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 22:59:42 --> Language Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Loader Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Helper loaded: url_helper
DEBUG - 2012-01-12 22:59:42 --> Database Driver Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Session Class Initialized
DEBUG - 2012-01-12 22:59:42 --> Helper loaded: string_helper
DEBUG - 2012-01-12 22:59:42 --> Session routines successfully run
DEBUG - 2012-01-12 22:59:42 --> Controller Class Initialized
DEBUG - 2012-01-12 22:59:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 22:59:43 --> Final output sent to browser
DEBUG - 2012-01-12 22:59:43 --> Total execution time: 0.7732
DEBUG - 2012-01-12 23:00:53 --> Config Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:00:53 --> URI Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Router Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Output Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Security Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Input Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:00:53 --> Language Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Loader Class Initialized
DEBUG - 2012-01-12 23:00:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:00:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:00:54 --> Session Class Initialized
DEBUG - 2012-01-12 23:00:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:00:54 --> Session routines successfully run
DEBUG - 2012-01-12 23:00:54 --> Controller Class Initialized
DEBUG - 2012-01-12 23:00:54 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:00:54 --> Final output sent to browser
DEBUG - 2012-01-12 23:00:54 --> Total execution time: 0.2095
DEBUG - 2012-01-12 23:00:56 --> Config Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:00:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:00:56 --> URI Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Router Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Output Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Security Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Input Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:00:56 --> Language Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Loader Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:00:56 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Session Class Initialized
DEBUG - 2012-01-12 23:00:56 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:00:56 --> Session routines successfully run
DEBUG - 2012-01-12 23:00:56 --> Controller Class Initialized
DEBUG - 2012-01-12 23:00:56 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:00:56 --> Final output sent to browser
DEBUG - 2012-01-12 23:00:56 --> Total execution time: 0.1622
DEBUG - 2012-01-12 23:00:59 --> Config Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:00:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:00:59 --> URI Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Router Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Output Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Security Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Input Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:00:59 --> Language Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Loader Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:00:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Session Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:00:59 --> Session routines successfully run
DEBUG - 2012-01-12 23:00:59 --> Controller Class Initialized
DEBUG - 2012-01-12 23:00:59 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:00:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:00:59 --> Final output sent to browser
DEBUG - 2012-01-12 23:00:59 --> Total execution time: 0.2787
DEBUG - 2012-01-12 23:01:17 --> Config Class Initialized
DEBUG - 2012-01-12 23:01:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:01:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:01:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:01:17 --> URI Class Initialized
DEBUG - 2012-01-12 23:01:17 --> Router Class Initialized
DEBUG - 2012-01-12 23:01:17 --> Output Class Initialized
DEBUG - 2012-01-12 23:01:17 --> Security Class Initialized
DEBUG - 2012-01-12 23:01:17 --> Input Class Initialized
DEBUG - 2012-01-12 23:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:01:18 --> Language Class Initialized
DEBUG - 2012-01-12 23:01:18 --> Loader Class Initialized
DEBUG - 2012-01-12 23:01:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:01:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:01:18 --> Session Class Initialized
DEBUG - 2012-01-12 23:01:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:01:18 --> Session routines successfully run
DEBUG - 2012-01-12 23:01:18 --> Controller Class Initialized
DEBUG - 2012-01-12 23:01:18 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:01:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:01:18 --> Final output sent to browser
DEBUG - 2012-01-12 23:01:18 --> Total execution time: 0.5664
DEBUG - 2012-01-12 23:01:31 --> Config Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:01:31 --> URI Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Router Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Output Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Security Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Input Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:01:31 --> Language Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Loader Class Initialized
DEBUG - 2012-01-12 23:01:31 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:01:31 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:01:32 --> Session Class Initialized
DEBUG - 2012-01-12 23:01:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:01:32 --> Session routines successfully run
DEBUG - 2012-01-12 23:01:32 --> Controller Class Initialized
DEBUG - 2012-01-12 23:01:32 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:01:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:01:32 --> Final output sent to browser
DEBUG - 2012-01-12 23:01:32 --> Total execution time: 0.3971
DEBUG - 2012-01-12 23:02:57 --> Config Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:02:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:02:57 --> URI Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Router Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Output Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Security Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Input Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:02:57 --> Language Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Loader Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:02:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Session Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:02:57 --> Session routines successfully run
DEBUG - 2012-01-12 23:02:57 --> Controller Class Initialized
DEBUG - 2012-01-12 23:02:57 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:02:57 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:02:57 --> Final output sent to browser
DEBUG - 2012-01-12 23:02:57 --> Total execution time: 0.1710
DEBUG - 2012-01-12 23:04:04 --> Config Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:04:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:04:04 --> URI Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Router Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Output Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Security Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Input Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:04:04 --> Language Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Loader Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:04:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Session Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:04:04 --> Session routines successfully run
DEBUG - 2012-01-12 23:04:04 --> Controller Class Initialized
DEBUG - 2012-01-12 23:04:04 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:04:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:04:04 --> Final output sent to browser
DEBUG - 2012-01-12 23:04:04 --> Total execution time: 0.4181
DEBUG - 2012-01-12 23:04:40 --> Config Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:04:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:04:40 --> URI Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Router Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Output Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Security Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Input Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:04:40 --> Language Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Loader Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:04:40 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Session Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:04:40 --> Session routines successfully run
DEBUG - 2012-01-12 23:04:40 --> Controller Class Initialized
DEBUG - 2012-01-12 23:04:40 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:04:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:04:40 --> Final output sent to browser
DEBUG - 2012-01-12 23:04:40 --> Total execution time: 0.5838
DEBUG - 2012-01-12 23:04:58 --> Config Class Initialized
DEBUG - 2012-01-12 23:04:58 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:04:58 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:04:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:04:58 --> URI Class Initialized
DEBUG - 2012-01-12 23:04:58 --> Router Class Initialized
DEBUG - 2012-01-12 23:04:59 --> Output Class Initialized
DEBUG - 2012-01-12 23:04:59 --> Security Class Initialized
DEBUG - 2012-01-12 23:04:59 --> Input Class Initialized
DEBUG - 2012-01-12 23:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:05:00 --> Language Class Initialized
DEBUG - 2012-01-12 23:05:00 --> Loader Class Initialized
DEBUG - 2012-01-12 23:05:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:05:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:05:00 --> Session Class Initialized
DEBUG - 2012-01-12 23:05:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:05:00 --> Session routines successfully run
DEBUG - 2012-01-12 23:05:00 --> Controller Class Initialized
DEBUG - 2012-01-12 23:05:00 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:05:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:05:00 --> Final output sent to browser
DEBUG - 2012-01-12 23:05:00 --> Total execution time: 2.0940
DEBUG - 2012-01-12 23:05:15 --> Config Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:05:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:05:15 --> URI Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Router Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Output Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Security Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Input Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:05:15 --> Language Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Loader Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:05:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Session Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:05:15 --> Session routines successfully run
DEBUG - 2012-01-12 23:05:15 --> Controller Class Initialized
DEBUG - 2012-01-12 23:05:15 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:05:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:05:15 --> Final output sent to browser
DEBUG - 2012-01-12 23:05:15 --> Total execution time: 0.4933
DEBUG - 2012-01-12 23:06:09 --> Config Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:06:09 --> URI Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Router Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Output Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Security Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Input Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:06:09 --> Language Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Loader Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:06:09 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Session Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:06:09 --> Session routines successfully run
DEBUG - 2012-01-12 23:06:09 --> Controller Class Initialized
DEBUG - 2012-01-12 23:06:09 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:06:09 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:06:09 --> Final output sent to browser
DEBUG - 2012-01-12 23:06:09 --> Total execution time: 0.4177
DEBUG - 2012-01-12 23:06:31 --> Config Class Initialized
DEBUG - 2012-01-12 23:06:31 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:06:31 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:06:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:06:31 --> URI Class Initialized
DEBUG - 2012-01-12 23:06:31 --> Router Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Output Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Security Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Input Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:06:32 --> Language Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Loader Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:06:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Session Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:06:32 --> Session routines successfully run
DEBUG - 2012-01-12 23:06:32 --> Controller Class Initialized
DEBUG - 2012-01-12 23:06:32 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:06:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:06:32 --> Final output sent to browser
DEBUG - 2012-01-12 23:06:32 --> Total execution time: 0.4875
DEBUG - 2012-01-12 23:09:56 --> Config Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:09:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:09:56 --> URI Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Router Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Output Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Security Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Input Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:09:56 --> Language Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Loader Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:09:56 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Session Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:09:56 --> Session routines successfully run
DEBUG - 2012-01-12 23:09:56 --> Controller Class Initialized
DEBUG - 2012-01-12 23:09:56 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:09:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:09:56 --> Final output sent to browser
DEBUG - 2012-01-12 23:09:56 --> Total execution time: 0.7183
DEBUG - 2012-01-12 23:10:24 --> Config Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:10:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:10:24 --> URI Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Router Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Output Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Security Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Input Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:10:24 --> Language Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Loader Class Initialized
DEBUG - 2012-01-12 23:10:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:10:25 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:10:25 --> Session Class Initialized
DEBUG - 2012-01-12 23:10:25 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:10:25 --> Session routines successfully run
DEBUG - 2012-01-12 23:10:25 --> Controller Class Initialized
DEBUG - 2012-01-12 23:10:25 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:10:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:10:25 --> Final output sent to browser
DEBUG - 2012-01-12 23:10:25 --> Total execution time: 0.4897
DEBUG - 2012-01-12 23:10:44 --> Config Class Initialized
DEBUG - 2012-01-12 23:10:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:10:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:10:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:10:44 --> URI Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Router Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Output Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Security Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Input Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:10:45 --> Language Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Loader Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:10:45 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Session Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:10:45 --> Session routines successfully run
DEBUG - 2012-01-12 23:10:45 --> Controller Class Initialized
DEBUG - 2012-01-12 23:10:45 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:10:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:10:45 --> Final output sent to browser
DEBUG - 2012-01-12 23:10:45 --> Total execution time: 0.5031
DEBUG - 2012-01-12 23:10:56 --> Config Class Initialized
DEBUG - 2012-01-12 23:10:56 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:10:56 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:10:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:10:56 --> URI Class Initialized
DEBUG - 2012-01-12 23:10:56 --> Router Class Initialized
DEBUG - 2012-01-12 23:10:56 --> Output Class Initialized
DEBUG - 2012-01-12 23:10:56 --> Security Class Initialized
DEBUG - 2012-01-12 23:10:56 --> Input Class Initialized
DEBUG - 2012-01-12 23:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:10:57 --> Language Class Initialized
DEBUG - 2012-01-12 23:10:57 --> Loader Class Initialized
DEBUG - 2012-01-12 23:10:57 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:10:57 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:10:57 --> Session Class Initialized
DEBUG - 2012-01-12 23:10:57 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:10:57 --> Session routines successfully run
DEBUG - 2012-01-12 23:10:57 --> Controller Class Initialized
DEBUG - 2012-01-12 23:10:57 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:10:57 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:10:57 --> Final output sent to browser
DEBUG - 2012-01-12 23:10:57 --> Total execution time: 0.4694
DEBUG - 2012-01-12 23:12:38 --> Config Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:12:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:12:38 --> URI Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Router Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Output Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Security Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Input Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:12:38 --> Language Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Loader Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:12:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Session Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:12:38 --> Session routines successfully run
DEBUG - 2012-01-12 23:12:38 --> Controller Class Initialized
DEBUG - 2012-01-12 23:12:38 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:12:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:12:38 --> Final output sent to browser
DEBUG - 2012-01-12 23:12:38 --> Total execution time: 0.5087
DEBUG - 2012-01-12 23:13:15 --> Config Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:13:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:13:15 --> URI Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Router Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Output Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Security Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Input Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:13:15 --> Language Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Loader Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:13:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Session Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:13:15 --> Session routines successfully run
DEBUG - 2012-01-12 23:13:15 --> Controller Class Initialized
DEBUG - 2012-01-12 23:13:15 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:13:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:13:15 --> Final output sent to browser
DEBUG - 2012-01-12 23:13:15 --> Total execution time: 0.4612
DEBUG - 2012-01-12 23:13:39 --> Config Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:13:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:13:39 --> URI Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Router Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Output Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Security Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Input Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:13:39 --> Language Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Loader Class Initialized
DEBUG - 2012-01-12 23:13:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:13:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:13:40 --> Session Class Initialized
DEBUG - 2012-01-12 23:13:40 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:13:40 --> Session routines successfully run
DEBUG - 2012-01-12 23:13:40 --> Controller Class Initialized
DEBUG - 2012-01-12 23:13:40 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:13:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:13:40 --> Final output sent to browser
DEBUG - 2012-01-12 23:13:40 --> Total execution time: 0.4344
DEBUG - 2012-01-12 23:13:54 --> Config Class Initialized
DEBUG - 2012-01-12 23:13:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:13:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:13:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:13:54 --> URI Class Initialized
DEBUG - 2012-01-12 23:13:54 --> Router Class Initialized
DEBUG - 2012-01-12 23:13:54 --> Output Class Initialized
DEBUG - 2012-01-12 23:13:54 --> Security Class Initialized
DEBUG - 2012-01-12 23:13:54 --> Input Class Initialized
DEBUG - 2012-01-12 23:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:13:55 --> Language Class Initialized
DEBUG - 2012-01-12 23:13:55 --> Loader Class Initialized
DEBUG - 2012-01-12 23:13:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:13:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:13:55 --> Session Class Initialized
DEBUG - 2012-01-12 23:13:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:13:55 --> Session routines successfully run
DEBUG - 2012-01-12 23:13:55 --> Controller Class Initialized
DEBUG - 2012-01-12 23:13:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:13:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:13:55 --> Final output sent to browser
DEBUG - 2012-01-12 23:13:55 --> Total execution time: 0.4109
DEBUG - 2012-01-12 23:14:27 --> Config Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:14:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:14:27 --> URI Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Router Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Output Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Security Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Input Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:14:27 --> Language Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Loader Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:14:27 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Session Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:14:27 --> Session routines successfully run
DEBUG - 2012-01-12 23:14:27 --> Controller Class Initialized
DEBUG - 2012-01-12 23:14:27 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:14:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:14:27 --> Final output sent to browser
DEBUG - 2012-01-12 23:14:27 --> Total execution time: 1.5972
DEBUG - 2012-01-12 23:16:46 --> Config Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:16:46 --> URI Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Router Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Output Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Security Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Input Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:16:46 --> Language Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Loader Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:16:46 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Session Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:16:46 --> Session routines successfully run
DEBUG - 2012-01-12 23:16:46 --> Controller Class Initialized
DEBUG - 2012-01-12 23:16:46 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:16:46 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:16:46 --> Final output sent to browser
DEBUG - 2012-01-12 23:16:46 --> Total execution time: 0.5108
DEBUG - 2012-01-12 23:20:53 --> Config Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:20:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:20:53 --> URI Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Router Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Output Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Security Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Input Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:20:53 --> Language Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Loader Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:20:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Session Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:20:53 --> Session routines successfully run
DEBUG - 2012-01-12 23:20:53 --> Controller Class Initialized
DEBUG - 2012-01-12 23:20:53 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:20:53 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:20:53 --> Final output sent to browser
DEBUG - 2012-01-12 23:20:53 --> Total execution time: 0.4482
DEBUG - 2012-01-12 23:21:29 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:30 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Router Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Output Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Security Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Input Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:21:30 --> Language Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Loader Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:21:30 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Session Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:21:30 --> Session routines successfully run
DEBUG - 2012-01-12 23:21:30 --> Controller Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:21:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:21:30 --> Final output sent to browser
DEBUG - 2012-01-12 23:21:30 --> Total execution time: 0.3693
DEBUG - 2012-01-12 23:21:30 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:30 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:30 --> Router Class Initialized
ERROR - 2012-01-12 23:21:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 23:21:32 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:32 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Router Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Output Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Security Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Input Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:21:32 --> Language Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Loader Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:21:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Session Class Initialized
DEBUG - 2012-01-12 23:21:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:21:32 --> Session routines successfully run
DEBUG - 2012-01-12 23:21:32 --> Controller Class Initialized
DEBUG - 2012-01-12 23:21:32 --> DB Transaction Failure
ERROR - 2012-01-12 23:21:32 --> Query error: Unknown column 'id_categiry' in 'where clause'
DEBUG - 2012-01-12 23:21:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-12 23:21:33 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:33 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:33 --> Router Class Initialized
ERROR - 2012-01-12 23:21:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 23:21:49 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:49 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Router Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Output Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Security Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Input Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:21:49 --> Language Class Initialized
DEBUG - 2012-01-12 23:21:49 --> Loader Class Initialized
DEBUG - 2012-01-12 23:21:50 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:21:50 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:21:50 --> Session Class Initialized
DEBUG - 2012-01-12 23:21:50 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:21:50 --> Session routines successfully run
DEBUG - 2012-01-12 23:21:50 --> Controller Class Initialized
DEBUG - 2012-01-12 23:21:50 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:21:50 --> Final output sent to browser
DEBUG - 2012-01-12 23:21:50 --> Total execution time: 0.5089
DEBUG - 2012-01-12 23:21:52 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:52 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:52 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:52 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Router Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Output Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Security Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Input Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:21:53 --> Language Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Loader Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:21:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Session Class Initialized
DEBUG - 2012-01-12 23:21:53 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:21:53 --> Session routines successfully run
DEBUG - 2012-01-12 23:21:53 --> Controller Class Initialized
DEBUG - 2012-01-12 23:21:53 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:21:53 --> Final output sent to browser
DEBUG - 2012-01-12 23:21:53 --> Total execution time: 0.3835
DEBUG - 2012-01-12 23:21:54 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:54 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:54 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:55 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Router Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Output Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Security Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Input Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:21:55 --> Language Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Loader Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:21:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Session Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:21:55 --> Session routines successfully run
DEBUG - 2012-01-12 23:21:55 --> Controller Class Initialized
DEBUG - 2012-01-12 23:21:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:21:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:21:55 --> Final output sent to browser
DEBUG - 2012-01-12 23:21:55 --> Total execution time: 1.1438
DEBUG - 2012-01-12 23:21:58 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:58 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:58 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:58 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:58 --> Router Class Initialized
DEBUG - 2012-01-12 23:21:58 --> Output Class Initialized
DEBUG - 2012-01-12 23:21:58 --> Security Class Initialized
DEBUG - 2012-01-12 23:21:58 --> Input Class Initialized
DEBUG - 2012-01-12 23:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:21:58 --> Language Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Loader Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:21:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Session Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:21:59 --> Session routines successfully run
DEBUG - 2012-01-12 23:21:59 --> Controller Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Config Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:21:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:21:59 --> URI Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Router Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Output Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Security Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Input Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:21:59 --> Language Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Loader Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:21:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Session Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:21:59 --> Session routines successfully run
DEBUG - 2012-01-12 23:21:59 --> Controller Class Initialized
DEBUG - 2012-01-12 23:21:59 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:21:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:21:59 --> Final output sent to browser
DEBUG - 2012-01-12 23:21:59 --> Total execution time: 0.4470
DEBUG - 2012-01-12 23:22:03 --> Config Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:22:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:22:03 --> URI Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Router Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Output Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Security Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Input Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:22:03 --> Language Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Loader Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:22:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Session Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:22:03 --> Session routines successfully run
DEBUG - 2012-01-12 23:22:03 --> Controller Class Initialized
DEBUG - 2012-01-12 23:22:03 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:22:03 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:22:03 --> Final output sent to browser
DEBUG - 2012-01-12 23:22:03 --> Total execution time: 0.4164
DEBUG - 2012-01-12 23:26:29 --> Config Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:26:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:26:29 --> URI Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Router Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Output Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Security Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Input Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:26:29 --> Language Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Loader Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:26:29 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:26:29 --> Session Class Initialized
DEBUG - 2012-01-12 23:26:30 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:26:30 --> Session routines successfully run
DEBUG - 2012-01-12 23:26:30 --> Controller Class Initialized
DEBUG - 2012-01-12 23:26:30 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:26:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:26:30 --> Final output sent to browser
DEBUG - 2012-01-12 23:26:30 --> Total execution time: 0.3940
DEBUG - 2012-01-12 23:27:10 --> Config Class Initialized
DEBUG - 2012-01-12 23:27:10 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:27:10 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:27:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:27:10 --> URI Class Initialized
DEBUG - 2012-01-12 23:27:10 --> Router Class Initialized
DEBUG - 2012-01-12 23:27:10 --> Output Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Security Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Input Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:27:11 --> Language Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Loader Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:27:11 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Session Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:27:11 --> Session routines successfully run
DEBUG - 2012-01-12 23:27:11 --> Controller Class Initialized
DEBUG - 2012-01-12 23:27:11 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:27:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:27:11 --> Final output sent to browser
DEBUG - 2012-01-12 23:27:11 --> Total execution time: 0.3747
DEBUG - 2012-01-12 23:27:29 --> Config Class Initialized
DEBUG - 2012-01-12 23:27:29 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:27:29 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:27:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:27:30 --> URI Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Router Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Output Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Security Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Input Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:27:30 --> Language Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Loader Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:27:30 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Session Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:27:30 --> Session routines successfully run
DEBUG - 2012-01-12 23:27:30 --> Controller Class Initialized
DEBUG - 2012-01-12 23:27:30 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:27:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:27:30 --> Final output sent to browser
DEBUG - 2012-01-12 23:27:30 --> Total execution time: 0.3983
DEBUG - 2012-01-12 23:28:01 --> Config Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:28:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:28:02 --> URI Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Router Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Output Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Security Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Input Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:28:02 --> Language Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Loader Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:28:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Session Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:28:02 --> Session routines successfully run
DEBUG - 2012-01-12 23:28:02 --> Controller Class Initialized
DEBUG - 2012-01-12 23:28:02 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:28:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:28:02 --> Final output sent to browser
DEBUG - 2012-01-12 23:28:02 --> Total execution time: 0.4726
DEBUG - 2012-01-12 23:28:22 --> Config Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:28:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:28:22 --> URI Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Router Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Output Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Security Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Input Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:28:22 --> Language Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Loader Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:28:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Session Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:28:22 --> Session routines successfully run
DEBUG - 2012-01-12 23:28:22 --> Controller Class Initialized
DEBUG - 2012-01-12 23:28:22 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:28:22 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:28:22 --> Final output sent to browser
DEBUG - 2012-01-12 23:28:22 --> Total execution time: 0.5284
DEBUG - 2012-01-12 23:28:42 --> Config Class Initialized
DEBUG - 2012-01-12 23:28:42 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:28:42 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:28:42 --> URI Class Initialized
DEBUG - 2012-01-12 23:28:42 --> Router Class Initialized
ERROR - 2012-01-12 23:28:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 23:28:44 --> Config Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:28:44 --> URI Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Router Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Output Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Security Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Input Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:28:44 --> Language Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Loader Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:28:44 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Session Class Initialized
DEBUG - 2012-01-12 23:28:44 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:28:44 --> Session routines successfully run
DEBUG - 2012-01-12 23:28:44 --> Controller Class Initialized
DEBUG - 2012-01-12 23:28:45 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:28:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:28:45 --> Final output sent to browser
DEBUG - 2012-01-12 23:28:45 --> Total execution time: 0.3699
DEBUG - 2012-01-12 23:28:45 --> Config Class Initialized
DEBUG - 2012-01-12 23:28:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:28:45 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:28:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:28:45 --> URI Class Initialized
DEBUG - 2012-01-12 23:28:45 --> Router Class Initialized
ERROR - 2012-01-12 23:28:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-12 23:31:31 --> Config Class Initialized
DEBUG - 2012-01-12 23:31:31 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:31:31 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:31:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:31:31 --> URI Class Initialized
DEBUG - 2012-01-12 23:31:31 --> Router Class Initialized
DEBUG - 2012-01-12 23:31:31 --> Output Class Initialized
DEBUG - 2012-01-12 23:31:31 --> Security Class Initialized
DEBUG - 2012-01-12 23:31:31 --> Input Class Initialized
DEBUG - 2012-01-12 23:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:31:32 --> Language Class Initialized
DEBUG - 2012-01-12 23:31:32 --> Loader Class Initialized
DEBUG - 2012-01-12 23:31:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:31:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:31:32 --> Session Class Initialized
DEBUG - 2012-01-12 23:31:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:31:32 --> Session routines successfully run
DEBUG - 2012-01-12 23:31:32 --> Controller Class Initialized
ERROR - 2012-01-12 23:31:32 --> 404 Page Not Found --> category/create
DEBUG - 2012-01-12 23:33:34 --> Config Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:33:34 --> URI Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Router Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Output Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Security Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Input Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:33:34 --> Language Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Loader Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:33:34 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Session Class Initialized
DEBUG - 2012-01-12 23:33:34 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:33:34 --> Session routines successfully run
DEBUG - 2012-01-12 23:33:34 --> Controller Class Initialized
DEBUG - 2012-01-12 23:33:35 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:33:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:33:35 --> Final output sent to browser
DEBUG - 2012-01-12 23:33:35 --> Total execution time: 0.5626
DEBUG - 2012-01-12 23:33:37 --> Config Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:33:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:33:37 --> URI Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Router Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Output Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Security Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Input Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:33:37 --> Language Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Loader Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:33:37 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Session Class Initialized
DEBUG - 2012-01-12 23:33:37 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:33:37 --> Session routines successfully run
DEBUG - 2012-01-12 23:33:37 --> Controller Class Initialized
ERROR - 2012-01-12 23:33:37 --> 404 Page Not Found --> category/create
DEBUG - 2012-01-12 23:33:42 --> Config Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:33:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:33:43 --> URI Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Router Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Output Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Security Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Input Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:33:43 --> Language Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Loader Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:33:43 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Session Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:33:43 --> Session routines successfully run
DEBUG - 2012-01-12 23:33:43 --> Controller Class Initialized
DEBUG - 2012-01-12 23:33:43 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:33:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:33:43 --> Final output sent to browser
DEBUG - 2012-01-12 23:33:43 --> Total execution time: 1.0872
DEBUG - 2012-01-12 23:33:45 --> Config Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:33:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:33:45 --> URI Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Router Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Output Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Security Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Input Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:33:45 --> Language Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Loader Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:33:45 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Session Class Initialized
DEBUG - 2012-01-12 23:33:45 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:33:45 --> Session routines successfully run
DEBUG - 2012-01-12 23:33:45 --> Controller Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Config Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:33:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:33:49 --> URI Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Router Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Output Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Security Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Input Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:33:49 --> Language Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Loader Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:33:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Session Class Initialized
DEBUG - 2012-01-12 23:33:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:33:49 --> Session routines successfully run
DEBUG - 2012-01-12 23:33:49 --> Controller Class Initialized
ERROR - 2012-01-12 23:33:49 --> 404 Page Not Found --> category/create
DEBUG - 2012-01-12 23:35:57 --> Config Class Initialized
DEBUG - 2012-01-12 23:35:57 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:35:57 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:35:58 --> URI Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Router Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Output Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Security Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Input Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:35:58 --> Language Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Loader Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:35:58 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Session Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:35:58 --> Session routines successfully run
DEBUG - 2012-01-12 23:35:58 --> Controller Class Initialized
DEBUG - 2012-01-12 23:35:58 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:35:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:35:58 --> Final output sent to browser
DEBUG - 2012-01-12 23:35:58 --> Total execution time: 0.5692
DEBUG - 2012-01-12 23:36:00 --> Config Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:36:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:36:00 --> URI Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Router Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Output Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Security Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Input Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:36:00 --> Language Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Loader Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:36:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Session Class Initialized
DEBUG - 2012-01-12 23:36:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:36:00 --> Session routines successfully run
DEBUG - 2012-01-12 23:36:00 --> Controller Class Initialized
ERROR - 2012-01-12 23:36:00 --> 404 Page Not Found --> category/create
DEBUG - 2012-01-12 23:37:21 --> Config Class Initialized
DEBUG - 2012-01-12 23:37:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:37:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:37:22 --> URI Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Router Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Output Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Security Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Input Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:37:22 --> Language Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Loader Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:37:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Session Class Initialized
DEBUG - 2012-01-12 23:37:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:37:22 --> Session routines successfully run
DEBUG - 2012-01-12 23:37:22 --> Controller Class Initialized
ERROR - 2012-01-12 23:37:22 --> Severity: Notice  --> Undefined variable: pages A:\home\codeigniter.blog\www\application\views\admin\category_new.php 48
DEBUG - 2012-01-12 23:37:22 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:37:22 --> Final output sent to browser
DEBUG - 2012-01-12 23:37:22 --> Total execution time: 0.4433
DEBUG - 2012-01-12 23:38:47 --> Config Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:38:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:38:47 --> URI Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Router Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Output Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Security Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Input Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:38:47 --> Language Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Loader Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:38:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Session Class Initialized
DEBUG - 2012-01-12 23:38:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:38:47 --> Session routines successfully run
DEBUG - 2012-01-12 23:38:47 --> Controller Class Initialized
ERROR - 2012-01-12 23:38:47 --> Severity: Notice  --> Undefined variable: pages A:\home\codeigniter.blog\www\application\views\admin\category_new.php 48
DEBUG - 2012-01-12 23:38:47 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:38:47 --> Final output sent to browser
DEBUG - 2012-01-12 23:38:47 --> Total execution time: 0.4173
DEBUG - 2012-01-12 23:40:59 --> Config Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:40:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:40:59 --> URI Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Router Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Output Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Security Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Input Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:40:59 --> Language Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Loader Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:40:59 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Session Class Initialized
DEBUG - 2012-01-12 23:40:59 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:40:59 --> Session routines successfully run
DEBUG - 2012-01-12 23:40:59 --> Controller Class Initialized
DEBUG - 2012-01-12 23:40:59 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:40:59 --> Final output sent to browser
DEBUG - 2012-01-12 23:40:59 --> Total execution time: 0.3963
DEBUG - 2012-01-12 23:41:22 --> Config Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:41:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:41:22 --> URI Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Router Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Output Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Security Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Input Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:41:22 --> Language Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Loader Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:41:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Session Class Initialized
DEBUG - 2012-01-12 23:41:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:41:22 --> Session routines successfully run
DEBUG - 2012-01-12 23:41:22 --> Controller Class Initialized
DEBUG - 2012-01-12 23:41:22 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:41:22 --> Final output sent to browser
DEBUG - 2012-01-12 23:41:23 --> Total execution time: 0.4090
DEBUG - 2012-01-12 23:41:40 --> Config Class Initialized
DEBUG - 2012-01-12 23:41:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:41:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:41:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:41:41 --> URI Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Router Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Output Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Security Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Input Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:41:41 --> Language Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Loader Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:41:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Session Class Initialized
DEBUG - 2012-01-12 23:41:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:41:41 --> Session routines successfully run
DEBUG - 2012-01-12 23:41:41 --> Controller Class Initialized
DEBUG - 2012-01-12 23:41:41 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:41:41 --> Final output sent to browser
DEBUG - 2012-01-12 23:41:41 --> Total execution time: 0.4663
DEBUG - 2012-01-12 23:41:48 --> Config Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:41:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:41:48 --> URI Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Router Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Output Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Security Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Input Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:41:48 --> Language Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Loader Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:41:48 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Session Class Initialized
DEBUG - 2012-01-12 23:41:48 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:41:48 --> Session routines successfully run
DEBUG - 2012-01-12 23:41:48 --> Controller Class Initialized
DEBUG - 2012-01-12 23:41:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:41:48 --> Final output sent to browser
DEBUG - 2012-01-12 23:41:48 --> Total execution time: 0.4041
DEBUG - 2012-01-12 23:41:50 --> Config Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:41:50 --> URI Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Router Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Output Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Security Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Input Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:41:50 --> Language Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Loader Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:41:50 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Session Class Initialized
DEBUG - 2012-01-12 23:41:50 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:41:50 --> Session routines successfully run
DEBUG - 2012-01-12 23:41:50 --> Controller Class Initialized
DEBUG - 2012-01-12 23:41:50 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-12 23:41:50 --> Final output sent to browser
DEBUG - 2012-01-12 23:41:50 --> Total execution time: 0.4807
DEBUG - 2012-01-12 23:42:02 --> Config Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:42:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:42:02 --> URI Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Router Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Output Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Security Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Input Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:42:02 --> Language Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Loader Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:42:02 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Session Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:42:02 --> Session routines successfully run
DEBUG - 2012-01-12 23:42:02 --> Controller Class Initialized
DEBUG - 2012-01-12 23:42:02 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:42:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:42:03 --> Final output sent to browser
DEBUG - 2012-01-12 23:42:03 --> Total execution time: 0.5426
DEBUG - 2012-01-12 23:42:04 --> Config Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:42:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:42:04 --> URI Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Router Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Output Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Security Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Input Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:42:04 --> Language Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Loader Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:42:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Session Class Initialized
DEBUG - 2012-01-12 23:42:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:42:04 --> Session routines successfully run
DEBUG - 2012-01-12 23:42:04 --> Controller Class Initialized
DEBUG - 2012-01-12 23:42:04 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:42:04 --> Final output sent to browser
DEBUG - 2012-01-12 23:42:04 --> Total execution time: 0.4632
DEBUG - 2012-01-12 23:42:14 --> Config Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:42:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:42:14 --> URI Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Router Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Output Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Security Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Input Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:42:14 --> Language Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Loader Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:42:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Session Class Initialized
DEBUG - 2012-01-12 23:42:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:42:14 --> Session routines successfully run
DEBUG - 2012-01-12 23:42:14 --> Controller Class Initialized
DEBUG - 2012-01-12 23:42:15 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:42:15 --> Final output sent to browser
DEBUG - 2012-01-12 23:42:15 --> Total execution time: 0.4435
DEBUG - 2012-01-12 23:43:53 --> Config Class Initialized
DEBUG - 2012-01-12 23:43:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:43:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:43:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:43:53 --> URI Class Initialized
DEBUG - 2012-01-12 23:43:53 --> Router Class Initialized
DEBUG - 2012-01-12 23:43:53 --> Output Class Initialized
DEBUG - 2012-01-12 23:43:53 --> Security Class Initialized
DEBUG - 2012-01-12 23:43:54 --> Input Class Initialized
DEBUG - 2012-01-12 23:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:43:54 --> Language Class Initialized
DEBUG - 2012-01-12 23:43:54 --> Loader Class Initialized
DEBUG - 2012-01-12 23:43:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:43:54 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:43:54 --> Session Class Initialized
DEBUG - 2012-01-12 23:43:54 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:43:54 --> Session routines successfully run
DEBUG - 2012-01-12 23:43:54 --> Controller Class Initialized
DEBUG - 2012-01-12 23:43:54 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:43:54 --> Final output sent to browser
DEBUG - 2012-01-12 23:43:54 --> Total execution time: 0.7212
DEBUG - 2012-01-12 23:43:59 --> Config Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:43:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:43:59 --> URI Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Router Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Output Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Security Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Input Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:43:59 --> Language Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Loader Class Initialized
DEBUG - 2012-01-12 23:43:59 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:00 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:00 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:00 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:00 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:00 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:00 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:00 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:00 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:44:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:44:00 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:00 --> Total execution time: 0.4159
DEBUG - 2012-01-12 23:44:04 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:04 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:04 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:05 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:05 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:05 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:05 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:05 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:06 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:06 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:06 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:06 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:44:06 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:44:06 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:06 --> Total execution time: 0.7461
DEBUG - 2012-01-12 23:44:13 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:13 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:13 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:13 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:13 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:13 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:13 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:13 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:44:13 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:13 --> Total execution time: 0.5539
DEBUG - 2012-01-12 23:44:17 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:17 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:17 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:17 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:17 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:17 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:17 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:17 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:17 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:18 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:18 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:18 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:18 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:44:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:44:18 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:18 --> Total execution time: 0.3815
DEBUG - 2012-01-12 23:44:24 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:24 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:24 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:24 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:24 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:24 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:24 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:24 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-12 23:44:24 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:24 --> Total execution time: 0.8658
DEBUG - 2012-01-12 23:44:31 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:31 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:31 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:31 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:32 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:32 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:32 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:32 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:32 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:32 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:32 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:32 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:32 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:44:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:44:32 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:32 --> Total execution time: 0.4764
DEBUG - 2012-01-12 23:44:35 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:35 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:35 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:35 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:35 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:35 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:35 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:36 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:36 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:36 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:36 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:36 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:36 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:36 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:36 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:36 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:36 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:44:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:44:36 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:36 --> Total execution time: 0.5436
DEBUG - 2012-01-12 23:44:40 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:40 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:40 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:40 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:41 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:41 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:41 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:41 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:41 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:41 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:44:41 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:41 --> Total execution time: 0.4592
DEBUG - 2012-01-12 23:44:46 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:46 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:46 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:47 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:47 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:47 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:47 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:47 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:47 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:44:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:44:47 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:47 --> Total execution time: 0.4844
DEBUG - 2012-01-12 23:44:50 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:50 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:50 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:50 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:50 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:50 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:50 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Config Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:44:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:44:51 --> URI Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Router Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Output Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Security Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Input Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:44:51 --> Language Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Loader Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:44:51 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Session Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:44:51 --> Session routines successfully run
DEBUG - 2012-01-12 23:44:51 --> Controller Class Initialized
DEBUG - 2012-01-12 23:44:51 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:44:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:44:51 --> Final output sent to browser
DEBUG - 2012-01-12 23:44:51 --> Total execution time: 0.5057
DEBUG - 2012-01-12 23:52:21 --> Config Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:52:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:52:21 --> URI Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Router Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Output Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Security Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Input Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:52:21 --> Language Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Loader Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:52:21 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Session Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:52:21 --> Session routines successfully run
DEBUG - 2012-01-12 23:52:21 --> Controller Class Initialized
DEBUG - 2012-01-12 23:52:21 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:52:21 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:52:22 --> Final output sent to browser
DEBUG - 2012-01-12 23:52:22 --> Total execution time: 0.4607
DEBUG - 2012-01-12 23:52:23 --> Config Class Initialized
DEBUG - 2012-01-12 23:52:23 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:52:23 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:52:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:52:24 --> URI Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Router Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Output Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Security Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Input Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:52:24 --> Language Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Loader Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:52:24 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Session Class Initialized
DEBUG - 2012-01-12 23:52:24 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:52:24 --> Session routines successfully run
DEBUG - 2012-01-12 23:52:24 --> Controller Class Initialized
DEBUG - 2012-01-12 23:52:24 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:52:24 --> Final output sent to browser
DEBUG - 2012-01-12 23:52:24 --> Total execution time: 0.7677
DEBUG - 2012-01-12 23:54:08 --> Config Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:54:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:54:08 --> URI Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Router Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Output Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Security Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Input Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:54:08 --> Language Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Loader Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:54:08 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Session Class Initialized
DEBUG - 2012-01-12 23:54:08 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:54:08 --> Session routines successfully run
DEBUG - 2012-01-12 23:54:08 --> Controller Class Initialized
DEBUG - 2012-01-12 23:54:08 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:54:08 --> Final output sent to browser
DEBUG - 2012-01-12 23:54:08 --> Total execution time: 0.4382
DEBUG - 2012-01-12 23:54:12 --> Config Class Initialized
DEBUG - 2012-01-12 23:54:12 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:54:12 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:54:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:54:12 --> URI Class Initialized
DEBUG - 2012-01-12 23:54:12 --> Router Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Output Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Security Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Input Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:54:13 --> Language Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Loader Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:54:13 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Session Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:54:13 --> Session routines successfully run
DEBUG - 2012-01-12 23:54:13 --> Controller Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Config Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:54:13 --> URI Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Router Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Output Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Security Class Initialized
DEBUG - 2012-01-12 23:54:13 --> Input Class Initialized
DEBUG - 2012-01-12 23:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:54:14 --> Language Class Initialized
DEBUG - 2012-01-12 23:54:14 --> Loader Class Initialized
DEBUG - 2012-01-12 23:54:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:54:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:54:14 --> Session Class Initialized
DEBUG - 2012-01-12 23:54:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:54:14 --> Session routines successfully run
DEBUG - 2012-01-12 23:54:14 --> Controller Class Initialized
DEBUG - 2012-01-12 23:54:14 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:54:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:54:14 --> Final output sent to browser
DEBUG - 2012-01-12 23:54:14 --> Total execution time: 1.0545
DEBUG - 2012-01-12 23:54:52 --> Config Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:54:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:54:52 --> URI Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Router Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Output Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Security Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Input Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:54:52 --> Language Class Initialized
DEBUG - 2012-01-12 23:54:52 --> Loader Class Initialized
DEBUG - 2012-01-12 23:54:54 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:54:55 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:54:55 --> Session Class Initialized
DEBUG - 2012-01-12 23:54:55 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:54:55 --> Session routines successfully run
DEBUG - 2012-01-12 23:54:55 --> Controller Class Initialized
DEBUG - 2012-01-12 23:54:55 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:54:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:54:55 --> Final output sent to browser
DEBUG - 2012-01-12 23:54:55 --> Total execution time: 3.1870
DEBUG - 2012-01-12 23:55:02 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:02 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:02 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:02 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:02 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:02 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:02 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:02 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:02 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:03 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:03 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:03 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:03 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:03 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:55:03 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:03 --> Total execution time: 0.5354
DEBUG - 2012-01-12 23:55:09 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:09 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:09 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:09 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:09 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:09 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:09 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:09 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:55:09 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:09 --> Total execution time: 0.7447
DEBUG - 2012-01-12 23:55:13 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:13 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:13 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:13 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:13 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:13 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:13 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:13 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:13 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:14 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:14 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:14 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:14 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:14 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:14 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:15 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:15 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:15 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:15 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:15 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:55:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:55:15 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:15 --> Total execution time: 0.9183
DEBUG - 2012-01-12 23:55:21 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:21 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:21 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:21 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:21 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:21 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:21 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:21 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:55:21 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:21 --> Total execution time: 0.4789
DEBUG - 2012-01-12 23:55:34 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:34 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:34 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:34 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:34 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:34 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:34 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:35 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:35 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:35 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:35 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:35 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:35 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:35 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:35 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:35 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:55:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:55:35 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:35 --> Total execution time: 0.4391
DEBUG - 2012-01-12 23:55:38 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:38 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:38 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:38 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:38 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:38 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:38 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:38 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:55:38 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:38 --> Total execution time: 0.5035
DEBUG - 2012-01-12 23:55:49 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:49 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:49 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:49 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:49 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:50 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:50 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:50 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:50 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:50 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:50 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:55:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:55:50 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:50 --> Total execution time: 0.4380
DEBUG - 2012-01-12 23:55:53 --> Config Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:55:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:55:53 --> URI Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Router Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Output Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Security Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Input Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:55:53 --> Language Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Loader Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:55:53 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Session Class Initialized
DEBUG - 2012-01-12 23:55:53 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:55:53 --> Session routines successfully run
DEBUG - 2012-01-12 23:55:53 --> Controller Class Initialized
DEBUG - 2012-01-12 23:55:53 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:55:53 --> Final output sent to browser
DEBUG - 2012-01-12 23:55:53 --> Total execution time: 0.5352
DEBUG - 2012-01-12 23:56:03 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:03 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:03 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:03 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:03 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:03 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:03 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:03 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:04 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:04 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:04 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:04 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:04 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:56:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:56:04 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:04 --> Total execution time: 0.4363
DEBUG - 2012-01-12 23:56:09 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:09 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:09 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:09 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:09 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:09 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:09 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:09 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:56:09 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:09 --> Total execution time: 0.5268
DEBUG - 2012-01-12 23:56:15 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:15 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:15 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:15 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:15 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:15 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:15 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:16 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:16 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:16 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:16 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:16 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:16 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:56:16 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:56:16 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:16 --> Total execution time: 0.4704
DEBUG - 2012-01-12 23:56:18 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:18 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:18 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:18 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:18 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:18 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:18 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:18 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:56:18 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:18 --> Total execution time: 0.4650
DEBUG - 2012-01-12 23:56:22 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:22 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:22 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:22 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:22 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:22 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:22 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:22 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:56:22 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:22 --> Total execution time: 0.4687
DEBUG - 2012-01-12 23:56:36 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:36 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:36 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:36 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:36 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:36 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:36 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:36 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:36 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:36 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:37 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:37 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:37 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:56:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:56:37 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:37 --> Total execution time: 0.4517
DEBUG - 2012-01-12 23:56:39 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:39 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:39 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:39 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:39 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:39 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:39 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:39 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-12 23:56:39 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:39 --> Total execution time: 0.4786
DEBUG - 2012-01-12 23:56:49 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:49 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:49 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:49 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:49 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:49 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Config Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:56:49 --> URI Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Router Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Output Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Security Class Initialized
DEBUG - 2012-01-12 23:56:49 --> Input Class Initialized
DEBUG - 2012-01-12 23:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:56:50 --> Language Class Initialized
DEBUG - 2012-01-12 23:56:50 --> Loader Class Initialized
DEBUG - 2012-01-12 23:56:50 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:56:50 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:56:50 --> Session Class Initialized
DEBUG - 2012-01-12 23:56:50 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:56:50 --> Session routines successfully run
DEBUG - 2012-01-12 23:56:50 --> Controller Class Initialized
DEBUG - 2012-01-12 23:56:50 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:56:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:56:50 --> Final output sent to browser
DEBUG - 2012-01-12 23:56:50 --> Total execution time: 0.4306
DEBUG - 2012-01-12 23:57:05 --> Config Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:57:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:57:05 --> URI Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Router Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Output Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Security Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Input Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:57:05 --> Language Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Loader Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:57:05 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Session Class Initialized
DEBUG - 2012-01-12 23:57:05 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:57:05 --> Session routines successfully run
DEBUG - 2012-01-12 23:57:05 --> Controller Class Initialized
DEBUG - 2012-01-12 23:57:05 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-12 23:57:05 --> Final output sent to browser
DEBUG - 2012-01-12 23:57:05 --> Total execution time: 0.4709
DEBUG - 2012-01-12 23:57:15 --> Config Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:57:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:57:15 --> URI Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Router Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Output Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Security Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Input Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:57:15 --> Language Class Initialized
DEBUG - 2012-01-12 23:57:15 --> Loader Class Initialized
DEBUG - 2012-01-12 23:57:16 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:57:16 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:57:16 --> Session Class Initialized
DEBUG - 2012-01-12 23:57:16 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:57:16 --> Session routines successfully run
DEBUG - 2012-01-12 23:57:16 --> Controller Class Initialized
DEBUG - 2012-01-12 23:57:16 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:57:16 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:57:16 --> Final output sent to browser
DEBUG - 2012-01-12 23:57:16 --> Total execution time: 0.5211
DEBUG - 2012-01-12 23:57:20 --> Config Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:57:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:57:20 --> URI Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Router Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Output Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Security Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Input Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:57:20 --> Language Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Loader Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:57:20 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Session Class Initialized
DEBUG - 2012-01-12 23:57:20 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:57:20 --> Session routines successfully run
DEBUG - 2012-01-12 23:57:20 --> Controller Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Config Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:57:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:57:21 --> URI Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Router Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Output Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Security Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Input Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:57:21 --> Language Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Loader Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:57:21 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Session Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:57:21 --> Session routines successfully run
DEBUG - 2012-01-12 23:57:21 --> Controller Class Initialized
DEBUG - 2012-01-12 23:57:21 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:57:21 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:57:21 --> Final output sent to browser
DEBUG - 2012-01-12 23:57:21 --> Total execution time: 0.9848
DEBUG - 2012-01-12 23:57:23 --> Config Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:57:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:57:23 --> URI Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Router Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Output Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Security Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Input Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:57:23 --> Language Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Loader Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:57:23 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Session Class Initialized
DEBUG - 2012-01-12 23:57:23 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:57:23 --> Session routines successfully run
DEBUG - 2012-01-12 23:57:23 --> Controller Class Initialized
DEBUG - 2012-01-12 23:57:23 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-12 23:57:23 --> Final output sent to browser
DEBUG - 2012-01-12 23:57:23 --> Total execution time: 0.5673
DEBUG - 2012-01-12 23:57:33 --> Config Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:57:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:57:33 --> URI Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Router Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Output Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Security Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Input Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:57:33 --> Language Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Loader Class Initialized
DEBUG - 2012-01-12 23:57:33 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:57:33 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Session Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:57:34 --> Session routines successfully run
DEBUG - 2012-01-12 23:57:34 --> Controller Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Config Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Hooks Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Utf8 Class Initialized
DEBUG - 2012-01-12 23:57:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-12 23:57:34 --> URI Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Router Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Output Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Security Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Input Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-12 23:57:34 --> Language Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Loader Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Helper loaded: url_helper
DEBUG - 2012-01-12 23:57:34 --> Database Driver Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Session Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Helper loaded: string_helper
DEBUG - 2012-01-12 23:57:34 --> Session routines successfully run
DEBUG - 2012-01-12 23:57:34 --> Controller Class Initialized
DEBUG - 2012-01-12 23:57:34 --> Pagination Class Initialized
DEBUG - 2012-01-12 23:57:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-12 23:57:34 --> Final output sent to browser
DEBUG - 2012-01-12 23:57:34 --> Total execution time: 0.4458

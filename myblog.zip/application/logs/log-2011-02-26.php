<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-26 02:46:32 --> Config Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:46:32 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:46:32 --> URI Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Router Class Initialized
DEBUG - 2011-02-26 02:46:32 --> No URI present. Default controller set.
DEBUG - 2011-02-26 02:46:32 --> Output Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Security Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Input Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:46:32 --> Language Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Loader Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:46:32 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Session Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:46:32 --> A session cookie was not found.
DEBUG - 2011-02-26 02:46:32 --> Session routines successfully run
DEBUG - 2011-02-26 02:46:32 --> Model Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Model Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Controller Class Initialized
DEBUG - 2011-02-26 02:46:32 --> Pagination Class Initialized
DEBUG - 2011-02-26 02:46:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:46:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:46:32 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2011-02-26 02:46:32 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2011-02-26 02:46:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:46:32 --> File loaded: application/views/user/home.php
DEBUG - 2011-02-26 02:46:32 --> Final output sent to browser
DEBUG - 2011-02-26 02:46:32 --> Total execution time: 0.2732
DEBUG - 2011-02-26 02:46:33 --> Config Class Initialized
DEBUG - 2011-02-26 02:46:33 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:46:33 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:46:33 --> URI Class Initialized
DEBUG - 2011-02-26 02:46:33 --> Config Class Initialized
DEBUG - 2011-02-26 02:46:33 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:46:33 --> Router Class Initialized
DEBUG - 2011-02-26 02:46:33 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:46:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:46:33 --> URI Class Initialized
ERROR - 2011-02-26 02:46:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:46:33 --> Router Class Initialized
ERROR - 2011-02-26 02:46:33 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-26 02:46:40 --> Config Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:46:40 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:46:40 --> URI Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Router Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Output Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Security Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Input Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:46:40 --> Language Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Loader Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:46:40 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Session Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:46:40 --> Session routines successfully run
DEBUG - 2011-02-26 02:46:40 --> Model Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Model Class Initialized
DEBUG - 2011-02-26 02:46:40 --> Controller Class Initialized
DEBUG - 2011-02-26 02:46:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:46:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:46:40 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:46:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:46:40 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:46:40 --> Final output sent to browser
DEBUG - 2011-02-26 02:46:40 --> Total execution time: 0.1432
DEBUG - 2011-02-26 02:46:46 --> Config Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:46:46 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:46:46 --> URI Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Router Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Output Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Security Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Input Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:46:46 --> Language Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Loader Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:46:46 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Session Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:46:46 --> Session routines successfully run
DEBUG - 2011-02-26 02:46:46 --> Model Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Model Class Initialized
DEBUG - 2011-02-26 02:46:46 --> Controller Class Initialized
DEBUG - 2011-02-26 02:46:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:46:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:46:46 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:46:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:46:46 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:46:46 --> Final output sent to browser
DEBUG - 2011-02-26 02:46:46 --> Total execution time: 0.2240
DEBUG - 2011-02-26 02:47:01 --> Config Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:47:01 --> URI Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Router Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Output Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Security Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Input Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:47:01 --> Language Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Loader Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:47:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Session Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:47:01 --> Session routines successfully run
DEBUG - 2011-02-26 02:47:01 --> Model Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Model Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Controller Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Config Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:47:01 --> URI Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Router Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Output Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Security Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Input Class Initialized
DEBUG - 2011-02-26 02:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:47:01 --> Language Class Initialized
DEBUG - 2011-02-26 02:47:02 --> Loader Class Initialized
DEBUG - 2011-02-26 02:47:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:47:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:47:02 --> Session Class Initialized
DEBUG - 2011-02-26 02:47:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:47:02 --> Session routines successfully run
DEBUG - 2011-02-26 02:47:02 --> Model Class Initialized
DEBUG - 2011-02-26 02:47:02 --> Model Class Initialized
DEBUG - 2011-02-26 02:47:02 --> Controller Class Initialized
DEBUG - 2011-02-26 02:47:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:47:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:47:02 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:47:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:47:02 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:47:02 --> Final output sent to browser
DEBUG - 2011-02-26 02:47:02 --> Total execution time: 0.1304
DEBUG - 2011-02-26 02:49:17 --> Config Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:49:17 --> URI Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Router Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Output Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Security Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Input Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:49:17 --> Language Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Loader Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:49:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Session Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:49:17 --> Session routines successfully run
DEBUG - 2011-02-26 02:49:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Controller Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Config Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:49:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:49:17 --> URI Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Router Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Output Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Security Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Input Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:49:17 --> Language Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Loader Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:49:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Session Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:49:17 --> Session routines successfully run
DEBUG - 2011-02-26 02:49:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:49:17 --> Controller Class Initialized
DEBUG - 2011-02-26 02:49:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:49:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:49:17 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:49:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:49:17 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:49:17 --> Final output sent to browser
DEBUG - 2011-02-26 02:49:17 --> Total execution time: 0.1314
DEBUG - 2011-02-26 02:49:59 --> Config Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:49:59 --> URI Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Router Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Output Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Security Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Input Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:49:59 --> Language Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Loader Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:49:59 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Session Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:49:59 --> Session routines successfully run
DEBUG - 2011-02-26 02:49:59 --> Model Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Model Class Initialized
DEBUG - 2011-02-26 02:49:59 --> Controller Class Initialized
DEBUG - 2011-02-26 02:49:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:49:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:49:59 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:49:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:49:59 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:49:59 --> Final output sent to browser
DEBUG - 2011-02-26 02:49:59 --> Total execution time: 0.1333
DEBUG - 2011-02-26 02:50:01 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:01 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:01 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:02 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:02 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:02 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:02 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:02 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:02 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:02 --> Total execution time: 0.1314
DEBUG - 2011-02-26 02:50:02 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:02 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Router Class Initialized
ERROR - 2011-02-26 02:50:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:02 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:02 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:02 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:03 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:03 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:03 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:03 --> Total execution time: 0.1298
DEBUG - 2011-02-26 02:50:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Router Class Initialized
ERROR - 2011-02-26 02:50:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:03 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:03 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:03 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:03 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:03 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:03 --> Total execution time: 0.1389
DEBUG - 2011-02-26 02:50:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:03 --> Router Class Initialized
ERROR - 2011-02-26 02:50:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:04 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:04 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:04 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:04 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:04 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:04 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:04 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:04 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:04 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:04 --> Total execution time: 0.1319
DEBUG - 2011-02-26 02:50:04 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:04 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Router Class Initialized
ERROR - 2011-02-26 02:50:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:04 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:04 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:04 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:05 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:05 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:05 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:05 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:05 --> Total execution time: 0.1295
DEBUG - 2011-02-26 02:50:05 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:05 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Router Class Initialized
ERROR - 2011-02-26 02:50:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:05 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:05 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:05 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:05 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:05 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:05 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:05 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:05 --> Total execution time: 0.1298
DEBUG - 2011-02-26 02:50:05 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:05 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:05 --> Router Class Initialized
ERROR - 2011-02-26 02:50:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:06 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:06 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:06 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:06 --> Total execution time: 0.1409
DEBUG - 2011-02-26 02:50:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Router Class Initialized
ERROR - 2011-02-26 02:50:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:06 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:06 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:06 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:06 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:06 --> Total execution time: 0.1319
DEBUG - 2011-02-26 02:50:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Router Class Initialized
ERROR - 2011-02-26 02:50:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:07 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:07 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:07 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:07 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:07 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:07 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:07 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:07 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:07 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:07 --> Total execution time: 0.1311
DEBUG - 2011-02-26 02:50:07 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:07 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Router Class Initialized
ERROR - 2011-02-26 02:50:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:07 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:07 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:07 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:08 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:08 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:08 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:08 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:08 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:08 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:08 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:08 --> Total execution time: 0.1299
DEBUG - 2011-02-26 02:50:08 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:08 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:08 --> Router Class Initialized
ERROR - 2011-02-26 02:50:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:10 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:10 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:10 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:10 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:10 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:10 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:10 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:10 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:10 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:10 --> Total execution time: 0.1304
DEBUG - 2011-02-26 02:50:10 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:10 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:10 --> Router Class Initialized
ERROR - 2011-02-26 02:50:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:13 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:13 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:13 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:13 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:13 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:13 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:13 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:13 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:13 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:13 --> Total execution time: 0.1266
DEBUG - 2011-02-26 02:50:13 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:13 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:13 --> Router Class Initialized
ERROR - 2011-02-26 02:50:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:14 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:14 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:14 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:14 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:14 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:14 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:14 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:14 --> Total execution time: 0.1360
DEBUG - 2011-02-26 02:50:14 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:14 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Router Class Initialized
ERROR - 2011-02-26 02:50:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:14 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:14 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:14 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:14 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:14 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:14 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:14 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:14 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:14 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:14 --> Total execution time: 0.1634
DEBUG - 2011-02-26 02:50:15 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:15 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Router Class Initialized
ERROR - 2011-02-26 02:50:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:15 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:15 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:15 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:15 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:15 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:15 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:15 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:15 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:15 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:15 --> Total execution time: 0.1294
DEBUG - 2011-02-26 02:50:15 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:15 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:15 --> Router Class Initialized
ERROR - 2011-02-26 02:50:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:16 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:16 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:16 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:16 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:16 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:16 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:16 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:16 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:16 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:16 --> Total execution time: 0.1285
DEBUG - 2011-02-26 02:50:16 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:16 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:16 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:16 --> Router Class Initialized
ERROR - 2011-02-26 02:50:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:38 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:38 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:38 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:38 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:38 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:38 --> A session cookie was not found.
DEBUG - 2011-02-26 02:50:38 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:38 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:38 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:38 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:38 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:38 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:38 --> Total execution time: 0.1439
DEBUG - 2011-02-26 02:50:39 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:39 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:39 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:39 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:39 --> Router Class Initialized
ERROR - 2011-02-26 02:50:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:39 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:39 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:39 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:39 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:39 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:39 --> Router Class Initialized
ERROR - 2011-02-26 02:50:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:58 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:58 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:58 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:58 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:58 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:58 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:58 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:58 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:58 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:58 --> Total execution time: 0.1277
DEBUG - 2011-02-26 02:50:58 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:58 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:58 --> Router Class Initialized
ERROR - 2011-02-26 02:50:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:59 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:59 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:59 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:59 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:59 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:59 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:59 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:59 --> Total execution time: 0.1269
DEBUG - 2011-02-26 02:50:59 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:59 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Router Class Initialized
ERROR - 2011-02-26 02:50:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:50:59 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:50:59 --> URI Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Router Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Output Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Security Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Input Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:50:59 --> Language Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Loader Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:50:59 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Session Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:50:59 --> Session routines successfully run
DEBUG - 2011-02-26 02:50:59 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Model Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Controller Class Initialized
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:50:59 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:50:59 --> Final output sent to browser
DEBUG - 2011-02-26 02:50:59 --> Total execution time: 0.1440
DEBUG - 2011-02-26 02:50:59 --> Config Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:50:59 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:00 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Router Class Initialized
ERROR - 2011-02-26 02:51:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:00 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:00 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:00 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:00 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:00 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:00 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:00 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:00 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:00 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:00 --> Total execution time: 0.1271
DEBUG - 2011-02-26 02:51:00 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:00 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Router Class Initialized
ERROR - 2011-02-26 02:51:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:00 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:00 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:00 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:00 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:00 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:00 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:00 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:00 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:01 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:01 --> Total execution time: 0.1272
DEBUG - 2011-02-26 02:51:01 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:01 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Router Class Initialized
ERROR - 2011-02-26 02:51:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:01 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:01 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:01 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:01 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:01 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:01 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:01 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:01 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:01 --> Total execution time: 0.1370
DEBUG - 2011-02-26 02:51:01 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:01 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:01 --> Router Class Initialized
ERROR - 2011-02-26 02:51:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:02 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:02 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:02 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:02 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:02 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:02 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:02 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:02 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:02 --> Total execution time: 0.1263
DEBUG - 2011-02-26 02:51:02 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:02 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Router Class Initialized
ERROR - 2011-02-26 02:51:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:02 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:02 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:02 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:02 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:02 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:02 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:02 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:02 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:03 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:03 --> Total execution time: 0.1267
DEBUG - 2011-02-26 02:51:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Router Class Initialized
ERROR - 2011-02-26 02:51:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:03 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:03 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:03 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:03 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:03 --> Total execution time: 0.1270
DEBUG - 2011-02-26 02:51:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Router Class Initialized
ERROR - 2011-02-26 02:51:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:03 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:03 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:03 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:03 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:03 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:03 --> Total execution time: 0.1262
DEBUG - 2011-02-26 02:51:03 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:03 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:03 --> Router Class Initialized
ERROR - 2011-02-26 02:51:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:04 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:04 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:04 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:04 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:04 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:04 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:04 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:04 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:04 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:04 --> Total execution time: 0.1269
DEBUG - 2011-02-26 02:51:04 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:04 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:04 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:04 --> Router Class Initialized
ERROR - 2011-02-26 02:51:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:05 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:05 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:05 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:05 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:05 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:05 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:05 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:05 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:05 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:05 --> Total execution time: 0.1355
DEBUG - 2011-02-26 02:51:05 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:05 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:05 --> Router Class Initialized
ERROR - 2011-02-26 02:51:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:06 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:06 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:06 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:06 --> Total execution time: 0.1267
DEBUG - 2011-02-26 02:51:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Router Class Initialized
ERROR - 2011-02-26 02:51:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:06 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:06 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:06 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:06 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:06 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:06 --> Total execution time: 0.1269
DEBUG - 2011-02-26 02:51:06 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:06 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:06 --> Router Class Initialized
ERROR - 2011-02-26 02:51:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:07 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:07 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:07 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:07 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:07 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:07 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:07 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:07 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:07 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:07 --> Total execution time: 0.1353
DEBUG - 2011-02-26 02:51:07 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:07 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:07 --> Router Class Initialized
ERROR - 2011-02-26 02:51:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:14 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:14 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:14 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:14 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:14 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:14 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:14 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:14 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:14 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:14 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:14 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:14 --> Total execution time: 0.1275
DEBUG - 2011-02-26 02:51:15 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:15 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Router Class Initialized
ERROR - 2011-02-26 02:51:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:15 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:15 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:15 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:15 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:15 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:15 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:15 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:15 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:15 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:15 --> Total execution time: 0.1299
DEBUG - 2011-02-26 02:51:15 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:15 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:15 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:15 --> Router Class Initialized
ERROR - 2011-02-26 02:51:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:17 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:17 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:17 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:17 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:17 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:17 --> Total execution time: 0.1280
DEBUG - 2011-02-26 02:51:17 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:17 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Router Class Initialized
ERROR - 2011-02-26 02:51:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:17 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:17 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:17 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:17 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:17 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:17 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:17 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:17 --> Total execution time: 0.1283
DEBUG - 2011-02-26 02:51:17 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:17 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:17 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:17 --> Router Class Initialized
ERROR - 2011-02-26 02:51:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:18 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:18 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:18 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:18 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:18 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:18 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:18 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:18 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:18 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:18 --> Total execution time: 0.1291
DEBUG - 2011-02-26 02:51:18 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:18 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:18 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:18 --> Router Class Initialized
ERROR - 2011-02-26 02:51:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:20 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:20 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:20 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:20 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:20 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:20 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:20 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:20 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:20 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:20 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:20 --> Total execution time: 0.1358
DEBUG - 2011-02-26 02:51:21 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:21 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Router Class Initialized
ERROR - 2011-02-26 02:51:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:21 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:21 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:21 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:21 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:21 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:21 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:21 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:21 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:21 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:21 --> Total execution time: 0.1371
DEBUG - 2011-02-26 02:51:21 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:21 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:21 --> Router Class Initialized
ERROR - 2011-02-26 02:51:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:23 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:23 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:23 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:23 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:23 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:23 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:23 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:23 --> Total execution time: 0.1277
DEBUG - 2011-02-26 02:51:23 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:23 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Router Class Initialized
ERROR - 2011-02-26 02:51:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:23 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:23 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:23 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:23 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:23 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:23 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:23 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:23 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:23 --> Total execution time: 0.1273
DEBUG - 2011-02-26 02:51:23 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:23 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:23 --> Router Class Initialized
ERROR - 2011-02-26 02:51:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:24 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:24 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:24 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:24 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:24 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:24 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:24 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:24 --> Total execution time: 0.1370
DEBUG - 2011-02-26 02:51:24 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:24 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Router Class Initialized
ERROR - 2011-02-26 02:51:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:24 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:24 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:24 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:24 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:24 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:24 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:24 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:24 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:24 --> Total execution time: 0.1285
DEBUG - 2011-02-26 02:51:24 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:24 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:24 --> Router Class Initialized
ERROR - 2011-02-26 02:51:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:25 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:25 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:25 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:25 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:25 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:25 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:25 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:25 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:25 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:25 --> Total execution time: 0.1278
DEBUG - 2011-02-26 02:51:25 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:25 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:25 --> Router Class Initialized
ERROR - 2011-02-26 02:51:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:26 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:26 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:26 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:26 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:26 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:26 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:26 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:26 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:26 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:26 --> Total execution time: 0.1284
DEBUG - 2011-02-26 02:51:26 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:26 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Router Class Initialized
ERROR - 2011-02-26 02:51:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:26 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:26 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:26 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:26 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:27 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:27 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:27 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:27 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:27 --> Total execution time: 0.1316
DEBUG - 2011-02-26 02:51:27 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:27 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Router Class Initialized
ERROR - 2011-02-26 02:51:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:27 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:27 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:27 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:27 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:27 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:27 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:27 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:27 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:27 --> Total execution time: 0.1271
DEBUG - 2011-02-26 02:51:27 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:27 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:27 --> Router Class Initialized
ERROR - 2011-02-26 02:51:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:28 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:28 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:28 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:28 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:28 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:28 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:28 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:28 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:28 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:28 --> Total execution time: 0.1370
DEBUG - 2011-02-26 02:51:28 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:28 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:28 --> Router Class Initialized
ERROR - 2011-02-26 02:51:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-26 02:51:30 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:30 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Router Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Output Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Security Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Input Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-26 02:51:30 --> Language Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Loader Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Helper loaded: url_helper
DEBUG - 2011-02-26 02:51:30 --> Database Driver Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Session Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Helper loaded: string_helper
DEBUG - 2011-02-26 02:51:30 --> Session routines successfully run
DEBUG - 2011-02-26 02:51:30 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Model Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Controller Class Initialized
DEBUG - 2011-02-26 02:51:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-26 02:51:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-26 02:51:30 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2011-02-26 02:51:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-26 02:51:30 --> File loaded: application/views/user/article.php
DEBUG - 2011-02-26 02:51:30 --> Final output sent to browser
DEBUG - 2011-02-26 02:51:30 --> Total execution time: 0.1276
DEBUG - 2011-02-26 02:51:30 --> Config Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Hooks Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Utf8 Class Initialized
DEBUG - 2011-02-26 02:51:30 --> UTF-8 Support Enabled
DEBUG - 2011-02-26 02:51:30 --> URI Class Initialized
DEBUG - 2011-02-26 02:51:30 --> Router Class Initialized
ERROR - 2011-02-26 02:51:30 --> 404 Page Not Found --> favicon.ico

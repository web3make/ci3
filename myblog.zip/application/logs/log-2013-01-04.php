<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-04 13:53:45 --> Config Class Initialized
DEBUG - 2013-01-04 13:53:45 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:53:45 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:53:45 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:53:45 --> URI Class Initialized
DEBUG - 2013-01-04 13:53:45 --> Router Class Initialized
DEBUG - 2013-01-04 13:53:45 --> No URI present. Default controller set.
DEBUG - 2013-01-04 13:53:45 --> Output Class Initialized
DEBUG - 2013-01-04 13:53:45 --> Security Class Initialized
DEBUG - 2013-01-04 13:53:45 --> Input Class Initialized
DEBUG - 2013-01-04 13:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:53:46 --> Language Class Initialized
DEBUG - 2013-01-04 13:53:46 --> Loader Class Initialized
DEBUG - 2013-01-04 13:53:46 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:53:46 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:53:46 --> Session Class Initialized
DEBUG - 2013-01-04 13:53:46 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:53:46 --> A session cookie was not found.
DEBUG - 2013-01-04 13:53:46 --> Session routines successfully run
DEBUG - 2013-01-04 13:53:46 --> Model Class Initialized
DEBUG - 2013-01-04 13:53:46 --> Model Class Initialized
DEBUG - 2013-01-04 13:53:46 --> Controller Class Initialized
DEBUG - 2013-01-04 13:53:46 --> Pagination Class Initialized
DEBUG - 2013-01-04 13:53:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-04 13:53:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-04 13:53:46 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2013-01-04 13:53:47 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2013-01-04 13:53:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-04 13:53:47 --> File loaded: application/views/user/home.php
DEBUG - 2013-01-04 13:53:47 --> Final output sent to browser
DEBUG - 2013-01-04 13:53:47 --> Total execution time: 1.3747
DEBUG - 2013-01-04 13:53:48 --> Config Class Initialized
DEBUG - 2013-01-04 13:53:48 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:53:48 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:53:48 --> URI Class Initialized
DEBUG - 2013-01-04 13:53:48 --> Router Class Initialized
ERROR - 2013-01-04 13:53:48 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 13:53:59 --> Config Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:53:59 --> URI Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Router Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Output Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Security Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Input Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:53:59 --> Language Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Loader Class Initialized
DEBUG - 2013-01-04 13:53:59 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:53:59 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Session Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:54:00 --> A session cookie was not found.
DEBUG - 2013-01-04 13:54:00 --> Session routines successfully run
DEBUG - 2013-01-04 13:54:00 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Controller Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Config Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:54:00 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:54:00 --> URI Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Router Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Output Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Security Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Input Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:54:00 --> Language Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Loader Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:54:00 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Session Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:54:00 --> Session routines successfully run
DEBUG - 2013-01-04 13:54:00 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:00 --> Controller Class Initialized
DEBUG - 2013-01-04 13:54:00 --> File loaded: application/views/admin/login.php
DEBUG - 2013-01-04 13:54:00 --> Final output sent to browser
DEBUG - 2013-01-04 13:54:00 --> Total execution time: 0.1668
DEBUG - 2013-01-04 13:54:13 --> Config Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:54:13 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:54:13 --> URI Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Router Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Output Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Security Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Input Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:54:13 --> Language Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Loader Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:54:13 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Session Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:54:13 --> Session routines successfully run
DEBUG - 2013-01-04 13:54:13 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Controller Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Config Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:54:13 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:54:13 --> URI Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Router Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Output Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Security Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Input Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:54:13 --> Language Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Loader Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:54:13 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Session Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:54:13 --> Session routines successfully run
DEBUG - 2013-01-04 13:54:13 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Controller Class Initialized
DEBUG - 2013-01-04 13:54:13 --> Pagination Class Initialized
ERROR - 2013-01-04 13:54:14 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:54:14 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:54:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:54:14 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2013-01-04 13:54:14 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2013-01-04 13:54:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:54:14 --> File loaded: application/views/admin/home.php
DEBUG - 2013-01-04 13:54:14 --> Final output sent to browser
DEBUG - 2013-01-04 13:54:14 --> Total execution time: 0.4042
DEBUG - 2013-01-04 13:54:14 --> Config Class Initialized
DEBUG - 2013-01-04 13:54:14 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:54:14 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:54:14 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:54:14 --> URI Class Initialized
DEBUG - 2013-01-04 13:54:14 --> Router Class Initialized
ERROR - 2013-01-04 13:54:14 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 13:54:18 --> Config Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:54:18 --> URI Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Router Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Output Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Security Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Input Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:54:18 --> Language Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Loader Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:54:18 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Session Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:54:18 --> Session routines successfully run
DEBUG - 2013-01-04 13:54:18 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Model Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Controller Class Initialized
DEBUG - 2013-01-04 13:54:18 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 13:54:19 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:54:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:54:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:54:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:54:19 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 13:54:19 --> Final output sent to browser
DEBUG - 2013-01-04 13:54:19 --> Total execution time: 0.3449
DEBUG - 2013-01-04 13:55:56 --> Config Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:55:56 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:55:56 --> URI Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Router Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Output Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Security Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Input Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:55:56 --> Language Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Loader Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:55:56 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Session Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:55:56 --> Session routines successfully run
DEBUG - 2013-01-04 13:55:56 --> Model Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Model Class Initialized
DEBUG - 2013-01-04 13:55:56 --> Controller Class Initialized
ERROR - 2013-01-04 13:55:56 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:55:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:55:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:55:56 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-01-04 13:55:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:55:56 --> File loaded: application/views/admin/category.php
DEBUG - 2013-01-04 13:55:56 --> Final output sent to browser
DEBUG - 2013-01-04 13:55:56 --> Total execution time: 0.2026
DEBUG - 2013-01-04 13:55:58 --> Config Class Initialized
DEBUG - 2013-01-04 13:55:58 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:55:58 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:55:58 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:55:58 --> URI Class Initialized
DEBUG - 2013-01-04 13:55:58 --> Router Class Initialized
DEBUG - 2013-01-04 13:55:58 --> Output Class Initialized
DEBUG - 2013-01-04 13:55:58 --> Security Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Input Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:55:59 --> Language Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Loader Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:55:59 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Session Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:55:59 --> Session routines successfully run
DEBUG - 2013-01-04 13:55:59 --> Model Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Model Class Initialized
DEBUG - 2013-01-04 13:55:59 --> Controller Class Initialized
ERROR - 2013-01-04 13:55:59 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:55:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:55:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:55:59 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-01-04 13:55:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:55:59 --> File loaded: application/views/admin/category.php
DEBUG - 2013-01-04 13:55:59 --> Final output sent to browser
DEBUG - 2013-01-04 13:55:59 --> Total execution time: 0.3366
DEBUG - 2013-01-04 13:56:00 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:00 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:00 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:00 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:00 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:00 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:00 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:00 --> Controller Class Initialized
ERROR - 2013-01-04 13:56:00 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:56:00 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-01-04 13:56:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:00 --> File loaded: application/views/admin/category.php
DEBUG - 2013-01-04 13:56:00 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:00 --> Total execution time: 0.3242
DEBUG - 2013-01-04 13:56:01 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:01 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Router Class Initialized
ERROR - 2013-01-04 13:56:01 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 13:56:01 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:01 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:01 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:01 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:01 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:02 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:02 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:02 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:02 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:02 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:02 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:02 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:02 --> Controller Class Initialized
ERROR - 2013-01-04 13:56:02 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:56:02 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-01-04 13:56:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:02 --> File loaded: application/views/admin/category.php
DEBUG - 2013-01-04 13:56:02 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:02 --> Total execution time: 0.2883
DEBUG - 2013-01-04 13:56:04 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:04 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:04 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:04 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:04 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:04 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:04 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Controller Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 13:56:04 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:56:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:04 --> File loaded: application/views/admin/page.php
DEBUG - 2013-01-04 13:56:04 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:04 --> Total execution time: 0.3988
DEBUG - 2013-01-04 13:56:04 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:04 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:04 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:04 --> Router Class Initialized
ERROR - 2013-01-04 13:56:05 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 13:56:06 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:06 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:06 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:06 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:06 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:06 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:06 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Controller Class Initialized
DEBUG - 2013-01-04 13:56:06 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 13:56:06 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:06 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:06 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:56:06 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:06 --> File loaded: application/views/admin/page_create.php
DEBUG - 2013-01-04 13:56:06 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:06 --> Total execution time: 0.3263
DEBUG - 2013-01-04 13:56:09 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:09 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:09 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:09 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:09 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:09 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:09 --> Controller Class Initialized
ERROR - 2013-01-04 13:56:09 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:09 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2013-01-04 13:56:09 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\settings.php 18
DEBUG - 2013-01-04 13:56:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:09 --> File loaded: application/views/admin/settings.php
DEBUG - 2013-01-04 13:56:09 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:09 --> Total execution time: 0.2881
DEBUG - 2013-01-04 13:56:22 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:22 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:22 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:22 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:23 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:23 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:23 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:23 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:23 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:23 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:23 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:23 --> Controller Class Initialized
ERROR - 2013-01-04 13:56:23 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:56:23 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-01-04 13:56:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:23 --> File loaded: application/views/admin/category.php
DEBUG - 2013-01-04 13:56:23 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:23 --> Total execution time: 0.3571
DEBUG - 2013-01-04 13:56:25 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:25 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:25 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:25 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:25 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:25 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:25 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Controller Class Initialized
DEBUG - 2013-01-04 13:56:25 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 13:56:25 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:56:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:25 --> File loaded: application/views/admin/page.php
DEBUG - 2013-01-04 13:56:25 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:25 --> Total execution time: 0.2391
DEBUG - 2013-01-04 13:56:26 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:26 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:26 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:26 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:26 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:26 --> Router Class Initialized
ERROR - 2013-01-04 13:56:26 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 13:56:29 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:29 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Router Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Output Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Security Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Input Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:56:29 --> Language Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Loader Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:56:29 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Session Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:56:29 --> Session routines successfully run
DEBUG - 2013-01-04 13:56:29 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Model Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Controller Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Pagination Class Initialized
ERROR - 2013-01-04 13:56:29 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:56:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:56:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:56:29 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2013-01-04 13:56:29 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2013-01-04 13:56:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:56:29 --> File loaded: application/views/admin/home.php
DEBUG - 2013-01-04 13:56:29 --> Final output sent to browser
DEBUG - 2013-01-04 13:56:29 --> Total execution time: 0.1923
DEBUG - 2013-01-04 13:56:29 --> Config Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:56:29 --> URI Class Initialized
DEBUG - 2013-01-04 13:56:29 --> Router Class Initialized
ERROR - 2013-01-04 13:56:29 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 13:59:58 --> Config Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Hooks Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Utf8 Class Initialized
DEBUG - 2013-01-04 13:59:58 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 13:59:58 --> URI Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Router Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Output Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Security Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Input Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 13:59:58 --> Language Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Loader Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Helper loaded: url_helper
DEBUG - 2013-01-04 13:59:58 --> Database Driver Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Session Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Helper loaded: string_helper
DEBUG - 2013-01-04 13:59:58 --> Session routines successfully run
DEBUG - 2013-01-04 13:59:58 --> Model Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Model Class Initialized
DEBUG - 2013-01-04 13:59:58 --> Controller Class Initialized
ERROR - 2013-01-04 13:59:58 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 13:59:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 13:59:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 13:59:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 13:59:58 --> File loaded: application/views/admin/category_new.php
DEBUG - 2013-01-04 13:59:58 --> Final output sent to browser
DEBUG - 2013-01-04 13:59:58 --> Total execution time: 0.3332
DEBUG - 2013-01-04 14:00:03 --> Config Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:00:03 --> URI Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Router Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Output Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Security Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Input Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:00:03 --> Language Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Loader Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:00:03 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Session Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:00:03 --> Session routines successfully run
DEBUG - 2013-01-04 14:00:03 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:03 --> Controller Class Initialized
ERROR - 2013-01-04 14:00:03 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:00:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:00:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:00:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:00:03 --> File loaded: application/views/admin/category_new.php
DEBUG - 2013-01-04 14:00:03 --> Final output sent to browser
DEBUG - 2013-01-04 14:00:03 --> Total execution time: 0.2458
DEBUG - 2013-01-04 14:00:04 --> Config Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:00:04 --> URI Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Router Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Output Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Security Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Input Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:00:04 --> Language Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Loader Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:00:04 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Session Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:00:04 --> Session routines successfully run
DEBUG - 2013-01-04 14:00:04 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:04 --> Controller Class Initialized
ERROR - 2013-01-04 14:00:04 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:00:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:00:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:00:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:00:04 --> File loaded: application/views/admin/category_new.php
DEBUG - 2013-01-04 14:00:04 --> Final output sent to browser
DEBUG - 2013-01-04 14:00:04 --> Total execution time: 0.2300
DEBUG - 2013-01-04 14:00:07 --> Config Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:00:07 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:00:07 --> URI Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Router Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Output Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Security Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Input Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:00:07 --> Language Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Loader Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:00:07 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Session Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:00:07 --> Session routines successfully run
DEBUG - 2013-01-04 14:00:07 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Controller Class Initialized
DEBUG - 2013-01-04 14:00:07 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 14:00:07 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:00:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:00:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:00:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:00:07 --> File loaded: application/views/admin/page_create.php
DEBUG - 2013-01-04 14:00:07 --> Final output sent to browser
DEBUG - 2013-01-04 14:00:07 --> Total execution time: 0.3206
DEBUG - 2013-01-04 14:00:09 --> Config Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:00:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:00:09 --> URI Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Router Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Output Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Security Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Input Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:00:09 --> Language Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Loader Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:00:09 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Session Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:00:09 --> Session routines successfully run
DEBUG - 2013-01-04 14:00:09 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:09 --> Controller Class Initialized
ERROR - 2013-01-04 14:00:09 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:00:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:00:09 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:00:09 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-01-04 14:00:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:00:09 --> File loaded: application/views/admin/category.php
DEBUG - 2013-01-04 14:00:09 --> Final output sent to browser
DEBUG - 2013-01-04 14:00:09 --> Total execution time: 0.3163
DEBUG - 2013-01-04 14:00:11 --> Config Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:00:11 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:00:11 --> URI Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Router Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Output Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Security Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Input Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:00:11 --> Language Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Loader Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:00:11 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Session Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:00:11 --> Session routines successfully run
DEBUG - 2013-01-04 14:00:11 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Model Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Controller Class Initialized
DEBUG - 2013-01-04 14:00:11 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 14:00:11 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:00:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:00:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:00:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:00:11 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 14:00:11 --> Final output sent to browser
DEBUG - 2013-01-04 14:00:11 --> Total execution time: 0.3224
DEBUG - 2013-01-04 14:03:03 --> Config Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:03:03 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:03:03 --> URI Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Router Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Output Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Security Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Input Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:03:03 --> Language Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Loader Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:03:03 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Session Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:03:03 --> Session routines successfully run
DEBUG - 2013-01-04 14:03:03 --> Model Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Model Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Controller Class Initialized
DEBUG - 2013-01-04 14:03:03 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 14:03:03 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:03:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:03:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:03:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:03:03 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 14:03:03 --> Final output sent to browser
DEBUG - 2013-01-04 14:03:03 --> Total execution time: 0.2029
DEBUG - 2013-01-04 14:04:54 --> Config Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:04:54 --> URI Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Router Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Output Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Security Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Input Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:04:54 --> Language Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Loader Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:04:54 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Session Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:04:54 --> Session routines successfully run
DEBUG - 2013-01-04 14:04:54 --> Model Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Model Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Controller Class Initialized
DEBUG - 2013-01-04 14:04:54 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 14:04:54 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:04:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:04:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:04:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:04:54 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 14:04:54 --> Final output sent to browser
DEBUG - 2013-01-04 14:04:54 --> Total execution time: 0.3361
DEBUG - 2013-01-04 14:05:09 --> Config Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:05:09 --> URI Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Router Class Initialized
DEBUG - 2013-01-04 14:05:09 --> No URI present. Default controller set.
DEBUG - 2013-01-04 14:05:09 --> Output Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Security Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Input Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:05:09 --> Language Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Loader Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:05:09 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Session Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:05:09 --> Session routines successfully run
DEBUG - 2013-01-04 14:05:09 --> Model Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Model Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Controller Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Pagination Class Initialized
DEBUG - 2013-01-04 14:05:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-04 14:05:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-04 14:05:09 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2013-01-04 14:05:09 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2013-01-04 14:05:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-04 14:05:09 --> File loaded: application/views/user/home.php
DEBUG - 2013-01-04 14:05:09 --> Final output sent to browser
DEBUG - 2013-01-04 14:05:09 --> Total execution time: 0.1752
DEBUG - 2013-01-04 14:05:09 --> Config Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:05:09 --> URI Class Initialized
DEBUG - 2013-01-04 14:05:09 --> Router Class Initialized
ERROR - 2013-01-04 14:05:09 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 14:14:33 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:33 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:33 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:33 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:33 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:33 --> Router Class Initialized
DEBUG - 2013-01-04 14:14:33 --> Output Class Initialized
DEBUG - 2013-01-04 14:14:33 --> Security Class Initialized
DEBUG - 2013-01-04 14:14:33 --> Input Class Initialized
DEBUG - 2013-01-04 14:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:14:33 --> Language Class Initialized
DEBUG - 2013-01-04 14:14:40 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:40 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:40 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:40 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:40 --> Router Class Initialized
ERROR - 2013-01-04 14:14:40 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 14:14:41 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:41 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:41 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:41 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:41 --> Router Class Initialized
DEBUG - 2013-01-04 14:14:41 --> Output Class Initialized
DEBUG - 2013-01-04 14:14:41 --> Security Class Initialized
DEBUG - 2013-01-04 14:14:41 --> Input Class Initialized
DEBUG - 2013-01-04 14:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:14:41 --> Language Class Initialized
DEBUG - 2013-01-04 14:14:43 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:43 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:43 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:43 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:43 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:43 --> Router Class Initialized
ERROR - 2013-01-04 14:14:43 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 14:14:45 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:45 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Router Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Output Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Security Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Input Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:14:45 --> Language Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Loader Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:14:45 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Session Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:14:45 --> Session routines successfully run
DEBUG - 2013-01-04 14:14:45 --> Model Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Model Class Initialized
DEBUG - 2013-01-04 14:14:45 --> Controller Class Initialized
DEBUG - 2013-01-04 14:14:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-04 14:14:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-04 14:14:45 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2013-01-04 14:14:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-04 14:14:45 --> File loaded: application/views/user/article.php
DEBUG - 2013-01-04 14:14:45 --> Final output sent to browser
DEBUG - 2013-01-04 14:14:45 --> Total execution time: 0.3409
DEBUG - 2013-01-04 14:14:48 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:48 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:48 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:48 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:48 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:48 --> Router Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Output Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Security Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Input Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:14:49 --> Language Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Loader Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:14:49 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Session Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:14:49 --> Session routines successfully run
DEBUG - 2013-01-04 14:14:49 --> Model Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Model Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Controller Class Initialized
DEBUG - 2013-01-04 14:14:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-04 14:14:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-04 14:14:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-04 14:14:49 --> File loaded: application/views/user/page.php
DEBUG - 2013-01-04 14:14:49 --> Final output sent to browser
DEBUG - 2013-01-04 14:14:49 --> Total execution time: 0.2091
DEBUG - 2013-01-04 14:14:49 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:49 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:49 --> Router Class Initialized
ERROR - 2013-01-04 14:14:49 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 14:14:55 --> Config Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:14:55 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:14:55 --> URI Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Router Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Output Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Security Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Input Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:14:55 --> Language Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Loader Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:14:55 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Session Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:14:55 --> Session routines successfully run
DEBUG - 2013-01-04 14:14:55 --> Model Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Model Class Initialized
DEBUG - 2013-01-04 14:14:55 --> Controller Class Initialized
DEBUG - 2013-01-04 14:14:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-04 14:14:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-04 14:14:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-04 14:14:55 --> File loaded: application/views/user/page.php
DEBUG - 2013-01-04 14:14:55 --> Final output sent to browser
DEBUG - 2013-01-04 14:14:55 --> Total execution time: 0.1804
DEBUG - 2013-01-04 14:15:02 --> Config Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:15:02 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:15:02 --> URI Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Router Class Initialized
DEBUG - 2013-01-04 14:15:02 --> No URI present. Default controller set.
DEBUG - 2013-01-04 14:15:02 --> Output Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Security Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Input Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:15:02 --> Language Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Loader Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:15:02 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Session Class Initialized
DEBUG - 2013-01-04 14:15:02 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:15:02 --> Session routines successfully run
DEBUG - 2013-01-04 14:15:03 --> Model Class Initialized
DEBUG - 2013-01-04 14:15:03 --> Model Class Initialized
DEBUG - 2013-01-04 14:15:03 --> Controller Class Initialized
DEBUG - 2013-01-04 14:15:03 --> Pagination Class Initialized
DEBUG - 2013-01-04 14:15:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-04 14:15:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-04 14:15:03 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2013-01-04 14:15:03 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2013-01-04 14:15:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-04 14:15:03 --> File loaded: application/views/user/home.php
DEBUG - 2013-01-04 14:15:03 --> Final output sent to browser
DEBUG - 2013-01-04 14:15:03 --> Total execution time: 0.3581
DEBUG - 2013-01-04 14:15:03 --> Config Class Initialized
DEBUG - 2013-01-04 14:15:03 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:15:03 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:15:03 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:15:03 --> URI Class Initialized
DEBUG - 2013-01-04 14:15:03 --> Router Class Initialized
ERROR - 2013-01-04 14:15:03 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 14:30:25 --> Config Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:30:25 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:30:25 --> URI Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Router Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Output Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Security Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Input Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:30:25 --> Language Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Loader Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:30:25 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Session Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:30:25 --> Session routines successfully run
DEBUG - 2013-01-04 14:30:25 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Controller Class Initialized
DEBUG - 2013-01-04 14:30:25 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 14:30:25 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:30:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:30:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:30:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:30:25 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 14:30:25 --> Final output sent to browser
DEBUG - 2013-01-04 14:30:25 --> Total execution time: 0.2426
DEBUG - 2013-01-04 14:30:27 --> Config Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:30:27 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:30:27 --> URI Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Router Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Output Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Security Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Input Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:30:27 --> Language Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Loader Class Initialized
DEBUG - 2013-01-04 14:30:27 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:30:27 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:30:28 --> Session Class Initialized
DEBUG - 2013-01-04 14:30:28 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:30:28 --> Session routines successfully run
DEBUG - 2013-01-04 14:30:28 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:28 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:28 --> Controller Class Initialized
DEBUG - 2013-01-04 14:30:28 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 14:30:28 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:30:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:30:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:30:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:30:28 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 14:30:28 --> Final output sent to browser
DEBUG - 2013-01-04 14:30:28 --> Total execution time: 0.3325
DEBUG - 2013-01-04 14:30:29 --> Config Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:30:29 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:30:29 --> URI Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Router Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Output Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Security Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Input Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:30:29 --> Language Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Loader Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:30:29 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:30:29 --> Session Class Initialized
DEBUG - 2013-01-04 14:30:30 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:30:30 --> Session routines successfully run
DEBUG - 2013-01-04 14:30:30 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:30 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:30 --> Controller Class Initialized
DEBUG - 2013-01-04 14:30:30 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 14:30:30 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 14:30:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 14:30:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 14:30:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 14:30:30 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 14:30:30 --> Final output sent to browser
DEBUG - 2013-01-04 14:30:30 --> Total execution time: 0.2565
DEBUG - 2013-01-04 14:30:31 --> Config Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:30:31 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:30:31 --> URI Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Router Class Initialized
DEBUG - 2013-01-04 14:30:31 --> No URI present. Default controller set.
DEBUG - 2013-01-04 14:30:31 --> Output Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Security Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Input Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 14:30:31 --> Language Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Loader Class Initialized
DEBUG - 2013-01-04 14:30:31 --> Helper loaded: url_helper
DEBUG - 2013-01-04 14:30:32 --> Database Driver Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Session Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Helper loaded: string_helper
DEBUG - 2013-01-04 14:30:32 --> Session routines successfully run
DEBUG - 2013-01-04 14:30:32 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Model Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Controller Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Pagination Class Initialized
DEBUG - 2013-01-04 14:30:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-04 14:30:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-04 14:30:32 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2013-01-04 14:30:32 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2013-01-04 14:30:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-04 14:30:32 --> File loaded: application/views/user/home.php
DEBUG - 2013-01-04 14:30:32 --> Final output sent to browser
DEBUG - 2013-01-04 14:30:32 --> Total execution time: 0.3576
DEBUG - 2013-01-04 14:30:32 --> Config Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Hooks Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Utf8 Class Initialized
DEBUG - 2013-01-04 14:30:32 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 14:30:32 --> URI Class Initialized
DEBUG - 2013-01-04 14:30:32 --> Router Class Initialized
ERROR - 2013-01-04 14:30:32 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-04 16:01:43 --> Config Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Hooks Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Utf8 Class Initialized
DEBUG - 2013-01-04 16:01:43 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 16:01:43 --> URI Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Router Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Output Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Security Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Input Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 16:01:43 --> Language Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Loader Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Helper loaded: url_helper
DEBUG - 2013-01-04 16:01:43 --> Database Driver Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Session Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Helper loaded: string_helper
DEBUG - 2013-01-04 16:01:43 --> Session routines successfully run
DEBUG - 2013-01-04 16:01:43 --> Model Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Model Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Controller Class Initialized
DEBUG - 2013-01-04 16:01:43 --> Helper loaded: tinymce_helper
ERROR - 2013-01-04 16:01:43 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-04 16:01:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-04 16:01:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-04 16:01:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-04 16:01:43 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-04 16:01:43 --> Final output sent to browser
DEBUG - 2013-01-04 16:01:43 --> Total execution time: 0.2612
DEBUG - 2013-01-04 16:02:16 --> Config Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Hooks Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Utf8 Class Initialized
DEBUG - 2013-01-04 16:02:16 --> UTF-8 Support Enabled
DEBUG - 2013-01-04 16:02:16 --> URI Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Router Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Output Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Security Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Input Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-04 16:02:16 --> Language Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Loader Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Helper loaded: url_helper
DEBUG - 2013-01-04 16:02:16 --> Database Driver Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Session Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Helper loaded: string_helper
DEBUG - 2013-01-04 16:02:16 --> Session routines successfully run
DEBUG - 2013-01-04 16:02:16 --> Model Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Model Class Initialized
DEBUG - 2013-01-04 16:02:16 --> Controller Class Initialized
ERROR - 2013-01-04 16:02:16 --> 404 Page Not Found --> article/lists

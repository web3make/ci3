<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-10-11 17:57:18 --> Config Class Initialized
DEBUG - 2013-10-11 17:57:18 --> Hooks Class Initialized
DEBUG - 2013-10-11 17:57:18 --> Utf8 Class Initialized
DEBUG - 2013-10-11 17:57:18 --> UTF-8 Support Enabled
DEBUG - 2013-10-11 17:57:18 --> URI Class Initialized
DEBUG - 2013-10-11 17:57:18 --> Router Class Initialized
ERROR - 2013-10-11 17:57:18 --> 404 Page Not Found --> assets
DEBUG - 2013-10-11 17:57:18 --> Config Class Initialized
DEBUG - 2013-10-11 17:57:18 --> Hooks Class Initialized
DEBUG - 2013-10-11 17:57:18 --> Utf8 Class Initialized
DEBUG - 2013-10-11 17:57:18 --> UTF-8 Support Enabled
DEBUG - 2013-10-11 17:57:18 --> URI Class Initialized
DEBUG - 2013-10-11 17:57:18 --> Router Class Initialized
ERROR - 2013-10-11 17:57:18 --> 404 Page Not Found --> assets

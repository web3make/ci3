<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-16 22:03:47 --> Config Class Initialized
DEBUG - 2012-01-16 22:03:47 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:03:47 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:03:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:03:48 --> URI Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Router Class Initialized
DEBUG - 2012-01-16 22:03:48 --> No URI present. Default controller set.
DEBUG - 2012-01-16 22:03:48 --> Output Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Security Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Input Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:03:48 --> Language Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Loader Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:03:48 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Session Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:03:48 --> A session cookie was not found.
DEBUG - 2012-01-16 22:03:48 --> Session routines successfully run
DEBUG - 2012-01-16 22:03:48 --> Model Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Model Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Controller Class Initialized
DEBUG - 2012-01-16 22:03:48 --> Pagination Class Initialized
DEBUG - 2012-01-16 22:03:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-16 22:03:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-16 22:03:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-16 22:03:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-16 22:03:49 --> Final output sent to browser
DEBUG - 2012-01-16 22:03:49 --> Total execution time: 1.3540
DEBUG - 2012-01-16 22:04:01 --> Config Class Initialized
DEBUG - 2012-01-16 22:04:01 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:04:01 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:04:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:04:01 --> URI Class Initialized
DEBUG - 2012-01-16 22:04:01 --> Router Class Initialized
ERROR - 2012-01-16 22:04:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-16 22:04:07 --> Config Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:04:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:04:07 --> URI Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Router Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Output Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Security Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Input Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:04:07 --> Language Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Loader Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:04:07 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Session Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:04:07 --> Session routines successfully run
DEBUG - 2012-01-16 22:04:07 --> Model Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Model Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Controller Class Initialized
DEBUG - 2012-01-16 22:04:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-16 22:04:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-16 22:04:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-16 22:04:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-16 22:04:07 --> Final output sent to browser
DEBUG - 2012-01-16 22:04:07 --> Total execution time: 0.2975
DEBUG - 2012-01-16 22:04:07 --> Config Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:04:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:04:07 --> URI Class Initialized
DEBUG - 2012-01-16 22:04:07 --> Router Class Initialized
ERROR - 2012-01-16 22:04:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-16 22:04:08 --> Config Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:04:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:04:08 --> URI Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Router Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Output Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Security Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Input Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:04:08 --> Language Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Loader Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:04:08 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Session Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:04:08 --> Session routines successfully run
DEBUG - 2012-01-16 22:04:08 --> Model Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Model Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Controller Class Initialized
DEBUG - 2012-01-16 22:04:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-16 22:04:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-16 22:04:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-16 22:04:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-16 22:04:08 --> Final output sent to browser
DEBUG - 2012-01-16 22:04:08 --> Total execution time: 0.2846
DEBUG - 2012-01-16 22:04:08 --> Config Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:04:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:04:08 --> URI Class Initialized
DEBUG - 2012-01-16 22:04:08 --> Router Class Initialized
ERROR - 2012-01-16 22:04:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-16 22:11:23 --> Config Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:11:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:11:23 --> URI Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Router Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Output Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Security Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Input Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:11:23 --> Language Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Loader Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:11:23 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Session Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:11:23 --> Session routines successfully run
DEBUG - 2012-01-16 22:11:23 --> Model Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Model Class Initialized
DEBUG - 2012-01-16 22:11:23 --> Controller Class Initialized
DEBUG - 2012-01-16 22:11:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-16 22:11:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-16 22:11:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-16 22:11:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-16 22:11:23 --> Final output sent to browser
DEBUG - 2012-01-16 22:11:23 --> Total execution time: 0.1755
DEBUG - 2012-01-16 22:11:24 --> Config Class Initialized
DEBUG - 2012-01-16 22:11:24 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:11:24 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:11:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:11:24 --> URI Class Initialized
DEBUG - 2012-01-16 22:11:24 --> Router Class Initialized
ERROR - 2012-01-16 22:11:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-16 22:11:25 --> Config Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:11:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:11:25 --> URI Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Router Class Initialized
DEBUG - 2012-01-16 22:11:25 --> No URI present. Default controller set.
DEBUG - 2012-01-16 22:11:25 --> Output Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Security Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Input Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:11:25 --> Language Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Loader Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:11:25 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Session Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:11:25 --> Session routines successfully run
DEBUG - 2012-01-16 22:11:25 --> Model Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Model Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Controller Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Pagination Class Initialized
DEBUG - 2012-01-16 22:11:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-16 22:11:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-16 22:11:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-16 22:11:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-16 22:11:25 --> Final output sent to browser
DEBUG - 2012-01-16 22:11:25 --> Total execution time: 0.1824
DEBUG - 2012-01-16 22:11:25 --> Config Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:11:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:11:25 --> URI Class Initialized
DEBUG - 2012-01-16 22:11:25 --> Router Class Initialized
ERROR - 2012-01-16 22:11:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-16 22:11:27 --> Config Class Initialized
DEBUG - 2012-01-16 22:11:27 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:11:27 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:11:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:11:28 --> URI Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Router Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Output Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Security Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Input Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:11:28 --> Language Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Loader Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:11:28 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Session Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:11:28 --> Session routines successfully run
DEBUG - 2012-01-16 22:11:28 --> Model Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Model Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Controller Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Pagination Class Initialized
DEBUG - 2012-01-16 22:11:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-16 22:11:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-16 22:11:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-16 22:11:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-16 22:11:28 --> Final output sent to browser
DEBUG - 2012-01-16 22:11:28 --> Total execution time: 0.1958
DEBUG - 2012-01-16 22:11:28 --> Config Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:11:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:11:28 --> URI Class Initialized
DEBUG - 2012-01-16 22:11:28 --> Router Class Initialized
ERROR - 2012-01-16 22:11:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-16 22:12:08 --> Config Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:12:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:12:08 --> URI Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Router Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Output Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Security Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Input Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:12:08 --> Language Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Loader Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:12:08 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Session Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:12:08 --> A session cookie was not found.
DEBUG - 2012-01-16 22:12:08 --> Session routines successfully run
DEBUG - 2012-01-16 22:12:08 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:08 --> Controller Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Config Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:12:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:12:09 --> URI Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Router Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Output Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Security Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Input Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:12:09 --> Language Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Loader Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:12:09 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Session Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:12:09 --> Session routines successfully run
DEBUG - 2012-01-16 22:12:09 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:09 --> Controller Class Initialized
DEBUG - 2012-01-16 22:12:09 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-16 22:12:09 --> Final output sent to browser
DEBUG - 2012-01-16 22:12:09 --> Total execution time: 0.2748
DEBUG - 2012-01-16 22:12:11 --> Config Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:12:11 --> URI Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Router Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Output Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Security Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Input Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:12:11 --> Language Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Loader Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:12:11 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Session Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:12:11 --> Session routines successfully run
DEBUG - 2012-01-16 22:12:11 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Controller Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Config Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Hooks Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Utf8 Class Initialized
DEBUG - 2012-01-16 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 22:12:11 --> URI Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Router Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Output Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Security Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Input Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 22:12:11 --> Language Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Loader Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Helper loaded: url_helper
DEBUG - 2012-01-16 22:12:11 --> Database Driver Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Session Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Helper loaded: string_helper
DEBUG - 2012-01-16 22:12:11 --> Session routines successfully run
DEBUG - 2012-01-16 22:12:11 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Model Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Controller Class Initialized
DEBUG - 2012-01-16 22:12:11 --> Pagination Class Initialized
DEBUG - 2012-01-16 22:12:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-16 22:12:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-16 22:12:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-16 22:12:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-16 22:12:11 --> Final output sent to browser
DEBUG - 2012-01-16 22:12:11 --> Total execution time: 0.2664
DEBUG - 2012-01-16 23:59:04 --> Config Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Hooks Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Utf8 Class Initialized
DEBUG - 2012-01-16 23:59:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 23:59:04 --> URI Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Router Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Output Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Security Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Input Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 23:59:04 --> Language Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Loader Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Helper loaded: url_helper
DEBUG - 2012-01-16 23:59:04 --> Database Driver Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Session Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Helper loaded: string_helper
DEBUG - 2012-01-16 23:59:04 --> Session routines successfully run
DEBUG - 2012-01-16 23:59:04 --> Model Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Model Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Controller Class Initialized
DEBUG - 2012-01-16 23:59:04 --> Pagination Class Initialized
DEBUG - 2012-01-16 23:59:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-16 23:59:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-16 23:59:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-16 23:59:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-16 23:59:05 --> Final output sent to browser
DEBUG - 2012-01-16 23:59:05 --> Total execution time: 0.5592
DEBUG - 2012-01-16 23:59:08 --> Config Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Hooks Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Utf8 Class Initialized
DEBUG - 2012-01-16 23:59:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 23:59:08 --> URI Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Router Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Output Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Security Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Input Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 23:59:08 --> Language Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Loader Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Helper loaded: url_helper
DEBUG - 2012-01-16 23:59:08 --> Database Driver Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Session Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Helper loaded: string_helper
DEBUG - 2012-01-16 23:59:08 --> Session routines successfully run
DEBUG - 2012-01-16 23:59:08 --> Model Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Model Class Initialized
DEBUG - 2012-01-16 23:59:08 --> Controller Class Initialized
DEBUG - 2012-01-16 23:59:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-16 23:59:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-16 23:59:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-16 23:59:08 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-16 23:59:08 --> Final output sent to browser
DEBUG - 2012-01-16 23:59:08 --> Total execution time: 0.4904
DEBUG - 2012-01-16 23:59:56 --> Config Class Initialized
DEBUG - 2012-01-16 23:59:56 --> Hooks Class Initialized
DEBUG - 2012-01-16 23:59:57 --> Utf8 Class Initialized
DEBUG - 2012-01-16 23:59:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-16 23:59:57 --> URI Class Initialized
DEBUG - 2012-01-16 23:59:57 --> Router Class Initialized
DEBUG - 2012-01-16 23:59:57 --> Output Class Initialized
DEBUG - 2012-01-16 23:59:57 --> Security Class Initialized
DEBUG - 2012-01-16 23:59:57 --> Input Class Initialized
DEBUG - 2012-01-16 23:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-16 23:59:57 --> Language Class Initialized
DEBUG - 2012-01-16 23:59:57 --> Loader Class Initialized
DEBUG - 2012-01-16 23:59:58 --> Helper loaded: url_helper
DEBUG - 2012-01-16 23:59:58 --> Database Driver Class Initialized
DEBUG - 2012-01-16 23:59:58 --> Session Class Initialized
DEBUG - 2012-01-16 23:59:58 --> Helper loaded: string_helper
DEBUG - 2012-01-16 23:59:58 --> Session routines successfully run
DEBUG - 2012-01-16 23:59:58 --> Model Class Initialized
DEBUG - 2012-01-16 23:59:58 --> Model Class Initialized
DEBUG - 2012-01-16 23:59:58 --> Controller Class Initialized
DEBUG - 2012-01-16 23:59:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-16 23:59:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-16 23:59:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-16 23:59:59 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-16 23:59:59 --> Final output sent to browser
DEBUG - 2012-01-16 23:59:59 --> Total execution time: 2.4782

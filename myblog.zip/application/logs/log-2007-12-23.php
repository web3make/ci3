<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-12-23 01:43:50 --> Config Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Hooks Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Utf8 Class Initialized
DEBUG - 2007-12-23 01:43:50 --> UTF-8 Support Enabled
DEBUG - 2007-12-23 01:43:50 --> URI Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Router Class Initialized
DEBUG - 2007-12-23 01:43:50 --> No URI present. Default controller set.
DEBUG - 2007-12-23 01:43:50 --> Output Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Security Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Input Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Global POST and COOKIE data sanitized
DEBUG - 2007-12-23 01:43:50 --> Language Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Loader Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Helper loaded: url_helper
DEBUG - 2007-12-23 01:43:50 --> Database Driver Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Session Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Helper loaded: string_helper
DEBUG - 2007-12-23 01:43:50 --> A session cookie was not found.
DEBUG - 2007-12-23 01:43:50 --> Session routines successfully run
DEBUG - 2007-12-23 01:43:50 --> Model Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Model Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Controller Class Initialized
DEBUG - 2007-12-23 01:43:50 --> Pagination Class Initialized
DEBUG - 2007-12-23 01:43:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-12-23 01:43:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-12-23 01:43:51 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-12-23 01:43:51 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-12-23 01:43:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-12-23 01:43:51 --> File loaded: application/views/user/home.php
DEBUG - 2007-12-23 01:43:51 --> Final output sent to browser
DEBUG - 2007-12-23 01:43:51 --> Total execution time: 0.4158
DEBUG - 2007-12-23 01:43:51 --> Config Class Initialized
DEBUG - 2007-12-23 01:43:51 --> Hooks Class Initialized
DEBUG - 2007-12-23 01:43:51 --> Utf8 Class Initialized
DEBUG - 2007-12-23 01:43:51 --> UTF-8 Support Enabled
DEBUG - 2007-12-23 01:43:51 --> URI Class Initialized
DEBUG - 2007-12-23 01:43:51 --> Router Class Initialized
ERROR - 2007-12-23 01:43:51 --> 404 Page Not Found --> lessons
DEBUG - 2007-12-23 01:43:51 --> Config Class Initialized
DEBUG - 2007-12-23 01:43:51 --> Hooks Class Initialized
DEBUG - 2007-12-23 01:43:51 --> Utf8 Class Initialized
DEBUG - 2007-12-23 01:43:51 --> UTF-8 Support Enabled
DEBUG - 2007-12-23 01:43:51 --> URI Class Initialized
DEBUG - 2007-12-23 01:43:51 --> Router Class Initialized
ERROR - 2007-12-23 01:43:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-12-23 01:43:58 --> Config Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Hooks Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Utf8 Class Initialized
DEBUG - 2007-12-23 01:43:58 --> UTF-8 Support Enabled
DEBUG - 2007-12-23 01:43:58 --> URI Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Router Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Output Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Security Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Input Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2007-12-23 01:43:58 --> Language Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Loader Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Helper loaded: url_helper
DEBUG - 2007-12-23 01:43:58 --> Database Driver Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Session Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Helper loaded: string_helper
DEBUG - 2007-12-23 01:43:58 --> Session routines successfully run
DEBUG - 2007-12-23 01:43:58 --> Model Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Model Class Initialized
DEBUG - 2007-12-23 01:43:58 --> Controller Class Initialized
DEBUG - 2007-12-23 01:43:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-12-23 01:43:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-12-23 01:43:58 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-12-23 01:43:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-12-23 01:43:58 --> File loaded: application/views/user/article.php
DEBUG - 2007-12-23 01:43:58 --> Final output sent to browser
DEBUG - 2007-12-23 01:43:58 --> Total execution time: 0.1480
DEBUG - 2007-12-23 01:43:59 --> Config Class Initialized
DEBUG - 2007-12-23 01:43:59 --> Hooks Class Initialized
DEBUG - 2007-12-23 01:43:59 --> Utf8 Class Initialized
DEBUG - 2007-12-23 01:43:59 --> UTF-8 Support Enabled
DEBUG - 2007-12-23 01:43:59 --> URI Class Initialized
DEBUG - 2007-12-23 01:43:59 --> Router Class Initialized
ERROR - 2007-12-23 01:43:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-12-23 01:44:03 --> Config Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Hooks Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Utf8 Class Initialized
DEBUG - 2007-12-23 01:44:03 --> UTF-8 Support Enabled
DEBUG - 2007-12-23 01:44:03 --> URI Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Router Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Output Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Security Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Input Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Global POST and COOKIE data sanitized
DEBUG - 2007-12-23 01:44:03 --> Language Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Loader Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Helper loaded: url_helper
DEBUG - 2007-12-23 01:44:03 --> Database Driver Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Session Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Helper loaded: string_helper
DEBUG - 2007-12-23 01:44:03 --> Session routines successfully run
DEBUG - 2007-12-23 01:44:03 --> Model Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Model Class Initialized
DEBUG - 2007-12-23 01:44:03 --> Controller Class Initialized
DEBUG - 2007-12-23 01:44:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-12-23 01:44:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-12-23 01:44:04 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-12-23 01:44:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-12-23 01:44:04 --> File loaded: application/views/user/article.php
DEBUG - 2007-12-23 01:44:04 --> Final output sent to browser
DEBUG - 2007-12-23 01:44:04 --> Total execution time: 0.1472
DEBUG - 2007-12-23 01:44:04 --> Config Class Initialized
DEBUG - 2007-12-23 01:44:04 --> Hooks Class Initialized
DEBUG - 2007-12-23 01:44:04 --> Utf8 Class Initialized
DEBUG - 2007-12-23 01:44:04 --> UTF-8 Support Enabled
DEBUG - 2007-12-23 01:44:04 --> URI Class Initialized
DEBUG - 2007-12-23 01:44:04 --> Router Class Initialized
ERROR - 2007-12-23 01:44:04 --> 404 Page Not Found --> favicon.ico

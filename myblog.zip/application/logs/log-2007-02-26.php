<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-02-26 04:18:19 --> Config Class Initialized
DEBUG - 2007-02-26 04:18:19 --> Hooks Class Initialized
DEBUG - 2007-02-26 04:18:19 --> Utf8 Class Initialized
DEBUG - 2007-02-26 04:18:19 --> UTF-8 Support Enabled
DEBUG - 2007-02-26 04:18:19 --> URI Class Initialized
DEBUG - 2007-02-26 04:18:20 --> Router Class Initialized
DEBUG - 2007-02-26 04:18:20 --> No URI present. Default controller set.
DEBUG - 2007-02-26 04:18:20 --> Output Class Initialized
DEBUG - 2007-02-26 04:18:20 --> Security Class Initialized
DEBUG - 2007-02-26 04:18:20 --> Input Class Initialized
DEBUG - 2007-02-26 04:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-26 04:18:20 --> Language Class Initialized
DEBUG - 2007-02-26 04:18:20 --> Loader Class Initialized
DEBUG - 2007-02-26 04:18:21 --> Helper loaded: url_helper
DEBUG - 2007-02-26 04:18:21 --> Database Driver Class Initialized
DEBUG - 2007-02-26 04:18:21 --> Session Class Initialized
DEBUG - 2007-02-26 04:18:21 --> Helper loaded: string_helper
DEBUG - 2007-02-26 04:18:21 --> A session cookie was not found.
DEBUG - 2007-02-26 04:18:21 --> Session routines successfully run
DEBUG - 2007-02-26 04:18:21 --> Model Class Initialized
DEBUG - 2007-02-26 04:18:22 --> Model Class Initialized
DEBUG - 2007-02-26 04:18:22 --> Controller Class Initialized
DEBUG - 2007-02-26 04:18:22 --> Pagination Class Initialized
DEBUG - 2007-02-26 04:18:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-26 04:18:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-26 04:18:22 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-26 04:18:22 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-26 04:18:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-26 04:18:22 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-26 04:18:22 --> Final output sent to browser
DEBUG - 2007-02-26 04:18:22 --> Total execution time: 3.5463
DEBUG - 2007-02-26 04:18:22 --> Config Class Initialized
DEBUG - 2007-02-26 04:18:22 --> Hooks Class Initialized
DEBUG - 2007-02-26 04:18:22 --> Utf8 Class Initialized
DEBUG - 2007-02-26 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2007-02-26 04:18:22 --> URI Class Initialized
DEBUG - 2007-02-26 04:18:22 --> Router Class Initialized
ERROR - 2007-02-26 04:18:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-26 04:18:23 --> Config Class Initialized
DEBUG - 2007-02-26 04:18:23 --> Hooks Class Initialized
DEBUG - 2007-02-26 04:18:23 --> Utf8 Class Initialized
DEBUG - 2007-02-26 04:18:23 --> UTF-8 Support Enabled
DEBUG - 2007-02-26 04:18:23 --> URI Class Initialized
DEBUG - 2007-02-26 04:18:23 --> Router Class Initialized
ERROR - 2007-02-26 04:18:23 --> 404 Page Not Found --> lessons

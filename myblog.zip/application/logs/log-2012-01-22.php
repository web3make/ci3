<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-22 12:35:17 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:17 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:17 --> No URI present. Default controller set.
DEBUG - 2012-01-22 12:35:17 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:17 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:17 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:17 --> A session cookie was not found.
DEBUG - 2012-01-22 12:35:17 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:17 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:17 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:35:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:35:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:35:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:35:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-22 12:35:18 --> Final output sent to browser
DEBUG - 2012-01-22 12:35:18 --> Total execution time: 1.3725
DEBUG - 2012-01-22 12:35:18 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:18 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:18 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:18 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:18 --> Router Class Initialized
ERROR - 2012-01-22 12:35:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:35:23 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:23 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:23 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:23 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:23 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:23 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:23 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:23 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:23 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:23 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:24 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:24 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:24 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:24 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:24 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:24 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:24 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-22 12:35:24 --> Final output sent to browser
DEBUG - 2012-01-22 12:35:24 --> Total execution time: 0.2516
DEBUG - 2012-01-22 12:35:24 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:24 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:24 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:24 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:24 --> Router Class Initialized
ERROR - 2012-01-22 12:35:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:35:37 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:37 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:37 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:37 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:37 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:37 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:37 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:35:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:35:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:35:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:35:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-22 12:35:37 --> Final output sent to browser
DEBUG - 2012-01-22 12:35:37 --> Total execution time: 0.2015
DEBUG - 2012-01-22 12:35:38 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:38 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:38 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:38 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:38 --> Router Class Initialized
ERROR - 2012-01-22 12:35:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:35:39 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:39 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:39 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:39 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:39 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:39 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:39 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:40 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:40 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:35:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:35:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:35:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:35:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-22 12:35:40 --> Final output sent to browser
DEBUG - 2012-01-22 12:35:40 --> Total execution time: 0.1892
DEBUG - 2012-01-22 12:35:40 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:40 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:40 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:40 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:40 --> Router Class Initialized
ERROR - 2012-01-22 12:35:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:35:41 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:41 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:41 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:41 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:41 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:41 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:41 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:35:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:35:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:35:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:35:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-22 12:35:41 --> Final output sent to browser
DEBUG - 2012-01-22 12:35:41 --> Total execution time: 0.2292
DEBUG - 2012-01-22 12:35:42 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:42 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:42 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:42 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:42 --> Router Class Initialized
ERROR - 2012-01-22 12:35:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:35:46 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:46 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:46 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:46 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:46 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:46 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:35:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:35:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:35:46 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-22 12:35:46 --> Final output sent to browser
DEBUG - 2012-01-22 12:35:46 --> Total execution time: 0.2724
DEBUG - 2012-01-22 12:35:46 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:46 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:46 --> Router Class Initialized
ERROR - 2012-01-22 12:35:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:35:51 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:51 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:51 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:51 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Router Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Output Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Security Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Input Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:35:52 --> Language Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Loader Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:35:52 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Session Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:35:52 --> Session routines successfully run
DEBUG - 2012-01-22 12:35:52 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Model Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Controller Class Initialized
DEBUG - 2012-01-22 12:35:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:35:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:35:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:35:52 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-22 12:35:52 --> Final output sent to browser
DEBUG - 2012-01-22 12:35:52 --> Total execution time: 0.2377
DEBUG - 2012-01-22 12:35:52 --> Config Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:35:52 --> URI Class Initialized
DEBUG - 2012-01-22 12:35:52 --> Router Class Initialized
ERROR - 2012-01-22 12:35:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:36:26 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:26 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:26 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:26 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:26 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:26 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:26 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:26 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:26 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:26 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:26 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:26 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:36:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:36:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:36:26 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-22 12:36:26 --> Final output sent to browser
DEBUG - 2012-01-22 12:36:26 --> Total execution time: 0.1701
DEBUG - 2012-01-22 12:36:27 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:27 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:27 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:27 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:27 --> Router Class Initialized
ERROR - 2012-01-22 12:36:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:36:31 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:31 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:31 --> No URI present. Default controller set.
DEBUG - 2012-01-22 12:36:31 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:31 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:31 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:31 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:31 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:36:31 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:36:31 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:36:31 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:36:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-22 12:36:31 --> Final output sent to browser
DEBUG - 2012-01-22 12:36:31 --> Total execution time: 0.1582
DEBUG - 2012-01-22 12:36:31 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:31 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:31 --> Router Class Initialized
ERROR - 2012-01-22 12:36:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:36:32 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:32 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:32 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:32 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:32 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:32 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:32 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:36:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:36:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:36:33 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-22 12:36:33 --> Final output sent to browser
DEBUG - 2012-01-22 12:36:33 --> Total execution time: 0.2296
DEBUG - 2012-01-22 12:36:33 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:33 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:33 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:33 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:33 --> Router Class Initialized
ERROR - 2012-01-22 12:36:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:36:34 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:34 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:34 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:34 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:34 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:34 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:34 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:34 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:34 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:35 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:35 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:35 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:36:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:36:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:36:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-22 12:36:35 --> Final output sent to browser
DEBUG - 2012-01-22 12:36:35 --> Total execution time: 0.2003
DEBUG - 2012-01-22 12:36:35 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:35 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:35 --> Router Class Initialized
ERROR - 2012-01-22 12:36:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:36:36 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:36 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:36 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:36 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:36 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:36 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:36:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:36:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:36:36 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-22 12:36:36 --> Final output sent to browser
DEBUG - 2012-01-22 12:36:36 --> Total execution time: 0.1954
DEBUG - 2012-01-22 12:36:36 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:36 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:36 --> Router Class Initialized
ERROR - 2012-01-22 12:36:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:36:39 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:39 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:39 --> No URI present. Default controller set.
DEBUG - 2012-01-22 12:36:39 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:39 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:39 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:39 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:39 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:36:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:36:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:36:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:36:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-22 12:36:39 --> Final output sent to browser
DEBUG - 2012-01-22 12:36:39 --> Total execution time: 0.1656
DEBUG - 2012-01-22 12:36:39 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:39 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:39 --> Router Class Initialized
ERROR - 2012-01-22 12:36:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:36:57 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:57 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:57 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:57 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:57 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:57 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:57 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Router Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Output Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Security Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Input Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:36:57 --> Language Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Loader Class Initialized
DEBUG - 2012-01-22 12:36:57 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:36:58 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Session Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:36:58 --> Session routines successfully run
DEBUG - 2012-01-22 12:36:58 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Model Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Controller Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:36:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:36:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:36:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:36:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-22 12:36:58 --> Final output sent to browser
DEBUG - 2012-01-22 12:36:58 --> Total execution time: 0.2515
DEBUG - 2012-01-22 12:36:58 --> Config Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:36:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:36:58 --> URI Class Initialized
DEBUG - 2012-01-22 12:36:58 --> Router Class Initialized
ERROR - 2012-01-22 12:36:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:16 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:16 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:16 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:16 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:16 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:16 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:16 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-22 12:37:16 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:16 --> Total execution time: 0.2314
DEBUG - 2012-01-22 12:37:16 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:16 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:16 --> Router Class Initialized
ERROR - 2012-01-22 12:37:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:22 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:22 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:22 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:22 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:22 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:22 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:22 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:22 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:22 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:22 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-22 12:37:22 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:22 --> Total execution time: 0.1582
DEBUG - 2012-01-22 12:37:22 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:22 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:22 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:23 --> Router Class Initialized
ERROR - 2012-01-22 12:37:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:24 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:24 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:24 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:24 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:24 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:24 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:24 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:24 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:24 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:25 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:25 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:25 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:25 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:37:25 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:25 --> Total execution time: 0.2274
DEBUG - 2012-01-22 12:37:25 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:25 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:25 --> Router Class Initialized
ERROR - 2012-01-22 12:37:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:28 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:28 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:28 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:28 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:28 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:28 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:28 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:37:28 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:28 --> Total execution time: 0.1556
DEBUG - 2012-01-22 12:37:28 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:28 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:28 --> Router Class Initialized
ERROR - 2012-01-22 12:37:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:30 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:30 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:30 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:30 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:30 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:30 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:37:30 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:30 --> Total execution time: 0.1534
DEBUG - 2012-01-22 12:37:30 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:30 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:30 --> Router Class Initialized
ERROR - 2012-01-22 12:37:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:31 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:31 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:31 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:31 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:31 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:31 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:31 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:31 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:37:31 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:31 --> Total execution time: 0.1686
DEBUG - 2012-01-22 12:37:32 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:32 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:32 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:32 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:32 --> Router Class Initialized
ERROR - 2012-01-22 12:37:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:40 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:40 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:40 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:40 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:40 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:40 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:40 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-22 12:37:40 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:40 --> Total execution time: 0.1584
DEBUG - 2012-01-22 12:37:40 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:40 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:40 --> Router Class Initialized
ERROR - 2012-01-22 12:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:54 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:54 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:54 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:54 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:54 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:54 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:54 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:55 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:37:55 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:55 --> Total execution time: 0.1854
DEBUG - 2012-01-22 12:37:55 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:55 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:55 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:55 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:55 --> Router Class Initialized
ERROR - 2012-01-22 12:37:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:56 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:56 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:56 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:56 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:56 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:56 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:56 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:37:56 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:56 --> Total execution time: 0.1507
DEBUG - 2012-01-22 12:37:56 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:56 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:57 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:57 --> Router Class Initialized
ERROR - 2012-01-22 12:37:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:37:59 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:59 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Router Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Output Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Security Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Input Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:37:59 --> Language Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Loader Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:37:59 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Session Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:37:59 --> Session routines successfully run
DEBUG - 2012-01-22 12:37:59 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Model Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Controller Class Initialized
DEBUG - 2012-01-22 12:37:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:37:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:37:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:37:59 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-22 12:37:59 --> Final output sent to browser
DEBUG - 2012-01-22 12:37:59 --> Total execution time: 0.1591
DEBUG - 2012-01-22 12:37:59 --> Config Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:37:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:37:59 --> URI Class Initialized
DEBUG - 2012-01-22 12:37:59 --> Router Class Initialized
ERROR - 2012-01-22 12:37:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:01 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:01 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:01 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:01 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:01 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:01 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:01 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-22 12:38:01 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:01 --> Total execution time: 0.2356
DEBUG - 2012-01-22 12:38:01 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:01 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:01 --> Router Class Initialized
ERROR - 2012-01-22 12:38:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:03 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:03 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:03 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:03 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:03 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:03 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:03 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:03 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:38:03 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:03 --> Total execution time: 0.1505
DEBUG - 2012-01-22 12:38:04 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:04 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:04 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:04 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:04 --> Router Class Initialized
ERROR - 2012-01-22 12:38:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:05 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:05 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:05 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:05 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:05 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:05 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:05 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:05 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-22 12:38:05 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:05 --> Total execution time: 0.1635
DEBUG - 2012-01-22 12:38:06 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:06 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:06 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:06 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:06 --> Router Class Initialized
ERROR - 2012-01-22 12:38:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:07 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:07 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:07 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:07 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:07 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:07 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:07 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-22 12:38:07 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:07 --> Total execution time: 0.1561
DEBUG - 2012-01-22 12:38:07 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:07 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:07 --> Router Class Initialized
ERROR - 2012-01-22 12:38:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:13 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:13 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:13 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:13 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:13 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:13 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:13 --> File loaded: application/views/admin/comment_edit.php
DEBUG - 2012-01-22 12:38:13 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:13 --> Total execution time: 0.1994
DEBUG - 2012-01-22 12:38:13 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:13 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:13 --> Router Class Initialized
ERROR - 2012-01-22 12:38:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:22 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:22 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:22 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:22 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:22 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:22 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:22 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:22 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:22 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:22 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-22 12:38:22 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:22 --> Total execution time: 0.1714
DEBUG - 2012-01-22 12:38:22 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:22 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:22 --> Router Class Initialized
ERROR - 2012-01-22 12:38:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:33 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:33 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:33 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:33 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:33 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:33 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:33 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:34 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:34 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:34 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:34 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:34 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:34 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-22 12:38:34 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:34 --> Total execution time: 0.1542
DEBUG - 2012-01-22 12:38:34 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:34 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:34 --> Router Class Initialized
ERROR - 2012-01-22 12:38:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:37 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:37 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:37 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:37 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:37 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:37 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:37 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:37 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:37 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:37 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:37 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:37 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-22 12:38:37 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:37 --> Total execution time: 0.1529
DEBUG - 2012-01-22 12:38:37 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:37 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:37 --> Router Class Initialized
ERROR - 2012-01-22 12:38:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:43 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:43 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:43 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:43 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:43 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:43 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:43 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:38:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:38:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:38:43 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-22 12:38:43 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:43 --> Total execution time: 0.1826
DEBUG - 2012-01-22 12:38:44 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:44 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:44 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:44 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:44 --> Router Class Initialized
ERROR - 2012-01-22 12:38:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:55 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:55 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:55 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:55 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:56 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:56 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:56 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:56 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:56 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:56 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:56 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:56 --> A session cookie was not found.
DEBUG - 2012-01-22 12:38:56 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:56 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:56 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-22 12:38:56 --> Final output sent to browser
DEBUG - 2012-01-22 12:38:56 --> Total execution time: 0.1396
DEBUG - 2012-01-22 12:38:56 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:56 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:56 --> Router Class Initialized
ERROR - 2012-01-22 12:38:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:38:59 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:59 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Security Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Input Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:38:59 --> Language Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Loader Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:38:59 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Session Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:38:59 --> Session routines successfully run
DEBUG - 2012-01-22 12:38:59 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Model Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Controller Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Config Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:38:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:38:59 --> URI Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Router Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Output Class Initialized
DEBUG - 2012-01-22 12:38:59 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:00 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:00 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:00 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:00 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:39:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:39:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:39:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-22 12:39:00 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:00 --> Total execution time: 0.1738
DEBUG - 2012-01-22 12:39:00 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:00 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:00 --> Router Class Initialized
ERROR - 2012-01-22 12:39:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:39:29 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:29 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:29 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:29 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:29 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:29 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:29 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:39:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:39:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:39:29 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-22 12:39:29 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:29 --> Total execution time: 0.2191
DEBUG - 2012-01-22 12:39:30 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:30 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:30 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:30 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:30 --> Router Class Initialized
ERROR - 2012-01-22 12:39:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:39:31 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:31 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:31 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:31 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:31 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:31 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:39:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:39:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:39:31 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-22 12:39:31 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:31 --> Total execution time: 0.1959
DEBUG - 2012-01-22 12:39:31 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:31 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:31 --> Router Class Initialized
ERROR - 2012-01-22 12:39:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:39:38 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:38 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:38 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:38 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:39 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:39 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:39 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:39 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:39 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:39 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:39 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:39:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:39:39 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-22 12:39:39 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:39 --> Total execution time: 0.2192
DEBUG - 2012-01-22 12:39:39 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:39 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:39 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:39 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:39 --> Router Class Initialized
ERROR - 2012-01-22 12:39:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:39:42 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:42 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:42 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:42 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:42 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:42 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:42 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:42 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:42 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:42 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:42 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:39:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:39:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:39:42 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-22 12:39:42 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:42 --> Total execution time: 0.1806
DEBUG - 2012-01-22 12:39:42 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:42 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:42 --> Router Class Initialized
ERROR - 2012-01-22 12:39:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:39:44 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:44 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:44 --> No URI present. Default controller set.
DEBUG - 2012-01-22 12:39:44 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:44 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:44 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:44 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:44 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:44 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:39:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-22 12:39:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-22 12:39:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-22 12:39:44 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:44 --> Total execution time: 0.1666
DEBUG - 2012-01-22 12:39:45 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:45 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:45 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:45 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:45 --> Router Class Initialized
ERROR - 2012-01-22 12:39:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:39:53 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:53 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:53 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:53 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:53 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:53 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:39:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:39:53 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-22 12:39:53 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:53 --> Total execution time: 0.1883
DEBUG - 2012-01-22 12:39:53 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:53 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:53 --> Router Class Initialized
ERROR - 2012-01-22 12:39:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-22 12:39:57 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:57 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:57 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:57 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:57 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:57 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:57 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Router Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Output Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Security Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Input Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-22 12:39:57 --> Language Class Initialized
DEBUG - 2012-01-22 12:39:57 --> Loader Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Helper loaded: url_helper
DEBUG - 2012-01-22 12:39:58 --> Database Driver Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Session Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Helper loaded: string_helper
DEBUG - 2012-01-22 12:39:58 --> Session routines successfully run
DEBUG - 2012-01-22 12:39:58 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Model Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Controller Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Pagination Class Initialized
DEBUG - 2012-01-22 12:39:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-22 12:39:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-22 12:39:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-22 12:39:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-22 12:39:58 --> Final output sent to browser
DEBUG - 2012-01-22 12:39:58 --> Total execution time: 0.1998
DEBUG - 2012-01-22 12:39:58 --> Config Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Hooks Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Utf8 Class Initialized
DEBUG - 2012-01-22 12:39:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-22 12:39:58 --> URI Class Initialized
DEBUG - 2012-01-22 12:39:58 --> Router Class Initialized
ERROR - 2012-01-22 12:39:58 --> 404 Page Not Found --> favicon.ico

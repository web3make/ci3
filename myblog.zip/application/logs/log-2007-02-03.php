<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-02-03 01:08:30 --> Config Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Hooks Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Utf8 Class Initialized
DEBUG - 2007-02-03 01:08:30 --> UTF-8 Support Enabled
DEBUG - 2007-02-03 01:08:30 --> URI Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Router Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Output Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Security Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Input Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-03 01:08:30 --> Language Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Loader Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Helper loaded: url_helper
DEBUG - 2007-02-03 01:08:30 --> Database Driver Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Session Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Helper loaded: string_helper
DEBUG - 2007-02-03 01:08:30 --> Session routines successfully run
DEBUG - 2007-02-03 01:08:30 --> Model Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Model Class Initialized
DEBUG - 2007-02-03 01:08:30 --> Controller Class Initialized
DEBUG - 2007-02-03 01:08:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-03 01:08:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-03 01:08:30 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-02-03 01:08:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-03 01:08:30 --> File loaded: application/views/user/article.php
DEBUG - 2007-02-03 01:08:30 --> Final output sent to browser
DEBUG - 2007-02-03 01:08:30 --> Total execution time: 0.1786
DEBUG - 2007-02-03 01:08:31 --> Config Class Initialized
DEBUG - 2007-02-03 01:08:31 --> Hooks Class Initialized
DEBUG - 2007-02-03 01:08:31 --> Utf8 Class Initialized
DEBUG - 2007-02-03 01:08:31 --> UTF-8 Support Enabled
DEBUG - 2007-02-03 01:08:31 --> URI Class Initialized
DEBUG - 2007-02-03 01:08:31 --> Router Class Initialized
ERROR - 2007-02-03 01:08:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-03 01:08:32 --> Config Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Hooks Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Utf8 Class Initialized
DEBUG - 2007-02-03 01:08:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-03 01:08:32 --> URI Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Router Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Output Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Security Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Input Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-03 01:08:32 --> Language Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Loader Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Helper loaded: url_helper
DEBUG - 2007-02-03 01:08:32 --> Database Driver Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Session Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Helper loaded: string_helper
DEBUG - 2007-02-03 01:08:32 --> Session routines successfully run
DEBUG - 2007-02-03 01:08:32 --> Model Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Model Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Controller Class Initialized
DEBUG - 2007-02-03 01:08:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-03 01:08:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-03 01:08:32 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-02-03 01:08:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-03 01:08:32 --> File loaded: application/views/user/article.php
DEBUG - 2007-02-03 01:08:32 --> Final output sent to browser
DEBUG - 2007-02-03 01:08:32 --> Total execution time: 0.1567
DEBUG - 2007-02-03 01:08:32 --> Config Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Hooks Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Utf8 Class Initialized
DEBUG - 2007-02-03 01:08:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-03 01:08:32 --> URI Class Initialized
DEBUG - 2007-02-03 01:08:32 --> Router Class Initialized
ERROR - 2007-02-03 01:08:32 --> 404 Page Not Found --> favicon.ico

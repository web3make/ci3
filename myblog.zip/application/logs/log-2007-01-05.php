<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-01-05 02:30:22 --> Config Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:30:22 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:30:22 --> URI Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Router Class Initialized
DEBUG - 2007-01-05 02:30:22 --> No URI present. Default controller set.
DEBUG - 2007-01-05 02:30:22 --> Output Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Security Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Input Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:30:22 --> Language Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Loader Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:30:22 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Session Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:30:22 --> A session cookie was not found.
DEBUG - 2007-01-05 02:30:22 --> Session routines successfully run
DEBUG - 2007-01-05 02:30:22 --> Model Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Model Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Controller Class Initialized
DEBUG - 2007-01-05 02:30:22 --> Pagination Class Initialized
DEBUG - 2007-01-05 02:30:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:30:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:30:23 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-05 02:30:23 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-05 02:30:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:30:23 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-05 02:30:25 --> Config Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:30:25 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:30:25 --> URI Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Router Class Initialized
DEBUG - 2007-01-05 02:30:25 --> No URI present. Default controller set.
DEBUG - 2007-01-05 02:30:25 --> Output Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Security Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Input Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:30:25 --> Language Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Loader Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:30:25 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Session Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:30:25 --> A session cookie was not found.
DEBUG - 2007-01-05 02:30:25 --> Session routines successfully run
DEBUG - 2007-01-05 02:30:25 --> Model Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Model Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Controller Class Initialized
DEBUG - 2007-01-05 02:30:25 --> Pagination Class Initialized
DEBUG - 2007-01-05 02:30:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:30:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:30:26 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-05 02:30:26 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-05 02:30:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:30:26 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-05 02:30:26 --> Final output sent to browser
DEBUG - 2007-01-05 02:30:26 --> Total execution time: 0.1039
DEBUG - 2007-01-05 02:30:26 --> Config Class Initialized
DEBUG - 2007-01-05 02:30:26 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:30:26 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:30:26 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:30:26 --> URI Class Initialized
DEBUG - 2007-01-05 02:30:26 --> Router Class Initialized
ERROR - 2007-01-05 02:30:26 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:30:26 --> Config Class Initialized
DEBUG - 2007-01-05 02:30:26 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:30:26 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:30:26 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:30:26 --> URI Class Initialized
DEBUG - 2007-01-05 02:30:26 --> Router Class Initialized
ERROR - 2007-01-05 02:30:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-05 02:32:35 --> Config Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:32:35 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:32:35 --> URI Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Router Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Output Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Security Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Input Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:32:35 --> Language Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Loader Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:32:35 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Session Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:32:35 --> Session routines successfully run
DEBUG - 2007-01-05 02:32:35 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Controller Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Config Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:32:35 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:32:35 --> URI Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Router Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Output Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Security Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Input Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:32:35 --> Language Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Loader Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:32:35 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Session Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:32:35 --> Session routines successfully run
DEBUG - 2007-01-05 02:32:35 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:35 --> Controller Class Initialized
DEBUG - 2007-01-05 02:32:35 --> File loaded: application/views/admin/login.php
DEBUG - 2007-01-05 02:32:35 --> Final output sent to browser
DEBUG - 2007-01-05 02:32:35 --> Total execution time: 0.0718
DEBUG - 2007-01-05 02:32:50 --> Config Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:32:50 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:32:50 --> URI Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Router Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Output Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Security Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Input Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:32:50 --> Language Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Loader Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:32:50 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Session Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:32:50 --> Session routines successfully run
DEBUG - 2007-01-05 02:32:50 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Controller Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Config Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:32:50 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:32:50 --> URI Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Router Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Output Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Security Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Input Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:32:50 --> Language Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Loader Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:32:50 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Session Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:32:50 --> Session routines successfully run
DEBUG - 2007-01-05 02:32:50 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Controller Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Pagination Class Initialized
ERROR - 2007-01-05 02:32:50 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:32:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:32:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:32:50 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-01-05 02:32:50 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-01-05 02:32:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:32:50 --> File loaded: application/views/admin/home.php
DEBUG - 2007-01-05 02:32:50 --> Final output sent to browser
DEBUG - 2007-01-05 02:32:50 --> Total execution time: 0.1485
DEBUG - 2007-01-05 02:32:50 --> Config Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:32:50 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:32:50 --> URI Class Initialized
DEBUG - 2007-01-05 02:32:50 --> Router Class Initialized
ERROR - 2007-01-05 02:32:50 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:32:55 --> Config Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:32:55 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:32:55 --> URI Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Router Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Output Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Security Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Input Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:32:55 --> Language Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Loader Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:32:55 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Session Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:32:55 --> Session routines successfully run
DEBUG - 2007-01-05 02:32:55 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:55 --> Controller Class Initialized
ERROR - 2007-01-05 02:32:55 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:32:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:32:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:32:55 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-05 02:32:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:32:55 --> File loaded: application/views/admin/category.php
DEBUG - 2007-01-05 02:32:55 --> Final output sent to browser
DEBUG - 2007-01-05 02:32:55 --> Total execution time: 0.0993
DEBUG - 2007-01-05 02:32:56 --> Config Class Initialized
DEBUG - 2007-01-05 02:32:56 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:32:56 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:32:56 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:32:56 --> URI Class Initialized
DEBUG - 2007-01-05 02:32:56 --> Router Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Output Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Security Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Input Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:32:57 --> Language Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Loader Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:32:57 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Session Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:32:57 --> Session routines successfully run
DEBUG - 2007-01-05 02:32:57 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Model Class Initialized
DEBUG - 2007-01-05 02:32:57 --> Controller Class Initialized
ERROR - 2007-01-05 02:32:57 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:32:57 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:32:57 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2007-01-05 02:32:57 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\settings.php 18
DEBUG - 2007-01-05 02:32:57 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:32:57 --> File loaded: application/views/admin/settings.php
DEBUG - 2007-01-05 02:32:57 --> Final output sent to browser
DEBUG - 2007-01-05 02:32:57 --> Total execution time: 0.0698
DEBUG - 2007-01-05 02:33:01 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:01 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:01 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:01 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:01 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:01 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:01 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:01 --> Controller Class Initialized
ERROR - 2007-01-05 02:33:01 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:01 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-05 02:33:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:01 --> File loaded: application/views/admin/category.php
DEBUG - 2007-01-05 02:33:01 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:01 --> Total execution time: 0.0782
DEBUG - 2007-01-05 02:33:05 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:05 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:05 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:05 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:05 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:05 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:05 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:05 --> Controller Class Initialized
ERROR - 2007-01-05 02:33:05 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:05 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-05 02:33:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:05 --> File loaded: application/views/admin/category.php
DEBUG - 2007-01-05 02:33:05 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:05 --> Total execution time: 0.0695
DEBUG - 2007-01-05 02:33:06 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:06 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:06 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:06 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:06 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:06 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:07 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:07 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:07 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:07 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:07 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:07 --> Controller Class Initialized
ERROR - 2007-01-05 02:33:07 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:07 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-05 02:33:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:07 --> File loaded: application/views/admin/category.php
DEBUG - 2007-01-05 02:33:07 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:07 --> Total execution time: 0.0687
DEBUG - 2007-01-05 02:33:07 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:07 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:07 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:07 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:07 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:07 --> Router Class Initialized
ERROR - 2007-01-05 02:33:07 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:33:08 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:08 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:08 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:08 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:08 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:08 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:08 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:08 --> Controller Class Initialized
ERROR - 2007-01-05 02:33:08 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:08 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-05 02:33:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:08 --> File loaded: application/views/admin/category.php
DEBUG - 2007-01-05 02:33:08 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:08 --> Total execution time: 0.0589
DEBUG - 2007-01-05 02:33:10 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:10 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:10 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:10 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:10 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:10 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:10 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:10 --> Controller Class Initialized
ERROR - 2007-01-05 02:33:10 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:10 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:10 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:10 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:10 --> File loaded: application/views/admin/category_new.php
DEBUG - 2007-01-05 02:33:10 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:10 --> Total execution time: 0.0680
DEBUG - 2007-01-05 02:33:15 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:15 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:15 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:15 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:15 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:15 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:16 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:16 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Controller Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:33:16 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:16 --> File loaded: application/views/admin/page.php
DEBUG - 2007-01-05 02:33:16 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:16 --> Total execution time: 0.1482
DEBUG - 2007-01-05 02:33:16 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:16 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:16 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:16 --> Router Class Initialized
ERROR - 2007-01-05 02:33:16 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:33:19 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:19 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:19 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:19 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:19 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:19 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:19 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Controller Class Initialized
DEBUG - 2007-01-05 02:33:19 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:33:19 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:19 --> File loaded: application/views/admin/page_create.php
DEBUG - 2007-01-05 02:33:19 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:19 --> Total execution time: 0.1044
DEBUG - 2007-01-05 02:33:21 --> Config Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:33:21 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:33:21 --> URI Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Router Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Output Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Security Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Input Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:33:21 --> Language Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Loader Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:33:21 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Session Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:33:21 --> Session routines successfully run
DEBUG - 2007-01-05 02:33:21 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Model Class Initialized
DEBUG - 2007-01-05 02:33:21 --> Controller Class Initialized
ERROR - 2007-01-05 02:33:21 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:33:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:33:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:33:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:33:21 --> File loaded: application/views/admin/category_new.php
DEBUG - 2007-01-05 02:33:21 --> Final output sent to browser
DEBUG - 2007-01-05 02:33:21 --> Total execution time: 0.0722
DEBUG - 2007-01-05 02:46:24 --> Config Class Initialized
DEBUG - 2007-01-05 02:46:24 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:46:24 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:46:24 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:46:24 --> URI Class Initialized
DEBUG - 2007-01-05 02:46:24 --> Router Class Initialized
DEBUG - 2007-01-05 02:46:24 --> Output Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Security Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Input Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:46:25 --> Language Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Loader Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:46:25 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Session Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:46:25 --> Session routines successfully run
DEBUG - 2007-01-05 02:46:25 --> Model Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Model Class Initialized
DEBUG - 2007-01-05 02:46:25 --> Controller Class Initialized
ERROR - 2007-01-05 02:46:25 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:46:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:46:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:46:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:46:25 --> File loaded: application/views/admin/category_new.php
DEBUG - 2007-01-05 02:46:25 --> Final output sent to browser
DEBUG - 2007-01-05 02:46:25 --> Total execution time: 0.0714
DEBUG - 2007-01-05 02:46:27 --> Config Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:46:27 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:46:27 --> URI Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Router Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Output Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Security Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Input Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:46:27 --> Language Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Loader Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:46:27 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Session Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:46:27 --> Session routines successfully run
DEBUG - 2007-01-05 02:46:27 --> Model Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Model Class Initialized
DEBUG - 2007-01-05 02:46:27 --> Controller Class Initialized
ERROR - 2007-01-05 02:46:27 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:46:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:46:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:46:27 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-05 02:46:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:46:27 --> File loaded: application/views/admin/category.php
DEBUG - 2007-01-05 02:46:27 --> Final output sent to browser
DEBUG - 2007-01-05 02:46:27 --> Total execution time: 0.0694
DEBUG - 2007-01-05 02:46:28 --> Config Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:46:28 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:46:28 --> URI Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Router Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Output Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Security Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Input Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:46:28 --> Language Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Loader Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:46:28 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Session Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:46:28 --> Session routines successfully run
DEBUG - 2007-01-05 02:46:28 --> Model Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Model Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Controller Class Initialized
DEBUG - 2007-01-05 02:46:28 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:46:28 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:46:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:46:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:46:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:46:28 --> File loaded: application/views/admin/article_create.php
DEBUG - 2007-01-05 02:46:28 --> Final output sent to browser
DEBUG - 2007-01-05 02:46:28 --> Total execution time: 0.0913
DEBUG - 2007-01-05 02:47:31 --> Config Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:47:31 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:47:31 --> URI Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Router Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Output Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Security Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Input Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:47:31 --> Language Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Loader Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:47:31 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Session Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:47:31 --> Session routines successfully run
DEBUG - 2007-01-05 02:47:31 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Controller Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Config Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:47:31 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:47:31 --> URI Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Router Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Output Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Security Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Input Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:47:31 --> Language Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Loader Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:47:31 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Session Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:47:31 --> Session routines successfully run
DEBUG - 2007-01-05 02:47:31 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Controller Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Pagination Class Initialized
ERROR - 2007-01-05 02:47:31 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:47:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:47:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:47:31 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-01-05 02:47:31 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-01-05 02:47:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:47:31 --> File loaded: application/views/admin/home.php
DEBUG - 2007-01-05 02:47:31 --> Final output sent to browser
DEBUG - 2007-01-05 02:47:31 --> Total execution time: 0.0831
DEBUG - 2007-01-05 02:47:31 --> Config Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:47:31 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:47:31 --> URI Class Initialized
DEBUG - 2007-01-05 02:47:31 --> Router Class Initialized
ERROR - 2007-01-05 02:47:31 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:47:37 --> Config Class Initialized
DEBUG - 2007-01-05 02:47:37 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:47:37 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:47:37 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:47:37 --> URI Class Initialized
DEBUG - 2007-01-05 02:47:37 --> Router Class Initialized
DEBUG - 2007-01-05 02:47:37 --> Output Class Initialized
DEBUG - 2007-01-05 02:47:37 --> Security Class Initialized
DEBUG - 2007-01-05 02:47:37 --> Input Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:47:38 --> Language Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Loader Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:47:38 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Session Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:47:38 --> Session routines successfully run
DEBUG - 2007-01-05 02:47:38 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Controller Class Initialized
DEBUG - 2007-01-05 02:47:38 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:47:38 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:47:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:47:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:47:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:47:38 --> File loaded: application/views/admin/article_create.php
DEBUG - 2007-01-05 02:47:38 --> Final output sent to browser
DEBUG - 2007-01-05 02:47:38 --> Total execution time: 0.0920
DEBUG - 2007-01-05 02:47:48 --> Config Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:47:48 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:47:48 --> URI Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Router Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Output Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Security Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Input Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:47:48 --> Language Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Loader Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:47:48 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Session Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:47:48 --> Session routines successfully run
DEBUG - 2007-01-05 02:47:48 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Model Class Initialized
DEBUG - 2007-01-05 02:47:48 --> Controller Class Initialized
ERROR - 2007-01-05 02:47:48 --> 404 Page Not Found --> article/lists
DEBUG - 2007-01-05 02:48:55 --> Config Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:48:55 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:48:55 --> URI Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Router Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Output Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Security Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Input Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:48:55 --> Language Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Loader Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:48:55 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Session Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:48:55 --> Session routines successfully run
DEBUG - 2007-01-05 02:48:55 --> Model Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Model Class Initialized
DEBUG - 2007-01-05 02:48:55 --> Controller Class Initialized
ERROR - 2007-01-05 02:48:55 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:48:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:48:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:48:55 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-05 02:48:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:48:55 --> File loaded: application/views/admin/category.php
DEBUG - 2007-01-05 02:48:55 --> Final output sent to browser
DEBUG - 2007-01-05 02:48:55 --> Total execution time: 0.0692
DEBUG - 2007-01-05 02:49:02 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:02 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:02 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:02 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:02 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:02 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Controller Class Initialized
DEBUG - 2007-01-05 02:49:02 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:49:02 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:02 --> File loaded: application/views/admin/article.php
DEBUG - 2007-01-05 02:49:02 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:02 --> Total execution time: 0.0991
DEBUG - 2007-01-05 02:49:06 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:06 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:06 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:06 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:06 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:06 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:06 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:06 --> Controller Class Initialized
ERROR - 2007-01-05 02:49:06 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:06 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:06 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:06 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:06 --> File loaded: application/views/admin/comments.php
DEBUG - 2007-01-05 02:49:06 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:06 --> Total execution time: 0.0887
DEBUG - 2007-01-05 02:49:22 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:22 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:22 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:22 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:22 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:22 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:22 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:22 --> Controller Class Initialized
ERROR - 2007-01-05 02:49:22 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:22 --> File loaded: application/views/admin/comment_edit.php
DEBUG - 2007-01-05 02:49:22 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:22 --> Total execution time: 0.0671
DEBUG - 2007-01-05 02:49:46 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:46 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:46 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:46 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:46 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:46 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Controller Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:49:46 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:46 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:46 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:46 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:46 --> File loaded: application/views/admin/page.php
DEBUG - 2007-01-05 02:49:46 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:46 --> Total execution time: 0.0752
DEBUG - 2007-01-05 02:49:46 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:46 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:46 --> Router Class Initialized
ERROR - 2007-01-05 02:49:46 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:49:48 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:48 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:48 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:48 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:48 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:48 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:48 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Controller Class Initialized
DEBUG - 2007-01-05 02:49:48 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:49:48 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:48 --> File loaded: application/views/admin/page_create.php
DEBUG - 2007-01-05 02:49:48 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:48 --> Total execution time: 0.0821
DEBUG - 2007-01-05 02:49:53 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:53 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:53 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:53 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:53 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:53 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:53 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Controller Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:53 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:53 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:53 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:53 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:53 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:53 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Controller Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Pagination Class Initialized
ERROR - 2007-01-05 02:49:53 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:53 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-01-05 02:49:53 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-01-05 02:49:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:53 --> File loaded: application/views/admin/home.php
DEBUG - 2007-01-05 02:49:53 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:53 --> Total execution time: 0.0720
DEBUG - 2007-01-05 02:49:53 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:53 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:53 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:53 --> Router Class Initialized
ERROR - 2007-01-05 02:49:53 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:49:56 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:56 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:56 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:56 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:56 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:56 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:56 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Controller Class Initialized
DEBUG - 2007-01-05 02:49:56 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:49:56 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:56 --> File loaded: application/views/admin/page.php
DEBUG - 2007-01-05 02:49:56 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:56 --> Total execution time: 0.0680
DEBUG - 2007-01-05 02:49:57 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:57 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:57 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Router Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Output Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Security Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Input Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:49:57 --> Language Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Loader Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:49:57 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Session Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:49:57 --> Session routines successfully run
DEBUG - 2007-01-05 02:49:57 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Model Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Controller Class Initialized
DEBUG - 2007-01-05 02:49:57 --> Helper loaded: tinymce_helper
ERROR - 2007-01-05 02:49:57 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-05 02:49:57 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-05 02:49:57 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-05 02:49:57 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-05 02:49:57 --> File loaded: application/views/admin/page.php
DEBUG - 2007-01-05 02:49:57 --> Final output sent to browser
DEBUG - 2007-01-05 02:49:57 --> Total execution time: 0.2917
DEBUG - 2007-01-05 02:49:58 --> Config Class Initialized
DEBUG - 2007-01-05 02:49:58 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:49:58 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:49:58 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:49:58 --> URI Class Initialized
DEBUG - 2007-01-05 02:49:58 --> Router Class Initialized
ERROR - 2007-01-05 02:49:58 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:50:05 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:05 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Router Class Initialized
DEBUG - 2007-01-05 02:50:05 --> No URI present. Default controller set.
DEBUG - 2007-01-05 02:50:05 --> Output Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Security Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Input Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:50:05 --> Language Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Loader Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:50:05 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Session Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:50:05 --> Session routines successfully run
DEBUG - 2007-01-05 02:50:05 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Controller Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Pagination Class Initialized
DEBUG - 2007-01-05 02:50:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:50:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:50:05 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-05 02:50:05 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-05 02:50:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:50:05 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-05 02:50:05 --> Final output sent to browser
DEBUG - 2007-01-05 02:50:05 --> Total execution time: 0.0905
DEBUG - 2007-01-05 02:50:05 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:05 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:05 --> Router Class Initialized
ERROR - 2007-01-05 02:50:05 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:50:07 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:07 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:07 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Router Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Output Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Security Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Input Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:50:07 --> Language Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Loader Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:50:07 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Session Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:50:07 --> Session routines successfully run
DEBUG - 2007-01-05 02:50:07 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:07 --> Controller Class Initialized
DEBUG - 2007-01-05 02:50:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:50:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:50:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:50:07 --> File loaded: application/views/user/page.php
DEBUG - 2007-01-05 02:50:07 --> Final output sent to browser
DEBUG - 2007-01-05 02:50:07 --> Total execution time: 0.0697
DEBUG - 2007-01-05 02:50:08 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:08 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Router Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Output Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Security Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Input Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:50:08 --> Language Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Loader Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:50:08 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Session Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:50:08 --> Session routines successfully run
DEBUG - 2007-01-05 02:50:08 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Controller Class Initialized
DEBUG - 2007-01-05 02:50:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:50:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:50:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:50:08 --> File loaded: application/views/user/page.php
DEBUG - 2007-01-05 02:50:08 --> Final output sent to browser
DEBUG - 2007-01-05 02:50:08 --> Total execution time: 0.0644
DEBUG - 2007-01-05 02:50:08 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:08 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:08 --> Router Class Initialized
ERROR - 2007-01-05 02:50:08 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:50:10 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:10 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:10 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Router Class Initialized
DEBUG - 2007-01-05 02:50:10 --> No URI present. Default controller set.
DEBUG - 2007-01-05 02:50:10 --> Output Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Security Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Input Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:50:10 --> Language Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Loader Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:50:10 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Session Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:50:10 --> Session routines successfully run
DEBUG - 2007-01-05 02:50:10 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Controller Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Pagination Class Initialized
DEBUG - 2007-01-05 02:50:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:50:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:50:10 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-05 02:50:10 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-05 02:50:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:50:10 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-05 02:50:10 --> Final output sent to browser
DEBUG - 2007-01-05 02:50:10 --> Total execution time: 0.0777
DEBUG - 2007-01-05 02:50:10 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:10 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:10 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:10 --> Router Class Initialized
ERROR - 2007-01-05 02:50:10 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:50:12 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:12 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:12 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Router Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Output Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Security Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Input Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:50:12 --> Language Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Loader Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:50:12 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Session Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:50:12 --> Session routines successfully run
DEBUG - 2007-01-05 02:50:12 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Controller Class Initialized
DEBUG - 2007-01-05 02:50:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:50:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:50:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:50:12 --> File loaded: application/views/user/page.php
DEBUG - 2007-01-05 02:50:12 --> Final output sent to browser
DEBUG - 2007-01-05 02:50:12 --> Total execution time: 0.0648
DEBUG - 2007-01-05 02:50:12 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:12 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:12 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:12 --> Router Class Initialized
ERROR - 2007-01-05 02:50:12 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:50:14 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:14 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Router Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Output Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Security Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Input Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:50:14 --> Language Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Loader Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:50:14 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Session Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:50:14 --> Session routines successfully run
DEBUG - 2007-01-05 02:50:14 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:14 --> Controller Class Initialized
DEBUG - 2007-01-05 02:50:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:50:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:50:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:50:14 --> File loaded: application/views/user/page.php
DEBUG - 2007-01-05 02:50:14 --> Final output sent to browser
DEBUG - 2007-01-05 02:50:14 --> Total execution time: 0.0643
DEBUG - 2007-01-05 02:50:18 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:18 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:18 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Router Class Initialized
DEBUG - 2007-01-05 02:50:18 --> No URI present. Default controller set.
DEBUG - 2007-01-05 02:50:18 --> Output Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Security Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Input Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:50:18 --> Language Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Loader Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:50:18 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Session Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:50:18 --> Session routines successfully run
DEBUG - 2007-01-05 02:50:18 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Model Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Controller Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Pagination Class Initialized
DEBUG - 2007-01-05 02:50:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:50:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:50:18 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-05 02:50:18 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-05 02:50:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:50:18 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-05 02:50:18 --> Final output sent to browser
DEBUG - 2007-01-05 02:50:18 --> Total execution time: 0.0716
DEBUG - 2007-01-05 02:50:18 --> Config Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:50:18 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:50:18 --> URI Class Initialized
DEBUG - 2007-01-05 02:50:18 --> Router Class Initialized
ERROR - 2007-01-05 02:50:18 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:51:03 --> Config Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:51:03 --> URI Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Router Class Initialized
DEBUG - 2007-01-05 02:51:03 --> No URI present. Default controller set.
DEBUG - 2007-01-05 02:51:03 --> Output Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Security Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Input Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:51:03 --> Language Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Loader Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:51:03 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Session Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:51:03 --> Session routines successfully run
DEBUG - 2007-01-05 02:51:03 --> Model Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Model Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Controller Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Pagination Class Initialized
DEBUG - 2007-01-05 02:51:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:51:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:51:03 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-05 02:51:03 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-05 02:51:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:51:03 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-05 02:51:03 --> Final output sent to browser
DEBUG - 2007-01-05 02:51:03 --> Total execution time: 0.1425
DEBUG - 2007-01-05 02:51:03 --> Config Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:51:03 --> URI Class Initialized
DEBUG - 2007-01-05 02:51:03 --> Router Class Initialized
ERROR - 2007-01-05 02:51:03 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-05 02:57:02 --> Config Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:57:02 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:57:02 --> URI Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Router Class Initialized
DEBUG - 2007-01-05 02:57:02 --> No URI present. Default controller set.
DEBUG - 2007-01-05 02:57:02 --> Output Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Security Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Input Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-05 02:57:02 --> Language Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Loader Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Helper loaded: url_helper
DEBUG - 2007-01-05 02:57:02 --> Database Driver Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Session Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Helper loaded: string_helper
DEBUG - 2007-01-05 02:57:02 --> Session routines successfully run
DEBUG - 2007-01-05 02:57:02 --> Model Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Model Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Controller Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Pagination Class Initialized
DEBUG - 2007-01-05 02:57:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-05 02:57:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-05 02:57:02 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-05 02:57:02 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-05 02:57:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-05 02:57:02 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-05 02:57:02 --> Final output sent to browser
DEBUG - 2007-01-05 02:57:02 --> Total execution time: 0.1198
DEBUG - 2007-01-05 02:57:02 --> Config Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Hooks Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Utf8 Class Initialized
DEBUG - 2007-01-05 02:57:02 --> UTF-8 Support Enabled
DEBUG - 2007-01-05 02:57:02 --> URI Class Initialized
DEBUG - 2007-01-05 02:57:02 --> Router Class Initialized
ERROR - 2007-01-05 02:57:02 --> 404 Page Not Found --> lessons

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-01-03 07:10:10 --> Config Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Hooks Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Utf8 Class Initialized
DEBUG - 2007-01-03 07:10:10 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 07:10:10 --> URI Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Router Class Initialized
DEBUG - 2007-01-03 07:10:10 --> No URI present. Default controller set.
DEBUG - 2007-01-03 07:10:10 --> Output Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Security Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Input Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 07:10:10 --> Language Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Loader Class Initialized
DEBUG - 2007-01-03 07:10:10 --> Helper loaded: url_helper
DEBUG - 2007-01-03 07:10:10 --> Database Driver Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Session Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Helper loaded: string_helper
DEBUG - 2007-01-03 07:10:11 --> A session cookie was not found.
DEBUG - 2007-01-03 07:10:11 --> Session routines successfully run
DEBUG - 2007-01-03 07:10:11 --> Model Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Model Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Controller Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Pagination Class Initialized
DEBUG - 2007-01-03 07:10:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-03 07:10:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-03 07:10:11 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-03 07:10:11 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-03 07:10:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-03 07:10:11 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-03 07:10:11 --> Final output sent to browser
DEBUG - 2007-01-03 07:10:11 --> Total execution time: 0.4578
DEBUG - 2007-01-03 07:10:11 --> Config Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Hooks Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Utf8 Class Initialized
DEBUG - 2007-01-03 07:10:11 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 07:10:11 --> URI Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Router Class Initialized
ERROR - 2007-01-03 07:10:11 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-03 07:10:11 --> Config Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Hooks Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Utf8 Class Initialized
DEBUG - 2007-01-03 07:10:11 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 07:10:11 --> URI Class Initialized
DEBUG - 2007-01-03 07:10:11 --> Router Class Initialized
ERROR - 2007-01-03 07:10:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-03 13:21:40 --> Config Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:21:40 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:21:40 --> URI Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Router Class Initialized
DEBUG - 2007-01-03 13:21:40 --> No URI present. Default controller set.
DEBUG - 2007-01-03 13:21:40 --> Output Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Security Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Input Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:21:40 --> Language Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Loader Class Initialized
DEBUG - 2007-01-03 13:21:40 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:21:41 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Session Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:21:41 --> Session routines successfully run
DEBUG - 2007-01-03 13:21:41 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Controller Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Pagination Class Initialized
DEBUG - 2007-01-03 13:21:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-03 13:21:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-03 13:21:41 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-03 13:21:41 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-03 13:21:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-03 13:21:41 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-03 13:21:41 --> Final output sent to browser
DEBUG - 2007-01-03 13:21:41 --> Total execution time: 0.2422
DEBUG - 2007-01-03 13:21:41 --> Config Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:21:41 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:21:41 --> URI Class Initialized
DEBUG - 2007-01-03 13:21:41 --> Router Class Initialized
ERROR - 2007-01-03 13:21:41 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-03 13:21:45 --> Config Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:21:45 --> URI Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Router Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Output Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Security Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Input Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:21:45 --> Language Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Loader Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:21:45 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Session Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:21:45 --> Session routines successfully run
DEBUG - 2007-01-03 13:21:45 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Controller Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Config Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:21:45 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:21:45 --> URI Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Router Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Output Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Security Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Input Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:21:45 --> Language Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Loader Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:21:45 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Session Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:21:45 --> Session routines successfully run
DEBUG - 2007-01-03 13:21:45 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:45 --> Controller Class Initialized
DEBUG - 2007-01-03 13:21:45 --> File loaded: application/views/admin/login.php
DEBUG - 2007-01-03 13:21:45 --> Final output sent to browser
DEBUG - 2007-01-03 13:21:45 --> Total execution time: 0.0963
DEBUG - 2007-01-03 13:21:56 --> Config Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:21:56 --> URI Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Router Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Output Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Security Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Input Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:21:56 --> Language Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Loader Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:21:56 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Session Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:21:56 --> Session routines successfully run
DEBUG - 2007-01-03 13:21:56 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Controller Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Config Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:21:56 --> URI Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Router Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Output Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Security Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Input Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:21:56 --> Language Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Loader Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:21:56 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Session Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:21:56 --> Session routines successfully run
DEBUG - 2007-01-03 13:21:56 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Model Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Controller Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Pagination Class Initialized
ERROR - 2007-01-03 13:21:56 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-03 13:21:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-03 13:21:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-03 13:21:56 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-01-03 13:21:56 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-01-03 13:21:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-03 13:21:56 --> File loaded: application/views/admin/home.php
DEBUG - 2007-01-03 13:21:56 --> Final output sent to browser
DEBUG - 2007-01-03 13:21:56 --> Total execution time: 0.0762
DEBUG - 2007-01-03 13:21:56 --> Config Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:21:56 --> URI Class Initialized
DEBUG - 2007-01-03 13:21:56 --> Router Class Initialized
ERROR - 2007-01-03 13:21:56 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-03 13:22:03 --> Config Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:22:03 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:22:03 --> URI Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Router Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Output Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Security Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Input Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:22:03 --> Language Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Loader Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:22:03 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Session Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:22:03 --> Session routines successfully run
DEBUG - 2007-01-03 13:22:03 --> Model Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Model Class Initialized
DEBUG - 2007-01-03 13:22:03 --> Controller Class Initialized
ERROR - 2007-01-03 13:22:03 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-03 13:22:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-03 13:22:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-03 13:22:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-03 13:22:03 --> File loaded: application/views/admin/category_new.php
DEBUG - 2007-01-03 13:22:03 --> Final output sent to browser
DEBUG - 2007-01-03 13:22:03 --> Total execution time: 0.0691
DEBUG - 2007-01-03 13:22:11 --> Config Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:22:11 --> URI Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Router Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Output Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Security Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Input Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:22:11 --> Language Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Loader Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:22:11 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Session Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:22:11 --> Session routines successfully run
DEBUG - 2007-01-03 13:22:11 --> Model Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Model Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Controller Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Config Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:22:11 --> URI Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Router Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Output Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Security Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Input Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-03 13:22:11 --> Language Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Loader Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Helper loaded: url_helper
DEBUG - 2007-01-03 13:22:11 --> Database Driver Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Session Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Helper loaded: string_helper
DEBUG - 2007-01-03 13:22:11 --> Session routines successfully run
DEBUG - 2007-01-03 13:22:11 --> Model Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Model Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Controller Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Pagination Class Initialized
ERROR - 2007-01-03 13:22:11 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-03 13:22:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-03 13:22:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-03 13:22:11 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-01-03 13:22:11 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-01-03 13:22:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-03 13:22:11 --> File loaded: application/views/admin/home.php
DEBUG - 2007-01-03 13:22:11 --> Final output sent to browser
DEBUG - 2007-01-03 13:22:11 --> Total execution time: 0.0750
DEBUG - 2007-01-03 13:22:11 --> Config Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Hooks Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Utf8 Class Initialized
DEBUG - 2007-01-03 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2007-01-03 13:22:11 --> URI Class Initialized
DEBUG - 2007-01-03 13:22:11 --> Router Class Initialized
ERROR - 2007-01-03 13:22:11 --> 404 Page Not Found --> lessons

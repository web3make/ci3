<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-11 00:00:02 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:02 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:02 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:02 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:02 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:02 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:02 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:02 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:00:02 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:02 --> Total execution time: 0.4304
DEBUG - 2012-01-11 00:00:30 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:30 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:30 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:30 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:00:30 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:30 --> Total execution time: 0.4227
DEBUG - 2012-01-11 00:00:34 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:34 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:34 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:34 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:34 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:34 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:00:34 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:34 --> Total execution time: 0.4397
DEBUG - 2012-01-11 00:00:35 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:35 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:35 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:36 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:36 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:36 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:36 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:00:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:00:36 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:36 --> Total execution time: 0.5515
DEBUG - 2012-01-11 00:00:37 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:37 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:37 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:37 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:37 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:37 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:00:37 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:38 --> Total execution time: 0.5158
DEBUG - 2012-01-11 00:00:39 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:39 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:39 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:39 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:39 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:00:39 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:39 --> Total execution time: 0.9138
DEBUG - 2012-01-11 00:00:40 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:41 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:41 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:41 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:41 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:41 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:00:41 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:41 --> Total execution time: 0.7404
DEBUG - 2012-01-11 00:00:42 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:42 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:42 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:42 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:42 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:42 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:00:42 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:42 --> Total execution time: 0.5224
DEBUG - 2012-01-11 00:00:45 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:45 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:45 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:46 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:00:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:46 --> Total execution time: 0.4100
DEBUG - 2012-01-11 00:00:47 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:47 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:47 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:47 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:47 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:47 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:00:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:00:47 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:47 --> Total execution time: 0.4425
DEBUG - 2012-01-11 00:00:49 --> Config Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:00:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:00:49 --> URI Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Router Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Output Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Security Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Input Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:00:49 --> Language Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Loader Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:00:49 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Session Class Initialized
DEBUG - 2012-01-11 00:00:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:00:49 --> Session routines successfully run
DEBUG - 2012-01-11 00:00:49 --> Controller Class Initialized
DEBUG - 2012-01-11 00:00:49 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:00:49 --> Final output sent to browser
DEBUG - 2012-01-11 00:00:49 --> Total execution time: 0.4889
DEBUG - 2012-01-11 00:01:42 --> Config Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:01:42 --> URI Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Router Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Output Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Security Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Input Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:01:42 --> Language Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Loader Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:01:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Session Class Initialized
DEBUG - 2012-01-11 00:01:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:01:42 --> Session routines successfully run
DEBUG - 2012-01-11 00:01:42 --> Controller Class Initialized
DEBUG - 2012-01-11 00:01:42 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:01:43 --> Final output sent to browser
DEBUG - 2012-01-11 00:01:43 --> Total execution time: 0.4919
DEBUG - 2012-01-11 00:01:46 --> Config Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:01:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:01:46 --> URI Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Router Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Output Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Security Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Input Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:01:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:01:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:01:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:01:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:01:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:01:46 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:01:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:01:46 --> Total execution time: 0.4027
DEBUG - 2012-01-11 00:01:48 --> Config Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:01:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:01:48 --> URI Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Router Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Output Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Security Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Input Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:01:48 --> Language Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Loader Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:01:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Session Class Initialized
DEBUG - 2012-01-11 00:01:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:01:48 --> Session routines successfully run
DEBUG - 2012-01-11 00:01:48 --> Controller Class Initialized
DEBUG - 2012-01-11 00:01:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:01:48 --> Final output sent to browser
DEBUG - 2012-01-11 00:01:48 --> Total execution time: 0.4668
DEBUG - 2012-01-11 00:02:46 --> Config Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:02:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:02:46 --> URI Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Router Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Output Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Security Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Input Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:02:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:02:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:02:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:02:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:02:46 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:02:46 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:02:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:02:46 --> Total execution time: 0.6324
DEBUG - 2012-01-11 00:02:48 --> Config Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:02:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:02:48 --> URI Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Router Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Output Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Security Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Input Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:02:48 --> Language Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Loader Class Initialized
DEBUG - 2012-01-11 00:02:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:02:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:02:49 --> Session Class Initialized
DEBUG - 2012-01-11 00:02:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:02:49 --> Session routines successfully run
DEBUG - 2012-01-11 00:02:49 --> Controller Class Initialized
DEBUG - 2012-01-11 00:02:49 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:02:49 --> Final output sent to browser
DEBUG - 2012-01-11 00:02:49 --> Total execution time: 0.6343
DEBUG - 2012-01-11 00:06:26 --> Config Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:06:26 --> URI Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Router Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Output Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Security Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Input Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:06:26 --> Language Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Loader Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:06:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Session Class Initialized
DEBUG - 2012-01-11 00:06:26 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:06:26 --> Session routines successfully run
DEBUG - 2012-01-11 00:06:26 --> Controller Class Initialized
DEBUG - 2012-01-11 00:06:26 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:06:26 --> Final output sent to browser
DEBUG - 2012-01-11 00:06:26 --> Total execution time: 0.4836
DEBUG - 2012-01-11 00:06:34 --> Config Class Initialized
DEBUG - 2012-01-11 00:06:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:06:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:06:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:06:34 --> URI Class Initialized
DEBUG - 2012-01-11 00:06:34 --> Router Class Initialized
DEBUG - 2012-01-11 00:06:34 --> Output Class Initialized
DEBUG - 2012-01-11 00:06:34 --> Security Class Initialized
DEBUG - 2012-01-11 00:06:34 --> Input Class Initialized
DEBUG - 2012-01-11 00:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:06:35 --> Language Class Initialized
DEBUG - 2012-01-11 00:06:35 --> Loader Class Initialized
DEBUG - 2012-01-11 00:06:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:06:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:06:35 --> Session Class Initialized
DEBUG - 2012-01-11 00:06:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:06:35 --> Session routines successfully run
DEBUG - 2012-01-11 00:06:35 --> Controller Class Initialized
DEBUG - 2012-01-11 00:06:35 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:06:35 --> Final output sent to browser
DEBUG - 2012-01-11 00:06:35 --> Total execution time: 0.4068
DEBUG - 2012-01-11 00:08:18 --> Config Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:08:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:08:18 --> URI Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Router Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Output Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Security Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Input Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:08:18 --> Language Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Loader Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:08:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Session Class Initialized
DEBUG - 2012-01-11 00:08:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:08:18 --> Session routines successfully run
DEBUG - 2012-01-11 00:08:18 --> Controller Class Initialized
DEBUG - 2012-01-11 00:08:18 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:08:18 --> Final output sent to browser
DEBUG - 2012-01-11 00:08:18 --> Total execution time: 0.4274
DEBUG - 2012-01-11 00:08:36 --> Config Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:08:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:08:36 --> URI Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Router Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Output Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Security Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Input Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:08:36 --> Language Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Loader Class Initialized
DEBUG - 2012-01-11 00:08:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:08:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:08:37 --> Session Class Initialized
DEBUG - 2012-01-11 00:08:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:08:37 --> Session routines successfully run
DEBUG - 2012-01-11 00:08:37 --> Controller Class Initialized
DEBUG - 2012-01-11 00:08:37 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:08:37 --> Final output sent to browser
DEBUG - 2012-01-11 00:08:37 --> Total execution time: 0.5406
DEBUG - 2012-01-11 00:09:02 --> Config Class Initialized
DEBUG - 2012-01-11 00:09:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:09:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:09:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:09:03 --> URI Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Router Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Output Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Security Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Input Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:09:03 --> Language Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Loader Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:09:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Session Class Initialized
DEBUG - 2012-01-11 00:09:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:09:03 --> Session routines successfully run
DEBUG - 2012-01-11 00:09:03 --> Controller Class Initialized
DEBUG - 2012-01-11 00:09:03 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:09:03 --> Final output sent to browser
DEBUG - 2012-01-11 00:09:03 --> Total execution time: 0.4656
DEBUG - 2012-01-11 00:09:19 --> Config Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:09:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:09:19 --> URI Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Router Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Output Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Security Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Input Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:09:19 --> Language Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Loader Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:09:19 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Session Class Initialized
DEBUG - 2012-01-11 00:09:19 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:09:19 --> Session routines successfully run
DEBUG - 2012-01-11 00:09:19 --> Controller Class Initialized
DEBUG - 2012-01-11 00:09:19 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:09:19 --> Final output sent to browser
DEBUG - 2012-01-11 00:09:19 --> Total execution time: 0.3798
DEBUG - 2012-01-11 00:09:39 --> Config Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:09:39 --> URI Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Router Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Output Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Security Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Input Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:09:39 --> Language Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Loader Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:09:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Session Class Initialized
DEBUG - 2012-01-11 00:09:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:09:39 --> Session routines successfully run
DEBUG - 2012-01-11 00:09:39 --> Controller Class Initialized
DEBUG - 2012-01-11 00:09:39 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:09:39 --> Final output sent to browser
DEBUG - 2012-01-11 00:09:39 --> Total execution time: 0.4735
DEBUG - 2012-01-11 00:09:50 --> Config Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:09:50 --> URI Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Router Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Output Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Security Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Input Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:09:50 --> Language Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Loader Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:09:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Session Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:09:50 --> Session routines successfully run
DEBUG - 2012-01-11 00:09:50 --> Controller Class Initialized
DEBUG - 2012-01-11 00:09:50 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:09:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:09:50 --> Final output sent to browser
DEBUG - 2012-01-11 00:09:50 --> Total execution time: 0.5684
DEBUG - 2012-01-11 00:10:28 --> Config Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:10:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:10:28 --> URI Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Router Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Output Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Security Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Input Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:10:28 --> Language Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Loader Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:10:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Session Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:10:28 --> Session routines successfully run
DEBUG - 2012-01-11 00:10:28 --> Controller Class Initialized
DEBUG - 2012-01-11 00:10:28 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:10:28 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:10:28 --> Final output sent to browser
DEBUG - 2012-01-11 00:10:28 --> Total execution time: 0.4785
DEBUG - 2012-01-11 00:10:30 --> Config Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:10:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:10:30 --> URI Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Router Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Output Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Security Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Input Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:10:30 --> Language Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Loader Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:10:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Session Class Initialized
DEBUG - 2012-01-11 00:10:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:10:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:10:30 --> Controller Class Initialized
DEBUG - 2012-01-11 00:10:31 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:10:31 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:10:31 --> Final output sent to browser
DEBUG - 2012-01-11 00:10:31 --> Total execution time: 0.4743
DEBUG - 2012-01-11 00:10:32 --> Config Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:10:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:10:32 --> URI Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Router Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Output Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Security Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Input Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:10:32 --> Language Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Loader Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:10:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Session Class Initialized
DEBUG - 2012-01-11 00:10:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:10:32 --> Session routines successfully run
DEBUG - 2012-01-11 00:10:32 --> Controller Class Initialized
DEBUG - 2012-01-11 00:10:32 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:10:32 --> Final output sent to browser
DEBUG - 2012-01-11 00:10:32 --> Total execution time: 0.5017
DEBUG - 2012-01-11 00:14:37 --> Config Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:14:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:14:37 --> URI Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Router Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Output Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Security Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Input Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:14:37 --> Language Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Loader Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:14:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Session Class Initialized
DEBUG - 2012-01-11 00:14:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:14:37 --> Session routines successfully run
DEBUG - 2012-01-11 00:14:37 --> Controller Class Initialized
DEBUG - 2012-01-11 00:14:37 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:14:37 --> Final output sent to browser
DEBUG - 2012-01-11 00:14:38 --> Total execution time: 0.8840
DEBUG - 2012-01-11 00:14:58 --> Config Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:14:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:14:58 --> URI Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Router Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Output Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Security Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Input Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:14:58 --> Language Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Loader Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:14:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Session Class Initialized
DEBUG - 2012-01-11 00:14:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:14:58 --> Session routines successfully run
DEBUG - 2012-01-11 00:14:58 --> Controller Class Initialized
DEBUG - 2012-01-11 00:14:58 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:14:58 --> Final output sent to browser
DEBUG - 2012-01-11 00:14:58 --> Total execution time: 0.3786
DEBUG - 2012-01-11 00:16:34 --> Config Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:16:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:16:34 --> URI Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Router Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Output Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Security Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Input Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:16:34 --> Language Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Loader Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:16:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Session Class Initialized
DEBUG - 2012-01-11 00:16:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:16:34 --> Session routines successfully run
DEBUG - 2012-01-11 00:16:34 --> Controller Class Initialized
DEBUG - 2012-01-11 00:16:34 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:16:34 --> Final output sent to browser
DEBUG - 2012-01-11 00:16:34 --> Total execution time: 0.4037
DEBUG - 2012-01-11 00:16:37 --> Config Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:16:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:16:37 --> URI Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Router Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Output Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Security Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Input Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:16:37 --> Language Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Loader Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:16:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Session Class Initialized
DEBUG - 2012-01-11 00:16:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:16:37 --> Session routines successfully run
DEBUG - 2012-01-11 00:16:37 --> Controller Class Initialized
DEBUG - 2012-01-11 00:16:37 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:16:37 --> Final output sent to browser
DEBUG - 2012-01-11 00:16:37 --> Total execution time: 0.3671
DEBUG - 2012-01-11 00:17:07 --> Config Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:17:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:17:07 --> URI Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Router Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Output Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Security Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Input Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:17:07 --> Language Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Loader Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:17:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Session Class Initialized
DEBUG - 2012-01-11 00:17:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:17:07 --> Session routines successfully run
DEBUG - 2012-01-11 00:17:07 --> Controller Class Initialized
DEBUG - 2012-01-11 00:17:07 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:17:07 --> Final output sent to browser
DEBUG - 2012-01-11 00:17:07 --> Total execution time: 0.5083
DEBUG - 2012-01-11 00:17:09 --> Config Class Initialized
DEBUG - 2012-01-11 00:17:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:17:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:17:10 --> URI Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Router Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Output Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Security Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Input Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:17:10 --> Language Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Loader Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:17:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Session Class Initialized
DEBUG - 2012-01-11 00:17:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:17:10 --> Session routines successfully run
DEBUG - 2012-01-11 00:17:10 --> Controller Class Initialized
DEBUG - 2012-01-11 00:17:10 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:17:10 --> Final output sent to browser
DEBUG - 2012-01-11 00:17:10 --> Total execution time: 0.7103
DEBUG - 2012-01-11 00:17:25 --> Config Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:17:25 --> URI Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Router Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Output Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Security Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Input Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:17:25 --> Language Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Loader Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:17:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Session Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:17:25 --> Session routines successfully run
DEBUG - 2012-01-11 00:17:25 --> Controller Class Initialized
DEBUG - 2012-01-11 00:17:25 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:17:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:17:25 --> Final output sent to browser
DEBUG - 2012-01-11 00:17:26 --> Total execution time: 0.5057
DEBUG - 2012-01-11 00:17:30 --> Config Class Initialized
DEBUG - 2012-01-11 00:17:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:17:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:17:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:17:30 --> URI Class Initialized
DEBUG - 2012-01-11 00:17:30 --> Router Class Initialized
DEBUG - 2012-01-11 00:17:31 --> No URI present. Default controller set.
DEBUG - 2012-01-11 00:17:31 --> Output Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Security Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Input Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:17:31 --> Language Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Loader Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:17:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Session Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:17:31 --> Session routines successfully run
DEBUG - 2012-01-11 00:17:31 --> Controller Class Initialized
DEBUG - 2012-01-11 00:17:31 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:17:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 00:17:31 --> Final output sent to browser
DEBUG - 2012-01-11 00:17:31 --> Total execution time: 1.0452
DEBUG - 2012-01-11 00:17:33 --> Config Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:17:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:17:33 --> URI Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Router Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Output Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Security Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Input Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:17:33 --> Language Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Loader Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:17:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Session Class Initialized
DEBUG - 2012-01-11 00:17:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:17:33 --> Session routines successfully run
DEBUG - 2012-01-11 00:17:33 --> Controller Class Initialized
DEBUG - 2012-01-11 00:17:33 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 00:17:33 --> Final output sent to browser
DEBUG - 2012-01-11 00:17:33 --> Total execution time: 0.6041
DEBUG - 2012-01-11 00:17:57 --> Config Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:17:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:17:57 --> URI Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Router Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Output Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Security Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Input Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:17:57 --> Language Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Loader Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:17:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Session Class Initialized
DEBUG - 2012-01-11 00:17:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:17:57 --> Session routines successfully run
DEBUG - 2012-01-11 00:17:57 --> Controller Class Initialized
DEBUG - 2012-01-11 00:17:57 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 00:17:57 --> Final output sent to browser
DEBUG - 2012-01-11 00:17:57 --> Total execution time: 0.3934
DEBUG - 2012-01-11 00:18:04 --> Config Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:18:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:18:04 --> URI Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Router Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Output Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Security Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Input Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:18:04 --> Language Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Loader Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:18:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Session Class Initialized
DEBUG - 2012-01-11 00:18:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:18:04 --> Session routines successfully run
DEBUG - 2012-01-11 00:18:04 --> Controller Class Initialized
DEBUG - 2012-01-11 00:18:04 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:18:04 --> Final output sent to browser
DEBUG - 2012-01-11 00:18:04 --> Total execution time: 0.4608
DEBUG - 2012-01-11 00:18:23 --> Config Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:18:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:18:23 --> URI Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Router Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Output Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Security Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Input Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:18:23 --> Language Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Loader Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:18:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:18:23 --> Session Class Initialized
DEBUG - 2012-01-11 00:18:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:18:24 --> Session routines successfully run
DEBUG - 2012-01-11 00:18:24 --> Controller Class Initialized
DEBUG - 2012-01-11 00:18:24 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:18:24 --> Final output sent to browser
DEBUG - 2012-01-11 00:18:24 --> Total execution time: 0.4254
DEBUG - 2012-01-11 00:18:41 --> Config Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:18:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:18:41 --> URI Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Router Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Output Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Security Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Input Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:18:41 --> Language Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Loader Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:18:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Session Class Initialized
DEBUG - 2012-01-11 00:18:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:18:41 --> Session routines successfully run
DEBUG - 2012-01-11 00:18:41 --> Controller Class Initialized
DEBUG - 2012-01-11 00:18:41 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:18:41 --> Final output sent to browser
DEBUG - 2012-01-11 00:18:41 --> Total execution time: 0.4513
DEBUG - 2012-01-11 00:19:25 --> Config Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:19:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:19:25 --> URI Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Router Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Output Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Security Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Input Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:19:25 --> Language Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Loader Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:19:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Session Class Initialized
DEBUG - 2012-01-11 00:19:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:19:25 --> Session routines successfully run
DEBUG - 2012-01-11 00:19:25 --> Controller Class Initialized
DEBUG - 2012-01-11 00:19:25 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:19:25 --> Final output sent to browser
DEBUG - 2012-01-11 00:19:25 --> Total execution time: 0.5162
DEBUG - 2012-01-11 00:19:35 --> Config Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:19:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:19:35 --> URI Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Router Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Output Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Security Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Input Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:19:35 --> Language Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Loader Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:19:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:19:35 --> Session Class Initialized
DEBUG - 2012-01-11 00:19:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:19:36 --> Session routines successfully run
DEBUG - 2012-01-11 00:19:36 --> Controller Class Initialized
DEBUG - 2012-01-11 00:19:36 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:19:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:19:36 --> Final output sent to browser
DEBUG - 2012-01-11 00:19:36 --> Total execution time: 0.4716
DEBUG - 2012-01-11 00:19:38 --> Config Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:19:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:19:38 --> URI Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Router Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Output Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Security Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Input Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:19:38 --> Language Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Loader Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:19:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Session Class Initialized
DEBUG - 2012-01-11 00:19:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:19:38 --> Session routines successfully run
DEBUG - 2012-01-11 00:19:38 --> Controller Class Initialized
DEBUG - 2012-01-11 00:19:38 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:19:38 --> Final output sent to browser
DEBUG - 2012-01-11 00:19:38 --> Total execution time: 0.5238
DEBUG - 2012-01-11 00:19:48 --> Config Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:19:48 --> URI Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Router Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Output Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Security Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Input Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:19:48 --> Language Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Loader Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:19:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Session Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:19:48 --> Session routines successfully run
DEBUG - 2012-01-11 00:19:48 --> Controller Class Initialized
DEBUG - 2012-01-11 00:19:48 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:19:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:19:48 --> Final output sent to browser
DEBUG - 2012-01-11 00:19:48 --> Total execution time: 0.4707
DEBUG - 2012-01-11 00:21:10 --> Config Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:21:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:21:10 --> URI Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Router Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Output Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Security Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Input Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:21:10 --> Language Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Loader Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:21:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Session Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:21:10 --> Session routines successfully run
DEBUG - 2012-01-11 00:21:10 --> Controller Class Initialized
DEBUG - 2012-01-11 00:21:10 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:21:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:21:10 --> Final output sent to browser
DEBUG - 2012-01-11 00:21:10 --> Total execution time: 0.5823
DEBUG - 2012-01-11 00:21:12 --> Config Class Initialized
DEBUG - 2012-01-11 00:21:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:21:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:21:13 --> URI Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Router Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Output Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Security Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Input Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:21:13 --> Language Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Loader Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:21:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Session Class Initialized
DEBUG - 2012-01-11 00:21:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:21:13 --> Session routines successfully run
DEBUG - 2012-01-11 00:21:13 --> Controller Class Initialized
DEBUG - 2012-01-11 00:21:13 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:21:13 --> Final output sent to browser
DEBUG - 2012-01-11 00:21:13 --> Total execution time: 0.6284
DEBUG - 2012-01-11 00:21:18 --> Config Class Initialized
DEBUG - 2012-01-11 00:21:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:21:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:21:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:21:18 --> URI Class Initialized
DEBUG - 2012-01-11 00:21:18 --> Router Class Initialized
ERROR - 2012-01-11 00:21:18 --> 404 Page Not Found --> admin/articles
DEBUG - 2012-01-11 00:21:35 --> Config Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:21:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:21:35 --> URI Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Router Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Output Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Security Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Input Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:21:35 --> Language Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Loader Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:21:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Session Class Initialized
DEBUG - 2012-01-11 00:21:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:21:35 --> Session routines successfully run
DEBUG - 2012-01-11 00:21:35 --> Controller Class Initialized
DEBUG - 2012-01-11 00:21:35 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:21:35 --> Final output sent to browser
DEBUG - 2012-01-11 00:21:35 --> Total execution time: 0.4408
DEBUG - 2012-01-11 00:21:40 --> Config Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:21:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:21:40 --> URI Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Router Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Output Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Security Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Input Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:21:40 --> Language Class Initialized
DEBUG - 2012-01-11 00:21:40 --> Loader Class Initialized
DEBUG - 2012-01-11 00:21:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:21:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:21:41 --> Session Class Initialized
DEBUG - 2012-01-11 00:21:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:21:41 --> Session routines successfully run
DEBUG - 2012-01-11 00:21:41 --> Controller Class Initialized
ERROR - 2012-01-11 00:21:41 --> Severity: Notice  --> Undefined index: user_name A:\home\codeigniter.blog\www\application\controllers\admin\article.php 32
DEBUG - 2012-01-11 00:21:41 --> DB Transaction Failure
ERROR - 2012-01-11 00:21:41 --> Query error: Table 'codeigniter.blog.article' doesn't exist
DEBUG - 2012-01-11 00:21:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2012-01-11 00:21:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.blog\www\system\core\Exceptions.php:185) A:\home\codeigniter.blog\www\system\core\Common.php 442
DEBUG - 2012-01-11 00:22:07 --> Config Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:22:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:22:07 --> URI Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Router Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Output Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Security Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Input Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:22:07 --> Language Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Loader Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:22:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Session Class Initialized
DEBUG - 2012-01-11 00:22:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:22:07 --> Session routines successfully run
DEBUG - 2012-01-11 00:22:07 --> Controller Class Initialized
DEBUG - 2012-01-11 00:22:07 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:22:07 --> Final output sent to browser
DEBUG - 2012-01-11 00:22:07 --> Total execution time: 0.4135
DEBUG - 2012-01-11 00:22:11 --> Config Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:22:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:22:11 --> URI Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Router Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Output Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Security Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Input Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:22:11 --> Language Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Loader Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:22:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:22:11 --> Session Class Initialized
DEBUG - 2012-01-11 00:22:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:22:12 --> Session routines successfully run
DEBUG - 2012-01-11 00:22:12 --> Controller Class Initialized
DEBUG - 2012-01-11 00:22:12 --> DB Transaction Failure
ERROR - 2012-01-11 00:22:12 --> Query error: Table 'codeigniter.blog.article' doesn't exist
DEBUG - 2012-01-11 00:22:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:22:30 --> Config Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:22:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:22:30 --> URI Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Router Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Output Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Security Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Input Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:22:30 --> Language Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Loader Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:22:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Session Class Initialized
DEBUG - 2012-01-11 00:22:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:22:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:22:30 --> Controller Class Initialized
DEBUG - 2012-01-11 00:22:30 --> DB Transaction Failure
ERROR - 2012-01-11 00:22:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.blog`.`articles`, CONSTRAINT `fk_articles_categories1` FOREIGN KEY (`id_category`) REFERENCES `categories` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-01-11 00:22:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:25:08 --> Config Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:25:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:25:08 --> URI Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Router Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Output Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Security Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Input Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:25:08 --> Language Class Initialized
DEBUG - 2012-01-11 00:25:08 --> Loader Class Initialized
DEBUG - 2012-01-11 00:25:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:25:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:25:09 --> Session Class Initialized
DEBUG - 2012-01-11 00:25:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:25:09 --> Session routines successfully run
DEBUG - 2012-01-11 00:25:09 --> Controller Class Initialized
DEBUG - 2012-01-11 00:25:09 --> DB Transaction Failure
ERROR - 2012-01-11 00:25:09 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.blog`.`articles`, CONSTRAINT `fk_articles_categories1` FOREIGN KEY (`id_category`) REFERENCES `categories` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-01-11 00:25:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:25:13 --> Config Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:25:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:25:13 --> URI Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Router Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Output Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Security Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Input Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:25:13 --> Language Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Loader Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:25:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Session Class Initialized
DEBUG - 2012-01-11 00:25:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:25:13 --> Session routines successfully run
DEBUG - 2012-01-11 00:25:13 --> Controller Class Initialized
DEBUG - 2012-01-11 00:25:13 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:25:13 --> Final output sent to browser
DEBUG - 2012-01-11 00:25:13 --> Total execution time: 0.4874
DEBUG - 2012-01-11 00:25:18 --> Config Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:25:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:25:18 --> URI Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Router Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Output Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Security Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Input Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:25:18 --> Language Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Loader Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:25:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Session Class Initialized
DEBUG - 2012-01-11 00:25:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:25:18 --> Session routines successfully run
DEBUG - 2012-01-11 00:25:18 --> Controller Class Initialized
DEBUG - 2012-01-11 00:25:18 --> DB Transaction Failure
ERROR - 2012-01-11 00:25:18 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.blog`.`articles`, CONSTRAINT `fk_articles_categories1` FOREIGN KEY (`id_category`) REFERENCES `categories` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-01-11 00:25:18 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:25:26 --> Config Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:25:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:25:26 --> URI Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Router Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Output Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Security Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Input Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:25:26 --> Language Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Loader Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:25:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Session Class Initialized
DEBUG - 2012-01-11 00:25:26 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:25:26 --> Session routines successfully run
DEBUG - 2012-01-11 00:25:26 --> Controller Class Initialized
DEBUG - 2012-01-11 00:25:26 --> DB Transaction Failure
ERROR - 2012-01-11 00:25:26 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.blog`.`articles`, CONSTRAINT `fk_articles_categories1` FOREIGN KEY (`id_category`) REFERENCES `categories` (`id_category`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-01-11 00:25:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:27:51 --> Config Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:27:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:27:51 --> URI Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Router Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Output Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Security Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Input Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:27:51 --> Language Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Loader Class Initialized
DEBUG - 2012-01-11 00:27:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:27:52 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:27:52 --> Session Class Initialized
DEBUG - 2012-01-11 00:27:52 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:27:52 --> Session routines successfully run
DEBUG - 2012-01-11 00:27:52 --> Controller Class Initialized
DEBUG - 2012-01-11 00:27:52 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:27:52 --> Final output sent to browser
DEBUG - 2012-01-11 00:27:52 --> Total execution time: 0.9707
DEBUG - 2012-01-11 00:27:54 --> Config Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:27:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:27:54 --> URI Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Router Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Output Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Security Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Input Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:27:54 --> Language Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Loader Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:27:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Session Class Initialized
DEBUG - 2012-01-11 00:27:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:27:54 --> Session routines successfully run
DEBUG - 2012-01-11 00:27:55 --> Controller Class Initialized
DEBUG - 2012-01-11 00:27:55 --> DB Transaction Failure
ERROR - 2012-01-11 00:27:55 --> Query error: Duplicate entry '1-1' for key 'PRIMARY'
DEBUG - 2012-01-11 00:27:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:29:42 --> Config Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:29:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:29:42 --> URI Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Router Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Output Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Security Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Input Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:29:42 --> Language Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Loader Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:29:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Session Class Initialized
DEBUG - 2012-01-11 00:29:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:29:42 --> Session routines successfully run
DEBUG - 2012-01-11 00:29:42 --> Controller Class Initialized
DEBUG - 2012-01-11 00:29:42 --> DB Transaction Failure
ERROR - 2012-01-11 00:29:42 --> Query error: Duplicate entry '1-1' for key 'PRIMARY'
DEBUG - 2012-01-11 00:29:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:29:45 --> Config Class Initialized
DEBUG - 2012-01-11 00:29:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:29:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:29:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:29:45 --> URI Class Initialized
DEBUG - 2012-01-11 00:29:45 --> Router Class Initialized
DEBUG - 2012-01-11 00:29:45 --> Output Class Initialized
DEBUG - 2012-01-11 00:29:45 --> Security Class Initialized
DEBUG - 2012-01-11 00:29:45 --> Input Class Initialized
DEBUG - 2012-01-11 00:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:29:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:29:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:29:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:29:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:29:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:29:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:29:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:29:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:29:46 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:29:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:29:46 --> Total execution time: 0.4260
DEBUG - 2012-01-11 00:29:48 --> Config Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:29:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:29:48 --> URI Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Router Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Output Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Security Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Input Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:29:48 --> Language Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Loader Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:29:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Session Class Initialized
DEBUG - 2012-01-11 00:29:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:29:48 --> Session routines successfully run
DEBUG - 2012-01-11 00:29:48 --> Controller Class Initialized
DEBUG - 2012-01-11 00:29:48 --> DB Transaction Failure
ERROR - 2012-01-11 00:29:48 --> Query error: Duplicate entry '1-1' for key 'PRIMARY'
DEBUG - 2012-01-11 00:29:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-11 00:32:08 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:09 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:09 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:09 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:09 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:09 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:32:09 --> Final output sent to browser
DEBUG - 2012-01-11 00:32:09 --> Total execution time: 0.4767
DEBUG - 2012-01-11 00:32:10 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:10 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:10 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:10 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:10 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:10 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:10 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:11 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:11 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:11 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:11 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:11 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:11 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:11 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:32:11 --> Final output sent to browser
DEBUG - 2012-01-11 00:32:11 --> Total execution time: 0.4891
DEBUG - 2012-01-11 00:32:19 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:19 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:19 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:19 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:19 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:19 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:19 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:20 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:20 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:20 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:20 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:20 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:20 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:20 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:32:20 --> Final output sent to browser
DEBUG - 2012-01-11 00:32:20 --> Total execution time: 0.3989
DEBUG - 2012-01-11 00:32:28 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:28 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:28 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:28 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:28 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:28 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:28 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:28 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:29 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:29 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:29 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:29 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:29 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:29 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:29 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:29 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:32:29 --> Final output sent to browser
DEBUG - 2012-01-11 00:32:29 --> Total execution time: 0.4500
DEBUG - 2012-01-11 00:32:40 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:40 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:40 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:41 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:41 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Config Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:32:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:32:41 --> URI Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Router Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Output Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Security Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Input Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:32:41 --> Language Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Loader Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:32:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Session Class Initialized
DEBUG - 2012-01-11 00:32:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:32:41 --> Session routines successfully run
DEBUG - 2012-01-11 00:32:41 --> Controller Class Initialized
DEBUG - 2012-01-11 00:32:41 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:32:41 --> Final output sent to browser
DEBUG - 2012-01-11 00:32:41 --> Total execution time: 0.4515
DEBUG - 2012-01-11 00:34:02 --> Config Class Initialized
DEBUG - 2012-01-11 00:34:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:34:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:34:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:34:02 --> URI Class Initialized
DEBUG - 2012-01-11 00:34:02 --> Router Class Initialized
DEBUG - 2012-01-11 00:34:02 --> Output Class Initialized
DEBUG - 2012-01-11 00:34:02 --> Security Class Initialized
DEBUG - 2012-01-11 00:34:02 --> Input Class Initialized
DEBUG - 2012-01-11 00:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:34:03 --> Language Class Initialized
DEBUG - 2012-01-11 00:34:03 --> Loader Class Initialized
DEBUG - 2012-01-11 00:34:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:34:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:34:03 --> Session Class Initialized
DEBUG - 2012-01-11 00:34:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:34:03 --> Session routines successfully run
DEBUG - 2012-01-11 00:34:03 --> Controller Class Initialized
DEBUG - 2012-01-11 00:34:03 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:34:03 --> Final output sent to browser
DEBUG - 2012-01-11 00:34:03 --> Total execution time: 0.4198
DEBUG - 2012-01-11 00:34:04 --> Config Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:34:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:34:04 --> URI Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Router Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Output Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Security Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Input Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:34:04 --> Language Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Loader Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:34:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Session Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:34:04 --> Session routines successfully run
DEBUG - 2012-01-11 00:34:04 --> Controller Class Initialized
DEBUG - 2012-01-11 00:34:04 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:34:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:34:04 --> Final output sent to browser
DEBUG - 2012-01-11 00:34:04 --> Total execution time: 0.4506
DEBUG - 2012-01-11 00:34:06 --> Config Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:34:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:34:06 --> URI Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Router Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Output Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Security Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Input Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:34:06 --> Language Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Loader Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:34:06 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Session Class Initialized
DEBUG - 2012-01-11 00:34:06 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:34:06 --> Session routines successfully run
DEBUG - 2012-01-11 00:34:06 --> Controller Class Initialized
DEBUG - 2012-01-11 00:34:06 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:34:06 --> Final output sent to browser
DEBUG - 2012-01-11 00:34:06 --> Total execution time: 0.4655
DEBUG - 2012-01-11 00:35:24 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:25 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:25 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:25 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:25 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:25 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:25 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:25 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:25 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:25 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:35:25 --> Final output sent to browser
DEBUG - 2012-01-11 00:35:25 --> Total execution time: 0.4908
DEBUG - 2012-01-11 00:35:27 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:27 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:28 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:28 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:28 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:28 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:35:28 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:35:28 --> Final output sent to browser
DEBUG - 2012-01-11 00:35:28 --> Total execution time: 0.5257
DEBUG - 2012-01-11 00:35:32 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:32 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:32 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:32 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:33 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:33 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:33 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:35:33 --> Final output sent to browser
DEBUG - 2012-01-11 00:35:33 --> Total execution time: 0.4876
DEBUG - 2012-01-11 00:35:46 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:46 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:47 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:47 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:47 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:47 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:47 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:35:47 --> Final output sent to browser
DEBUG - 2012-01-11 00:35:47 --> Total execution time: 0.5012
DEBUG - 2012-01-11 00:35:48 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:48 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:48 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:48 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:49 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:49 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:49 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:35:49 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:35:49 --> Final output sent to browser
DEBUG - 2012-01-11 00:35:49 --> Total execution time: 0.4466
DEBUG - 2012-01-11 00:35:51 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:52 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:52 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:52 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:52 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:52 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:52 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:35:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:35:52 --> Final output sent to browser
DEBUG - 2012-01-11 00:35:52 --> Total execution time: 1.0480
DEBUG - 2012-01-11 00:35:54 --> Config Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:35:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:35:54 --> URI Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Router Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Output Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Security Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Input Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:35:54 --> Language Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Loader Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:35:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Session Class Initialized
DEBUG - 2012-01-11 00:35:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:35:55 --> Session routines successfully run
DEBUG - 2012-01-11 00:35:55 --> Controller Class Initialized
DEBUG - 2012-01-11 00:35:55 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:35:55 --> Final output sent to browser
DEBUG - 2012-01-11 00:35:55 --> Total execution time: 0.4395
DEBUG - 2012-01-11 00:36:05 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:05 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:05 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:05 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:06 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:06 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:06 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:06 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:06 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:06 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:06 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:06 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:06 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:36:06 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:06 --> Total execution time: 0.4028
DEBUG - 2012-01-11 00:36:12 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:12 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:12 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:12 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:12 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:12 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:13 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:13 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:13 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:13 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:13 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:13 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:13 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:13 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:36:13 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:13 --> Total execution time: 0.4185
DEBUG - 2012-01-11 00:36:15 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:15 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:15 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:15 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:15 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:15 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:36:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:36:15 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:15 --> Total execution time: 0.5459
DEBUG - 2012-01-11 00:36:17 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:17 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:17 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:17 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:17 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:17 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:17 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:36:17 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:36:17 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:17 --> Total execution time: 0.5563
DEBUG - 2012-01-11 00:36:22 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:22 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:22 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:23 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:23 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:23 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:23 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:23 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:36:23 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:23 --> Total execution time: 0.4877
DEBUG - 2012-01-11 00:36:32 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:32 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:33 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:33 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:33 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:33 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:33 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:33 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:33 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:33 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:36:33 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:33 --> Total execution time: 0.4218
DEBUG - 2012-01-11 00:36:36 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:36 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:36 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:37 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:37 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:37 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:37 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:36:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:36:37 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:37 --> Total execution time: 0.5190
DEBUG - 2012-01-11 00:36:38 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:38 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:38 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:38 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:39 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:39 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:39 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:39 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:36:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:36:39 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:39 --> Total execution time: 0.8108
DEBUG - 2012-01-11 00:36:43 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:43 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:43 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:43 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:43 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:43 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:36:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:36:43 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:43 --> Total execution time: 0.6211
DEBUG - 2012-01-11 00:36:46 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:46 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:46 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:36:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:46 --> Total execution time: 0.4871
DEBUG - 2012-01-11 00:36:55 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:55 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:55 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:55 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:55 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:55 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:55 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:55 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:56 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:56 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:56 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:56 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:36:56 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:56 --> Total execution time: 0.5308
DEBUG - 2012-01-11 00:36:58 --> Config Class Initialized
DEBUG - 2012-01-11 00:36:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:36:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:36:58 --> URI Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Router Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Output Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Security Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Input Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:36:59 --> Language Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Loader Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:36:59 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Session Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:36:59 --> Session routines successfully run
DEBUG - 2012-01-11 00:36:59 --> Controller Class Initialized
DEBUG - 2012-01-11 00:36:59 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:36:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:36:59 --> Final output sent to browser
DEBUG - 2012-01-11 00:36:59 --> Total execution time: 0.5950
DEBUG - 2012-01-11 00:37:01 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:01 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:01 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:01 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:01 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:01 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:37:01 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:37:01 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:01 --> Total execution time: 0.9026
DEBUG - 2012-01-11 00:37:02 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:02 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:02 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:02 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:02 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:02 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:03 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:03 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:03 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:03 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:03 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:03 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:37:03 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:03 --> Total execution time: 0.4710
DEBUG - 2012-01-11 00:37:11 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:12 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:12 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:12 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:12 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:12 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:12 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:12 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:12 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:12 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:37:12 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:12 --> Total execution time: 0.4352
DEBUG - 2012-01-11 00:37:14 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:14 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:14 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:14 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:14 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:14 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:14 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:37:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:37:14 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:14 --> Total execution time: 0.5191
DEBUG - 2012-01-11 00:37:16 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:16 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:16 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:16 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:16 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:16 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:16 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:37:16 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:37:16 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:16 --> Total execution time: 0.5253
DEBUG - 2012-01-11 00:37:18 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:18 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:18 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:19 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:19 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:19 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:19 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:19 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:19 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:37:19 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:37:19 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:19 --> Total execution time: 0.5146
DEBUG - 2012-01-11 00:37:45 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:45 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:45 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:45 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:45 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:46 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:37:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:46 --> Total execution time: 0.6011
DEBUG - 2012-01-11 00:37:50 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:50 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:50 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:50 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:50 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:50 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:37:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:37:50 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:50 --> Total execution time: 0.8356
DEBUG - 2012-01-11 00:37:52 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:52 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:52 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:52 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:52 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:53 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:53 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:53 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:53 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:37:53 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:53 --> Total execution time: 0.4722
DEBUG - 2012-01-11 00:37:56 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:37:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:37:56 --> URI Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Router Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Output Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Security Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Input Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:37:57 --> Language Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Loader Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:37:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Session Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:37:57 --> Session routines successfully run
DEBUG - 2012-01-11 00:37:57 --> Controller Class Initialized
DEBUG - 2012-01-11 00:37:57 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:37:57 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:37:57 --> Final output sent to browser
DEBUG - 2012-01-11 00:37:57 --> Total execution time: 0.5674
DEBUG - 2012-01-11 00:37:59 --> Config Class Initialized
DEBUG - 2012-01-11 00:37:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:37:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:00 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:00 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:00 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:00 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:00 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:00 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:38:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:38:00 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:00 --> Total execution time: 0.4756
DEBUG - 2012-01-11 00:38:01 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:01 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:01 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:02 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:02 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:02 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:02 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:02 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:38:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:38:02 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:02 --> Total execution time: 1.0489
DEBUG - 2012-01-11 00:38:27 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:27 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:27 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:27 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:27 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:27 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:27 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:38:27 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:27 --> Total execution time: 0.5271
DEBUG - 2012-01-11 00:38:29 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:29 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:29 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:30 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:30 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:38:30 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:30 --> Total execution time: 0.5721
DEBUG - 2012-01-11 00:38:32 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:32 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:32 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:32 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:32 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:32 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:38:32 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:32 --> Total execution time: 0.5757
DEBUG - 2012-01-11 00:38:34 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:34 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:34 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:34 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:34 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:34 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:38:34 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:34 --> Total execution time: 0.4310
DEBUG - 2012-01-11 00:38:35 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:36 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:36 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:36 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:36 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:36 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:38:36 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:36 --> Total execution time: 0.4763
DEBUG - 2012-01-11 00:38:37 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:38 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:38 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:38 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:38 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:38:38 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:38 --> Total execution time: 0.9121
DEBUG - 2012-01-11 00:38:40 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:40 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:40 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:40 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:40 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:40 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:38:40 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:40 --> Total execution time: 0.5172
DEBUG - 2012-01-11 00:38:46 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:46 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:46 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:47 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:47 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:47 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:47 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:38:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:38:47 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:47 --> Total execution time: 0.5191
DEBUG - 2012-01-11 00:38:49 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:49 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:49 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:49 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:49 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:49 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:49 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:38:49 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:38:49 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:49 --> Total execution time: 0.5105
DEBUG - 2012-01-11 00:38:51 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:51 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:51 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:51 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:51 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:51 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:38:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:38:51 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:51 --> Total execution time: 0.4553
DEBUG - 2012-01-11 00:38:58 --> Config Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:38:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:38:58 --> URI Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Router Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Output Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Security Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Input Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:38:58 --> Language Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Loader Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:38:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Session Class Initialized
DEBUG - 2012-01-11 00:38:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:38:58 --> Session routines successfully run
DEBUG - 2012-01-11 00:38:58 --> Controller Class Initialized
DEBUG - 2012-01-11 00:38:58 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:38:58 --> Final output sent to browser
DEBUG - 2012-01-11 00:38:58 --> Total execution time: 0.5624
DEBUG - 2012-01-11 00:39:00 --> Config Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:39:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:39:00 --> URI Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Router Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Output Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Security Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Input Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:39:00 --> Language Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Loader Class Initialized
DEBUG - 2012-01-11 00:39:00 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:39:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:39:01 --> Session Class Initialized
DEBUG - 2012-01-11 00:39:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:39:01 --> Session routines successfully run
DEBUG - 2012-01-11 00:39:01 --> Controller Class Initialized
DEBUG - 2012-01-11 00:39:01 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:39:01 --> Final output sent to browser
DEBUG - 2012-01-11 00:39:01 --> Total execution time: 0.5070
DEBUG - 2012-01-11 00:39:10 --> Config Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:39:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:39:10 --> URI Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Router Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Output Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Security Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Input Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:39:10 --> Language Class Initialized
DEBUG - 2012-01-11 00:39:10 --> Loader Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:39:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Session Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:39:11 --> Session routines successfully run
DEBUG - 2012-01-11 00:39:11 --> Controller Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Config Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:39:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:39:11 --> URI Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Router Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Output Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Security Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Input Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:39:11 --> Language Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Loader Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:39:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Session Class Initialized
DEBUG - 2012-01-11 00:39:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:39:11 --> Session routines successfully run
DEBUG - 2012-01-11 00:39:11 --> Controller Class Initialized
DEBUG - 2012-01-11 00:39:11 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:39:11 --> Final output sent to browser
DEBUG - 2012-01-11 00:39:11 --> Total execution time: 0.4382
DEBUG - 2012-01-11 00:40:24 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:24 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:24 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:24 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:24 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:24 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:24 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:25 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:25 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:25 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:25 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:25 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:40:25 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:25 --> Total execution time: 0.4618
DEBUG - 2012-01-11 00:40:29 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:29 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:29 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:30 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:30 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:40:30 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:30 --> Total execution time: 0.4808
DEBUG - 2012-01-11 00:40:31 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:31 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:31 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:31 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:31 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:31 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:40:31 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:31 --> Total execution time: 0.4723
DEBUG - 2012-01-11 00:40:36 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:36 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:36 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:36 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:36 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:36 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:40:36 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:36 --> Total execution time: 0.4155
DEBUG - 2012-01-11 00:40:38 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:38 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:38 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:38 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:38 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:40:38 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:38 --> Total execution time: 0.4600
DEBUG - 2012-01-11 00:40:39 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:40 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:40 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:40 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:40 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:40 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:40:40 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:40 --> Total execution time: 0.4790
DEBUG - 2012-01-11 00:40:44 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:44 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:44 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:44 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:44 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:44 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:44 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:44 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:40:44 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:44 --> Total execution time: 0.5652
DEBUG - 2012-01-11 00:40:45 --> Config Class Initialized
DEBUG - 2012-01-11 00:40:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:40:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:40:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:40:45 --> URI Class Initialized
DEBUG - 2012-01-11 00:40:45 --> Router Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Output Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Security Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Input Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:40:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:40:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:40:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:40:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:40:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:40:46 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:40:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:40:46 --> Total execution time: 0.4496
DEBUG - 2012-01-11 00:41:00 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:00 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:00 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:01 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:01 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:01 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:01 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:01 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:01 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:01 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:01 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:02 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:02 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:02 --> Total execution time: 0.4129
DEBUG - 2012-01-11 00:41:04 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:04 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:04 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:04 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:04 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:04 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:41:04 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:04 --> Total execution time: 0.4306
DEBUG - 2012-01-11 00:41:06 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:07 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:07 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:07 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:07 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:07 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:07 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:07 --> Total execution time: 0.6622
DEBUG - 2012-01-11 00:41:15 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:15 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:15 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:15 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:15 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:16 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:16 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:16 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:16 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:16 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:16 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:16 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:16 --> Total execution time: 0.4155
DEBUG - 2012-01-11 00:41:18 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:18 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:18 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:18 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:18 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:18 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:41:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:41:18 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:18 --> Total execution time: 0.5047
DEBUG - 2012-01-11 00:41:22 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:22 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:22 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:22 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:22 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:22 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:22 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:22 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:22 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:22 --> Total execution time: 0.5058
DEBUG - 2012-01-11 00:41:30 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:30 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:30 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:31 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:31 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:31 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:31 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:31 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:31 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:31 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:31 --> Total execution time: 0.3877
DEBUG - 2012-01-11 00:41:34 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:34 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:34 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:34 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:34 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:34 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:41:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:41:35 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:35 --> Total execution time: 0.4967
DEBUG - 2012-01-11 00:41:38 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:38 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:38 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:39 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:39 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:39 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:39 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:41:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:41:39 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:39 --> Total execution time: 0.5019
DEBUG - 2012-01-11 00:41:41 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:41 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:41 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:41 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:42 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:42 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:42 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:42 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:42 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:42 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:42 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:42 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:42 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:42 --> Total execution time: 0.4160
DEBUG - 2012-01-11 00:41:49 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:49 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:49 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:49 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:49 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:49 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:49 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:50 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:50 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:50 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:50 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:50 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:50 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:50 --> Total execution time: 0.4056
DEBUG - 2012-01-11 00:41:51 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:51 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:51 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:51 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:51 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:51 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:41:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:41:51 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:51 --> Total execution time: 0.4866
DEBUG - 2012-01-11 00:41:53 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:54 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:54 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:54 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:54 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:54 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:41:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:41:54 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:54 --> Total execution time: 0.4732
DEBUG - 2012-01-11 00:41:56 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:56 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:56 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:56 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:56 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:56 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:41:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:41:56 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:56 --> Total execution time: 0.4783
DEBUG - 2012-01-11 00:41:59 --> Config Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:41:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:41:59 --> URI Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Router Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Output Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Security Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Input Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:41:59 --> Language Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Loader Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:41:59 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Session Class Initialized
DEBUG - 2012-01-11 00:41:59 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:41:59 --> Session routines successfully run
DEBUG - 2012-01-11 00:41:59 --> Controller Class Initialized
DEBUG - 2012-01-11 00:41:59 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:41:59 --> Final output sent to browser
DEBUG - 2012-01-11 00:41:59 --> Total execution time: 0.4422
DEBUG - 2012-01-11 00:42:07 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:07 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:07 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:07 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:07 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:07 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:07 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:08 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:08 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:08 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:08 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:08 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:08 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:08 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:08 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:42:08 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:08 --> Total execution time: 0.4099
DEBUG - 2012-01-11 00:42:10 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:10 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:10 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:10 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:10 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:10 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:42:10 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:10 --> Total execution time: 0.4512
DEBUG - 2012-01-11 00:42:13 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:13 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:13 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:13 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:13 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:13 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:42:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:42:13 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:13 --> Total execution time: 0.8920
DEBUG - 2012-01-11 00:42:16 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:16 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:16 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:16 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:16 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:16 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:16 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:42:16 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:42:16 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:16 --> Total execution time: 0.4230
DEBUG - 2012-01-11 00:42:19 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:19 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:19 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:19 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:19 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:19 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:19 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:42:19 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:42:19 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:19 --> Total execution time: 0.5140
DEBUG - 2012-01-11 00:42:23 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:24 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:24 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:24 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:24 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:24 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:42:24 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:24 --> Total execution time: 0.4514
DEBUG - 2012-01-11 00:42:31 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:31 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:31 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:31 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:31 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:31 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:32 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:32 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:32 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:32 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:32 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:32 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:32 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:32 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:42:32 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:32 --> Total execution time: 0.3962
DEBUG - 2012-01-11 00:42:34 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:34 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:34 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:34 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:34 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:35 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:42:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:42:35 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:35 --> Total execution time: 0.5405
DEBUG - 2012-01-11 00:42:38 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:38 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:38 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:38 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:38 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:38 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:42:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:42:38 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:38 --> Total execution time: 0.4404
DEBUG - 2012-01-11 00:42:44 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:44 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:44 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:44 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:44 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:45 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:45 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:45 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:42:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:42:45 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:45 --> Total execution time: 0.9205
DEBUG - 2012-01-11 00:42:57 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:57 --> URI Class Initialized
DEBUG - 2012-01-11 00:42:57 --> Router Class Initialized
DEBUG - 2012-01-11 00:42:57 --> Output Class Initialized
DEBUG - 2012-01-11 00:42:57 --> Security Class Initialized
DEBUG - 2012-01-11 00:42:57 --> Input Class Initialized
DEBUG - 2012-01-11 00:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:42:57 --> Language Class Initialized
DEBUG - 2012-01-11 00:42:58 --> Loader Class Initialized
DEBUG - 2012-01-11 00:42:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:42:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:42:58 --> Session Class Initialized
DEBUG - 2012-01-11 00:42:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:42:58 --> Session routines successfully run
DEBUG - 2012-01-11 00:42:58 --> Controller Class Initialized
DEBUG - 2012-01-11 00:42:58 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:42:58 --> Final output sent to browser
DEBUG - 2012-01-11 00:42:58 --> Total execution time: 0.4789
DEBUG - 2012-01-11 00:42:59 --> Config Class Initialized
DEBUG - 2012-01-11 00:42:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:42:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:42:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:42:59 --> URI Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Router Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Output Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Security Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Input Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:43:00 --> Language Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Loader Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:43:00 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Session Class Initialized
DEBUG - 2012-01-11 00:43:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:43:00 --> Session routines successfully run
DEBUG - 2012-01-11 00:43:00 --> Controller Class Initialized
DEBUG - 2012-01-11 00:43:00 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:43:00 --> Final output sent to browser
DEBUG - 2012-01-11 00:43:00 --> Total execution time: 0.4469
DEBUG - 2012-01-11 00:43:01 --> Config Class Initialized
DEBUG - 2012-01-11 00:43:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:43:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:43:02 --> URI Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Router Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Output Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Security Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Input Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:43:02 --> Language Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Loader Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:43:02 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Session Class Initialized
DEBUG - 2012-01-11 00:43:02 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:43:02 --> Session routines successfully run
DEBUG - 2012-01-11 00:43:02 --> Controller Class Initialized
DEBUG - 2012-01-11 00:43:02 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:43:02 --> Final output sent to browser
DEBUG - 2012-01-11 00:43:02 --> Total execution time: 0.4244
DEBUG - 2012-01-11 00:43:07 --> Config Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:43:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:43:07 --> URI Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Router Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Output Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Security Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Input Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:43:07 --> Language Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Loader Class Initialized
DEBUG - 2012-01-11 00:43:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:43:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:43:08 --> Session Class Initialized
DEBUG - 2012-01-11 00:43:08 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:43:08 --> Session routines successfully run
DEBUG - 2012-01-11 00:43:08 --> Controller Class Initialized
DEBUG - 2012-01-11 00:43:08 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:43:08 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:43:08 --> Final output sent to browser
DEBUG - 2012-01-11 00:43:08 --> Total execution time: 0.4375
DEBUG - 2012-01-11 00:43:10 --> Config Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:43:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:43:10 --> URI Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Router Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Output Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Security Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Input Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:43:10 --> Language Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Loader Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:43:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Session Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:43:10 --> Session routines successfully run
DEBUG - 2012-01-11 00:43:10 --> Controller Class Initialized
DEBUG - 2012-01-11 00:43:10 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:43:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:43:11 --> Final output sent to browser
DEBUG - 2012-01-11 00:43:11 --> Total execution time: 0.5047
DEBUG - 2012-01-11 00:43:12 --> Config Class Initialized
DEBUG - 2012-01-11 00:43:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:43:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:43:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:43:12 --> URI Class Initialized
DEBUG - 2012-01-11 00:43:12 --> Router Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Output Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Security Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Input Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:43:13 --> Language Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Loader Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:43:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Session Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:43:13 --> Session routines successfully run
DEBUG - 2012-01-11 00:43:13 --> Controller Class Initialized
DEBUG - 2012-01-11 00:43:13 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:43:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:43:13 --> Final output sent to browser
DEBUG - 2012-01-11 00:43:13 --> Total execution time: 1.0312
DEBUG - 2012-01-11 00:43:21 --> Config Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:43:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:43:21 --> URI Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Router Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Output Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Security Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Input Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:43:21 --> Language Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Loader Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:43:21 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Session Class Initialized
DEBUG - 2012-01-11 00:43:21 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:43:21 --> Session routines successfully run
DEBUG - 2012-01-11 00:43:21 --> Controller Class Initialized
DEBUG - 2012-01-11 00:43:21 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:43:21 --> Final output sent to browser
DEBUG - 2012-01-11 00:43:21 --> Total execution time: 0.4888
DEBUG - 2012-01-11 00:44:24 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:24 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:24 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:24 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:24 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:24 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:24 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:24 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:24 --> Total execution time: 0.5303
DEBUG - 2012-01-11 00:44:27 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:27 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:27 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:27 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:27 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:27 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:27 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:27 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:27 --> Total execution time: 0.4901
DEBUG - 2012-01-11 00:44:29 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:29 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:29 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:29 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:30 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:30 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:30 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:30 --> Total execution time: 0.9390
DEBUG - 2012-01-11 00:44:33 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:33 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:33 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:33 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:33 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:33 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:33 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:33 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:33 --> Total execution time: 0.4306
DEBUG - 2012-01-11 00:44:35 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:35 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:35 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:35 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:35 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:35 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:35 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:35 --> Total execution time: 0.5272
DEBUG - 2012-01-11 00:44:37 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:37 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:37 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:37 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:37 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:37 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:37 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:37 --> Total execution time: 0.5206
DEBUG - 2012-01-11 00:44:39 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:39 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:39 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:39 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:39 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:39 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:39 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:39 --> Total execution time: 0.5791
DEBUG - 2012-01-11 00:44:43 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:43 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:43 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:44 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:44 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:44 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:44 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:44 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 00:44:44 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:44 --> Total execution time: 0.4860
DEBUG - 2012-01-11 00:44:46 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:46 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:46 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:46 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:46 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:46 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:44:46 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:46 --> Total execution time: 0.4851
DEBUG - 2012-01-11 00:44:55 --> Config Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:44:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:44:55 --> URI Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Router Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Output Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Security Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Input Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:44:55 --> Language Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Loader Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:44:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Session Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:44:55 --> Session routines successfully run
DEBUG - 2012-01-11 00:44:55 --> Controller Class Initialized
DEBUG - 2012-01-11 00:44:55 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:44:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:44:55 --> Final output sent to browser
DEBUG - 2012-01-11 00:44:55 --> Total execution time: 0.4987
DEBUG - 2012-01-11 00:45:03 --> Config Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:45:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:45:03 --> URI Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Router Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Output Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Security Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Input Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:45:03 --> Language Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Loader Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:45:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Session Class Initialized
DEBUG - 2012-01-11 00:45:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:45:03 --> Session routines successfully run
DEBUG - 2012-01-11 00:45:03 --> Controller Class Initialized
DEBUG - 2012-01-11 00:45:03 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:45:03 --> Final output sent to browser
DEBUG - 2012-01-11 00:45:03 --> Total execution time: 0.4131
DEBUG - 2012-01-11 00:45:06 --> Config Class Initialized
DEBUG - 2012-01-11 00:45:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:45:06 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:45:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:45:06 --> URI Class Initialized
DEBUG - 2012-01-11 00:45:06 --> Router Class Initialized
DEBUG - 2012-01-11 00:45:06 --> Output Class Initialized
DEBUG - 2012-01-11 00:45:06 --> Security Class Initialized
DEBUG - 2012-01-11 00:45:06 --> Input Class Initialized
DEBUG - 2012-01-11 00:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:45:07 --> Language Class Initialized
DEBUG - 2012-01-11 00:45:07 --> Loader Class Initialized
DEBUG - 2012-01-11 00:45:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:45:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:45:07 --> Session Class Initialized
DEBUG - 2012-01-11 00:45:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:45:07 --> Session routines successfully run
DEBUG - 2012-01-11 00:45:07 --> Controller Class Initialized
DEBUG - 2012-01-11 00:45:07 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:45:07 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:45:07 --> Final output sent to browser
DEBUG - 2012-01-11 00:45:07 --> Total execution time: 0.5826
DEBUG - 2012-01-11 00:48:20 --> Config Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:48:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:48:20 --> URI Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Router Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Output Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Security Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Input Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:48:20 --> Language Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Loader Class Initialized
DEBUG - 2012-01-11 00:48:20 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:48:21 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:48:21 --> Session Class Initialized
DEBUG - 2012-01-11 00:48:21 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:48:21 --> Session routines successfully run
DEBUG - 2012-01-11 00:48:21 --> Controller Class Initialized
DEBUG - 2012-01-11 00:48:21 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:48:21 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:48:21 --> Final output sent to browser
DEBUG - 2012-01-11 00:48:21 --> Total execution time: 0.4369
DEBUG - 2012-01-11 00:49:09 --> Config Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:49:09 --> URI Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Router Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Output Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Security Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Input Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:49:09 --> Language Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Loader Class Initialized
DEBUG - 2012-01-11 00:49:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:49:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:49:10 --> Session Class Initialized
DEBUG - 2012-01-11 00:49:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:49:10 --> Session routines successfully run
DEBUG - 2012-01-11 00:49:10 --> Controller Class Initialized
DEBUG - 2012-01-11 00:49:10 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:49:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:49:10 --> Final output sent to browser
DEBUG - 2012-01-11 00:49:10 --> Total execution time: 0.8366
DEBUG - 2012-01-11 00:49:59 --> Config Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:49:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:49:59 --> URI Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Router Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Output Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Security Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Input Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:49:59 --> Language Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Loader Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:49:59 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Session Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:49:59 --> Session routines successfully run
DEBUG - 2012-01-11 00:49:59 --> Controller Class Initialized
DEBUG - 2012-01-11 00:49:59 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:49:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:49:59 --> Final output sent to browser
DEBUG - 2012-01-11 00:49:59 --> Total execution time: 0.4629
DEBUG - 2012-01-11 00:53:41 --> Config Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:53:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:53:41 --> URI Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Router Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Output Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Security Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Input Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:53:41 --> Language Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Loader Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:53:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Session Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:53:41 --> Session routines successfully run
DEBUG - 2012-01-11 00:53:41 --> Controller Class Initialized
DEBUG - 2012-01-11 00:53:41 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:53:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:53:41 --> Final output sent to browser
DEBUG - 2012-01-11 00:53:41 --> Total execution time: 0.4309
DEBUG - 2012-01-11 00:53:54 --> Config Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:53:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:53:54 --> URI Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Router Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Output Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Security Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Input Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:53:54 --> Language Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Loader Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:53:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Session Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:53:54 --> Session routines successfully run
DEBUG - 2012-01-11 00:53:54 --> Controller Class Initialized
DEBUG - 2012-01-11 00:53:54 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:53:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:53:54 --> Final output sent to browser
DEBUG - 2012-01-11 00:53:54 --> Total execution time: 0.4349
DEBUG - 2012-01-11 00:54:09 --> Config Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:54:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:54:09 --> URI Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Router Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Output Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Security Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Input Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:54:09 --> Language Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Loader Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:54:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Session Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:54:09 --> Session routines successfully run
DEBUG - 2012-01-11 00:54:09 --> Controller Class Initialized
DEBUG - 2012-01-11 00:54:09 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:54:09 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:54:09 --> Final output sent to browser
DEBUG - 2012-01-11 00:54:09 --> Total execution time: 0.4444
DEBUG - 2012-01-11 00:56:10 --> Config Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:56:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:56:10 --> URI Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Router Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Output Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Security Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Input Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:56:10 --> Language Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Loader Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:56:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Session Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:56:10 --> Session routines successfully run
DEBUG - 2012-01-11 00:56:10 --> Controller Class Initialized
DEBUG - 2012-01-11 00:56:10 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:56:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:56:10 --> Final output sent to browser
DEBUG - 2012-01-11 00:56:10 --> Total execution time: 0.4192
DEBUG - 2012-01-11 00:56:12 --> Config Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:56:12 --> URI Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Router Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Output Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Security Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Input Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:56:12 --> Language Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Loader Class Initialized
DEBUG - 2012-01-11 00:56:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:56:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:56:13 --> Session Class Initialized
DEBUG - 2012-01-11 00:56:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:56:13 --> Session routines successfully run
DEBUG - 2012-01-11 00:56:13 --> Controller Class Initialized
DEBUG - 2012-01-11 00:56:13 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:56:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:56:13 --> Final output sent to browser
DEBUG - 2012-01-11 00:56:13 --> Total execution time: 1.2546
DEBUG - 2012-01-11 00:56:15 --> Config Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:56:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:56:15 --> URI Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Router Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Output Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Security Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Input Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:56:15 --> Language Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Loader Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:56:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Session Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:56:15 --> Session routines successfully run
DEBUG - 2012-01-11 00:56:15 --> Controller Class Initialized
DEBUG - 2012-01-11 00:56:15 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:56:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:56:15 --> Final output sent to browser
DEBUG - 2012-01-11 00:56:15 --> Total execution time: 0.5148
DEBUG - 2012-01-11 00:56:18 --> Config Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:56:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:56:18 --> URI Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Router Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Output Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Security Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Input Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:56:18 --> Language Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Loader Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:56:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Session Class Initialized
DEBUG - 2012-01-11 00:56:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:56:18 --> Session routines successfully run
DEBUG - 2012-01-11 00:56:18 --> Controller Class Initialized
DEBUG - 2012-01-11 00:56:19 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:56:19 --> Final output sent to browser
DEBUG - 2012-01-11 00:56:19 --> Total execution time: 0.6104
DEBUG - 2012-01-11 00:57:05 --> Config Class Initialized
DEBUG - 2012-01-11 00:57:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:57:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:57:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:57:05 --> URI Class Initialized
DEBUG - 2012-01-11 00:57:05 --> Router Class Initialized
DEBUG - 2012-01-11 00:57:05 --> Output Class Initialized
DEBUG - 2012-01-11 00:57:05 --> Security Class Initialized
DEBUG - 2012-01-11 00:57:06 --> Input Class Initialized
DEBUG - 2012-01-11 00:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:57:06 --> Language Class Initialized
DEBUG - 2012-01-11 00:57:06 --> Loader Class Initialized
DEBUG - 2012-01-11 00:57:06 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:57:06 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:57:06 --> Session Class Initialized
DEBUG - 2012-01-11 00:57:06 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:57:06 --> Session routines successfully run
DEBUG - 2012-01-11 00:57:06 --> Controller Class Initialized
DEBUG - 2012-01-11 00:57:06 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:57:06 --> Final output sent to browser
DEBUG - 2012-01-11 00:57:06 --> Total execution time: 0.8791
DEBUG - 2012-01-11 00:58:25 --> Config Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:58:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:58:25 --> URI Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Router Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Output Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Security Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Input Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:58:25 --> Language Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Loader Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:58:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Session Class Initialized
DEBUG - 2012-01-11 00:58:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:58:25 --> Session routines successfully run
DEBUG - 2012-01-11 00:58:25 --> Controller Class Initialized
DEBUG - 2012-01-11 00:58:25 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:58:25 --> Final output sent to browser
DEBUG - 2012-01-11 00:58:25 --> Total execution time: 0.4594
DEBUG - 2012-01-11 00:58:27 --> Config Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:58:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:58:27 --> URI Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Router Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Output Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Security Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Input Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:58:27 --> Language Class Initialized
DEBUG - 2012-01-11 00:58:27 --> Loader Class Initialized
DEBUG - 2012-01-11 00:58:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:58:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:58:28 --> Session Class Initialized
DEBUG - 2012-01-11 00:58:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:58:28 --> Session routines successfully run
DEBUG - 2012-01-11 00:58:28 --> Controller Class Initialized
DEBUG - 2012-01-11 00:58:28 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:58:28 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:58:28 --> Final output sent to browser
DEBUG - 2012-01-11 00:58:28 --> Total execution time: 0.4732
DEBUG - 2012-01-11 00:58:30 --> Config Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:58:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:58:30 --> URI Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Router Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Output Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Security Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Input Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:58:30 --> Language Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Loader Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:58:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Session Class Initialized
DEBUG - 2012-01-11 00:58:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:58:30 --> Session routines successfully run
DEBUG - 2012-01-11 00:58:30 --> Controller Class Initialized
DEBUG - 2012-01-11 00:58:30 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 00:58:30 --> Final output sent to browser
DEBUG - 2012-01-11 00:58:30 --> Total execution time: 0.4400
DEBUG - 2012-01-11 00:58:31 --> Config Class Initialized
DEBUG - 2012-01-11 00:58:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:58:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:58:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:58:31 --> URI Class Initialized
DEBUG - 2012-01-11 00:58:31 --> Router Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Output Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Security Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Input Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:58:32 --> Language Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Loader Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:58:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Session Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:58:32 --> Session routines successfully run
DEBUG - 2012-01-11 00:58:32 --> Controller Class Initialized
DEBUG - 2012-01-11 00:58:32 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:58:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:58:32 --> Final output sent to browser
DEBUG - 2012-01-11 00:58:32 --> Total execution time: 0.5107
DEBUG - 2012-01-11 00:58:34 --> Config Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:58:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:58:34 --> URI Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Router Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Output Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Security Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Input Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:58:34 --> Language Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Loader Class Initialized
DEBUG - 2012-01-11 00:58:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:58:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:58:35 --> Session Class Initialized
DEBUG - 2012-01-11 00:58:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:58:35 --> Session routines successfully run
DEBUG - 2012-01-11 00:58:35 --> Controller Class Initialized
DEBUG - 2012-01-11 00:58:35 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:58:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:58:35 --> Final output sent to browser
DEBUG - 2012-01-11 00:58:35 --> Total execution time: 0.5853
DEBUG - 2012-01-11 00:58:36 --> Config Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:58:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:58:36 --> URI Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Router Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Output Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Security Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Input Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:58:36 --> Language Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Loader Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:58:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Session Class Initialized
DEBUG - 2012-01-11 00:58:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:58:36 --> Session routines successfully run
DEBUG - 2012-01-11 00:58:36 --> Controller Class Initialized
DEBUG - 2012-01-11 00:58:37 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:58:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:58:37 --> Final output sent to browser
DEBUG - 2012-01-11 00:58:37 --> Total execution time: 0.5085
DEBUG - 2012-01-11 00:58:39 --> Config Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 00:58:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 00:58:39 --> URI Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Router Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Output Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Security Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Input Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 00:58:39 --> Language Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Loader Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 00:58:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Session Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 00:58:39 --> Session routines successfully run
DEBUG - 2012-01-11 00:58:39 --> Controller Class Initialized
DEBUG - 2012-01-11 00:58:39 --> Pagination Class Initialized
DEBUG - 2012-01-11 00:58:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 00:58:40 --> Final output sent to browser
DEBUG - 2012-01-11 00:58:40 --> Total execution time: 0.7330
DEBUG - 2012-01-11 01:02:50 --> Config Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:02:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:02:50 --> URI Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Router Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Output Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Security Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Input Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:02:50 --> Language Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Loader Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:02:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Session Class Initialized
DEBUG - 2012-01-11 01:02:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:02:51 --> Session routines successfully run
DEBUG - 2012-01-11 01:02:51 --> Controller Class Initialized
DEBUG - 2012-01-11 01:02:51 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:02:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:02:51 --> Final output sent to browser
DEBUG - 2012-01-11 01:02:51 --> Total execution time: 0.5563
DEBUG - 2012-01-11 01:03:48 --> Config Class Initialized
DEBUG - 2012-01-11 01:03:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:03:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:03:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:03:48 --> URI Class Initialized
DEBUG - 2012-01-11 01:03:48 --> Router Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Output Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Security Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Input Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:03:49 --> Language Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Loader Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:03:49 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Session Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:03:49 --> Session routines successfully run
DEBUG - 2012-01-11 01:03:49 --> Controller Class Initialized
DEBUG - 2012-01-11 01:03:49 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:03:49 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:03:49 --> Final output sent to browser
DEBUG - 2012-01-11 01:03:49 --> Total execution time: 0.4422
DEBUG - 2012-01-11 01:03:51 --> Config Class Initialized
DEBUG - 2012-01-11 01:03:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:03:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:03:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:03:51 --> URI Class Initialized
DEBUG - 2012-01-11 01:03:51 --> Router Class Initialized
DEBUG - 2012-01-11 01:03:51 --> Output Class Initialized
DEBUG - 2012-01-11 01:03:51 --> Security Class Initialized
DEBUG - 2012-01-11 01:03:52 --> Input Class Initialized
DEBUG - 2012-01-11 01:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:03:52 --> Language Class Initialized
DEBUG - 2012-01-11 01:03:52 --> Loader Class Initialized
DEBUG - 2012-01-11 01:03:52 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:03:52 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:03:52 --> Session Class Initialized
DEBUG - 2012-01-11 01:03:52 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:03:52 --> Session routines successfully run
DEBUG - 2012-01-11 01:03:52 --> Controller Class Initialized
DEBUG - 2012-01-11 01:03:52 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:03:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:03:52 --> Final output sent to browser
DEBUG - 2012-01-11 01:03:52 --> Total execution time: 0.5021
DEBUG - 2012-01-11 01:03:57 --> Config Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:03:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:03:57 --> URI Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Router Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Output Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Security Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Input Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:03:57 --> Language Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Loader Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:03:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Session Class Initialized
DEBUG - 2012-01-11 01:03:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:03:57 --> Session routines successfully run
DEBUG - 2012-01-11 01:03:57 --> Controller Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Config Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:03:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:03:58 --> URI Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Router Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Output Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Security Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Input Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:03:58 --> Language Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Loader Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:03:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Session Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:03:58 --> Session routines successfully run
DEBUG - 2012-01-11 01:03:58 --> Controller Class Initialized
DEBUG - 2012-01-11 01:03:58 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:03:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:03:58 --> Final output sent to browser
DEBUG - 2012-01-11 01:03:58 --> Total execution time: 0.4064
DEBUG - 2012-01-11 01:04:00 --> Config Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:04:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:04:01 --> URI Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Router Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Output Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Security Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Input Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:04:01 --> Language Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Loader Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:04:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Session Class Initialized
DEBUG - 2012-01-11 01:04:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:04:01 --> Session routines successfully run
DEBUG - 2012-01-11 01:04:01 --> Controller Class Initialized
DEBUG - 2012-01-11 01:04:01 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:04:01 --> Final output sent to browser
DEBUG - 2012-01-11 01:04:01 --> Total execution time: 0.4741
DEBUG - 2012-01-11 01:05:52 --> Config Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:05:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:05:52 --> URI Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Router Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Output Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Security Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Input Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:05:52 --> Language Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Loader Class Initialized
DEBUG - 2012-01-11 01:05:52 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:05:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:05:53 --> Session Class Initialized
DEBUG - 2012-01-11 01:05:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:05:53 --> Session routines successfully run
DEBUG - 2012-01-11 01:05:53 --> Controller Class Initialized
DEBUG - 2012-01-11 01:05:53 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:05:53 --> Final output sent to browser
DEBUG - 2012-01-11 01:05:53 --> Total execution time: 0.4716
DEBUG - 2012-01-11 01:06:05 --> Config Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:06:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:06:05 --> URI Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Router Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Output Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Security Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Input Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:06:05 --> Language Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Loader Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:06:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Session Class Initialized
DEBUG - 2012-01-11 01:06:05 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:06:05 --> Session routines successfully run
DEBUG - 2012-01-11 01:06:05 --> Controller Class Initialized
ERROR - 2012-01-11 01:06:05 --> Severity: Notice  --> Undefined property: stdClass::$id_article A:\home\codeigniter.blog\www\application\views\admin\article.php 34
DEBUG - 2012-01-11 01:06:05 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:06:05 --> Final output sent to browser
DEBUG - 2012-01-11 01:06:05 --> Total execution time: 0.5820
DEBUG - 2012-01-11 01:07:00 --> Config Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:07:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:07:00 --> URI Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Router Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Output Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Security Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Input Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:07:00 --> Language Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Loader Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:07:00 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Session Class Initialized
DEBUG - 2012-01-11 01:07:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:07:00 --> Session routines successfully run
DEBUG - 2012-01-11 01:07:00 --> Controller Class Initialized
ERROR - 2012-01-11 01:07:00 --> Severity: Notice  --> Undefined property: stdClass::$id_article A:\home\codeigniter.blog\www\application\views\admin\article.php 34
DEBUG - 2012-01-11 01:07:00 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:07:00 --> Final output sent to browser
DEBUG - 2012-01-11 01:07:01 --> Total execution time: 0.4271
DEBUG - 2012-01-11 01:07:42 --> Config Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:07:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:07:42 --> URI Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Router Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Output Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Security Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Input Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:07:42 --> Language Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Loader Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:07:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Session Class Initialized
DEBUG - 2012-01-11 01:07:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:07:43 --> Session routines successfully run
DEBUG - 2012-01-11 01:07:43 --> Controller Class Initialized
DEBUG - 2012-01-11 01:07:43 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:07:43 --> Final output sent to browser
DEBUG - 2012-01-11 01:07:43 --> Total execution time: 1.0158
DEBUG - 2012-01-11 01:07:53 --> Config Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:07:53 --> URI Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Router Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Output Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Security Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Input Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:07:53 --> Language Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Loader Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:07:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Session Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:07:53 --> Session routines successfully run
DEBUG - 2012-01-11 01:07:53 --> Controller Class Initialized
DEBUG - 2012-01-11 01:07:53 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:07:53 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:07:53 --> Final output sent to browser
DEBUG - 2012-01-11 01:07:53 --> Total execution time: 0.4467
DEBUG - 2012-01-11 01:07:56 --> Config Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:07:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:07:56 --> URI Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Router Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Output Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Security Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Input Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:07:56 --> Language Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Loader Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:07:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Session Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:07:56 --> Session routines successfully run
DEBUG - 2012-01-11 01:07:56 --> Controller Class Initialized
DEBUG - 2012-01-11 01:07:56 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:07:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:07:56 --> Final output sent to browser
DEBUG - 2012-01-11 01:07:56 --> Total execution time: 0.4799
DEBUG - 2012-01-11 01:07:58 --> Config Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:07:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:07:59 --> URI Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Router Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Output Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Security Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Input Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:07:59 --> Language Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Loader Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:07:59 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Session Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:07:59 --> Session routines successfully run
DEBUG - 2012-01-11 01:07:59 --> Controller Class Initialized
DEBUG - 2012-01-11 01:07:59 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:07:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:07:59 --> Final output sent to browser
DEBUG - 2012-01-11 01:07:59 --> Total execution time: 0.9725
DEBUG - 2012-01-11 01:08:03 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:03 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:03 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:03 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:03 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:03 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:08:03 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:03 --> Total execution time: 0.4733
DEBUG - 2012-01-11 01:08:13 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:13 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:13 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:13 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:13 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:08:13 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:13 --> Total execution time: 0.4156
DEBUG - 2012-01-11 01:08:40 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:40 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:40 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:40 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:40 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:40 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:08:40 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:40 --> Total execution time: 0.5173
DEBUG - 2012-01-11 01:08:42 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:42 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:42 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:42 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:42 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:08:42 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:42 --> Total execution time: 0.4741
DEBUG - 2012-01-11 01:08:44 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:44 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:44 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:44 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:45 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:45 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:45 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:45 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:08:45 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:45 --> Total execution time: 0.5674
DEBUG - 2012-01-11 01:08:46 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:47 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:47 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:47 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:47 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:47 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:08:47 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:47 --> Total execution time: 0.4700
DEBUG - 2012-01-11 01:08:49 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:49 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:49 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:49 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:49 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:50 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:50 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:50 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:08:50 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:50 --> Total execution time: 0.4239
DEBUG - 2012-01-11 01:08:51 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:51 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:51 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:51 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:51 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:51 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:08:51 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:51 --> Total execution time: 0.4530
DEBUG - 2012-01-11 01:08:53 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:53 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:53 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:53 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:53 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:53 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:08:53 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:08:53 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:54 --> Total execution time: 0.8740
DEBUG - 2012-01-11 01:08:56 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:56 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:56 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:56 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:56 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:56 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:08:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:08:56 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:56 --> Total execution time: 0.5063
DEBUG - 2012-01-11 01:08:58 --> Config Class Initialized
DEBUG - 2012-01-11 01:08:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:08:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:08:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:08:58 --> URI Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Router Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Output Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Security Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Input Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:08:59 --> Language Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Loader Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:08:59 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Session Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:08:59 --> Session routines successfully run
DEBUG - 2012-01-11 01:08:59 --> Controller Class Initialized
DEBUG - 2012-01-11 01:08:59 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:08:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:08:59 --> Final output sent to browser
DEBUG - 2012-01-11 01:08:59 --> Total execution time: 1.1089
DEBUG - 2012-01-11 01:09:01 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:01 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:01 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:01 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:01 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:01 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:09:01 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:09:01 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:01 --> Total execution time: 0.5567
DEBUG - 2012-01-11 01:09:04 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:04 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:04 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:04 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:04 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:05 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:09:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:09:05 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:05 --> Total execution time: 1.2218
DEBUG - 2012-01-11 01:09:07 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:07 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:07 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:07 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:07 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:07 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:09:07 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:09:07 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:07 --> Total execution time: 0.5149
DEBUG - 2012-01-11 01:09:09 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:09 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:09 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:09 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:09 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:09 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:09 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:10 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:10 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:10 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:10 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:10 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:09:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:09:10 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:10 --> Total execution time: 1.0757
DEBUG - 2012-01-11 01:09:13 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:13 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:13 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:13 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:13 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:14 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:14 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:14 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:14 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:14 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:14 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:14 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:14 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:14 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:14 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:09:14 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:14 --> Total execution time: 0.4241
DEBUG - 2012-01-11 01:09:25 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:25 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:25 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:25 --> No URI present. Default controller set.
DEBUG - 2012-01-11 01:09:25 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:25 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:25 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:25 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:25 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:26 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:26 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:26 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:26 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:26 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:09:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:09:26 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:26 --> Total execution time: 0.4191
DEBUG - 2012-01-11 01:09:27 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:27 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:27 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:28 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:28 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:28 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:28 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:09:28 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:28 --> Total execution time: 0.5143
DEBUG - 2012-01-11 01:09:34 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:34 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:34 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:34 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:34 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:09:34 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:34 --> Total execution time: 0.4878
DEBUG - 2012-01-11 01:09:35 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:35 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:35 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:35 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:35 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:09:36 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:36 --> Total execution time: 0.4154
DEBUG - 2012-01-11 01:09:37 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:37 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:37 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:38 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:38 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:38 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:09:38 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:38 --> Total execution time: 0.4254
DEBUG - 2012-01-11 01:09:39 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:39 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:39 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:39 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:39 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:09:40 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:40 --> Total execution time: 0.8992
DEBUG - 2012-01-11 01:09:41 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:41 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:41 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:41 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:41 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:41 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:09:41 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:41 --> Total execution time: 0.6921
DEBUG - 2012-01-11 01:09:43 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:43 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:43 --> No URI present. Default controller set.
DEBUG - 2012-01-11 01:09:43 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:43 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:43 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:43 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:43 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:09:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:09:43 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:43 --> Total execution time: 0.5605
DEBUG - 2012-01-11 01:09:46 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:46 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:46 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:46 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:46 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:47 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:09:47 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:47 --> Total execution time: 0.5210
DEBUG - 2012-01-11 01:09:54 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:54 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:54 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:54 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:54 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:54 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:09:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:09:54 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:54 --> Total execution time: 0.4344
DEBUG - 2012-01-11 01:09:58 --> Config Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:09:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:09:58 --> URI Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Router Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Output Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Security Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Input Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:09:58 --> Language Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Loader Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:09:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Session Class Initialized
DEBUG - 2012-01-11 01:09:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:09:58 --> Session routines successfully run
DEBUG - 2012-01-11 01:09:58 --> Controller Class Initialized
DEBUG - 2012-01-11 01:09:58 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:09:58 --> Final output sent to browser
DEBUG - 2012-01-11 01:09:58 --> Total execution time: 0.6321
DEBUG - 2012-01-11 01:10:08 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:08 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:08 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:08 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:08 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:08 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:08 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:08 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:08 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:08 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:08 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:08 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:08 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-11 01:10:08 --> Final output sent to browser
DEBUG - 2012-01-11 01:10:08 --> Total execution time: 0.3404
DEBUG - 2012-01-11 01:10:09 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:09 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:09 --> Router Class Initialized
ERROR - 2012-01-11 01:10:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:10:16 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:16 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:16 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:16 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:16 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:16 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:16 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:16 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:16 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:16 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:16 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:16 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-11 01:10:16 --> Final output sent to browser
DEBUG - 2012-01-11 01:10:16 --> Total execution time: 0.3339
DEBUG - 2012-01-11 01:10:16 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:17 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:17 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:17 --> Router Class Initialized
ERROR - 2012-01-11 01:10:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:10:22 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:22 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:22 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:22 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:22 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:22 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:22 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:22 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:22 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:22 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:22 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:22 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:22 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-11 01:10:22 --> Final output sent to browser
DEBUG - 2012-01-11 01:10:23 --> Total execution time: 0.3254
DEBUG - 2012-01-11 01:10:23 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:23 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:23 --> Router Class Initialized
ERROR - 2012-01-11 01:10:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:10:33 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:33 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:33 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:33 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:33 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:33 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Router Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Output Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Security Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Input Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:10:33 --> Language Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Loader Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:10:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Session Class Initialized
DEBUG - 2012-01-11 01:10:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:10:34 --> Session routines successfully run
DEBUG - 2012-01-11 01:10:34 --> Controller Class Initialized
DEBUG - 2012-01-11 01:10:34 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:10:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:10:34 --> Final output sent to browser
DEBUG - 2012-01-11 01:10:34 --> Total execution time: 0.3701
DEBUG - 2012-01-11 01:10:34 --> Config Class Initialized
DEBUG - 2012-01-11 01:10:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:10:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:10:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:10:34 --> URI Class Initialized
DEBUG - 2012-01-11 01:10:34 --> Router Class Initialized
ERROR - 2012-01-11 01:10:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:12:31 --> Config Class Initialized
DEBUG - 2012-01-11 01:12:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:12:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:12:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:12:31 --> URI Class Initialized
DEBUG - 2012-01-11 01:12:31 --> Router Class Initialized
DEBUG - 2012-01-11 01:12:31 --> Output Class Initialized
DEBUG - 2012-01-11 01:12:31 --> Security Class Initialized
DEBUG - 2012-01-11 01:12:31 --> Input Class Initialized
DEBUG - 2012-01-11 01:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:12:31 --> Language Class Initialized
ERROR - 2012-01-11 01:12:31 --> Severity: Notice  --> Undefined property: Article::$session A:\home\codeigniter.blog\www\application\controllers\admin\article.php 7
DEBUG - 2012-01-11 01:13:09 --> Config Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:13:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:13:09 --> URI Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Router Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Output Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Security Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Input Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:13:09 --> Language Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Loader Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:13:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Session Class Initialized
DEBUG - 2012-01-11 01:13:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:13:09 --> Session routines successfully run
DEBUG - 2012-01-11 01:13:09 --> Controller Class Initialized
DEBUG - 2012-01-11 01:13:09 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:13:09 --> Final output sent to browser
DEBUG - 2012-01-11 01:13:09 --> Total execution time: 0.3641
DEBUG - 2012-01-11 01:13:38 --> Config Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:13:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:13:38 --> URI Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Router Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Output Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Security Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Input Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:13:38 --> Language Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Loader Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:13:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Session Class Initialized
DEBUG - 2012-01-11 01:13:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:13:38 --> Session routines successfully run
DEBUG - 2012-01-11 01:13:38 --> Controller Class Initialized
DEBUG - 2012-01-11 01:13:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:13:39 --> Final output sent to browser
DEBUG - 2012-01-11 01:13:39 --> Total execution time: 0.3830
DEBUG - 2012-01-11 01:13:40 --> Config Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:13:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:13:40 --> URI Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Router Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Output Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Security Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Input Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:13:40 --> Language Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Loader Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:13:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Session Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:13:40 --> Session routines successfully run
DEBUG - 2012-01-11 01:13:40 --> Controller Class Initialized
DEBUG - 2012-01-11 01:13:40 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:13:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:13:40 --> Final output sent to browser
DEBUG - 2012-01-11 01:13:40 --> Total execution time: 0.4488
DEBUG - 2012-01-11 01:13:41 --> Config Class Initialized
DEBUG - 2012-01-11 01:13:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:13:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:13:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:13:42 --> URI Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Router Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Output Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Security Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Input Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:13:42 --> Language Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Loader Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:13:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Session Class Initialized
DEBUG - 2012-01-11 01:13:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:13:42 --> Session routines successfully run
DEBUG - 2012-01-11 01:13:42 --> Controller Class Initialized
DEBUG - 2012-01-11 01:13:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:13:42 --> Final output sent to browser
DEBUG - 2012-01-11 01:13:42 --> Total execution time: 0.3474
DEBUG - 2012-01-11 01:13:43 --> Config Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:13:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:13:43 --> URI Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Router Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Output Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Security Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Input Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:13:43 --> Language Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Loader Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:13:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Session Class Initialized
DEBUG - 2012-01-11 01:13:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:13:43 --> Session routines successfully run
DEBUG - 2012-01-11 01:13:43 --> Controller Class Initialized
DEBUG - 2012-01-11 01:13:43 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:13:43 --> Final output sent to browser
DEBUG - 2012-01-11 01:13:43 --> Total execution time: 0.3790
DEBUG - 2012-01-11 01:13:45 --> Config Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:13:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:13:45 --> URI Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Router Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Output Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Security Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Input Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:13:45 --> Language Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Loader Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:13:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Session Class Initialized
DEBUG - 2012-01-11 01:13:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:13:45 --> Session routines successfully run
DEBUG - 2012-01-11 01:13:45 --> Controller Class Initialized
DEBUG - 2012-01-11 01:13:45 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:13:45 --> Final output sent to browser
DEBUG - 2012-01-11 01:13:45 --> Total execution time: 0.4291
DEBUG - 2012-01-11 01:16:07 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:07 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Router Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Output Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Security Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Input Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:16:07 --> Language Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Loader Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:16:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Session Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:16:07 --> Session routines successfully run
DEBUG - 2012-01-11 01:16:07 --> Controller Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:16:07 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:16:07 --> Final output sent to browser
DEBUG - 2012-01-11 01:16:07 --> Total execution time: 0.1852
DEBUG - 2012-01-11 01:16:07 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:07 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:07 --> Router Class Initialized
ERROR - 2012-01-11 01:16:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:16:08 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:08 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Router Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Output Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Security Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Input Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:16:08 --> Language Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Loader Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:16:08 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Session Class Initialized
DEBUG - 2012-01-11 01:16:08 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:16:09 --> Session routines successfully run
DEBUG - 2012-01-11 01:16:09 --> Controller Class Initialized
DEBUG - 2012-01-11 01:16:09 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:16:09 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:16:09 --> Final output sent to browser
DEBUG - 2012-01-11 01:16:09 --> Total execution time: 0.1796
DEBUG - 2012-01-11 01:16:09 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:09 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:09 --> Router Class Initialized
ERROR - 2012-01-11 01:16:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:16:10 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:10 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Router Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Output Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Security Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Input Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:16:10 --> Language Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Loader Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:16:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Session Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:16:10 --> Session routines successfully run
DEBUG - 2012-01-11 01:16:10 --> Controller Class Initialized
DEBUG - 2012-01-11 01:16:10 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:16:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:16:10 --> Final output sent to browser
DEBUG - 2012-01-11 01:16:10 --> Total execution time: 0.1836
DEBUG - 2012-01-11 01:16:11 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:11 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:11 --> Router Class Initialized
ERROR - 2012-01-11 01:16:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:16:12 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:12 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Router Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Output Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Security Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Input Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:16:12 --> Language Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Loader Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:16:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Session Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:16:12 --> Session routines successfully run
DEBUG - 2012-01-11 01:16:12 --> Controller Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:16:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:16:12 --> Final output sent to browser
DEBUG - 2012-01-11 01:16:12 --> Total execution time: 0.1679
DEBUG - 2012-01-11 01:16:12 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:12 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:12 --> Router Class Initialized
ERROR - 2012-01-11 01:16:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:16:14 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:14 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Router Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Output Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Security Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Input Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:16:14 --> Language Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Loader Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:16:14 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Session Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:16:14 --> Session routines successfully run
DEBUG - 2012-01-11 01:16:14 --> Controller Class Initialized
DEBUG - 2012-01-11 01:16:14 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:16:14 --> Final output sent to browser
DEBUG - 2012-01-11 01:16:14 --> Total execution time: 0.1320
DEBUG - 2012-01-11 01:16:14 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:14 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:14 --> Router Class Initialized
ERROR - 2012-01-11 01:16:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:16:19 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:19 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Router Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Output Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Security Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Input Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:16:19 --> Language Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Loader Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:16:19 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Session Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:16:19 --> Session routines successfully run
DEBUG - 2012-01-11 01:16:19 --> Controller Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:16:19 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:16:19 --> Final output sent to browser
DEBUG - 2012-01-11 01:16:19 --> Total execution time: 0.1802
DEBUG - 2012-01-11 01:16:19 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:19 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:19 --> Router Class Initialized
ERROR - 2012-01-11 01:16:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:16:39 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:39 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Router Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Output Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Security Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Input Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:16:39 --> Language Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Loader Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:16:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Session Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:16:39 --> Session routines successfully run
DEBUG - 2012-01-11 01:16:39 --> Controller Class Initialized
DEBUG - 2012-01-11 01:16:39 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:16:39 --> Final output sent to browser
DEBUG - 2012-01-11 01:16:39 --> Total execution time: 0.1341
DEBUG - 2012-01-11 01:16:39 --> Config Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:16:39 --> URI Class Initialized
DEBUG - 2012-01-11 01:16:39 --> Router Class Initialized
ERROR - 2012-01-11 01:16:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:02 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:02 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:02 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:02 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:02 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:02 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:02 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 01:17:02 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:02 --> Total execution time: 0.1368
DEBUG - 2012-01-11 01:17:02 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:02 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:02 --> Router Class Initialized
ERROR - 2012-01-11 01:17:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:06 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:06 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:06 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:06 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:06 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:07 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:07 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:07 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:17:07 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:07 --> Total execution time: 0.1489
DEBUG - 2012-01-11 01:17:07 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:07 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:07 --> Router Class Initialized
ERROR - 2012-01-11 01:17:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:12 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:12 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:12 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:12 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:12 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:17:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:17:12 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:12 --> Total execution time: 0.1845
DEBUG - 2012-01-11 01:17:12 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:12 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:12 --> Router Class Initialized
ERROR - 2012-01-11 01:17:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:16 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:17 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:17 --> No URI present. Default controller set.
DEBUG - 2012-01-11 01:17:17 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:17 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:17 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:17 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:17 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:17:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:17:17 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:17 --> Total execution time: 0.1375
DEBUG - 2012-01-11 01:17:17 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:17 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:17 --> Router Class Initialized
ERROR - 2012-01-11 01:17:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:18 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:18 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:18 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:18 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:18 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:18 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:17:18 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:18 --> Total execution time: 0.1546
DEBUG - 2012-01-11 01:17:18 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:18 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:18 --> Router Class Initialized
ERROR - 2012-01-11 01:17:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:21 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:21 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:21 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:21 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:21 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:21 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:21 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:17:21 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:22 --> Total execution time: 0.1417
DEBUG - 2012-01-11 01:17:22 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:22 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Router Class Initialized
ERROR - 2012-01-11 01:17:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:22 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:22 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:22 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:22 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:22 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:22 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:22 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:22 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:17:22 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:22 --> Total execution time: 0.1332
DEBUG - 2012-01-11 01:17:23 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:23 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Router Class Initialized
ERROR - 2012-01-11 01:17:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:23 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:23 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:23 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:23 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:23 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:23 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:23 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:17:23 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:23 --> Total execution time: 0.1466
DEBUG - 2012-01-11 01:17:24 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:24 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:24 --> Router Class Initialized
ERROR - 2012-01-11 01:17:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:26 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:26 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:26 --> No URI present. Default controller set.
DEBUG - 2012-01-11 01:17:26 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:26 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:26 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:26 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:26 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:17:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:17:26 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:26 --> Total execution time: 0.1607
DEBUG - 2012-01-11 01:17:27 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:27 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Router Class Initialized
ERROR - 2012-01-11 01:17:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:27 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:27 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:27 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:27 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:27 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:27 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:27 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:17:27 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:27 --> Total execution time: 0.1346
DEBUG - 2012-01-11 01:17:28 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:28 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:28 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:28 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:28 --> Router Class Initialized
ERROR - 2012-01-11 01:17:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:31 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:31 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:31 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:31 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:31 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:31 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:17:31 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:31 --> Total execution time: 0.1314
DEBUG - 2012-01-11 01:17:31 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:31 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:31 --> Router Class Initialized
ERROR - 2012-01-11 01:17:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:32 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:32 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:32 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:32 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:32 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:17:32 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:32 --> Total execution time: 0.1523
DEBUG - 2012-01-11 01:17:32 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:32 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:32 --> Router Class Initialized
ERROR - 2012-01-11 01:17:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:17:55 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:55 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:55 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:55 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:55 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:55 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Router Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Output Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Security Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Input Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:17:55 --> Language Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Loader Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:17:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Session Class Initialized
DEBUG - 2012-01-11 01:17:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:17:55 --> Session routines successfully run
DEBUG - 2012-01-11 01:17:55 --> Controller Class Initialized
DEBUG - 2012-01-11 01:17:55 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:17:55 --> Final output sent to browser
DEBUG - 2012-01-11 01:17:55 --> Total execution time: 0.1395
DEBUG - 2012-01-11 01:17:56 --> Config Class Initialized
DEBUG - 2012-01-11 01:17:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:17:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:17:56 --> URI Class Initialized
DEBUG - 2012-01-11 01:17:56 --> Router Class Initialized
ERROR - 2012-01-11 01:17:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:18:08 --> Config Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:18:08 --> URI Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Router Class Initialized
DEBUG - 2012-01-11 01:18:08 --> No URI present. Default controller set.
DEBUG - 2012-01-11 01:18:08 --> Output Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Security Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Input Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:18:08 --> Language Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Loader Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:18:08 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Session Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:18:08 --> Session routines successfully run
DEBUG - 2012-01-11 01:18:08 --> Controller Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:18:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:18:08 --> Final output sent to browser
DEBUG - 2012-01-11 01:18:08 --> Total execution time: 0.2395
DEBUG - 2012-01-11 01:18:08 --> Config Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:18:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:18:08 --> URI Class Initialized
DEBUG - 2012-01-11 01:18:08 --> Router Class Initialized
ERROR - 2012-01-11 01:18:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:20:56 --> Config Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:20:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:20:56 --> URI Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Router Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Output Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Security Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Input Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:20:56 --> Language Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Loader Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:20:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Session Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:20:56 --> Session routines successfully run
DEBUG - 2012-01-11 01:20:56 --> Controller Class Initialized
DEBUG - 2012-01-11 01:20:56 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:20:56 --> Final output sent to browser
DEBUG - 2012-01-11 01:20:56 --> Total execution time: 0.1451
DEBUG - 2012-01-11 01:20:56 --> Config Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:20:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:20:56 --> URI Class Initialized
DEBUG - 2012-01-11 01:20:56 --> Router Class Initialized
ERROR - 2012-01-11 01:20:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:20:58 --> Config Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:20:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:20:58 --> URI Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Router Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Output Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Security Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Input Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:20:58 --> Language Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Loader Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:20:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Session Class Initialized
DEBUG - 2012-01-11 01:20:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:20:58 --> Session routines successfully run
DEBUG - 2012-01-11 01:20:58 --> Controller Class Initialized
DEBUG - 2012-01-11 01:20:58 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 01:20:58 --> Final output sent to browser
DEBUG - 2012-01-11 01:20:58 --> Total execution time: 0.1625
DEBUG - 2012-01-11 01:20:59 --> Config Class Initialized
DEBUG - 2012-01-11 01:20:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:20:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:20:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:20:59 --> URI Class Initialized
DEBUG - 2012-01-11 01:20:59 --> Router Class Initialized
ERROR - 2012-01-11 01:20:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:21:00 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:00 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Router Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Output Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Security Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Input Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:21:00 --> Language Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Loader Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:21:00 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Session Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:21:00 --> Session routines successfully run
DEBUG - 2012-01-11 01:21:00 --> Controller Class Initialized
DEBUG - 2012-01-11 01:21:00 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 01:21:00 --> Final output sent to browser
DEBUG - 2012-01-11 01:21:00 --> Total execution time: 0.1421
DEBUG - 2012-01-11 01:21:00 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:00 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:00 --> Router Class Initialized
ERROR - 2012-01-11 01:21:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:21:01 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:01 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Router Class Initialized
DEBUG - 2012-01-11 01:21:01 --> No URI present. Default controller set.
DEBUG - 2012-01-11 01:21:01 --> Output Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Security Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Input Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:21:01 --> Language Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Loader Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:21:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Session Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:21:01 --> Session routines successfully run
DEBUG - 2012-01-11 01:21:01 --> Controller Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:21:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:21:01 --> Final output sent to browser
DEBUG - 2012-01-11 01:21:01 --> Total execution time: 0.1636
DEBUG - 2012-01-11 01:21:01 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:01 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:01 --> Router Class Initialized
ERROR - 2012-01-11 01:21:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:21:03 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:03 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Router Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Output Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Security Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Input Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:21:03 --> Language Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Loader Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:21:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Session Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:21:03 --> Session routines successfully run
DEBUG - 2012-01-11 01:21:03 --> Controller Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:21:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:21:03 --> Final output sent to browser
DEBUG - 2012-01-11 01:21:03 --> Total execution time: 0.1664
DEBUG - 2012-01-11 01:21:03 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:03 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:03 --> Router Class Initialized
ERROR - 2012-01-11 01:21:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:21:04 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:04 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Router Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Output Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Security Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Input Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:21:04 --> Language Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Loader Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:21:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Session Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:21:04 --> Session routines successfully run
DEBUG - 2012-01-11 01:21:04 --> Controller Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:21:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 01:21:04 --> Final output sent to browser
DEBUG - 2012-01-11 01:21:04 --> Total execution time: 0.1660
DEBUG - 2012-01-11 01:21:04 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:04 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:04 --> Router Class Initialized
ERROR - 2012-01-11 01:21:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:21:11 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:11 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Router Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Output Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Security Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Input Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:21:11 --> Language Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Loader Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:21:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Session Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:21:11 --> Session routines successfully run
DEBUG - 2012-01-11 01:21:11 --> Controller Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Pagination Class Initialized
DEBUG - 2012-01-11 01:21:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 01:21:11 --> Final output sent to browser
DEBUG - 2012-01-11 01:21:11 --> Total execution time: 0.1376
DEBUG - 2012-01-11 01:21:11 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:11 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:11 --> Router Class Initialized
ERROR - 2012-01-11 01:21:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 01:21:14 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:14 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Router Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Output Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Security Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Input Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 01:21:14 --> Language Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Loader Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Helper loaded: url_helper
DEBUG - 2012-01-11 01:21:14 --> Database Driver Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Session Class Initialized
DEBUG - 2012-01-11 01:21:14 --> Helper loaded: string_helper
DEBUG - 2012-01-11 01:21:14 --> Session routines successfully run
DEBUG - 2012-01-11 01:21:14 --> Controller Class Initialized
DEBUG - 2012-01-11 01:21:14 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 01:21:14 --> Final output sent to browser
DEBUG - 2012-01-11 01:21:14 --> Total execution time: 0.1520
DEBUG - 2012-01-11 01:21:15 --> Config Class Initialized
DEBUG - 2012-01-11 01:21:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 01:21:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 01:21:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 01:21:15 --> URI Class Initialized
DEBUG - 2012-01-11 01:21:15 --> Router Class Initialized
ERROR - 2012-01-11 01:21:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 21:54:40 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:41 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Router Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Output Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Security Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Input Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 21:54:41 --> Language Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Loader Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 21:54:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Session Class Initialized
DEBUG - 2012-01-11 21:54:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 21:54:41 --> A session cookie was not found.
DEBUG - 2012-01-11 21:54:41 --> Session routines successfully run
DEBUG - 2012-01-11 21:54:41 --> Controller Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:42 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Router Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Output Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Security Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Input Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 21:54:42 --> Language Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Loader Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 21:54:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Session Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 21:54:42 --> Session routines successfully run
DEBUG - 2012-01-11 21:54:42 --> Controller Class Initialized
DEBUG - 2012-01-11 21:54:42 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-11 21:54:42 --> Final output sent to browser
DEBUG - 2012-01-11 21:54:42 --> Total execution time: 0.1500
DEBUG - 2012-01-11 21:54:42 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:42 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:42 --> Router Class Initialized
ERROR - 2012-01-11 21:54:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 21:54:44 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:44 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Router Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Output Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Security Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Input Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 21:54:44 --> Language Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Loader Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Helper loaded: url_helper
DEBUG - 2012-01-11 21:54:44 --> Database Driver Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Session Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Helper loaded: string_helper
DEBUG - 2012-01-11 21:54:44 --> Session routines successfully run
DEBUG - 2012-01-11 21:54:44 --> Controller Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:44 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Router Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Output Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Security Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Input Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 21:54:44 --> Language Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Loader Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Helper loaded: url_helper
DEBUG - 2012-01-11 21:54:44 --> Database Driver Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Session Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Helper loaded: string_helper
DEBUG - 2012-01-11 21:54:44 --> Session routines successfully run
DEBUG - 2012-01-11 21:54:44 --> Controller Class Initialized
DEBUG - 2012-01-11 21:54:44 --> Pagination Class Initialized
DEBUG - 2012-01-11 21:54:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 21:54:45 --> Final output sent to browser
DEBUG - 2012-01-11 21:54:45 --> Total execution time: 0.3253
DEBUG - 2012-01-11 21:54:45 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:45 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:45 --> Router Class Initialized
ERROR - 2012-01-11 21:54:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 21:54:54 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:54 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Router Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Output Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Security Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Input Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 21:54:54 --> Language Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Loader Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 21:54:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 21:54:54 --> Session Class Initialized
DEBUG - 2012-01-11 21:54:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 21:54:55 --> Session routines successfully run
DEBUG - 2012-01-11 21:54:55 --> Controller Class Initialized
DEBUG - 2012-01-11 21:54:55 --> Pagination Class Initialized
DEBUG - 2012-01-11 21:54:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 21:54:55 --> Final output sent to browser
DEBUG - 2012-01-11 21:54:55 --> Total execution time: 0.2506
DEBUG - 2012-01-11 21:54:55 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:55 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:55 --> Router Class Initialized
ERROR - 2012-01-11 21:54:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 21:54:56 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:56 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Router Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Output Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Security Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Input Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 21:54:56 --> Language Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Loader Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 21:54:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Session Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 21:54:56 --> Session routines successfully run
DEBUG - 2012-01-11 21:54:56 --> Controller Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Pagination Class Initialized
DEBUG - 2012-01-11 21:54:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 21:54:56 --> Final output sent to browser
DEBUG - 2012-01-11 21:54:56 --> Total execution time: 0.2523
DEBUG - 2012-01-11 21:54:56 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:56 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:56 --> Router Class Initialized
ERROR - 2012-01-11 21:54:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 21:54:57 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:57 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Router Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Output Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Security Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Input Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 21:54:57 --> Language Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Loader Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 21:54:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Session Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 21:54:57 --> Session routines successfully run
DEBUG - 2012-01-11 21:54:57 --> Controller Class Initialized
DEBUG - 2012-01-11 21:54:57 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 21:54:57 --> Final output sent to browser
DEBUG - 2012-01-11 21:54:57 --> Total execution time: 0.2382
DEBUG - 2012-01-11 21:54:57 --> Config Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 21:54:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 21:54:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 21:54:58 --> URI Class Initialized
DEBUG - 2012-01-11 21:54:58 --> Router Class Initialized
ERROR - 2012-01-11 21:54:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:01:45 --> Config Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:01:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:01:45 --> URI Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Router Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Output Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Security Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Input Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:01:45 --> Language Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Loader Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:01:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Session Class Initialized
DEBUG - 2012-01-11 22:01:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:01:45 --> Session routines successfully run
DEBUG - 2012-01-11 22:01:45 --> Controller Class Initialized
DEBUG - 2012-01-11 22:01:45 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:01:45 --> Final output sent to browser
DEBUG - 2012-01-11 22:01:45 --> Total execution time: 0.3627
DEBUG - 2012-01-11 22:01:46 --> Config Class Initialized
DEBUG - 2012-01-11 22:01:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:01:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:01:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:01:46 --> URI Class Initialized
DEBUG - 2012-01-11 22:01:46 --> Router Class Initialized
ERROR - 2012-01-11 22:01:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:06:37 --> Config Class Initialized
DEBUG - 2012-01-11 22:06:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:06:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:06:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:06:37 --> URI Class Initialized
DEBUG - 2012-01-11 22:06:37 --> Router Class Initialized
DEBUG - 2012-01-11 22:06:37 --> Output Class Initialized
DEBUG - 2012-01-11 22:06:37 --> Security Class Initialized
DEBUG - 2012-01-11 22:06:37 --> Input Class Initialized
DEBUG - 2012-01-11 22:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:06:38 --> Language Class Initialized
DEBUG - 2012-01-11 22:06:38 --> Loader Class Initialized
DEBUG - 2012-01-11 22:06:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:06:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:06:38 --> Session Class Initialized
DEBUG - 2012-01-11 22:06:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:06:38 --> Session routines successfully run
DEBUG - 2012-01-11 22:06:38 --> Controller Class Initialized
DEBUG - 2012-01-11 22:06:38 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:06:38 --> Final output sent to browser
DEBUG - 2012-01-11 22:06:38 --> Total execution time: 0.3501
DEBUG - 2012-01-11 22:06:38 --> Config Class Initialized
DEBUG - 2012-01-11 22:06:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:06:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:06:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:06:38 --> URI Class Initialized
DEBUG - 2012-01-11 22:06:38 --> Router Class Initialized
ERROR - 2012-01-11 22:06:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:06:43 --> Config Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:06:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:06:43 --> URI Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Router Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Output Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Security Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Input Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:06:43 --> Language Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Loader Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:06:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Session Class Initialized
DEBUG - 2012-01-11 22:06:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:06:43 --> Session routines successfully run
DEBUG - 2012-01-11 22:06:43 --> Controller Class Initialized
ERROR - 2012-01-11 22:06:43 --> 404 Page Not Found --> comments/5
DEBUG - 2012-01-11 22:06:44 --> Config Class Initialized
DEBUG - 2012-01-11 22:06:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:06:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:06:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:06:44 --> URI Class Initialized
DEBUG - 2012-01-11 22:06:44 --> Router Class Initialized
ERROR - 2012-01-11 22:06:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:07:35 --> Config Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:07:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:07:35 --> URI Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Router Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Output Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Security Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Input Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:07:35 --> Language Class Initialized
DEBUG - 2012-01-11 22:07:35 --> Loader Class Initialized
DEBUG - 2012-01-11 22:07:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:07:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:07:36 --> Session Class Initialized
DEBUG - 2012-01-11 22:07:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:07:36 --> Session routines successfully run
DEBUG - 2012-01-11 22:07:36 --> Controller Class Initialized
DEBUG - 2012-01-11 22:07:36 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:07:36 --> Final output sent to browser
DEBUG - 2012-01-11 22:07:36 --> Total execution time: 0.3297
DEBUG - 2012-01-11 22:07:36 --> Config Class Initialized
DEBUG - 2012-01-11 22:07:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:07:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:07:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:07:36 --> URI Class Initialized
DEBUG - 2012-01-11 22:07:36 --> Router Class Initialized
ERROR - 2012-01-11 22:07:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:08:32 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:32 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Router Class Initialized
ERROR - 2012-01-11 22:08:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:08:32 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:32 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Router Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Output Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Security Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Input Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:08:32 --> Language Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Loader Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:08:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Session Class Initialized
DEBUG - 2012-01-11 22:08:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:08:32 --> Session routines successfully run
DEBUG - 2012-01-11 22:08:32 --> Controller Class Initialized
DEBUG - 2012-01-11 22:08:32 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:08:32 --> Final output sent to browser
DEBUG - 2012-01-11 22:08:32 --> Total execution time: 0.3599
DEBUG - 2012-01-11 22:08:33 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:33 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:33 --> Router Class Initialized
ERROR - 2012-01-11 22:08:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:08:35 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:36 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Router Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Output Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Security Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Input Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:08:36 --> Language Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Loader Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:08:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Session Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:08:36 --> Session routines successfully run
DEBUG - 2012-01-11 22:08:36 --> Controller Class Initialized
DEBUG - 2012-01-11 22:08:36 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:08:36 --> Final output sent to browser
DEBUG - 2012-01-11 22:08:36 --> Total execution time: 0.3451
DEBUG - 2012-01-11 22:08:36 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:36 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:36 --> Router Class Initialized
ERROR - 2012-01-11 22:08:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:08:43 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:43 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Router Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Output Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Security Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Input Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:08:43 --> Language Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Loader Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:08:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Session Class Initialized
DEBUG - 2012-01-11 22:08:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:08:43 --> Session routines successfully run
DEBUG - 2012-01-11 22:08:43 --> Controller Class Initialized
DEBUG - 2012-01-11 22:08:43 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 22:08:43 --> Final output sent to browser
DEBUG - 2012-01-11 22:08:43 --> Total execution time: 0.3602
DEBUG - 2012-01-11 22:08:43 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:44 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:44 --> Router Class Initialized
ERROR - 2012-01-11 22:08:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:08:45 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:45 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Router Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Output Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Security Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Input Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:08:45 --> Language Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Loader Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:08:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Session Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:08:45 --> Session routines successfully run
DEBUG - 2012-01-11 22:08:45 --> Controller Class Initialized
DEBUG - 2012-01-11 22:08:45 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:08:45 --> Final output sent to browser
DEBUG - 2012-01-11 22:08:45 --> Total execution time: 0.3522
DEBUG - 2012-01-11 22:08:45 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:45 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:45 --> Router Class Initialized
ERROR - 2012-01-11 22:08:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:08:46 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:46 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:46 --> Router Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Output Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Security Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Input Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:08:47 --> Language Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Loader Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:08:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Session Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:08:47 --> Session routines successfully run
DEBUG - 2012-01-11 22:08:47 --> Controller Class Initialized
DEBUG - 2012-01-11 22:08:47 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:08:47 --> Final output sent to browser
DEBUG - 2012-01-11 22:08:47 --> Total execution time: 0.3395
DEBUG - 2012-01-11 22:08:47 --> Config Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:08:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:08:47 --> URI Class Initialized
DEBUG - 2012-01-11 22:08:47 --> Router Class Initialized
ERROR - 2012-01-11 22:08:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:11:32 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:32 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Router Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Output Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Security Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Input Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:11:32 --> Language Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Loader Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:11:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Session Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:11:32 --> Session routines successfully run
DEBUG - 2012-01-11 22:11:32 --> Controller Class Initialized
DEBUG - 2012-01-11 22:11:32 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:11:32 --> Final output sent to browser
DEBUG - 2012-01-11 22:11:32 --> Total execution time: 0.3524
DEBUG - 2012-01-11 22:11:32 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:33 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:33 --> Router Class Initialized
ERROR - 2012-01-11 22:11:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:11:50 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:50 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Router Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Output Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Security Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Input Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:11:50 --> Language Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Loader Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:11:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Session Class Initialized
DEBUG - 2012-01-11 22:11:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:11:50 --> Session routines successfully run
DEBUG - 2012-01-11 22:11:51 --> Controller Class Initialized
DEBUG - 2012-01-11 22:11:51 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:11:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:11:51 --> Final output sent to browser
DEBUG - 2012-01-11 22:11:51 --> Total execution time: 0.4066
DEBUG - 2012-01-11 22:11:51 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:51 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:51 --> Router Class Initialized
ERROR - 2012-01-11 22:11:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:11:52 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:52 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Router Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Output Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Security Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Input Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:11:52 --> Language Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Loader Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:11:52 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Session Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:11:52 --> Session routines successfully run
DEBUG - 2012-01-11 22:11:52 --> Controller Class Initialized
DEBUG - 2012-01-11 22:11:52 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:11:52 --> Final output sent to browser
DEBUG - 2012-01-11 22:11:52 --> Total execution time: 0.3975
DEBUG - 2012-01-11 22:11:52 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:53 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:53 --> Router Class Initialized
ERROR - 2012-01-11 22:11:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:11:56 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:57 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Router Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Output Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Security Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Input Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:11:57 --> Language Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Loader Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:11:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Session Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:11:57 --> Session routines successfully run
DEBUG - 2012-01-11 22:11:57 --> Controller Class Initialized
DEBUG - 2012-01-11 22:11:57 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:11:57 --> Final output sent to browser
DEBUG - 2012-01-11 22:11:57 --> Total execution time: 0.5402
DEBUG - 2012-01-11 22:11:57 --> Config Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:11:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:11:57 --> URI Class Initialized
DEBUG - 2012-01-11 22:11:57 --> Router Class Initialized
ERROR - 2012-01-11 22:11:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:15:21 --> Config Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:15:21 --> URI Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Router Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Output Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Security Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Input Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:15:21 --> Language Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Loader Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:15:21 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Session Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:15:21 --> Session routines successfully run
DEBUG - 2012-01-11 22:15:21 --> Controller Class Initialized
DEBUG - 2012-01-11 22:15:21 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:15:21 --> Final output sent to browser
DEBUG - 2012-01-11 22:15:21 --> Total execution time: 0.3659
DEBUG - 2012-01-11 22:15:21 --> Config Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:15:21 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:15:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:15:22 --> URI Class Initialized
DEBUG - 2012-01-11 22:15:22 --> Router Class Initialized
ERROR - 2012-01-11 22:15:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:15:46 --> Config Class Initialized
DEBUG - 2012-01-11 22:15:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:15:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:15:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:15:46 --> URI Class Initialized
DEBUG - 2012-01-11 22:15:46 --> Router Class Initialized
DEBUG - 2012-01-11 22:15:46 --> Output Class Initialized
DEBUG - 2012-01-11 22:15:46 --> Security Class Initialized
DEBUG - 2012-01-11 22:15:46 --> Input Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:15:47 --> Language Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Loader Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:15:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Session Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:15:47 --> Session routines successfully run
DEBUG - 2012-01-11 22:15:47 --> Controller Class Initialized
DEBUG - 2012-01-11 22:15:47 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:15:47 --> Final output sent to browser
DEBUG - 2012-01-11 22:15:47 --> Total execution time: 0.3514
DEBUG - 2012-01-11 22:15:47 --> Config Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:15:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:15:47 --> URI Class Initialized
DEBUG - 2012-01-11 22:15:47 --> Router Class Initialized
ERROR - 2012-01-11 22:15:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:16:24 --> Config Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:16:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:16:24 --> URI Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Router Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Output Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Security Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Input Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:16:24 --> Language Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Loader Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:16:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Session Class Initialized
DEBUG - 2012-01-11 22:16:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:16:24 --> Session routines successfully run
DEBUG - 2012-01-11 22:16:24 --> Controller Class Initialized
DEBUG - 2012-01-11 22:16:24 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:16:24 --> Final output sent to browser
DEBUG - 2012-01-11 22:16:24 --> Total execution time: 0.3587
DEBUG - 2012-01-11 22:16:25 --> Config Class Initialized
DEBUG - 2012-01-11 22:16:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:16:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:16:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:16:25 --> URI Class Initialized
DEBUG - 2012-01-11 22:16:25 --> Router Class Initialized
ERROR - 2012-01-11 22:16:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:17:11 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:11 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Router Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Output Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Security Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Input Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:17:11 --> Language Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Loader Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:17:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Session Class Initialized
DEBUG - 2012-01-11 22:17:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:17:11 --> Session routines successfully run
DEBUG - 2012-01-11 22:17:11 --> Controller Class Initialized
DEBUG - 2012-01-11 22:17:11 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:17:11 --> Final output sent to browser
DEBUG - 2012-01-11 22:17:12 --> Total execution time: 0.3714
DEBUG - 2012-01-11 22:17:12 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:12 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:12 --> Router Class Initialized
ERROR - 2012-01-11 22:17:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:17:21 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:21 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Router Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Output Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Security Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Input Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:17:21 --> Language Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Loader Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:17:21 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Session Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:17:21 --> Session routines successfully run
DEBUG - 2012-01-11 22:17:21 --> Controller Class Initialized
DEBUG - 2012-01-11 22:17:21 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:17:21 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:17:21 --> Final output sent to browser
DEBUG - 2012-01-11 22:17:22 --> Total execution time: 0.4161
DEBUG - 2012-01-11 22:17:22 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:22 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:22 --> Router Class Initialized
ERROR - 2012-01-11 22:17:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:17:23 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:23 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Router Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Output Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Security Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Input Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:17:23 --> Language Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Loader Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:17:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Session Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:17:23 --> Session routines successfully run
DEBUG - 2012-01-11 22:17:23 --> Controller Class Initialized
DEBUG - 2012-01-11 22:17:23 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:17:23 --> Final output sent to browser
DEBUG - 2012-01-11 22:17:23 --> Total execution time: 0.3936
DEBUG - 2012-01-11 22:17:23 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:23 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:24 --> Router Class Initialized
ERROR - 2012-01-11 22:17:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:17:25 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:25 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Router Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Output Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Security Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Input Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:17:25 --> Language Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Loader Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:17:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Session Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:17:25 --> Session routines successfully run
DEBUG - 2012-01-11 22:17:25 --> Controller Class Initialized
DEBUG - 2012-01-11 22:17:25 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:17:25 --> Final output sent to browser
DEBUG - 2012-01-11 22:17:25 --> Total execution time: 0.3963
DEBUG - 2012-01-11 22:17:25 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:26 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:26 --> Router Class Initialized
ERROR - 2012-01-11 22:17:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:17:31 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:31 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Router Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Output Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Security Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Input Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:17:31 --> Language Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Loader Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:17:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Session Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:17:31 --> Session routines successfully run
DEBUG - 2012-01-11 22:17:31 --> Controller Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:17:31 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:17:31 --> Final output sent to browser
DEBUG - 2012-01-11 22:17:31 --> Total execution time: 0.3924
DEBUG - 2012-01-11 22:17:31 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:31 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:31 --> Router Class Initialized
ERROR - 2012-01-11 22:17:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:17:34 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:34 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Router Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Output Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Security Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Input Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:17:34 --> Language Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Loader Class Initialized
DEBUG - 2012-01-11 22:17:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:17:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:17:35 --> Session Class Initialized
DEBUG - 2012-01-11 22:17:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:17:35 --> Session routines successfully run
DEBUG - 2012-01-11 22:17:35 --> Controller Class Initialized
DEBUG - 2012-01-11 22:17:35 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:17:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:17:35 --> Final output sent to browser
DEBUG - 2012-01-11 22:17:35 --> Total execution time: 0.4534
DEBUG - 2012-01-11 22:17:35 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:35 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:35 --> Router Class Initialized
ERROR - 2012-01-11 22:17:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:17:36 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:36 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:36 --> Router Class Initialized
DEBUG - 2012-01-11 22:17:36 --> Output Class Initialized
DEBUG - 2012-01-11 22:17:36 --> Security Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Input Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:17:37 --> Language Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Loader Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:17:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Session Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:17:37 --> Session routines successfully run
DEBUG - 2012-01-11 22:17:37 --> Controller Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:17:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:17:37 --> Final output sent to browser
DEBUG - 2012-01-11 22:17:37 --> Total execution time: 0.7332
DEBUG - 2012-01-11 22:17:37 --> Config Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:17:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:17:37 --> URI Class Initialized
DEBUG - 2012-01-11 22:17:37 --> Router Class Initialized
ERROR - 2012-01-11 22:17:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:28:22 --> Config Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:28:22 --> URI Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Router Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Output Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Security Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Input Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:28:22 --> Language Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Loader Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:28:22 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Session Class Initialized
DEBUG - 2012-01-11 22:28:22 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:28:22 --> Session routines successfully run
DEBUG - 2012-01-11 22:28:22 --> Controller Class Initialized
DEBUG - 2012-01-11 22:28:22 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:28:22 --> Final output sent to browser
DEBUG - 2012-01-11 22:28:22 --> Total execution time: 0.4118
DEBUG - 2012-01-11 22:28:23 --> Config Class Initialized
DEBUG - 2012-01-11 22:28:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:28:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:28:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:28:23 --> URI Class Initialized
DEBUG - 2012-01-11 22:28:23 --> Router Class Initialized
ERROR - 2012-01-11 22:28:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:28:24 --> Config Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:28:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:28:24 --> URI Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Router Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Output Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Security Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Input Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:28:24 --> Language Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Loader Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:28:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Session Class Initialized
DEBUG - 2012-01-11 22:28:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:28:24 --> Session routines successfully run
DEBUG - 2012-01-11 22:28:24 --> Controller Class Initialized
DEBUG - 2012-01-11 22:28:25 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:28:25 --> Final output sent to browser
DEBUG - 2012-01-11 22:28:25 --> Total execution time: 0.4228
DEBUG - 2012-01-11 22:28:25 --> Config Class Initialized
DEBUG - 2012-01-11 22:28:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:28:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:28:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:28:25 --> URI Class Initialized
DEBUG - 2012-01-11 22:28:25 --> Router Class Initialized
ERROR - 2012-01-11 22:28:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:30:12 --> Config Class Initialized
DEBUG - 2012-01-11 22:30:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:30:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:30:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:30:12 --> URI Class Initialized
DEBUG - 2012-01-11 22:30:12 --> Router Class Initialized
DEBUG - 2012-01-11 22:30:12 --> Output Class Initialized
DEBUG - 2012-01-11 22:30:12 --> Security Class Initialized
DEBUG - 2012-01-11 22:30:12 --> Input Class Initialized
DEBUG - 2012-01-11 22:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:30:12 --> Language Class Initialized
DEBUG - 2012-01-11 22:30:13 --> Loader Class Initialized
DEBUG - 2012-01-11 22:30:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:30:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:30:13 --> Session Class Initialized
DEBUG - 2012-01-11 22:30:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:30:13 --> Session routines successfully run
DEBUG - 2012-01-11 22:30:13 --> Controller Class Initialized
DEBUG - 2012-01-11 22:30:13 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:30:13 --> Final output sent to browser
DEBUG - 2012-01-11 22:30:13 --> Total execution time: 0.3589
DEBUG - 2012-01-11 22:30:13 --> Config Class Initialized
DEBUG - 2012-01-11 22:30:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:30:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:30:13 --> URI Class Initialized
DEBUG - 2012-01-11 22:30:13 --> Router Class Initialized
ERROR - 2012-01-11 22:30:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:31:33 --> Config Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:31:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:31:33 --> URI Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Router Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Output Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Security Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Input Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:31:33 --> Language Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Loader Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:31:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Session Class Initialized
DEBUG - 2012-01-11 22:31:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:31:33 --> Session routines successfully run
DEBUG - 2012-01-11 22:31:34 --> Controller Class Initialized
ERROR - 2012-01-11 22:31:34 --> Severity: Notice  --> Undefined property: stdClass::$id_article A:\home\codeigniter.blog\www\application\views\admin\comments.php 11
DEBUG - 2012-01-11 22:31:34 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:31:34 --> Final output sent to browser
DEBUG - 2012-01-11 22:31:34 --> Total execution time: 0.3727
DEBUG - 2012-01-11 22:31:34 --> Config Class Initialized
DEBUG - 2012-01-11 22:31:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:31:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:31:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:31:34 --> URI Class Initialized
DEBUG - 2012-01-11 22:31:34 --> Router Class Initialized
ERROR - 2012-01-11 22:31:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:33:46 --> Config Class Initialized
DEBUG - 2012-01-11 22:33:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:33:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:33:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:33:46 --> URI Class Initialized
DEBUG - 2012-01-11 22:33:46 --> Router Class Initialized
DEBUG - 2012-01-11 22:33:46 --> Output Class Initialized
DEBUG - 2012-01-11 22:33:46 --> Security Class Initialized
DEBUG - 2012-01-11 22:33:46 --> Input Class Initialized
DEBUG - 2012-01-11 22:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:33:46 --> Language Class Initialized
DEBUG - 2012-01-11 22:33:47 --> Loader Class Initialized
DEBUG - 2012-01-11 22:33:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:33:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:33:47 --> Session Class Initialized
DEBUG - 2012-01-11 22:33:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:33:47 --> Session routines successfully run
DEBUG - 2012-01-11 22:33:47 --> Controller Class Initialized
DEBUG - 2012-01-11 22:33:47 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:33:47 --> Final output sent to browser
DEBUG - 2012-01-11 22:33:47 --> Total execution time: 0.3642
DEBUG - 2012-01-11 22:33:47 --> Config Class Initialized
DEBUG - 2012-01-11 22:33:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:33:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:33:47 --> URI Class Initialized
DEBUG - 2012-01-11 22:33:47 --> Router Class Initialized
ERROR - 2012-01-11 22:33:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:34:01 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:01 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Router Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Output Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Security Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Input Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:34:01 --> Language Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Loader Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:34:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Session Class Initialized
DEBUG - 2012-01-11 22:34:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:34:01 --> Session routines successfully run
DEBUG - 2012-01-11 22:34:01 --> Controller Class Initialized
DEBUG - 2012-01-11 22:34:01 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:34:01 --> Final output sent to browser
DEBUG - 2012-01-11 22:34:01 --> Total execution time: 0.3942
DEBUG - 2012-01-11 22:34:02 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:02 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:02 --> Router Class Initialized
ERROR - 2012-01-11 22:34:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:34:04 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:04 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Router Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Output Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Security Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Input Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:34:05 --> Language Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Loader Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:34:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Session Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:34:05 --> Session routines successfully run
DEBUG - 2012-01-11 22:34:05 --> Controller Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:34:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:34:05 --> Final output sent to browser
DEBUG - 2012-01-11 22:34:05 --> Total execution time: 0.4320
DEBUG - 2012-01-11 22:34:05 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:05 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:05 --> Router Class Initialized
ERROR - 2012-01-11 22:34:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:34:06 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:07 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Router Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Output Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Security Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Input Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:34:07 --> Language Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Loader Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:34:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Session Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:34:07 --> Session routines successfully run
DEBUG - 2012-01-11 22:34:07 --> Controller Class Initialized
DEBUG - 2012-01-11 22:34:07 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:34:07 --> Final output sent to browser
DEBUG - 2012-01-11 22:34:07 --> Total execution time: 0.8062
DEBUG - 2012-01-11 22:34:07 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:08 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:08 --> Router Class Initialized
ERROR - 2012-01-11 22:34:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:34:09 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:09 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Router Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Output Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Security Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Input Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:34:09 --> Language Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Loader Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:34:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Session Class Initialized
DEBUG - 2012-01-11 22:34:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:34:10 --> Session routines successfully run
DEBUG - 2012-01-11 22:34:10 --> Controller Class Initialized
DEBUG - 2012-01-11 22:34:10 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:34:10 --> Final output sent to browser
DEBUG - 2012-01-11 22:34:10 --> Total execution time: 0.4167
DEBUG - 2012-01-11 22:34:10 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:10 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:10 --> Router Class Initialized
ERROR - 2012-01-11 22:34:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:34:21 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:21 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Router Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Output Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Security Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Input Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:34:21 --> Language Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Loader Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:34:21 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Session Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:34:21 --> Session routines successfully run
DEBUG - 2012-01-11 22:34:21 --> Controller Class Initialized
DEBUG - 2012-01-11 22:34:21 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:34:21 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:34:21 --> Final output sent to browser
DEBUG - 2012-01-11 22:34:21 --> Total execution time: 0.4026
DEBUG - 2012-01-11 22:34:22 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:22 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:22 --> Router Class Initialized
ERROR - 2012-01-11 22:34:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:34:23 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:23 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Router Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Output Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Security Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Input Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:34:23 --> Language Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Loader Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:34:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Session Class Initialized
DEBUG - 2012-01-11 22:34:23 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:34:23 --> Session routines successfully run
DEBUG - 2012-01-11 22:34:23 --> Controller Class Initialized
DEBUG - 2012-01-11 22:34:23 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:34:23 --> Final output sent to browser
DEBUG - 2012-01-11 22:34:23 --> Total execution time: 0.3941
DEBUG - 2012-01-11 22:34:23 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:24 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:24 --> Router Class Initialized
ERROR - 2012-01-11 22:34:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:34:30 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:30 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Router Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Output Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Security Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Input Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:34:30 --> Language Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Loader Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:34:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:34:30 --> Session Class Initialized
DEBUG - 2012-01-11 22:34:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:34:31 --> Session routines successfully run
DEBUG - 2012-01-11 22:34:31 --> Controller Class Initialized
DEBUG - 2012-01-11 22:34:31 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:34:31 --> Final output sent to browser
DEBUG - 2012-01-11 22:34:31 --> Total execution time: 0.3558
DEBUG - 2012-01-11 22:34:31 --> Config Class Initialized
DEBUG - 2012-01-11 22:34:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:34:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:34:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:34:31 --> URI Class Initialized
DEBUG - 2012-01-11 22:34:31 --> Router Class Initialized
ERROR - 2012-01-11 22:34:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:36:29 --> Config Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:36:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:36:29 --> URI Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Router Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Output Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Security Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Input Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:36:29 --> Language Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Loader Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:36:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Session Class Initialized
DEBUG - 2012-01-11 22:36:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:36:29 --> Session routines successfully run
DEBUG - 2012-01-11 22:36:29 --> Controller Class Initialized
DEBUG - 2012-01-11 22:36:29 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:36:29 --> Final output sent to browser
DEBUG - 2012-01-11 22:36:29 --> Total execution time: 0.3520
DEBUG - 2012-01-11 22:36:30 --> Config Class Initialized
DEBUG - 2012-01-11 22:36:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:36:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:36:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:36:30 --> URI Class Initialized
DEBUG - 2012-01-11 22:36:30 --> Router Class Initialized
ERROR - 2012-01-11 22:36:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:37:43 --> Config Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:37:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:37:43 --> URI Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Router Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Output Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Security Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Input Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:37:43 --> Language Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Loader Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:37:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Session Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:37:43 --> Session routines successfully run
DEBUG - 2012-01-11 22:37:43 --> Controller Class Initialized
DEBUG - 2012-01-11 22:37:43 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:37:43 --> Final output sent to browser
DEBUG - 2012-01-11 22:37:43 --> Total execution time: 0.3789
DEBUG - 2012-01-11 22:37:43 --> Config Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:37:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:37:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:37:44 --> URI Class Initialized
DEBUG - 2012-01-11 22:37:44 --> Router Class Initialized
ERROR - 2012-01-11 22:37:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:38:16 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:16 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:16 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:16 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:16 --> A session cookie was not found.
DEBUG - 2012-01-11 22:38:16 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:16 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:16 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:16 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:16 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:17 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:17 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:17 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:17 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:17 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:17 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:17 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-11 22:38:17 --> Final output sent to browser
DEBUG - 2012-01-11 22:38:17 --> Total execution time: 0.5258
DEBUG - 2012-01-11 22:38:23 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:23 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:23 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:23 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:23 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:23 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:24 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:24 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:24 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:24 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:24 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:38:24 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:38:24 --> Final output sent to browser
DEBUG - 2012-01-11 22:38:24 --> Total execution time: 0.4619
DEBUG - 2012-01-11 22:38:26 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:26 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:26 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:27 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:27 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:27 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:27 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:27 --> Pagination Class Initialized
DEBUG - 2012-01-11 22:38:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 22:38:27 --> Final output sent to browser
DEBUG - 2012-01-11 22:38:27 --> Total execution time: 0.4596
DEBUG - 2012-01-11 22:38:28 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:28 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:28 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:28 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:28 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:28 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:38:28 --> Final output sent to browser
DEBUG - 2012-01-11 22:38:28 --> Total execution time: 0.4497
DEBUG - 2012-01-11 22:38:33 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:33 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:33 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:33 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:33 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:33 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 22:38:33 --> Final output sent to browser
DEBUG - 2012-01-11 22:38:33 --> Total execution time: 0.3953
DEBUG - 2012-01-11 22:38:34 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:34 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:34 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:35 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:35 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:35 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 22:38:35 --> Final output sent to browser
DEBUG - 2012-01-11 22:38:35 --> Total execution time: 0.4529
DEBUG - 2012-01-11 22:38:40 --> Config Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:38:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:38:40 --> URI Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Router Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Output Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Security Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Input Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:38:40 --> Language Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Loader Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:38:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Session Class Initialized
DEBUG - 2012-01-11 22:38:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:38:40 --> Session routines successfully run
DEBUG - 2012-01-11 22:38:40 --> Controller Class Initialized
DEBUG - 2012-01-11 22:38:40 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:38:40 --> Final output sent to browser
DEBUG - 2012-01-11 22:38:40 --> Total execution time: 0.4810
DEBUG - 2012-01-11 22:39:11 --> Config Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:39:11 --> URI Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Router Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Output Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Security Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Input Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:39:11 --> Language Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Loader Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:39:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Session Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:39:11 --> Session routines successfully run
DEBUG - 2012-01-11 22:39:11 --> Controller Class Initialized
DEBUG - 2012-01-11 22:39:11 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:39:11 --> Final output sent to browser
DEBUG - 2012-01-11 22:39:11 --> Total execution time: 0.3139
DEBUG - 2012-01-11 22:39:11 --> Config Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:39:11 --> URI Class Initialized
DEBUG - 2012-01-11 22:39:11 --> Router Class Initialized
ERROR - 2012-01-11 22:39:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:40:09 --> Config Class Initialized
DEBUG - 2012-01-11 22:40:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:40:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:40:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:40:09 --> URI Class Initialized
DEBUG - 2012-01-11 22:40:09 --> Router Class Initialized
DEBUG - 2012-01-11 22:40:09 --> Output Class Initialized
DEBUG - 2012-01-11 22:40:09 --> Security Class Initialized
DEBUG - 2012-01-11 22:40:09 --> Input Class Initialized
DEBUG - 2012-01-11 22:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:40:10 --> Language Class Initialized
DEBUG - 2012-01-11 22:40:10 --> Loader Class Initialized
DEBUG - 2012-01-11 22:40:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:40:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:40:10 --> Session Class Initialized
DEBUG - 2012-01-11 22:40:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:40:10 --> Session routines successfully run
DEBUG - 2012-01-11 22:40:10 --> Controller Class Initialized
DEBUG - 2012-01-11 22:40:10 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:40:10 --> Final output sent to browser
DEBUG - 2012-01-11 22:40:10 --> Total execution time: 0.4033
DEBUG - 2012-01-11 22:45:40 --> Config Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:45:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:45:40 --> URI Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Router Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Output Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Security Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Input Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:45:40 --> Language Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Loader Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:45:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Session Class Initialized
DEBUG - 2012-01-11 22:45:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:45:40 --> Session routines successfully run
DEBUG - 2012-01-11 22:45:40 --> Controller Class Initialized
DEBUG - 2012-01-11 22:45:40 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:45:40 --> Final output sent to browser
DEBUG - 2012-01-11 22:45:40 --> Total execution time: 0.9057
DEBUG - 2012-01-11 22:45:42 --> Config Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:45:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:45:42 --> URI Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Router Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Output Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Security Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Input Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:45:42 --> Language Class Initialized
DEBUG - 2012-01-11 22:45:42 --> Loader Class Initialized
DEBUG - 2012-01-11 22:45:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:45:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:45:43 --> Session Class Initialized
DEBUG - 2012-01-11 22:45:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:45:43 --> Session routines successfully run
DEBUG - 2012-01-11 22:45:43 --> Controller Class Initialized
ERROR - 2012-01-11 22:45:43 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 24
ERROR - 2012-01-11 22:45:43 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 24
DEBUG - 2012-01-11 22:45:43 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:45:43 --> Final output sent to browser
DEBUG - 2012-01-11 22:45:43 --> Total execution time: 0.6081
DEBUG - 2012-01-11 22:47:33 --> Config Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:47:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:47:33 --> URI Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Router Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Output Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Security Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Input Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:47:33 --> Language Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Loader Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:47:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Session Class Initialized
DEBUG - 2012-01-11 22:47:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:47:33 --> Session routines successfully run
DEBUG - 2012-01-11 22:47:33 --> Controller Class Initialized
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 28
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 29
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 28
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 29
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 28
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 29
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:33 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
ERROR - 2012-01-11 22:47:34 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
ERROR - 2012-01-11 22:47:34 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 28
ERROR - 2012-01-11 22:47:34 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 29
ERROR - 2012-01-11 22:47:34 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:34 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 30
ERROR - 2012-01-11 22:47:34 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
ERROR - 2012-01-11 22:47:34 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 31
DEBUG - 2012-01-11 22:47:34 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:47:34 --> Final output sent to browser
DEBUG - 2012-01-11 22:47:34 --> Total execution time: 1.6380
DEBUG - 2012-01-11 22:48:49 --> Config Class Initialized
DEBUG - 2012-01-11 22:48:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:48:49 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:48:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:48:50 --> URI Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Router Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Output Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Security Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Input Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:48:50 --> Language Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Loader Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:48:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Session Class Initialized
DEBUG - 2012-01-11 22:48:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:48:50 --> Session routines successfully run
DEBUG - 2012-01-11 22:48:50 --> Controller Class Initialized
ERROR - 2012-01-11 22:48:50 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 28
ERROR - 2012-01-11 22:48:50 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 28
ERROR - 2012-01-11 22:48:50 --> Severity: Notice  --> Undefined variable: article A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 29
ERROR - 2012-01-11 22:48:50 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\edit_comment.php 29
DEBUG - 2012-01-11 22:48:50 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:48:50 --> Final output sent to browser
DEBUG - 2012-01-11 22:48:50 --> Total execution time: 0.4346
DEBUG - 2012-01-11 22:49:29 --> Config Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:49:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:49:29 --> URI Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Router Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Output Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Security Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Input Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:49:29 --> Language Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Loader Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:49:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Session Class Initialized
DEBUG - 2012-01-11 22:49:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:49:29 --> Session routines successfully run
DEBUG - 2012-01-11 22:49:29 --> Controller Class Initialized
DEBUG - 2012-01-11 22:49:29 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 22:49:29 --> Final output sent to browser
DEBUG - 2012-01-11 22:49:29 --> Total execution time: 0.3776
DEBUG - 2012-01-11 22:49:30 --> Config Class Initialized
DEBUG - 2012-01-11 22:49:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:49:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:49:30 --> URI Class Initialized
DEBUG - 2012-01-11 22:49:30 --> Router Class Initialized
ERROR - 2012-01-11 22:49:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 22:49:31 --> Config Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:49:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:49:31 --> URI Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Router Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Output Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Security Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Input Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:49:31 --> Language Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Loader Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:49:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Session Class Initialized
DEBUG - 2012-01-11 22:49:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:49:31 --> Session routines successfully run
DEBUG - 2012-01-11 22:49:31 --> Controller Class Initialized
DEBUG - 2012-01-11 22:49:31 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:49:31 --> Final output sent to browser
DEBUG - 2012-01-11 22:49:31 --> Total execution time: 0.5502
DEBUG - 2012-01-11 22:51:03 --> Config Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:51:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:51:03 --> URI Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Router Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Output Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Security Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Input Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:51:03 --> Language Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Loader Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:51:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Session Class Initialized
DEBUG - 2012-01-11 22:51:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:51:03 --> Session routines successfully run
DEBUG - 2012-01-11 22:51:03 --> Controller Class Initialized
DEBUG - 2012-01-11 22:51:03 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:51:03 --> Final output sent to browser
DEBUG - 2012-01-11 22:51:03 --> Total execution time: 0.4506
DEBUG - 2012-01-11 22:51:34 --> Config Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:51:34 --> URI Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Router Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Output Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Security Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Input Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:51:34 --> Language Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Loader Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:51:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:51:34 --> Session Class Initialized
DEBUG - 2012-01-11 22:51:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:51:35 --> Session routines successfully run
DEBUG - 2012-01-11 22:51:35 --> Controller Class Initialized
DEBUG - 2012-01-11 22:51:35 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:51:35 --> Final output sent to browser
DEBUG - 2012-01-11 22:51:35 --> Total execution time: 0.3795
DEBUG - 2012-01-11 22:51:57 --> Config Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:51:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:51:57 --> URI Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Router Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Output Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Security Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Input Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:51:57 --> Language Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Loader Class Initialized
DEBUG - 2012-01-11 22:51:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:51:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:51:58 --> Session Class Initialized
DEBUG - 2012-01-11 22:51:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:51:58 --> Session routines successfully run
DEBUG - 2012-01-11 22:51:58 --> Controller Class Initialized
DEBUG - 2012-01-11 22:51:58 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:51:58 --> Final output sent to browser
DEBUG - 2012-01-11 22:51:58 --> Total execution time: 0.4061
DEBUG - 2012-01-11 22:52:45 --> Config Class Initialized
DEBUG - 2012-01-11 22:52:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:52:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:52:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:52:45 --> URI Class Initialized
DEBUG - 2012-01-11 22:52:45 --> Router Class Initialized
DEBUG - 2012-01-11 22:52:45 --> Output Class Initialized
DEBUG - 2012-01-11 22:52:45 --> Security Class Initialized
DEBUG - 2012-01-11 22:52:45 --> Input Class Initialized
DEBUG - 2012-01-11 22:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:52:45 --> Language Class Initialized
DEBUG - 2012-01-11 22:52:46 --> Loader Class Initialized
DEBUG - 2012-01-11 22:52:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:52:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:52:46 --> Session Class Initialized
DEBUG - 2012-01-11 22:52:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:52:46 --> Session routines successfully run
DEBUG - 2012-01-11 22:52:46 --> Controller Class Initialized
DEBUG - 2012-01-11 22:52:46 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:52:46 --> Final output sent to browser
DEBUG - 2012-01-11 22:52:46 --> Total execution time: 0.4802
DEBUG - 2012-01-11 22:53:35 --> Config Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:53:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:53:35 --> URI Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Router Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Output Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Security Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Input Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:53:35 --> Language Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Loader Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:53:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Session Class Initialized
DEBUG - 2012-01-11 22:53:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:53:35 --> Session routines successfully run
DEBUG - 2012-01-11 22:53:35 --> Controller Class Initialized
DEBUG - 2012-01-11 22:53:35 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:53:35 --> Final output sent to browser
DEBUG - 2012-01-11 22:53:35 --> Total execution time: 0.3956
DEBUG - 2012-01-11 22:57:50 --> Config Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:57:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:57:50 --> URI Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Router Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Output Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Security Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Input Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:57:50 --> Language Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Loader Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:57:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Session Class Initialized
DEBUG - 2012-01-11 22:57:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:57:50 --> Session routines successfully run
DEBUG - 2012-01-11 22:57:50 --> Controller Class Initialized
DEBUG - 2012-01-11 22:57:50 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:57:50 --> Final output sent to browser
DEBUG - 2012-01-11 22:57:50 --> Total execution time: 0.4553
DEBUG - 2012-01-11 22:57:55 --> Config Class Initialized
DEBUG - 2012-01-11 22:57:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:57:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:57:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:57:56 --> URI Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Router Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Output Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Security Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Input Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:57:56 --> Language Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Loader Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:57:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Session Class Initialized
DEBUG - 2012-01-11 22:57:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:57:56 --> Session routines successfully run
DEBUG - 2012-01-11 22:57:56 --> Controller Class Initialized
ERROR - 2012-01-11 22:57:56 --> Severity: Notice  --> Undefined index: user_name A:\home\codeigniter.blog\www\application\controllers\admin\comments.php 39
ERROR - 2012-01-11 22:57:56 --> Severity: Notice  --> Undefined index: text A:\home\codeigniter.blog\www\application\controllers\admin\comments.php 40
ERROR - 2012-01-11 22:57:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.blog\www\system\core\Exceptions.php:185) A:\home\codeigniter.blog\www\system\helpers\url_helper.php 546
DEBUG - 2012-01-11 22:58:29 --> Config Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:58:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:58:29 --> URI Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Router Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Output Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Security Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Input Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:58:29 --> Language Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Loader Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:58:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Session Class Initialized
DEBUG - 2012-01-11 22:58:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:58:29 --> Session routines successfully run
DEBUG - 2012-01-11 22:58:29 --> Controller Class Initialized
DEBUG - 2012-01-11 22:58:29 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:58:29 --> Final output sent to browser
DEBUG - 2012-01-11 22:58:29 --> Total execution time: 0.8407
DEBUG - 2012-01-11 22:58:37 --> Config Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:58:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:58:37 --> URI Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Router Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Output Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Security Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Input Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:58:37 --> Language Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Loader Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:58:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Session Class Initialized
DEBUG - 2012-01-11 22:58:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:58:37 --> Session routines successfully run
DEBUG - 2012-01-11 22:58:37 --> Controller Class Initialized
ERROR - 2012-01-11 22:58:37 --> Severity: Notice  --> Undefined index: text A:\home\codeigniter.blog\www\application\controllers\admin\comments.php 40
ERROR - 2012-01-11 22:58:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.blog\www\system\core\Exceptions.php:185) A:\home\codeigniter.blog\www\system\helpers\url_helper.php 546
DEBUG - 2012-01-11 22:59:09 --> Config Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:59:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:59:09 --> URI Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Router Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Output Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Security Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Input Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:59:09 --> Language Class Initialized
DEBUG - 2012-01-11 22:59:09 --> Loader Class Initialized
DEBUG - 2012-01-11 22:59:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:59:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:59:10 --> Session Class Initialized
DEBUG - 2012-01-11 22:59:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:59:10 --> Session routines successfully run
DEBUG - 2012-01-11 22:59:10 --> Controller Class Initialized
DEBUG - 2012-01-11 22:59:10 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:59:10 --> Final output sent to browser
DEBUG - 2012-01-11 22:59:10 --> Total execution time: 0.9858
DEBUG - 2012-01-11 22:59:15 --> Config Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:59:15 --> URI Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Router Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Output Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Security Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Input Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:59:15 --> Language Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Loader Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:59:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Session Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:59:15 --> Session routines successfully run
DEBUG - 2012-01-11 22:59:15 --> Controller Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Config Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:59:15 --> URI Class Initialized
DEBUG - 2012-01-11 22:59:15 --> Router Class Initialized
ERROR - 2012-01-11 22:59:15 --> 404 Page Not Found --> admin/edit
DEBUG - 2012-01-11 22:59:42 --> Config Class Initialized
DEBUG - 2012-01-11 22:59:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:59:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:59:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:59:42 --> URI Class Initialized
DEBUG - 2012-01-11 22:59:42 --> Router Class Initialized
ERROR - 2012-01-11 22:59:43 --> 404 Page Not Found --> admin/edit
DEBUG - 2012-01-11 22:59:47 --> Config Class Initialized
DEBUG - 2012-01-11 22:59:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:59:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:59:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:59:47 --> URI Class Initialized
DEBUG - 2012-01-11 22:59:47 --> Router Class Initialized
DEBUG - 2012-01-11 22:59:47 --> Output Class Initialized
DEBUG - 2012-01-11 22:59:47 --> Security Class Initialized
DEBUG - 2012-01-11 22:59:47 --> Input Class Initialized
DEBUG - 2012-01-11 22:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:59:47 --> Language Class Initialized
DEBUG - 2012-01-11 22:59:48 --> Loader Class Initialized
DEBUG - 2012-01-11 22:59:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:59:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:59:48 --> Session Class Initialized
DEBUG - 2012-01-11 22:59:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:59:48 --> Session routines successfully run
DEBUG - 2012-01-11 22:59:48 --> Controller Class Initialized
DEBUG - 2012-01-11 22:59:48 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:59:48 --> Final output sent to browser
DEBUG - 2012-01-11 22:59:48 --> Total execution time: 0.4222
DEBUG - 2012-01-11 22:59:50 --> Config Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:59:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:59:50 --> URI Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Router Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Output Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Security Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Input Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:59:50 --> Language Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Loader Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:59:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Session Class Initialized
DEBUG - 2012-01-11 22:59:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:59:50 --> Session routines successfully run
DEBUG - 2012-01-11 22:59:50 --> Controller Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Config Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 22:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 22:59:51 --> URI Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Router Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Output Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Security Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Input Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 22:59:51 --> Language Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Loader Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 22:59:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Session Class Initialized
DEBUG - 2012-01-11 22:59:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 22:59:51 --> Session routines successfully run
DEBUG - 2012-01-11 22:59:51 --> Controller Class Initialized
DEBUG - 2012-01-11 22:59:51 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 22:59:51 --> Final output sent to browser
DEBUG - 2012-01-11 22:59:51 --> Total execution time: 0.3948
DEBUG - 2012-01-11 23:00:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:00:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:00:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:00:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:00:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Session Class Initialized
DEBUG - 2012-01-11 23:00:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:00:50 --> Session routines successfully run
DEBUG - 2012-01-11 23:00:50 --> Controller Class Initialized
DEBUG - 2012-01-11 23:00:50 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:00:50 --> Final output sent to browser
DEBUG - 2012-01-11 23:00:50 --> Total execution time: 0.4033
DEBUG - 2012-01-11 23:01:23 --> Config Class Initialized
DEBUG - 2012-01-11 23:01:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:01:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:01:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:01:23 --> URI Class Initialized
DEBUG - 2012-01-11 23:01:23 --> Router Class Initialized
DEBUG - 2012-01-11 23:01:23 --> Output Class Initialized
DEBUG - 2012-01-11 23:01:23 --> Security Class Initialized
DEBUG - 2012-01-11 23:01:24 --> Input Class Initialized
DEBUG - 2012-01-11 23:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:01:24 --> Language Class Initialized
DEBUG - 2012-01-11 23:01:24 --> Loader Class Initialized
DEBUG - 2012-01-11 23:01:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:01:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:01:24 --> Session Class Initialized
DEBUG - 2012-01-11 23:01:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:01:24 --> Session routines successfully run
DEBUG - 2012-01-11 23:01:24 --> Controller Class Initialized
DEBUG - 2012-01-11 23:01:24 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:01:24 --> Final output sent to browser
DEBUG - 2012-01-11 23:01:24 --> Total execution time: 0.3793
DEBUG - 2012-01-11 23:01:27 --> Config Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:01:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:01:27 --> URI Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Router Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Output Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Security Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Input Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:01:27 --> Language Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Loader Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:01:27 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Session Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:01:27 --> Session routines successfully run
DEBUG - 2012-01-11 23:01:27 --> Controller Class Initialized
DEBUG - 2012-01-11 23:01:27 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:01:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:01:27 --> Final output sent to browser
DEBUG - 2012-01-11 23:01:27 --> Total execution time: 0.4798
DEBUG - 2012-01-11 23:01:28 --> Config Class Initialized
DEBUG - 2012-01-11 23:01:28 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:01:28 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:01:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:01:28 --> URI Class Initialized
DEBUG - 2012-01-11 23:01:28 --> Router Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Output Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Security Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Input Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:01:29 --> Language Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Loader Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:01:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Session Class Initialized
DEBUG - 2012-01-11 23:01:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:01:29 --> Session routines successfully run
DEBUG - 2012-01-11 23:01:29 --> Controller Class Initialized
DEBUG - 2012-01-11 23:01:29 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:01:29 --> Final output sent to browser
DEBUG - 2012-01-11 23:01:29 --> Total execution time: 0.4402
DEBUG - 2012-01-11 23:01:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:01:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:01:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:01:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:01:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:01:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:01:38 --> Session routines successfully run
DEBUG - 2012-01-11 23:01:38 --> Controller Class Initialized
DEBUG - 2012-01-11 23:01:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:01:38 --> Final output sent to browser
DEBUG - 2012-01-11 23:01:38 --> Total execution time: 0.4726
DEBUG - 2012-01-11 23:01:40 --> Config Class Initialized
DEBUG - 2012-01-11 23:01:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:01:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:01:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:01:40 --> URI Class Initialized
DEBUG - 2012-01-11 23:01:40 --> Router Class Initialized
DEBUG - 2012-01-11 23:01:40 --> Output Class Initialized
DEBUG - 2012-01-11 23:01:40 --> Security Class Initialized
DEBUG - 2012-01-11 23:01:40 --> Input Class Initialized
DEBUG - 2012-01-11 23:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:01:40 --> Language Class Initialized
DEBUG - 2012-01-11 23:01:41 --> Loader Class Initialized
DEBUG - 2012-01-11 23:01:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:01:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:01:41 --> Session Class Initialized
DEBUG - 2012-01-11 23:01:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:01:41 --> Session routines successfully run
DEBUG - 2012-01-11 23:01:41 --> Controller Class Initialized
DEBUG - 2012-01-11 23:01:41 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:01:41 --> Final output sent to browser
DEBUG - 2012-01-11 23:01:41 --> Total execution time: 0.5802
DEBUG - 2012-01-11 23:01:43 --> Config Class Initialized
DEBUG - 2012-01-11 23:01:43 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:01:43 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:01:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:01:43 --> URI Class Initialized
DEBUG - 2012-01-11 23:01:43 --> Router Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Output Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Security Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Input Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:01:44 --> Language Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Loader Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:01:44 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Session Class Initialized
DEBUG - 2012-01-11 23:01:44 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:01:44 --> Session routines successfully run
DEBUG - 2012-01-11 23:01:44 --> Controller Class Initialized
DEBUG - 2012-01-11 23:01:44 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:01:44 --> Final output sent to browser
DEBUG - 2012-01-11 23:01:44 --> Total execution time: 0.9728
DEBUG - 2012-01-11 23:01:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:01:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:01:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:01:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:01:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:01:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:01:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:01:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:01:47 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:01:47 --> Final output sent to browser
DEBUG - 2012-01-11 23:01:47 --> Total execution time: 0.4873
DEBUG - 2012-01-11 23:02:04 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:04 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:04 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:04 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:05 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:05 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:05 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:05 --> Loader Class Initialized
DEBUG - 2012-01-11 23:02:05 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:02:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:02:05 --> Session Class Initialized
DEBUG - 2012-01-11 23:02:05 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:02:05 --> Session routines successfully run
DEBUG - 2012-01-11 23:02:05 --> Controller Class Initialized
DEBUG - 2012-01-11 23:02:05 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:02:05 --> Final output sent to browser
DEBUG - 2012-01-11 23:02:05 --> Total execution time: 0.9972
DEBUG - 2012-01-11 23:02:28 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:28 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:28 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Loader Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:02:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Session Class Initialized
DEBUG - 2012-01-11 23:02:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:02:28 --> Session routines successfully run
DEBUG - 2012-01-11 23:02:28 --> Controller Class Initialized
DEBUG - 2012-01-11 23:02:28 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:02:28 --> Final output sent to browser
DEBUG - 2012-01-11 23:02:28 --> Total execution time: 0.3832
DEBUG - 2012-01-11 23:02:36 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:36 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:36 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Loader Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:02:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Session Class Initialized
DEBUG - 2012-01-11 23:02:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:02:36 --> Session routines successfully run
DEBUG - 2012-01-11 23:02:36 --> Controller Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:37 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:37 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Loader Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:02:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Session Class Initialized
DEBUG - 2012-01-11 23:02:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:02:37 --> Session routines successfully run
DEBUG - 2012-01-11 23:02:37 --> Controller Class Initialized
DEBUG - 2012-01-11 23:02:37 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:02:37 --> Final output sent to browser
DEBUG - 2012-01-11 23:02:37 --> Total execution time: 0.3784
DEBUG - 2012-01-11 23:02:51 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:51 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:51 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:51 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:52 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:52 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:52 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:52 --> Loader Class Initialized
DEBUG - 2012-01-11 23:02:52 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:02:52 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:02:52 --> Session Class Initialized
DEBUG - 2012-01-11 23:02:52 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:02:52 --> Session routines successfully run
DEBUG - 2012-01-11 23:02:52 --> Controller Class Initialized
DEBUG - 2012-01-11 23:02:52 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:02:52 --> Final output sent to browser
DEBUG - 2012-01-11 23:02:52 --> Total execution time: 0.4390
DEBUG - 2012-01-11 23:02:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:54 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Loader Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:02:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Session Class Initialized
DEBUG - 2012-01-11 23:02:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:02:54 --> Session routines successfully run
DEBUG - 2012-01-11 23:02:54 --> Controller Class Initialized
DEBUG - 2012-01-11 23:02:54 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:02:54 --> Final output sent to browser
DEBUG - 2012-01-11 23:02:54 --> Total execution time: 0.4853
DEBUG - 2012-01-11 23:02:55 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:55 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:56 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:56 --> Loader Class Initialized
DEBUG - 2012-01-11 23:02:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:02:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:02:56 --> Session Class Initialized
DEBUG - 2012-01-11 23:02:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:02:56 --> Session routines successfully run
DEBUG - 2012-01-11 23:02:56 --> Controller Class Initialized
DEBUG - 2012-01-11 23:02:56 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:02:56 --> Final output sent to browser
DEBUG - 2012-01-11 23:02:56 --> Total execution time: 0.5048
DEBUG - 2012-01-11 23:02:59 --> Config Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:02:59 --> URI Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Router Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Output Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Security Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Input Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:02:59 --> Language Class Initialized
DEBUG - 2012-01-11 23:02:59 --> Loader Class Initialized
DEBUG - 2012-01-11 23:03:00 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:03:00 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:03:00 --> Session Class Initialized
DEBUG - 2012-01-11 23:03:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:03:00 --> Session routines successfully run
DEBUG - 2012-01-11 23:03:00 --> Controller Class Initialized
DEBUG - 2012-01-11 23:03:00 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:03:00 --> Final output sent to browser
DEBUG - 2012-01-11 23:03:00 --> Total execution time: 0.4953
DEBUG - 2012-01-11 23:04:20 --> Config Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:04:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:04:20 --> URI Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Router Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Output Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Security Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Input Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:04:20 --> Language Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Loader Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:04:20 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Session Class Initialized
DEBUG - 2012-01-11 23:04:20 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:04:21 --> Session routines successfully run
DEBUG - 2012-01-11 23:04:21 --> Controller Class Initialized
DEBUG - 2012-01-11 23:04:21 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:04:21 --> Final output sent to browser
DEBUG - 2012-01-11 23:04:21 --> Total execution time: 0.4282
DEBUG - 2012-01-11 23:04:35 --> Config Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:04:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:04:35 --> URI Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Router Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Output Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Security Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Input Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:04:35 --> Language Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Loader Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:04:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Session Class Initialized
DEBUG - 2012-01-11 23:04:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:04:35 --> Session routines successfully run
DEBUG - 2012-01-11 23:04:35 --> Controller Class Initialized
DEBUG - 2012-01-11 23:04:35 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:04:35 --> Final output sent to browser
DEBUG - 2012-01-11 23:04:35 --> Total execution time: 0.5317
DEBUG - 2012-01-11 23:04:54 --> Config Class Initialized
DEBUG - 2012-01-11 23:04:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:04:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:04:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:04:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:04:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:04:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:04:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:04:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:04:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:04:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:04:55 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:04:55 --> Final output sent to browser
DEBUG - 2012-01-11 23:04:55 --> Total execution time: 0.4849
DEBUG - 2012-01-11 23:05:24 --> Config Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:05:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:05:24 --> URI Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Router Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Output Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Security Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Input Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:05:24 --> Language Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Loader Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:05:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Session Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:05:24 --> Session routines successfully run
DEBUG - 2012-01-11 23:05:24 --> Controller Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Config Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:05:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:05:24 --> URI Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Router Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Output Class Initialized
DEBUG - 2012-01-11 23:05:24 --> Security Class Initialized
DEBUG - 2012-01-11 23:05:25 --> Input Class Initialized
DEBUG - 2012-01-11 23:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:05:25 --> Language Class Initialized
DEBUG - 2012-01-11 23:05:25 --> Loader Class Initialized
DEBUG - 2012-01-11 23:05:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:05:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:05:25 --> Session Class Initialized
DEBUG - 2012-01-11 23:05:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:05:25 --> Session routines successfully run
DEBUG - 2012-01-11 23:05:25 --> Controller Class Initialized
DEBUG - 2012-01-11 23:05:25 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:05:25 --> Final output sent to browser
DEBUG - 2012-01-11 23:05:25 --> Total execution time: 0.4309
DEBUG - 2012-01-11 23:08:27 --> Config Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:08:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:08:27 --> URI Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Router Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Output Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Security Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Input Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:08:27 --> Language Class Initialized
DEBUG - 2012-01-11 23:08:27 --> Loader Class Initialized
DEBUG - 2012-01-11 23:08:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:08:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:08:28 --> Session Class Initialized
DEBUG - 2012-01-11 23:08:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:08:28 --> Session routines successfully run
DEBUG - 2012-01-11 23:08:28 --> Controller Class Initialized
DEBUG - 2012-01-11 23:08:29 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:08:29 --> Final output sent to browser
DEBUG - 2012-01-11 23:08:29 --> Total execution time: 1.7656
DEBUG - 2012-01-11 23:08:31 --> Config Class Initialized
DEBUG - 2012-01-11 23:08:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:08:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:08:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:08:31 --> URI Class Initialized
DEBUG - 2012-01-11 23:08:31 --> Router Class Initialized
DEBUG - 2012-01-11 23:08:31 --> Output Class Initialized
DEBUG - 2012-01-11 23:08:31 --> Security Class Initialized
DEBUG - 2012-01-11 23:08:31 --> Input Class Initialized
DEBUG - 2012-01-11 23:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:08:32 --> Language Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Loader Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:08:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Session Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:08:32 --> Session routines successfully run
DEBUG - 2012-01-11 23:08:32 --> Controller Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Config Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:08:32 --> URI Class Initialized
DEBUG - 2012-01-11 23:08:32 --> Router Class Initialized
ERROR - 2012-01-11 23:08:32 --> 404 Page Not Found --> admin/get_comments
DEBUG - 2012-01-11 23:09:11 --> Config Class Initialized
DEBUG - 2012-01-11 23:09:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:09:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:09:11 --> URI Class Initialized
DEBUG - 2012-01-11 23:09:11 --> Router Class Initialized
DEBUG - 2012-01-11 23:09:11 --> Output Class Initialized
DEBUG - 2012-01-11 23:09:11 --> Security Class Initialized
DEBUG - 2012-01-11 23:09:11 --> Input Class Initialized
DEBUG - 2012-01-11 23:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:09:11 --> Language Class Initialized
DEBUG - 2012-01-11 23:09:12 --> Loader Class Initialized
DEBUG - 2012-01-11 23:09:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:09:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:09:12 --> Session Class Initialized
DEBUG - 2012-01-11 23:09:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:09:12 --> Session routines successfully run
DEBUG - 2012-01-11 23:09:12 --> Controller Class Initialized
DEBUG - 2012-01-11 23:09:12 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:09:12 --> Final output sent to browser
DEBUG - 2012-01-11 23:09:12 --> Total execution time: 0.5288
DEBUG - 2012-01-11 23:09:15 --> Config Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:09:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:09:15 --> URI Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Router Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Output Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Security Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Input Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:09:15 --> Language Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Loader Class Initialized
DEBUG - 2012-01-11 23:09:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:09:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Session Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:09:16 --> Session routines successfully run
DEBUG - 2012-01-11 23:09:16 --> Controller Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Config Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:09:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:09:16 --> URI Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Router Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Output Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Security Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Input Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:09:16 --> Language Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Loader Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:09:16 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Session Class Initialized
DEBUG - 2012-01-11 23:09:16 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:09:16 --> Session routines successfully run
DEBUG - 2012-01-11 23:09:16 --> Controller Class Initialized
DEBUG - 2012-01-11 23:09:16 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:09:16 --> Final output sent to browser
DEBUG - 2012-01-11 23:09:16 --> Total execution time: 0.4136
DEBUG - 2012-01-11 23:09:20 --> Config Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:09:20 --> URI Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Router Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Output Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Security Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Input Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:09:20 --> Language Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Loader Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:09:20 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Session Class Initialized
DEBUG - 2012-01-11 23:09:20 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:09:20 --> Session routines successfully run
DEBUG - 2012-01-11 23:09:20 --> Controller Class Initialized
DEBUG - 2012-01-11 23:09:20 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:09:20 --> Final output sent to browser
DEBUG - 2012-01-11 23:09:20 --> Total execution time: 0.6897
DEBUG - 2012-01-11 23:09:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:09:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:09:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:09:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:09:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:09:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:09:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:09:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Config Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:09:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:09:48 --> URI Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Router Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Output Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Security Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Input Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:09:48 --> Language Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Loader Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:09:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Session Class Initialized
DEBUG - 2012-01-11 23:09:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:09:48 --> Session routines successfully run
DEBUG - 2012-01-11 23:09:48 --> Controller Class Initialized
DEBUG - 2012-01-11 23:09:48 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:09:48 --> Final output sent to browser
DEBUG - 2012-01-11 23:09:48 --> Total execution time: 0.4045
DEBUG - 2012-01-11 23:09:59 --> Config Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:09:59 --> URI Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Router Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Output Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Security Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Input Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:09:59 --> Language Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Loader Class Initialized
DEBUG - 2012-01-11 23:09:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:09:59 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:10:00 --> Session Class Initialized
DEBUG - 2012-01-11 23:10:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:10:00 --> Session routines successfully run
DEBUG - 2012-01-11 23:10:00 --> Controller Class Initialized
DEBUG - 2012-01-11 23:10:00 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:10:00 --> Final output sent to browser
DEBUG - 2012-01-11 23:10:00 --> Total execution time: 0.4605
DEBUG - 2012-01-11 23:10:04 --> Config Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:10:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:10:04 --> URI Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Router Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Output Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Security Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Input Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:10:04 --> Language Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Loader Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:10:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Session Class Initialized
DEBUG - 2012-01-11 23:10:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:10:04 --> Session routines successfully run
DEBUG - 2012-01-11 23:10:04 --> Controller Class Initialized
DEBUG - 2012-01-11 23:10:04 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:10:04 --> Final output sent to browser
DEBUG - 2012-01-11 23:10:04 --> Total execution time: 0.5942
DEBUG - 2012-01-11 23:10:11 --> Config Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:10:11 --> URI Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Router Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Output Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Security Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Input Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:10:11 --> Language Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Loader Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:10:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Session Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:10:11 --> Session routines successfully run
DEBUG - 2012-01-11 23:10:11 --> Controller Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Config Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:10:11 --> URI Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Router Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Output Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Security Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Input Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:10:11 --> Language Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Loader Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:10:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Session Class Initialized
DEBUG - 2012-01-11 23:10:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:10:11 --> Session routines successfully run
DEBUG - 2012-01-11 23:10:11 --> Controller Class Initialized
DEBUG - 2012-01-11 23:10:12 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:10:12 --> Final output sent to browser
DEBUG - 2012-01-11 23:10:12 --> Total execution time: 0.4024
DEBUG - 2012-01-11 23:10:15 --> Config Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:10:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:10:15 --> URI Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Router Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Output Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Security Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Input Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:10:15 --> Language Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Loader Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:10:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Session Class Initialized
DEBUG - 2012-01-11 23:10:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:10:15 --> Session routines successfully run
DEBUG - 2012-01-11 23:10:15 --> Controller Class Initialized
DEBUG - 2012-01-11 23:10:15 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:10:15 --> Final output sent to browser
DEBUG - 2012-01-11 23:10:15 --> Total execution time: 0.5051
DEBUG - 2012-01-11 23:10:18 --> Config Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:10:18 --> URI Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Router Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Output Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Security Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Input Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:10:18 --> Language Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Loader Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:10:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Session Class Initialized
DEBUG - 2012-01-11 23:10:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:10:18 --> Session routines successfully run
DEBUG - 2012-01-11 23:10:18 --> Controller Class Initialized
DEBUG - 2012-01-11 23:10:18 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:10:18 --> Final output sent to browser
DEBUG - 2012-01-11 23:10:18 --> Total execution time: 0.4785
DEBUG - 2012-01-11 23:10:44 --> Config Class Initialized
DEBUG - 2012-01-11 23:10:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:10:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:10:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:10:44 --> URI Class Initialized
DEBUG - 2012-01-11 23:10:44 --> Router Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Output Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Security Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Input Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:10:45 --> Language Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Loader Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:10:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Session Class Initialized
DEBUG - 2012-01-11 23:10:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:10:45 --> Session routines successfully run
DEBUG - 2012-01-11 23:10:45 --> Controller Class Initialized
DEBUG - 2012-01-11 23:10:45 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:10:45 --> Final output sent to browser
DEBUG - 2012-01-11 23:10:45 --> Total execution time: 0.4377
DEBUG - 2012-01-11 23:12:08 --> Config Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:12:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:12:08 --> URI Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Router Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Output Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Security Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Input Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:12:08 --> Language Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Loader Class Initialized
DEBUG - 2012-01-11 23:12:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:12:08 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:12:09 --> Session Class Initialized
DEBUG - 2012-01-11 23:12:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:12:09 --> Session routines successfully run
DEBUG - 2012-01-11 23:12:09 --> Controller Class Initialized
DEBUG - 2012-01-11 23:12:09 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:12:09 --> Final output sent to browser
DEBUG - 2012-01-11 23:12:09 --> Total execution time: 1.0199
DEBUG - 2012-01-11 23:12:10 --> Config Class Initialized
DEBUG - 2012-01-11 23:12:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:12:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:12:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:12:11 --> URI Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Router Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Output Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Security Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Input Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:12:11 --> Language Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Loader Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:12:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Session Class Initialized
DEBUG - 2012-01-11 23:12:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:12:11 --> Session routines successfully run
DEBUG - 2012-01-11 23:12:11 --> Controller Class Initialized
DEBUG - 2012-01-11 23:12:11 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:12:11 --> Final output sent to browser
DEBUG - 2012-01-11 23:12:11 --> Total execution time: 0.4673
DEBUG - 2012-01-11 23:12:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:12:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:12:53 --> URI Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Router Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Output Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Security Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Input Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:12:53 --> Language Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Loader Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:12:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Session Class Initialized
DEBUG - 2012-01-11 23:12:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:12:53 --> Session routines successfully run
DEBUG - 2012-01-11 23:12:53 --> Controller Class Initialized
DEBUG - 2012-01-11 23:12:53 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:12:53 --> Final output sent to browser
DEBUG - 2012-01-11 23:12:53 --> Total execution time: 0.4257
DEBUG - 2012-01-11 23:12:55 --> Config Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:12:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Router Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:12:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:12:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:12:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:12:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:12:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:12:55 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:12:55 --> Final output sent to browser
DEBUG - 2012-01-11 23:12:55 --> Total execution time: 0.4900
DEBUG - 2012-01-11 23:13:09 --> Config Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:13:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:13:09 --> URI Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Router Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Output Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Security Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Input Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:13:09 --> Language Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Loader Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:13:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Session Class Initialized
DEBUG - 2012-01-11 23:13:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:13:09 --> Session routines successfully run
DEBUG - 2012-01-11 23:13:09 --> Controller Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Config Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:13:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:13:10 --> URI Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Router Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Output Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Security Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Input Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:13:10 --> Language Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Loader Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:13:10 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Session Class Initialized
DEBUG - 2012-01-11 23:13:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:13:10 --> Session routines successfully run
DEBUG - 2012-01-11 23:13:10 --> Controller Class Initialized
DEBUG - 2012-01-11 23:13:10 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:13:10 --> Final output sent to browser
DEBUG - 2012-01-11 23:13:10 --> Total execution time: 0.4291
DEBUG - 2012-01-11 23:14:15 --> Config Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:14:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:14:15 --> URI Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Router Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Output Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Security Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Input Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:14:15 --> Language Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Loader Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:14:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Session Class Initialized
DEBUG - 2012-01-11 23:14:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:14:15 --> Session routines successfully run
DEBUG - 2012-01-11 23:14:15 --> Controller Class Initialized
DEBUG - 2012-01-11 23:14:15 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:14:15 --> Final output sent to browser
DEBUG - 2012-01-11 23:14:15 --> Total execution time: 0.1672
DEBUG - 2012-01-11 23:14:25 --> Config Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:14:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:14:25 --> URI Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Router Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Output Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Security Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Input Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:14:25 --> Language Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Loader Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:14:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Session Class Initialized
DEBUG - 2012-01-11 23:14:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:14:25 --> Session routines successfully run
DEBUG - 2012-01-11 23:14:25 --> Controller Class Initialized
DEBUG - 2012-01-11 23:14:25 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:14:25 --> Final output sent to browser
DEBUG - 2012-01-11 23:14:25 --> Total execution time: 0.2210
DEBUG - 2012-01-11 23:14:26 --> Config Class Initialized
DEBUG - 2012-01-11 23:14:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:14:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:14:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:14:26 --> URI Class Initialized
DEBUG - 2012-01-11 23:14:26 --> Router Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Output Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Security Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Input Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:14:27 --> Language Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Loader Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:14:27 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Session Class Initialized
DEBUG - 2012-01-11 23:14:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:14:27 --> Session routines successfully run
DEBUG - 2012-01-11 23:14:27 --> Controller Class Initialized
DEBUG - 2012-01-11 23:14:27 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:14:27 --> Final output sent to browser
DEBUG - 2012-01-11 23:14:27 --> Total execution time: 0.2047
DEBUG - 2012-01-11 23:15:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:15:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:15:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:15:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Output Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Security Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Input Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:15:54 --> Language Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Loader Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:15:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Session Class Initialized
DEBUG - 2012-01-11 23:15:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:15:54 --> Session routines successfully run
DEBUG - 2012-01-11 23:15:54 --> Controller Class Initialized
DEBUG - 2012-01-11 23:15:54 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:15:54 --> Final output sent to browser
DEBUG - 2012-01-11 23:15:54 --> Total execution time: 0.4135
DEBUG - 2012-01-11 23:16:07 --> Config Class Initialized
DEBUG - 2012-01-11 23:16:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:16:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:16:08 --> URI Class Initialized
DEBUG - 2012-01-11 23:16:08 --> Router Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Output Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Security Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Input Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:16:09 --> Language Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Loader Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:16:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Session Class Initialized
DEBUG - 2012-01-11 23:16:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:16:09 --> Session routines successfully run
DEBUG - 2012-01-11 23:16:09 --> Controller Class Initialized
DEBUG - 2012-01-11 23:16:09 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:16:09 --> Final output sent to browser
DEBUG - 2012-01-11 23:16:09 --> Total execution time: 1.6480
DEBUG - 2012-01-11 23:16:46 --> Config Class Initialized
DEBUG - 2012-01-11 23:16:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:16:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:16:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:16:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:16:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:16:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:16:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:16:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:16:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:16:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:16:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:16:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:16:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:16:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:16:47 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:16:47 --> Final output sent to browser
DEBUG - 2012-01-11 23:16:47 --> Total execution time: 0.4037
DEBUG - 2012-01-11 23:16:54 --> Config Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:16:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:16:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Output Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Security Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Input Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:16:54 --> Language Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Loader Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:16:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Session Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:16:54 --> Session routines successfully run
DEBUG - 2012-01-11 23:16:54 --> Controller Class Initialized
DEBUG - 2012-01-11 23:16:54 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:16:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:16:54 --> Final output sent to browser
DEBUG - 2012-01-11 23:16:54 --> Total execution time: 0.5256
DEBUG - 2012-01-11 23:16:57 --> Config Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:16:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:16:57 --> URI Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Router Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Output Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Security Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Input Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:16:57 --> Language Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Loader Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:16:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Session Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:16:57 --> Session routines successfully run
DEBUG - 2012-01-11 23:16:57 --> Controller Class Initialized
DEBUG - 2012-01-11 23:16:57 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:16:57 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:16:57 --> Final output sent to browser
DEBUG - 2012-01-11 23:16:57 --> Total execution time: 0.5555
DEBUG - 2012-01-11 23:17:01 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:01 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:01 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:01 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:01 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:01 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:02 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:02 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:02 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:02 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:02 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:02 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:02 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:02 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:02 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:17:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:17:02 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:02 --> Total execution time: 0.6023
DEBUG - 2012-01-11 23:17:06 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:06 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:06 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:06 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:06 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:06 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:06 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:17:06 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:17:06 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:06 --> Total execution time: 0.6078
DEBUG - 2012-01-11 23:17:13 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:13 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:13 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:14 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:14 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:14 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:17:14 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:14 --> Total execution time: 0.5543
DEBUG - 2012-01-11 23:17:24 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:24 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:24 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:24 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:24 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:25 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:25 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:25 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:25 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:25 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:25 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:25 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:17:25 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:25 --> Total execution time: 0.4875
DEBUG - 2012-01-11 23:17:28 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:28 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:28 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:28 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:28 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:28 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:17:28 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:28 --> Total execution time: 0.5070
DEBUG - 2012-01-11 23:17:30 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:30 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:30 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:30 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:31 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:31 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:31 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:31 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:31 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:31 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:31 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:31 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:17:31 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:31 --> Total execution time: 0.7729
DEBUG - 2012-01-11 23:17:35 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:35 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:36 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:36 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:36 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:36 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:36 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:17:36 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:36 --> Total execution time: 1.0677
DEBUG - 2012-01-11 23:17:41 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:41 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:41 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:42 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:42 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:42 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:42 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:42 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:42 --> Controller Class Initialized
DEBUG - 2012-01-11 23:17:42 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:17:42 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:42 --> Total execution time: 0.4078
DEBUG - 2012-01-11 23:17:52 --> Config Class Initialized
DEBUG - 2012-01-11 23:17:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:17:52 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:17:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:17:52 --> URI Class Initialized
DEBUG - 2012-01-11 23:17:52 --> Router Class Initialized
DEBUG - 2012-01-11 23:17:52 --> Output Class Initialized
DEBUG - 2012-01-11 23:17:52 --> Security Class Initialized
DEBUG - 2012-01-11 23:17:52 --> Input Class Initialized
DEBUG - 2012-01-11 23:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:17:53 --> Language Class Initialized
DEBUG - 2012-01-11 23:17:53 --> Loader Class Initialized
DEBUG - 2012-01-11 23:17:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:17:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:17:53 --> Session Class Initialized
DEBUG - 2012-01-11 23:17:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:17:53 --> Session routines successfully run
DEBUG - 2012-01-11 23:17:53 --> Controller Class Initialized
ERROR - 2012-01-11 23:17:53 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 11
ERROR - 2012-01-11 23:17:53 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 24
DEBUG - 2012-01-11 23:17:53 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:17:53 --> Final output sent to browser
DEBUG - 2012-01-11 23:17:53 --> Total execution time: 0.4441
DEBUG - 2012-01-11 23:18:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:18:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:18:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:18:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:18:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Session Class Initialized
DEBUG - 2012-01-11 23:18:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:18:50 --> Session routines successfully run
DEBUG - 2012-01-11 23:18:50 --> Controller Class Initialized
ERROR - 2012-01-11 23:18:50 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 11
ERROR - 2012-01-11 23:18:50 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 24
DEBUG - 2012-01-11 23:18:50 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:18:50 --> Final output sent to browser
DEBUG - 2012-01-11 23:18:50 --> Total execution time: 0.4090
DEBUG - 2012-01-11 23:20:31 --> Config Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:20:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:20:31 --> URI Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Router Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Output Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Security Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Input Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:20:31 --> Language Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Loader Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:20:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Session Class Initialized
DEBUG - 2012-01-11 23:20:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:20:31 --> Session routines successfully run
DEBUG - 2012-01-11 23:20:31 --> Controller Class Initialized
ERROR - 2012-01-11 23:20:31 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 11
ERROR - 2012-01-11 23:20:31 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 24
DEBUG - 2012-01-11 23:20:31 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:20:31 --> Final output sent to browser
DEBUG - 2012-01-11 23:20:31 --> Total execution time: 0.1674
DEBUG - 2012-01-11 23:26:44 --> Config Class Initialized
DEBUG - 2012-01-11 23:26:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:26:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:26:45 --> URI Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Router Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Output Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Security Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Input Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:26:45 --> Language Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Loader Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:26:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Session Class Initialized
DEBUG - 2012-01-11 23:26:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:26:45 --> Session routines successfully run
DEBUG - 2012-01-11 23:26:45 --> Controller Class Initialized
ERROR - 2012-01-11 23:26:45 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 11
DEBUG - 2012-01-11 23:26:45 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:26:45 --> Final output sent to browser
DEBUG - 2012-01-11 23:26:45 --> Total execution time: 0.5273
DEBUG - 2012-01-11 23:30:34 --> Config Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:30:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:30:34 --> URI Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Router Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Output Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Security Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Input Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:30:34 --> Language Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Loader Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:30:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Session Class Initialized
DEBUG - 2012-01-11 23:30:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:30:34 --> Session routines successfully run
DEBUG - 2012-01-11 23:30:34 --> Controller Class Initialized
ERROR - 2012-01-11 23:30:34 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\admin\comments.php 11
DEBUG - 2012-01-11 23:30:34 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:30:34 --> Final output sent to browser
DEBUG - 2012-01-11 23:30:34 --> Total execution time: 0.4134
DEBUG - 2012-01-11 23:30:36 --> Config Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:30:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:30:36 --> URI Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Router Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Output Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Security Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Input Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:30:36 --> Language Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Loader Class Initialized
DEBUG - 2012-01-11 23:30:36 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:30:36 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:30:37 --> Session Class Initialized
DEBUG - 2012-01-11 23:30:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:30:37 --> Session routines successfully run
DEBUG - 2012-01-11 23:30:37 --> Controller Class Initialized
DEBUG - 2012-01-11 23:30:37 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:30:37 --> Final output sent to browser
DEBUG - 2012-01-11 23:30:37 --> Total execution time: 1.0285
DEBUG - 2012-01-11 23:30:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:30:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:30:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:30:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:30:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:30:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:30:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:30:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:30:47 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:30:47 --> Final output sent to browser
DEBUG - 2012-01-11 23:30:47 --> Total execution time: 0.4556
DEBUG - 2012-01-11 23:30:49 --> Config Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:30:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:30:49 --> URI Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Router Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Output Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Security Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Input Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:30:49 --> Language Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Loader Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:30:49 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Session Class Initialized
DEBUG - 2012-01-11 23:30:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:30:49 --> Session routines successfully run
DEBUG - 2012-01-11 23:30:49 --> Controller Class Initialized
DEBUG - 2012-01-11 23:30:49 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:30:49 --> Final output sent to browser
DEBUG - 2012-01-11 23:30:49 --> Total execution time: 0.4506
DEBUG - 2012-01-11 23:30:51 --> Config Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:30:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:30:52 --> URI Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Router Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Output Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Security Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Input Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:30:52 --> Language Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Loader Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:30:52 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Session Class Initialized
DEBUG - 2012-01-11 23:30:52 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:30:52 --> Session routines successfully run
DEBUG - 2012-01-11 23:30:52 --> Controller Class Initialized
DEBUG - 2012-01-11 23:30:52 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:30:52 --> Final output sent to browser
DEBUG - 2012-01-11 23:30:52 --> Total execution time: 0.7625
DEBUG - 2012-01-11 23:30:55 --> Config Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:30:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:30:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Router Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:30:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:30:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:30:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:30:56 --> Session Class Initialized
DEBUG - 2012-01-11 23:30:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:30:56 --> Session routines successfully run
DEBUG - 2012-01-11 23:30:56 --> Controller Class Initialized
DEBUG - 2012-01-11 23:30:56 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:30:56 --> Final output sent to browser
DEBUG - 2012-01-11 23:30:56 --> Total execution time: 0.5004
DEBUG - 2012-01-11 23:30:57 --> Config Class Initialized
DEBUG - 2012-01-11 23:30:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:30:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:30:58 --> URI Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Router Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Output Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Security Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Input Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:30:58 --> Language Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Loader Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:30:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Session Class Initialized
DEBUG - 2012-01-11 23:30:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:30:58 --> Session routines successfully run
DEBUG - 2012-01-11 23:30:58 --> Controller Class Initialized
DEBUG - 2012-01-11 23:30:58 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:30:58 --> Final output sent to browser
DEBUG - 2012-01-11 23:30:58 --> Total execution time: 0.8620
DEBUG - 2012-01-11 23:31:04 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:04 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:04 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:04 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:04 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:05 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:05 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:05 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:05 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:05 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:31:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:31:05 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:05 --> Total execution time: 0.5094
DEBUG - 2012-01-11 23:31:10 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:10 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:10 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:10 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:11 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:11 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:11 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:11 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:11 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:11 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:11 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:11 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:31:11 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:11 --> Total execution time: 0.7132
DEBUG - 2012-01-11 23:31:13 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:13 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:13 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:13 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:13 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:31:14 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:14 --> Total execution time: 0.5019
DEBUG - 2012-01-11 23:31:42 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:42 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:42 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:42 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:42 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:42 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:31:42 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:42 --> Total execution time: 0.3732
DEBUG - 2012-01-11 23:31:42 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:42 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:42 --> Router Class Initialized
ERROR - 2012-01-11 23:31:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:31:44 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:44 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:44 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:44 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:45 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:45 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:45 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:45 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:31:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:31:45 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:45 --> Total execution time: 0.3886
DEBUG - 2012-01-11 23:31:45 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:45 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:45 --> Router Class Initialized
ERROR - 2012-01-11 23:31:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:31:48 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:48 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:48 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:48 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:48 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:48 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:31:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:31:48 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:48 --> Total execution time: 0.4113
DEBUG - 2012-01-11 23:31:49 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:49 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:49 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:49 --> Router Class Initialized
ERROR - 2012-01-11 23:31:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:31:49 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:49 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:50 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:50 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:31:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:31:50 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:50 --> Total execution time: 0.4351
DEBUG - 2012-01-11 23:31:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:50 --> Router Class Initialized
ERROR - 2012-01-11 23:31:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:31:54 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Router Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:31:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:31:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:31:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:31:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:31:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:31:55 --> Final output sent to browser
DEBUG - 2012-01-11 23:31:55 --> Total execution time: 0.3995
DEBUG - 2012-01-11 23:31:55 --> Config Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:31:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:31:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:31:55 --> Router Class Initialized
ERROR - 2012-01-11 23:31:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:00 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:00 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:00 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:00 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:01 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:01 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:01 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:32:01 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:01 --> Total execution time: 0.8955
DEBUG - 2012-01-11 23:32:01 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:01 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:01 --> Router Class Initialized
ERROR - 2012-01-11 23:32:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:02 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:02 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:02 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:02 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:02 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:02 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:02 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:02 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:03 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:03 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:03 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:03 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:32:03 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:03 --> Total execution time: 0.3954
DEBUG - 2012-01-11 23:32:03 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:03 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:03 --> Router Class Initialized
ERROR - 2012-01-11 23:32:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:04 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:04 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:04 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:04 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:04 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:05 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:05 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:05 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:05 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:32:05 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:05 --> Total execution time: 0.3985
DEBUG - 2012-01-11 23:32:05 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:05 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:05 --> Router Class Initialized
ERROR - 2012-01-11 23:32:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:11 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:11 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:11 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:11 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:11 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:11 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:11 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:11 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:12 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:12 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:12 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:32:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:32:12 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:12 --> Total execution time: 0.3578
DEBUG - 2012-01-11 23:32:12 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:12 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:12 --> Router Class Initialized
ERROR - 2012-01-11 23:32:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:18 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:18 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:18 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:18 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:18 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:18 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:32:18 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:18 --> Total execution time: 0.3621
DEBUG - 2012-01-11 23:32:18 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:18 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:19 --> Router Class Initialized
ERROR - 2012-01-11 23:32:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:29 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:29 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:29 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:29 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:29 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:29 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:32:29 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:29 --> Total execution time: 0.3695
DEBUG - 2012-01-11 23:32:29 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:29 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:29 --> Router Class Initialized
ERROR - 2012-01-11 23:32:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:31 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:31 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:31 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:32 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:32 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:32 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:32 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:32:32 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:32 --> Total execution time: 0.3880
DEBUG - 2012-01-11 23:32:32 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:32 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:32 --> Router Class Initialized
ERROR - 2012-01-11 23:32:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:35 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:35 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:35 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:35 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:35 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:35 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:32:35 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:35 --> Total execution time: 0.3695
DEBUG - 2012-01-11 23:32:35 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:35 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:35 --> Router Class Initialized
ERROR - 2012-01-11 23:32:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:38 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:38 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:39 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:39 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:39 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:39 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:39 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:32:39 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:39 --> Total execution time: 0.4026
DEBUG - 2012-01-11 23:32:40 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:40 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:40 --> Router Class Initialized
ERROR - 2012-01-11 23:32:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:46 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:46 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:46 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:46 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:46 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:47 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:32:47 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:47 --> Total execution time: 0.3548
DEBUG - 2012-01-11 23:32:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:47 --> Router Class Initialized
ERROR - 2012-01-11 23:32:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:32:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:32:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:32:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:32:50 --> Session Class Initialized
DEBUG - 2012-01-11 23:32:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:32:51 --> Session routines successfully run
DEBUG - 2012-01-11 23:32:51 --> Controller Class Initialized
DEBUG - 2012-01-11 23:32:51 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:32:51 --> Final output sent to browser
DEBUG - 2012-01-11 23:32:51 --> Total execution time: 0.3967
DEBUG - 2012-01-11 23:32:51 --> Config Class Initialized
DEBUG - 2012-01-11 23:32:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:32:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:32:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:32:51 --> URI Class Initialized
DEBUG - 2012-01-11 23:32:51 --> Router Class Initialized
ERROR - 2012-01-11 23:32:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:33:26 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:26 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:26 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:26 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:26 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:26 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:26 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:33:26 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:26 --> Total execution time: 0.4025
DEBUG - 2012-01-11 23:33:29 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:29 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:29 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:29 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:29 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:29 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:33:29 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:29 --> Total execution time: 0.4843
DEBUG - 2012-01-11 23:33:30 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:30 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:30 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:30 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:30 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:30 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:30 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:31 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:31 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:31 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:31 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:31 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:33:31 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:31 --> Total execution time: 0.5254
DEBUG - 2012-01-11 23:33:34 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:34 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:34 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:34 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:34 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:34 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:33:34 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:34 --> Total execution time: 0.4059
DEBUG - 2012-01-11 23:33:39 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:39 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:39 --> No URI present. Default controller set.
DEBUG - 2012-01-11 23:33:39 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:39 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:39 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:39 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:39 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:33:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-11 23:33:39 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:39 --> Total execution time: 0.9553
DEBUG - 2012-01-11 23:33:42 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:42 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:42 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:42 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:42 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:42 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:42 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:43 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:43 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:43 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:43 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:33:43 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:43 --> Total execution time: 0.4036
DEBUG - 2012-01-11 23:33:45 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:45 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:45 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:45 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:45 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:45 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:33:45 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:45 --> Total execution time: 0.6270
DEBUG - 2012-01-11 23:33:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:48 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:48 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:48 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:48 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:48 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:33:48 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:48 --> Total execution time: 0.4338
DEBUG - 2012-01-11 23:33:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:51 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:51 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:51 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:51 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:51 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:51 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:51 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:33:51 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:51 --> Total execution time: 0.5116
DEBUG - 2012-01-11 23:33:56 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:57 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:57 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:57 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:57 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Config Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:33:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:33:57 --> URI Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Router Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Output Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Security Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Input Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:33:57 --> Language Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Loader Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:33:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Session Class Initialized
DEBUG - 2012-01-11 23:33:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:33:57 --> Session routines successfully run
DEBUG - 2012-01-11 23:33:57 --> Controller Class Initialized
DEBUG - 2012-01-11 23:33:57 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:33:57 --> Final output sent to browser
DEBUG - 2012-01-11 23:33:57 --> Total execution time: 0.4275
DEBUG - 2012-01-11 23:34:01 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:01 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:01 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:01 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:01 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:01 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:01 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:01 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:34:01 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:01 --> Total execution time: 0.4873
DEBUG - 2012-01-11 23:34:03 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:03 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:03 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:03 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:03 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:03 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:03 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:03 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:34:03 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:03 --> Total execution time: 0.4894
DEBUG - 2012-01-11 23:34:06 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:06 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:06 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:06 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:06 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:06 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:06 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:06 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:06 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:06 --> Total execution time: 0.4681
DEBUG - 2012-01-11 23:34:08 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:08 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:08 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:09 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:09 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:09 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:09 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:10 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:10 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:10 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:10 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:10 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:10 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:10 --> Total execution time: 0.3757
DEBUG - 2012-01-11 23:34:14 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:14 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:14 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:14 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:14 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:14 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:14 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:15 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:15 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:15 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:15 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:15 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:15 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:15 --> Total execution time: 0.4327
DEBUG - 2012-01-11 23:34:22 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:22 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:22 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:23 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:23 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:23 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:23 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:34:23 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:23 --> Total execution time: 0.4988
DEBUG - 2012-01-11 23:34:25 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:25 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:25 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:25 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:25 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:34:25 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:26 --> Total execution time: 0.4003
DEBUG - 2012-01-11 23:34:27 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:27 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:27 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:28 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:28 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:28 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:28 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:28 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:28 --> Total execution time: 0.9898
DEBUG - 2012-01-11 23:34:31 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:31 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:31 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:31 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:31 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:31 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:31 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:31 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:32 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:32 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:32 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:32 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:32 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:32 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:32 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:32 --> Total execution time: 0.4406
DEBUG - 2012-01-11 23:34:37 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:37 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:37 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:37 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:37 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:38 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:38 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:38 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:38 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:38 --> Total execution time: 0.5990
DEBUG - 2012-01-11 23:34:40 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:40 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:40 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:41 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:41 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:41 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:34:41 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:41 --> Total execution time: 0.3916
DEBUG - 2012-01-11 23:34:42 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:42 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:43 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:43 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:43 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:43 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:43 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:43 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:43 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:43 --> Total execution time: 0.7504
DEBUG - 2012-01-11 23:34:45 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:45 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:45 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:45 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:45 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:45 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:45 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:45 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:45 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:46 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:46 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:46 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:46 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:46 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:46 --> Total execution time: 0.3855
DEBUG - 2012-01-11 23:34:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:50 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:50 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:50 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:50 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:50 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:34:50 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:50 --> Total execution time: 0.3371
DEBUG - 2012-01-11 23:34:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:53 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:53 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:53 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:53 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:53 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:34:53 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:53 --> Total execution time: 0.3602
DEBUG - 2012-01-11 23:34:55 --> Config Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:34:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:34:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Router Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:34:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:34:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:34:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:34:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:34:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:34:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-11 23:34:55 --> Final output sent to browser
DEBUG - 2012-01-11 23:34:55 --> Total execution time: 0.7456
DEBUG - 2012-01-11 23:35:04 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:04 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:04 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:04 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:04 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:04 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:04 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:04 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-11 23:35:04 --> Final output sent to browser
DEBUG - 2012-01-11 23:35:04 --> Total execution time: 0.4220
DEBUG - 2012-01-11 23:35:23 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:23 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:23 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:23 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:23 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:23 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:23 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:24 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:35:24 --> Final output sent to browser
DEBUG - 2012-01-11 23:35:24 --> Total execution time: 0.3811
DEBUG - 2012-01-11 23:35:27 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:28 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:28 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:28 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:28 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:28 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:28 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:35:28 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:35:28 --> Final output sent to browser
DEBUG - 2012-01-11 23:35:28 --> Total execution time: 0.5320
DEBUG - 2012-01-11 23:35:32 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:32 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:32 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:32 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:32 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:32 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:35:32 --> Final output sent to browser
DEBUG - 2012-01-11 23:35:32 --> Total execution time: 0.4846
DEBUG - 2012-01-11 23:35:34 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:34 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:34 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:34 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:34 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:34 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:34 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:34 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:35:34 --> Final output sent to browser
DEBUG - 2012-01-11 23:35:34 --> Total execution time: 0.3999
DEBUG - 2012-01-11 23:35:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:38 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:38 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:39 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:39 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:39 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:35:39 --> Final output sent to browser
DEBUG - 2012-01-11 23:35:39 --> Total execution time: 0.4844
DEBUG - 2012-01-11 23:35:41 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:41 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:41 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:41 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:41 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Config Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:35:41 --> URI Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Router Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Output Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Security Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Input Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:35:41 --> Language Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Loader Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:35:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Session Class Initialized
DEBUG - 2012-01-11 23:35:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:35:41 --> Session routines successfully run
DEBUG - 2012-01-11 23:35:41 --> Controller Class Initialized
DEBUG - 2012-01-11 23:35:41 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:35:41 --> Final output sent to browser
DEBUG - 2012-01-11 23:35:41 --> Total execution time: 0.3688
DEBUG - 2012-01-11 23:37:17 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:17 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:17 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:17 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:17 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:18 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:18 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:18 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:18 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:18 --> Total execution time: 0.3662
DEBUG - 2012-01-11 23:37:20 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:20 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:20 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:20 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:20 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:20 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:20 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:20 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:20 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:20 --> Total execution time: 0.3381
DEBUG - 2012-01-11 23:37:22 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:22 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:22 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:22 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:22 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:22 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:22 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:23 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:37:23 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:23 --> Total execution time: 0.3649
DEBUG - 2012-01-11 23:37:24 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:24 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:24 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:25 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:25 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:25 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:25 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:25 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:25 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:37:25 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:25 --> Total execution time: 0.3779
DEBUG - 2012-01-11 23:37:26 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:26 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:26 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:26 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:26 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:26 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:26 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:37:26 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:26 --> Total execution time: 0.6467
DEBUG - 2012-01-11 23:37:29 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:29 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:29 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:29 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:29 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:29 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:29 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:29 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:29 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:29 --> Total execution time: 0.4110
DEBUG - 2012-01-11 23:37:32 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:32 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:32 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:32 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:32 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:32 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:32 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:32 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:37:32 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:32 --> Total execution time: 0.3937
DEBUG - 2012-01-11 23:37:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:38 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:38 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:39 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:39 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:39 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:39 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:39 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:39 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:39 --> Total execution time: 0.3582
DEBUG - 2012-01-11 23:37:41 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:41 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:41 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:41 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:42 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:42 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:42 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:42 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:42 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:42 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:42 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:42 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:37:42 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:42 --> Total execution time: 0.3884
DEBUG - 2012-01-11 23:37:46 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:46 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:46 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:46 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:46 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:46 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:46 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:47 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:47 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:47 --> Total execution time: 0.3568
DEBUG - 2012-01-11 23:37:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:50 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:50 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:50 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:50 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:50 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:50 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:51 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:51 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:51 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:51 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:51 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:51 --> Total execution time: 0.3445
DEBUG - 2012-01-11 23:37:52 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:52 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:52 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:52 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:52 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:52 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:52 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:52 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:52 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:53 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:53 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:53 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:53 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:53 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:53 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:53 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:53 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:53 --> Total execution time: 0.3586
DEBUG - 2012-01-11 23:37:54 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Config Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:37:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:37:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Router Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:37:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:37:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:37:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:37:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:37:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:37:55 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:37:55 --> Final output sent to browser
DEBUG - 2012-01-11 23:37:55 --> Total execution time: 0.3368
DEBUG - 2012-01-11 23:38:27 --> Config Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:38:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:38:27 --> URI Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Router Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Output Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Security Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Input Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:38:27 --> Language Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Loader Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:38:27 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Session Class Initialized
DEBUG - 2012-01-11 23:38:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:38:27 --> Session routines successfully run
DEBUG - 2012-01-11 23:38:27 --> Controller Class Initialized
DEBUG - 2012-01-11 23:38:27 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:38:27 --> Final output sent to browser
DEBUG - 2012-01-11 23:38:27 --> Total execution time: 0.3590
DEBUG - 2012-01-11 23:39:04 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:04 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:04 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:05 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:05 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:05 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:05 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:39:05 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:05 --> Total execution time: 0.3556
DEBUG - 2012-01-11 23:39:05 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:05 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:05 --> Router Class Initialized
ERROR - 2012-01-11 23:39:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:06 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:06 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:06 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:06 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:06 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:06 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:06 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:07 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:39:07 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:07 --> Total execution time: 0.3453
DEBUG - 2012-01-11 23:39:07 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:07 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:07 --> Router Class Initialized
ERROR - 2012-01-11 23:39:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:07 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:07 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:07 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:08 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:08 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:08 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:08 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:08 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:39:08 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:08 --> Total execution time: 0.3697
DEBUG - 2012-01-11 23:39:08 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:08 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:08 --> Router Class Initialized
ERROR - 2012-01-11 23:39:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:09 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:09 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:09 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:09 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:09 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:09 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:39:09 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:39:09 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:09 --> Total execution time: 0.3938
DEBUG - 2012-01-11 23:39:10 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:10 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:10 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:10 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:10 --> Router Class Initialized
ERROR - 2012-01-11 23:39:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:12 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:12 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:12 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:12 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:12 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:39:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:39:12 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:12 --> Total execution time: 0.4447
DEBUG - 2012-01-11 23:39:12 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:13 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:13 --> Router Class Initialized
ERROR - 2012-01-11 23:39:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:26 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:26 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:26 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:27 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:27 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:27 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:27 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:27 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:39:27 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:27 --> Total execution time: 0.4083
DEBUG - 2012-01-11 23:39:27 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:27 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:27 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:27 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:27 --> Router Class Initialized
ERROR - 2012-01-11 23:39:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:30 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:30 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:30 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:30 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:30 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:30 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:30 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:39:30 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:30 --> Total execution time: 0.4230
DEBUG - 2012-01-11 23:39:30 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:30 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:30 --> Router Class Initialized
ERROR - 2012-01-11 23:39:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:33 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:33 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:33 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:33 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:33 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:33 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:33 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:33 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:39:33 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:33 --> Total execution time: 0.4249
DEBUG - 2012-01-11 23:39:34 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:34 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:34 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:34 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:34 --> Router Class Initialized
ERROR - 2012-01-11 23:39:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:54 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:54 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:54 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:54 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:39:54 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:54 --> Total execution time: 0.3652
DEBUG - 2012-01-11 23:39:54 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:54 --> Router Class Initialized
ERROR - 2012-01-11 23:39:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:57 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:57 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:57 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:39:57 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Session Class Initialized
DEBUG - 2012-01-11 23:39:57 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:39:57 --> Session routines successfully run
DEBUG - 2012-01-11 23:39:57 --> Controller Class Initialized
DEBUG - 2012-01-11 23:39:57 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:39:57 --> Final output sent to browser
DEBUG - 2012-01-11 23:39:57 --> Total execution time: 0.3898
DEBUG - 2012-01-11 23:39:58 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:58 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:58 --> Router Class Initialized
ERROR - 2012-01-11 23:39:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:39:59 --> Config Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:39:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:39:59 --> URI Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Router Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Output Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Security Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Input Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:39:59 --> Language Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Loader Class Initialized
DEBUG - 2012-01-11 23:39:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:00 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:00 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:00 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:00 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:00 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:00 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:40:00 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:00 --> Total execution time: 0.3999
DEBUG - 2012-01-11 23:40:00 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:00 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:00 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:00 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:00 --> Router Class Initialized
ERROR - 2012-01-11 23:40:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:07 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:07 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:07 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:07 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:07 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:07 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:08 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:08 --> File loaded: application/views/admin/edit_comment.php
DEBUG - 2012-01-11 23:40:08 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:08 --> Total execution time: 0.4023
DEBUG - 2012-01-11 23:40:08 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:08 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:08 --> Router Class Initialized
ERROR - 2012-01-11 23:40:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:13 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:13 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:13 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:13 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:13 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:13 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:14 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:14 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:14 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:14 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:14 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:14 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:40:14 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:14 --> Total execution time: 0.3570
DEBUG - 2012-01-11 23:40:14 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:14 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:14 --> Router Class Initialized
ERROR - 2012-01-11 23:40:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:18 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:18 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:18 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:18 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:18 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:18 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:40:18 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:18 --> Total execution time: 0.3981
DEBUG - 2012-01-11 23:40:19 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:19 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Router Class Initialized
ERROR - 2012-01-11 23:40:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:19 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:19 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:19 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:19 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:20 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:20 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:20 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:20 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:20 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:20 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:20 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:40:20 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:20 --> Total execution time: 0.7238
DEBUG - 2012-01-11 23:40:20 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:20 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:20 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:20 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:20 --> Router Class Initialized
ERROR - 2012-01-11 23:40:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:21 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:21 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:21 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:21 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:21 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:21 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:21 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:21 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:40:21 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:21 --> Total execution time: 0.3694
DEBUG - 2012-01-11 23:40:22 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:22 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:22 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:22 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:22 --> Router Class Initialized
ERROR - 2012-01-11 23:40:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:24 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:24 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:24 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:24 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:24 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:24 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:24 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:24 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:40:24 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:24 --> Total execution time: 0.7581
DEBUG - 2012-01-11 23:40:25 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:25 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:25 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:25 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:25 --> Router Class Initialized
ERROR - 2012-01-11 23:40:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:35 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:35 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:35 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:35 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:35 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:35 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:40:35 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:35 --> Total execution time: 0.4197
DEBUG - 2012-01-11 23:40:36 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:36 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:36 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:36 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:36 --> Router Class Initialized
ERROR - 2012-01-11 23:40:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:38 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:38 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:38 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:40:38 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:38 --> Total execution time: 0.4200
DEBUG - 2012-01-11 23:40:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:38 --> Router Class Initialized
ERROR - 2012-01-11 23:40:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:40 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:40 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:40 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:40 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:41 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:41 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:41 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:41 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:40:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:40:41 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:41 --> Total execution time: 0.9005
DEBUG - 2012-01-11 23:40:41 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:41 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:41 --> Router Class Initialized
ERROR - 2012-01-11 23:40:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:40:54 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:54 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:54 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:54 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:54 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:40:54 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:54 --> Total execution time: 0.3982
DEBUG - 2012-01-11 23:40:55 --> Config Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:40:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:40:55 --> URI Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Router Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Output Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Security Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Input Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:40:55 --> Language Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Loader Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:40:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:40:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:40:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:40:55 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:40:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:40:55 --> Final output sent to browser
DEBUG - 2012-01-11 23:40:55 --> Total execution time: 0.4452
DEBUG - 2012-01-11 23:43:37 --> Config Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:43:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:43:37 --> URI Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Router Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Output Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Security Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Input Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:43:37 --> Language Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Loader Class Initialized
DEBUG - 2012-01-11 23:43:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:43:38 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:43:38 --> Session Class Initialized
DEBUG - 2012-01-11 23:43:38 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:43:38 --> Session routines successfully run
DEBUG - 2012-01-11 23:43:38 --> Controller Class Initialized
DEBUG - 2012-01-11 23:43:38 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:43:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:43:38 --> Final output sent to browser
DEBUG - 2012-01-11 23:43:38 --> Total execution time: 0.4749
DEBUG - 2012-01-11 23:43:47 --> Config Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:43:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:43:47 --> URI Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Router Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Output Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Security Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Input Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:43:47 --> Language Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Loader Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:43:47 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Session Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:43:47 --> Session routines successfully run
DEBUG - 2012-01-11 23:43:47 --> Controller Class Initialized
DEBUG - 2012-01-11 23:43:47 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:43:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:43:47 --> Final output sent to browser
DEBUG - 2012-01-11 23:43:47 --> Total execution time: 0.5363
DEBUG - 2012-01-11 23:44:42 --> Config Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:44:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:44:42 --> URI Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Router Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Output Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Security Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Input Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:44:42 --> Language Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Loader Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:44:42 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Session Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:44:42 --> Session routines successfully run
DEBUG - 2012-01-11 23:44:42 --> Controller Class Initialized
DEBUG - 2012-01-11 23:44:42 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:44:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:44:43 --> Final output sent to browser
DEBUG - 2012-01-11 23:44:43 --> Total execution time: 0.4944
DEBUG - 2012-01-11 23:45:12 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:12 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:12 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:12 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:12 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:13 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:13 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:13 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:13 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:13 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:45:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:45:13 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:13 --> Total execution time: 0.4995
DEBUG - 2012-01-11 23:45:15 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:15 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:15 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:15 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:15 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:15 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:15 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:45:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:45:15 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:15 --> Total execution time: 0.7480
DEBUG - 2012-01-11 23:45:18 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:18 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:18 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:18 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:18 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:18 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:18 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:18 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:45:18 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:18 --> Total execution time: 0.9768
DEBUG - 2012-01-11 23:45:26 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:26 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:26 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:26 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:26 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:26 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:26 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:26 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:45:26 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:26 --> Total execution time: 0.4283
DEBUG - 2012-01-11 23:45:35 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:35 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:35 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:35 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:35 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:35 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:45:35 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:35 --> Total execution time: 0.4293
DEBUG - 2012-01-11 23:45:38 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:38 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:38 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:38 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:39 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:39 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:39 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:39 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:39 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:39 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:45:39 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:39 --> Total execution time: 0.4919
DEBUG - 2012-01-11 23:45:40 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:40 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:40 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:40 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:40 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:41 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:45:41 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:41 --> Total execution time: 0.7795
DEBUG - 2012-01-11 23:45:44 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:44 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:44 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:44 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:44 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:44 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:44 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:44 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:45:44 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:44 --> Total execution time: 0.4499
DEBUG - 2012-01-11 23:45:48 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:48 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:49 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:49 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:49 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:49 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:49 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:49 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:45:49 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:49 --> Total execution time: 0.5381
DEBUG - 2012-01-11 23:45:51 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:51 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:51 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:51 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:51 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:51 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:51 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-11 23:45:52 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:52 --> Total execution time: 0.5054
DEBUG - 2012-01-11 23:45:54 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:54 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:54 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:54 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:55 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:55 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:55 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:55 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:55 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:55 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:55 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:45:55 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:55 --> Total execution time: 0.8236
DEBUG - 2012-01-11 23:45:58 --> Config Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:45:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:45:58 --> URI Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Router Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Output Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Security Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Input Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:45:58 --> Language Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Loader Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:45:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Session Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:45:58 --> Session routines successfully run
DEBUG - 2012-01-11 23:45:58 --> Controller Class Initialized
DEBUG - 2012-01-11 23:45:58 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:45:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:45:58 --> Final output sent to browser
DEBUG - 2012-01-11 23:45:58 --> Total execution time: 0.5103
DEBUG - 2012-01-11 23:46:35 --> Config Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:46:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:46:35 --> URI Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Router Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Output Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Security Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Input Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:46:35 --> Language Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Loader Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:46:35 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Session Class Initialized
DEBUG - 2012-01-11 23:46:35 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:46:35 --> Session routines successfully run
DEBUG - 2012-01-11 23:46:35 --> Controller Class Initialized
DEBUG - 2012-01-11 23:46:35 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-11 23:46:35 --> Final output sent to browser
DEBUG - 2012-01-11 23:46:35 --> Total execution time: 0.5260
DEBUG - 2012-01-11 23:46:44 --> Config Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:46:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:46:44 --> URI Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Router Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Output Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Security Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Input Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:46:44 --> Language Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Loader Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:46:44 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Session Class Initialized
DEBUG - 2012-01-11 23:46:44 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:46:44 --> Session routines successfully run
DEBUG - 2012-01-11 23:46:44 --> Controller Class Initialized
DEBUG - 2012-01-11 23:46:44 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:46:44 --> Final output sent to browser
DEBUG - 2012-01-11 23:46:44 --> Total execution time: 0.5041
DEBUG - 2012-01-11 23:46:46 --> Config Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:46:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:46:46 --> URI Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Router Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Output Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Security Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Input Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:46:46 --> Language Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Loader Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:46:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Session Class Initialized
DEBUG - 2012-01-11 23:46:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:46:46 --> Session routines successfully run
DEBUG - 2012-01-11 23:46:46 --> Controller Class Initialized
DEBUG - 2012-01-11 23:46:46 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:46:46 --> Final output sent to browser
DEBUG - 2012-01-11 23:46:46 --> Total execution time: 0.4639
DEBUG - 2012-01-11 23:46:58 --> Config Class Initialized
DEBUG - 2012-01-11 23:46:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:46:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:46:59 --> URI Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Router Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Output Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Security Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Input Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:46:59 --> Language Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Loader Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:46:59 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Session Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:46:59 --> Session routines successfully run
DEBUG - 2012-01-11 23:46:59 --> Controller Class Initialized
DEBUG - 2012-01-11 23:46:59 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:46:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:46:59 --> Final output sent to browser
DEBUG - 2012-01-11 23:46:59 --> Total execution time: 0.4891
DEBUG - 2012-01-11 23:47:58 --> Config Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:47:58 --> URI Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Router Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Output Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Security Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Input Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:47:58 --> Language Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Loader Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:47:58 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Session Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:47:58 --> Session routines successfully run
DEBUG - 2012-01-11 23:47:58 --> Controller Class Initialized
DEBUG - 2012-01-11 23:47:58 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:47:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:47:58 --> Final output sent to browser
DEBUG - 2012-01-11 23:47:58 --> Total execution time: 1.0006
DEBUG - 2012-01-11 23:49:04 --> Config Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:49:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:49:04 --> URI Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Router Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Output Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Security Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Input Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:49:04 --> Language Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Loader Class Initialized
DEBUG - 2012-01-11 23:49:04 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:49:05 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:49:05 --> Session Class Initialized
DEBUG - 2012-01-11 23:49:05 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:49:05 --> Session routines successfully run
DEBUG - 2012-01-11 23:49:05 --> Controller Class Initialized
DEBUG - 2012-01-11 23:49:05 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:49:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:49:05 --> Final output sent to browser
DEBUG - 2012-01-11 23:49:05 --> Total execution time: 0.4137
DEBUG - 2012-01-11 23:49:05 --> Config Class Initialized
DEBUG - 2012-01-11 23:49:05 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:49:05 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:49:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:49:05 --> URI Class Initialized
DEBUG - 2012-01-11 23:49:05 --> Router Class Initialized
ERROR - 2012-01-11 23:49:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-11 23:50:40 --> Config Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:50:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:50:40 --> URI Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Router Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Output Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Security Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Input Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:50:40 --> Language Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Loader Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:50:40 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Session Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:50:40 --> Session routines successfully run
DEBUG - 2012-01-11 23:50:40 --> Controller Class Initialized
DEBUG - 2012-01-11 23:50:40 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:50:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:50:40 --> Final output sent to browser
DEBUG - 2012-01-11 23:50:41 --> Total execution time: 0.5138
DEBUG - 2012-01-11 23:50:46 --> Config Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:50:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:50:46 --> URI Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Router Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Output Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Security Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Input Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:50:46 --> Language Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Loader Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:50:46 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Session Class Initialized
DEBUG - 2012-01-11 23:50:46 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:50:46 --> Session routines successfully run
DEBUG - 2012-01-11 23:50:46 --> Controller Class Initialized
ERROR - 2012-01-11 23:50:46 --> 404 Page Not Found --> article/create
DEBUG - 2012-01-11 23:50:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:50:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:50:53 --> URI Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Router Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Output Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Security Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Input Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:50:53 --> Language Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Loader Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:50:53 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Session Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:50:53 --> Session routines successfully run
DEBUG - 2012-01-11 23:50:53 --> Controller Class Initialized
DEBUG - 2012-01-11 23:50:53 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:50:53 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:50:53 --> Final output sent to browser
DEBUG - 2012-01-11 23:50:53 --> Total execution time: 0.5344
DEBUG - 2012-01-11 23:52:37 --> Config Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:52:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:52:37 --> URI Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Router Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Output Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Security Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Input Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:52:37 --> Language Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Loader Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:52:37 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Session Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:52:37 --> Session routines successfully run
DEBUG - 2012-01-11 23:52:37 --> Controller Class Initialized
DEBUG - 2012-01-11 23:52:37 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:52:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:52:38 --> Final output sent to browser
DEBUG - 2012-01-11 23:52:38 --> Total execution time: 0.4888
DEBUG - 2012-01-11 23:53:48 --> Config Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:53:48 --> URI Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Router Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Output Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Security Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Input Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:53:48 --> Language Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Loader Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:53:48 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Session Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:53:48 --> Session routines successfully run
DEBUG - 2012-01-11 23:53:48 --> Controller Class Initialized
DEBUG - 2012-01-11 23:53:48 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:53:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:53:48 --> Final output sent to browser
DEBUG - 2012-01-11 23:53:48 --> Total execution time: 0.4495
DEBUG - 2012-01-11 23:53:53 --> Config Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:53:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:53:53 --> URI Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Router Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Output Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Security Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Input Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:53:53 --> Language Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Loader Class Initialized
DEBUG - 2012-01-11 23:53:53 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:53:54 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:53:54 --> Session Class Initialized
DEBUG - 2012-01-11 23:53:54 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:53:54 --> Session routines successfully run
DEBUG - 2012-01-11 23:53:54 --> Controller Class Initialized
DEBUG - 2012-01-11 23:53:54 --> Pagination Class Initialized
DEBUG - 2012-01-11 23:53:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-11 23:53:54 --> Final output sent to browser
DEBUG - 2012-01-11 23:53:54 --> Total execution time: 1.0884
DEBUG - 2012-01-11 23:59:08 --> Config Class Initialized
DEBUG - 2012-01-11 23:59:08 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:59:08 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:59:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:59:08 --> URI Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Router Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Output Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Security Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Input Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:59:09 --> Language Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Loader Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:59:09 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Session Class Initialized
DEBUG - 2012-01-11 23:59:09 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:59:09 --> Session routines successfully run
DEBUG - 2012-01-11 23:59:09 --> Controller Class Initialized
DEBUG - 2012-01-11 23:59:09 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-11 23:59:09 --> Final output sent to browser
DEBUG - 2012-01-11 23:59:09 --> Total execution time: 0.3989
DEBUG - 2012-01-11 23:59:51 --> Config Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:59:51 --> URI Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Router Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Output Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Security Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Input Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:59:51 --> Language Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Loader Class Initialized
DEBUG - 2012-01-11 23:59:51 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:59:51 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:59:52 --> Session Class Initialized
DEBUG - 2012-01-11 23:59:52 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:59:52 --> Session routines successfully run
DEBUG - 2012-01-11 23:59:52 --> Controller Class Initialized
DEBUG - 2012-01-11 23:59:52 --> File loaded: application/views/admin/create_article.php
DEBUG - 2012-01-11 23:59:52 --> Final output sent to browser
DEBUG - 2012-01-11 23:59:52 --> Total execution time: 0.4616
DEBUG - 2012-01-11 23:59:56 --> Config Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Hooks Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Utf8 Class Initialized
DEBUG - 2012-01-11 23:59:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-11 23:59:56 --> URI Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Router Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Output Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Security Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Input Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-11 23:59:56 --> Language Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Loader Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Helper loaded: url_helper
DEBUG - 2012-01-11 23:59:56 --> Database Driver Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Session Class Initialized
DEBUG - 2012-01-11 23:59:56 --> Helper loaded: string_helper
DEBUG - 2012-01-11 23:59:56 --> Session routines successfully run
DEBUG - 2012-01-11 23:59:56 --> Controller Class Initialized
DEBUG - 2012-01-11 23:59:56 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-11 23:59:57 --> Final output sent to browser
DEBUG - 2012-01-11 23:59:57 --> Total execution time: 0.4346

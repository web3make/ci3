<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-02-01 07:11:09 --> Config Class Initialized
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-02-01 07:11:09 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:09 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:09 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Router Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Router Class Initialized
DEBUG - 2007-02-01 07:11:09 --> No URI present. Default controller set.
DEBUG - 2007-02-01 07:11:09 --> Output Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Output Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Security Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Security Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Input Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Input Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 07:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 07:11:09 --> Language Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Language Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Loader Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Loader Class Initialized
DEBUG - 2007-02-01 07:11:09 --> Helper loaded: url_helper
DEBUG - 2007-02-01 07:11:09 --> Helper loaded: url_helper
DEBUG - 2007-02-01 07:11:10 --> Database Driver Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Database Driver Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Session Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Session Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Helper loaded: string_helper
DEBUG - 2007-02-01 07:11:10 --> A session cookie was not found.
DEBUG - 2007-02-01 07:11:10 --> Helper loaded: string_helper
DEBUG - 2007-02-01 07:11:10 --> A session cookie was not found.
DEBUG - 2007-02-01 07:11:10 --> Session routines successfully run
DEBUG - 2007-02-01 07:11:10 --> Session routines successfully run
DEBUG - 2007-02-01 07:11:10 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Controller Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Controller Class Initialized
DEBUG - 2007-02-01 07:11:10 --> Pagination Class Initialized
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-01 07:11:10 --> Final output sent to browser
DEBUG - 2007-02-01 07:11:10 --> Total execution time: 0.6670
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 07:11:10 --> File loaded: application/views/user/article.php
DEBUG - 2007-02-01 07:11:10 --> Final output sent to browser
DEBUG - 2007-02-01 07:11:10 --> Total execution time: 0.6817
DEBUG - 2007-02-01 07:11:11 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:11 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:11 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:11 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:11 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:11 --> Router Class Initialized
ERROR - 2007-02-01 07:11:11 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 07:11:11 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:11 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:11 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:11 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:11 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Router Class Initialized
ERROR - 2007-02-01 07:11:12 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 07:11:12 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:12 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:12 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Router Class Initialized
ERROR - 2007-02-01 07:11:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-01 07:11:12 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:12 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:12 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:12 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:12 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:12 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Router Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Router Class Initialized
ERROR - 2007-02-01 07:11:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-01 07:11:12 --> Output Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Security Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Input Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 07:11:12 --> Language Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Loader Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Helper loaded: url_helper
DEBUG - 2007-02-01 07:11:12 --> Database Driver Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Session Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Helper loaded: string_helper
DEBUG - 2007-02-01 07:11:12 --> Session routines successfully run
DEBUG - 2007-02-01 07:11:12 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Controller Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:12 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:12 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:12 --> Router Class Initialized
ERROR - 2007-02-01 07:11:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-01 07:11:13 --> Config Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Hooks Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Utf8 Class Initialized
DEBUG - 2007-02-01 07:11:13 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 07:11:13 --> URI Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Router Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Output Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Security Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Input Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 07:11:13 --> Language Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Loader Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Helper loaded: url_helper
DEBUG - 2007-02-01 07:11:13 --> Database Driver Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Session Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Helper loaded: string_helper
DEBUG - 2007-02-01 07:11:13 --> Session routines successfully run
DEBUG - 2007-02-01 07:11:13 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Model Class Initialized
DEBUG - 2007-02-01 07:11:13 --> Controller Class Initialized
DEBUG - 2007-02-01 07:11:13 --> File loaded: application/views/admin/login.php
DEBUG - 2007-02-01 07:11:13 --> Final output sent to browser
DEBUG - 2007-02-01 07:11:13 --> Total execution time: 0.2849
DEBUG - 2007-02-01 13:58:09 --> Config Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Hooks Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Utf8 Class Initialized
DEBUG - 2007-02-01 13:58:09 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 13:58:09 --> URI Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Router Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Output Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Security Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Input Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 13:58:09 --> Language Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Loader Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Helper loaded: url_helper
DEBUG - 2007-02-01 13:58:09 --> Database Driver Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Session Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Helper loaded: string_helper
DEBUG - 2007-02-01 13:58:09 --> A session cookie was not found.
DEBUG - 2007-02-01 13:58:09 --> Session routines successfully run
DEBUG - 2007-02-01 13:58:09 --> Model Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Model Class Initialized
DEBUG - 2007-02-01 13:58:09 --> Controller Class Initialized
DEBUG - 2007-02-01 13:58:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 13:58:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 13:58:09 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-02-01 13:58:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 13:58:09 --> File loaded: application/views/user/article.php
DEBUG - 2007-02-01 13:58:09 --> Final output sent to browser
DEBUG - 2007-02-01 13:58:09 --> Total execution time: 0.1468
DEBUG - 2007-02-01 13:58:19 --> Config Class Initialized
DEBUG - 2007-02-01 13:58:19 --> Hooks Class Initialized
DEBUG - 2007-02-01 13:58:19 --> Utf8 Class Initialized
DEBUG - 2007-02-01 13:58:20 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 13:58:20 --> URI Class Initialized
DEBUG - 2007-02-01 13:58:20 --> Router Class Initialized
ERROR - 2007-02-01 13:58:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-01 13:58:25 --> Config Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Hooks Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Utf8 Class Initialized
DEBUG - 2007-02-01 13:58:25 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 13:58:25 --> URI Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Router Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Output Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Security Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Input Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 13:58:25 --> Language Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Loader Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Helper loaded: url_helper
DEBUG - 2007-02-01 13:58:25 --> Database Driver Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Session Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Helper loaded: string_helper
DEBUG - 2007-02-01 13:58:25 --> Session routines successfully run
DEBUG - 2007-02-01 13:58:25 --> Model Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Model Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Controller Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Config Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Hooks Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Utf8 Class Initialized
DEBUG - 2007-02-01 13:58:25 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 13:58:25 --> URI Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Router Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Output Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Security Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Input Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 13:58:25 --> Language Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Loader Class Initialized
DEBUG - 2007-02-01 13:58:25 --> Helper loaded: url_helper
DEBUG - 2007-02-01 13:58:26 --> Database Driver Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Session Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Helper loaded: string_helper
DEBUG - 2007-02-01 13:58:26 --> Session routines successfully run
DEBUG - 2007-02-01 13:58:26 --> Model Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Model Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Controller Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Pagination Class Initialized
ERROR - 2007-02-01 13:58:26 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 13:58:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 13:58:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 13:58:26 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-02-01 13:58:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 13:58:26 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 13:58:26 --> Final output sent to browser
DEBUG - 2007-02-01 13:58:26 --> Total execution time: 0.1688
DEBUG - 2007-02-01 13:58:26 --> Config Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Hooks Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Utf8 Class Initialized
DEBUG - 2007-02-01 13:58:26 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 13:58:26 --> URI Class Initialized
DEBUG - 2007-02-01 13:58:26 --> Router Class Initialized
ERROR - 2007-02-01 13:58:26 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 14:00:24 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:24 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:24 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:24 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:24 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:24 --> Router Class Initialized
DEBUG - 2007-02-01 14:00:24 --> Output Class Initialized
DEBUG - 2007-02-01 14:00:24 --> Security Class Initialized
DEBUG - 2007-02-01 14:00:24 --> Input Class Initialized
DEBUG - 2007-02-01 14:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:00:24 --> Language Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Loader Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:00:25 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Session Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:00:25 --> Session routines successfully run
DEBUG - 2007-02-01 14:00:25 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Controller Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Pagination Class Initialized
ERROR - 2007-02-01 14:00:25 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 14:00:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 14:00:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 14:00:25 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 14:00:25 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 14:00:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 14:00:25 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 14:00:25 --> Final output sent to browser
DEBUG - 2007-02-01 14:00:25 --> Total execution time: 0.1544
DEBUG - 2007-02-01 14:00:25 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:25 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:25 --> Router Class Initialized
ERROR - 2007-02-01 14:00:25 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 14:00:28 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:28 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:28 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Router Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Output Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Security Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Input Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:00:28 --> Language Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Loader Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:00:28 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Session Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:00:28 --> Session routines successfully run
DEBUG - 2007-02-01 14:00:28 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Controller Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Pagination Class Initialized
ERROR - 2007-02-01 14:00:28 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 14:00:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 14:00:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 14:00:28 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 14:00:28 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 14:00:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 14:00:28 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 14:00:28 --> Final output sent to browser
DEBUG - 2007-02-01 14:00:28 --> Total execution time: 0.1499
DEBUG - 2007-02-01 14:00:28 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:28 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:28 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:28 --> Router Class Initialized
ERROR - 2007-02-01 14:00:28 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 14:00:29 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:29 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:29 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Router Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Output Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Security Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Input Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:00:29 --> Language Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Loader Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:00:29 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Session Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:00:29 --> Session routines successfully run
DEBUG - 2007-02-01 14:00:29 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Controller Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Pagination Class Initialized
ERROR - 2007-02-01 14:00:29 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 14:00:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 14:00:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 14:00:29 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 14:00:29 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 14:00:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 14:00:29 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 14:00:29 --> Final output sent to browser
DEBUG - 2007-02-01 14:00:29 --> Total execution time: 0.1518
DEBUG - 2007-02-01 14:00:29 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:29 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:29 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:29 --> Router Class Initialized
ERROR - 2007-02-01 14:00:29 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 14:00:30 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:30 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:30 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Router Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Output Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Security Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Input Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:00:30 --> Language Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Loader Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:00:30 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Session Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:00:30 --> Session routines successfully run
DEBUG - 2007-02-01 14:00:30 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Model Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Controller Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Pagination Class Initialized
ERROR - 2007-02-01 14:00:30 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 14:00:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 14:00:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 14:00:30 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 14:00:30 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 14:00:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 14:00:30 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 14:00:30 --> Final output sent to browser
DEBUG - 2007-02-01 14:00:30 --> Total execution time: 0.1501
DEBUG - 2007-02-01 14:00:30 --> Config Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:00:30 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:00:30 --> URI Class Initialized
DEBUG - 2007-02-01 14:00:30 --> Router Class Initialized
ERROR - 2007-02-01 14:00:30 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 14:01:25 --> Config Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:01:25 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:01:25 --> URI Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Router Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Output Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Security Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Input Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:01:25 --> Language Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Loader Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:01:25 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Session Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:01:25 --> Session routines successfully run
DEBUG - 2007-02-01 14:01:25 --> Model Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Model Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Controller Class Initialized
DEBUG - 2007-02-01 14:01:25 --> Pagination Class Initialized
ERROR - 2007-02-01 14:01:25 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 14:01:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 14:01:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 14:01:25 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 14:01:25 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 14:01:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 14:01:25 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 14:01:25 --> Final output sent to browser
DEBUG - 2007-02-01 14:01:26 --> Total execution time: 0.1676
DEBUG - 2007-02-01 14:01:26 --> Config Class Initialized
DEBUG - 2007-02-01 14:01:26 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:01:26 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:01:26 --> URI Class Initialized
DEBUG - 2007-02-01 14:01:26 --> Router Class Initialized
ERROR - 2007-02-01 14:01:26 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 14:05:09 --> Config Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:05:09 --> URI Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Router Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Output Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Security Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Input Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:05:09 --> Language Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Loader Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:05:09 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Session Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:05:09 --> Session routines successfully run
DEBUG - 2007-02-01 14:05:09 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:09 --> Controller Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Helper loaded: tinymce_helper
ERROR - 2007-02-01 14:05:10 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 14:05:10 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 14:05:10 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 14:05:10 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 14:05:10 --> File loaded: application/views/admin/article.php
DEBUG - 2007-02-01 14:05:10 --> Final output sent to browser
DEBUG - 2007-02-01 14:05:10 --> Total execution time: 0.1621
DEBUG - 2007-02-01 14:05:10 --> Config Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:05:10 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:05:10 --> URI Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Router Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Output Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Security Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Input Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:05:10 --> Language Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Loader Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:05:10 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Session Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:05:10 --> Session routines successfully run
DEBUG - 2007-02-01 14:05:10 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:10 --> Controller Class Initialized
ERROR - 2007-02-01 14:05:10 --> 404 Page Not Found --> article/css
DEBUG - 2007-02-01 14:05:19 --> Config Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:05:19 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:05:19 --> URI Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Router Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Output Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Security Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Input Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:05:19 --> Language Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Loader Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:05:19 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Session Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:05:19 --> Session routines successfully run
DEBUG - 2007-02-01 14:05:19 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:19 --> Controller Class Initialized
ERROR - 2007-02-01 14:05:19 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 14:05:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 14:05:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 14:05:19 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-02-01 14:05:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 14:05:19 --> File loaded: application/views/admin/category.php
DEBUG - 2007-02-01 14:05:19 --> Final output sent to browser
DEBUG - 2007-02-01 14:05:19 --> Total execution time: 0.1596
DEBUG - 2007-02-01 14:05:28 --> Config Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:05:28 --> URI Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Router Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Output Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Security Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Input Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:05:28 --> Language Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Loader Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:05:28 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Session Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:05:28 --> Session routines successfully run
DEBUG - 2007-02-01 14:05:28 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Model Class Initialized
DEBUG - 2007-02-01 14:05:28 --> Controller Class Initialized
DEBUG - 2007-02-01 14:05:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 14:05:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 14:05:28 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 14:05:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 14:05:28 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 14:05:28 --> Final output sent to browser
DEBUG - 2007-02-01 14:05:28 --> Total execution time: 0.1540
DEBUG - 2007-02-01 14:06:03 --> Config Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:06:03 --> URI Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Router Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Output Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Security Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Input Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:06:03 --> Language Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Loader Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:06:03 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Session Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:06:03 --> Session routines successfully run
DEBUG - 2007-02-01 14:06:03 --> Model Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Model Class Initialized
DEBUG - 2007-02-01 14:06:03 --> Controller Class Initialized
DEBUG - 2007-02-01 14:06:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 14:06:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 14:06:03 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 14:06:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 14:06:03 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 14:06:03 --> Final output sent to browser
DEBUG - 2007-02-01 14:06:03 --> Total execution time: 0.1428
DEBUG - 2007-02-01 14:06:05 --> Config Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:06:05 --> URI Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Router Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Output Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Security Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Input Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:06:05 --> Language Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Loader Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:06:05 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Session Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:06:05 --> Session routines successfully run
DEBUG - 2007-02-01 14:06:05 --> Model Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Model Class Initialized
DEBUG - 2007-02-01 14:06:05 --> Controller Class Initialized
DEBUG - 2007-02-01 14:06:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 14:06:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 14:06:05 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 14:06:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 14:06:05 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 14:06:05 --> Final output sent to browser
DEBUG - 2007-02-01 14:06:05 --> Total execution time: 0.1391
DEBUG - 2007-02-01 14:06:10 --> Config Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:06:10 --> URI Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Router Class Initialized
DEBUG - 2007-02-01 14:06:10 --> No URI present. Default controller set.
DEBUG - 2007-02-01 14:06:10 --> Output Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Security Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Input Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 14:06:10 --> Language Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Loader Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Helper loaded: url_helper
DEBUG - 2007-02-01 14:06:10 --> Database Driver Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Session Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Helper loaded: string_helper
DEBUG - 2007-02-01 14:06:10 --> Session routines successfully run
DEBUG - 2007-02-01 14:06:10 --> Model Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Model Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Controller Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Pagination Class Initialized
DEBUG - 2007-02-01 14:06:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 14:06:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 14:06:10 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-01 14:06:10 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-01 14:06:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 14:06:10 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-01 14:06:10 --> Final output sent to browser
DEBUG - 2007-02-01 14:06:10 --> Total execution time: 0.1461
DEBUG - 2007-02-01 14:06:10 --> Config Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Hooks Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Utf8 Class Initialized
DEBUG - 2007-02-01 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 14:06:10 --> URI Class Initialized
DEBUG - 2007-02-01 14:06:10 --> Router Class Initialized
ERROR - 2007-02-01 14:06:10 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:17:32 --> Config Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:17:32 --> URI Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Router Class Initialized
DEBUG - 2007-02-01 18:17:32 --> No URI present. Default controller set.
DEBUG - 2007-02-01 18:17:32 --> Output Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Security Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Input Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:17:32 --> Language Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Loader Class Initialized
DEBUG - 2007-02-01 18:17:32 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:17:32 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Session Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:17:33 --> A session cookie was not found.
DEBUG - 2007-02-01 18:17:33 --> Session routines successfully run
DEBUG - 2007-02-01 18:17:33 --> Model Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Model Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Controller Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Pagination Class Initialized
DEBUG - 2007-02-01 18:17:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:17:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:17:33 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-01 18:17:33 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-01 18:17:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:17:33 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-01 18:17:33 --> Final output sent to browser
DEBUG - 2007-02-01 18:17:33 --> Total execution time: 0.1591
DEBUG - 2007-02-01 18:17:33 --> Config Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:17:33 --> URI Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Router Class Initialized
ERROR - 2007-02-01 18:17:33 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:17:33 --> Config Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:17:33 --> URI Class Initialized
DEBUG - 2007-02-01 18:17:33 --> Router Class Initialized
ERROR - 2007-02-01 18:17:33 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:19:04 --> Config Class Initialized
DEBUG - 2007-02-01 18:19:04 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:19:04 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:19:04 --> URI Class Initialized
DEBUG - 2007-02-01 18:19:04 --> Router Class Initialized
ERROR - 2007-02-01 18:19:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-01 18:23:40 --> Config Class Initialized
DEBUG - 2007-02-01 18:23:40 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:23:40 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:23:40 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:23:40 --> URI Class Initialized
DEBUG - 2007-02-01 18:23:40 --> Router Class Initialized
ERROR - 2007-02-01 18:23:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-01 18:23:44 --> Config Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:23:44 --> URI Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Router Class Initialized
DEBUG - 2007-02-01 18:23:44 --> No URI present. Default controller set.
DEBUG - 2007-02-01 18:23:44 --> Output Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Security Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Input Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:23:44 --> Language Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Loader Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:23:44 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Session Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:23:44 --> Session routines successfully run
DEBUG - 2007-02-01 18:23:44 --> Model Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Model Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Controller Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Pagination Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Config Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:23:44 --> URI Class Initialized
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:23:44 --> Router Class Initialized
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-01 18:23:44 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-01 18:23:44 --> No URI present. Default controller set.
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-01 18:23:44 --> Output Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Final output sent to browser
DEBUG - 2007-02-01 18:23:44 --> Total execution time: 0.1545
DEBUG - 2007-02-01 18:23:44 --> Security Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Input Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:23:44 --> Language Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Loader Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:23:44 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Session Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:23:44 --> Session routines successfully run
DEBUG - 2007-02-01 18:23:44 --> Model Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Model Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Controller Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Pagination Class Initialized
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-01 18:23:44 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:23:44 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-01 18:23:44 --> Final output sent to browser
DEBUG - 2007-02-01 18:23:44 --> Total execution time: 0.1670
DEBUG - 2007-02-01 18:23:44 --> Config Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:23:44 --> URI Class Initialized
DEBUG - 2007-02-01 18:23:44 --> Router Class Initialized
ERROR - 2007-02-01 18:23:44 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:23:45 --> Config Class Initialized
DEBUG - 2007-02-01 18:23:45 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:23:45 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:23:45 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:23:45 --> URI Class Initialized
DEBUG - 2007-02-01 18:23:45 --> Router Class Initialized
ERROR - 2007-02-01 18:23:45 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:28:32 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:32 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:32 --> No URI present. Default controller set.
DEBUG - 2007-02-01 18:28:32 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:32 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:32 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:32 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:32 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Pagination Class Initialized
DEBUG - 2007-02-01 18:28:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:28:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:28:32 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-01 18:28:32 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-01 18:28:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:28:32 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-01 18:28:32 --> Final output sent to browser
DEBUG - 2007-02-01 18:28:32 --> Total execution time: 0.1549
DEBUG - 2007-02-01 18:28:32 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:32 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Router Class Initialized
ERROR - 2007-02-01 18:28:32 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:28:32 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:32 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:32 --> Router Class Initialized
ERROR - 2007-02-01 18:28:32 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:28:33 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:33 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:33 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:33 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:33 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:33 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:33 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:33 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:33 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:33 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:33 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:33 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:33 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:33 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:33 --> File loaded: application/views/admin/login.php
DEBUG - 2007-02-01 18:28:33 --> Final output sent to browser
DEBUG - 2007-02-01 18:28:33 --> Total execution time: 0.1025
DEBUG - 2007-02-01 18:28:35 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:35 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:35 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:35 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:35 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:35 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:35 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:35 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:35 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:35 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:35 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:35 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:35 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Pagination Class Initialized
ERROR - 2007-02-01 18:28:35 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 18:28:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 18:28:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 18:28:35 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 18:28:35 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 18:28:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 18:28:35 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 18:28:35 --> Final output sent to browser
DEBUG - 2007-02-01 18:28:35 --> Total execution time: 0.1523
DEBUG - 2007-02-01 18:28:35 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:35 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:35 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:35 --> Router Class Initialized
ERROR - 2007-02-01 18:28:35 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:28:36 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:36 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:36 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:36 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:36 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:36 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:36 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Pagination Class Initialized
ERROR - 2007-02-01 18:28:36 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 18:28:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 18:28:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 18:28:36 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 18:28:36 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 18:28:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 18:28:36 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 18:28:36 --> Final output sent to browser
DEBUG - 2007-02-01 18:28:36 --> Total execution time: 0.1494
DEBUG - 2007-02-01 18:28:36 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:36 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:36 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:36 --> Router Class Initialized
ERROR - 2007-02-01 18:28:36 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:28:38 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:38 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:38 --> No URI present. Default controller set.
DEBUG - 2007-02-01 18:28:38 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:38 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:38 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:38 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:38 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Pagination Class Initialized
DEBUG - 2007-02-01 18:28:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:28:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:28:38 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-01 18:28:38 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-01 18:28:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:28:38 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-01 18:28:38 --> Final output sent to browser
DEBUG - 2007-02-01 18:28:38 --> Total execution time: 0.1544
DEBUG - 2007-02-01 18:28:38 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:38 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Router Class Initialized
ERROR - 2007-02-01 18:28:38 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:28:38 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:38 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:38 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:38 --> Router Class Initialized
ERROR - 2007-02-01 18:28:38 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:28:40 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:40 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:40 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:40 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:40 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:40 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:40 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:40 --> Controller Class Initialized
DEBUG - 2007-02-01 18:28:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:28:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:28:40 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-02-01 18:28:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:28:40 --> File loaded: application/views/user/article.php
DEBUG - 2007-02-01 18:28:40 --> Final output sent to browser
DEBUG - 2007-02-01 18:28:40 --> Total execution time: 0.1381
DEBUG - 2007-02-01 18:28:51 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:51 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:51 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:51 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:51 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:28:51 --> Session routines successfully run
DEBUG - 2007-02-01 18:28:51 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Model Class Initialized
DEBUG - 2007-02-01 18:28:51 --> Controller Class Initialized
ERROR - 2007-02-01 18:28:51 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 18:28:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 18:28:51 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2007-02-01 18:28:51 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\settings.php 18
DEBUG - 2007-02-01 18:28:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 18:28:51 --> File loaded: application/views/admin/settings.php
DEBUG - 2007-02-01 18:28:51 --> Final output sent to browser
DEBUG - 2007-02-01 18:28:51 --> Total execution time: 0.1681
DEBUG - 2007-02-01 18:28:59 --> Config Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:28:59 --> URI Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Router Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Output Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Security Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Input Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:28:59 --> Language Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Loader Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:28:59 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Session Class Initialized
DEBUG - 2007-02-01 18:28:59 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:29:00 --> Session routines successfully run
DEBUG - 2007-02-01 18:29:00 --> Model Class Initialized
DEBUG - 2007-02-01 18:29:00 --> Model Class Initialized
DEBUG - 2007-02-01 18:29:00 --> Controller Class Initialized
DEBUG - 2007-02-01 18:29:00 --> Pagination Class Initialized
ERROR - 2007-02-01 18:29:00 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-01 18:29:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-01 18:29:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-01 18:29:00 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-01 18:29:00 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-01 18:29:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-01 18:29:00 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-01 18:29:00 --> Final output sent to browser
DEBUG - 2007-02-01 18:29:00 --> Total execution time: 0.2271
DEBUG - 2007-02-01 18:29:00 --> Config Class Initialized
DEBUG - 2007-02-01 18:29:00 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:29:00 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:29:00 --> URI Class Initialized
DEBUG - 2007-02-01 18:29:00 --> Router Class Initialized
ERROR - 2007-02-01 18:29:00 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:52:11 --> Config Class Initialized
DEBUG - 2007-02-01 18:52:11 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:52:11 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:52:11 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:52:11 --> URI Class Initialized
DEBUG - 2007-02-01 18:52:11 --> Router Class Initialized
DEBUG - 2007-02-01 18:52:11 --> Output Class Initialized
DEBUG - 2007-02-01 18:52:11 --> Security Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Input Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:52:12 --> Language Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Loader Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:52:12 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Session Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:52:12 --> Session routines successfully run
DEBUG - 2007-02-01 18:52:12 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:12 --> Controller Class Initialized
DEBUG - 2007-02-01 18:52:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:52:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:52:12 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 18:52:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:52:12 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 18:52:12 --> Final output sent to browser
DEBUG - 2007-02-01 18:52:12 --> Total execution time: 0.1389
DEBUG - 2007-02-01 18:52:13 --> Config Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:52:13 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:52:13 --> URI Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Router Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Output Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Security Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Input Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:52:13 --> Language Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Loader Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:52:13 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Session Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:52:13 --> Session routines successfully run
DEBUG - 2007-02-01 18:52:13 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:13 --> Controller Class Initialized
DEBUG - 2007-02-01 18:52:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:52:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:52:13 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 18:52:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:52:13 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 18:52:13 --> Final output sent to browser
DEBUG - 2007-02-01 18:52:13 --> Total execution time: 0.1360
DEBUG - 2007-02-01 18:52:14 --> Config Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:52:14 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:52:14 --> URI Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Router Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Output Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Security Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Input Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:52:14 --> Language Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Loader Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:52:14 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Session Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:52:14 --> Session routines successfully run
DEBUG - 2007-02-01 18:52:14 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Controller Class Initialized
DEBUG - 2007-02-01 18:52:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:52:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:52:14 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 18:52:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:52:14 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 18:52:14 --> Final output sent to browser
DEBUG - 2007-02-01 18:52:14 --> Total execution time: 0.1352
DEBUG - 2007-02-01 18:52:14 --> Config Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:52:14 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:52:14 --> URI Class Initialized
DEBUG - 2007-02-01 18:52:14 --> Router Class Initialized
ERROR - 2007-02-01 18:52:14 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-01 18:52:15 --> Config Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:52:15 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:52:15 --> URI Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Router Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Output Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Security Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Input Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:52:15 --> Language Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Loader Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:52:15 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Session Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:52:15 --> Session routines successfully run
DEBUG - 2007-02-01 18:52:15 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:15 --> Controller Class Initialized
DEBUG - 2007-02-01 18:52:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:52:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:52:15 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 18:52:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:52:15 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 18:52:15 --> Final output sent to browser
DEBUG - 2007-02-01 18:52:15 --> Total execution time: 0.1381
DEBUG - 2007-02-01 18:52:17 --> Config Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Hooks Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Utf8 Class Initialized
DEBUG - 2007-02-01 18:52:17 --> UTF-8 Support Enabled
DEBUG - 2007-02-01 18:52:17 --> URI Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Router Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Output Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Security Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Input Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-01 18:52:17 --> Language Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Loader Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Helper loaded: url_helper
DEBUG - 2007-02-01 18:52:17 --> Database Driver Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Session Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Helper loaded: string_helper
DEBUG - 2007-02-01 18:52:17 --> Session routines successfully run
DEBUG - 2007-02-01 18:52:17 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Model Class Initialized
DEBUG - 2007-02-01 18:52:17 --> Controller Class Initialized
DEBUG - 2007-02-01 18:52:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-01 18:52:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-01 18:52:17 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-02-01 18:52:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-01 18:52:17 --> File loaded: application/views/user/category.php
DEBUG - 2007-02-01 18:52:17 --> Final output sent to browser
DEBUG - 2007-02-01 18:52:17 --> Total execution time: 0.1269

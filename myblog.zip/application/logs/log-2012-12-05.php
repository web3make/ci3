<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-12-05 00:09:34 --> Config Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Hooks Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Utf8 Class Initialized
DEBUG - 2012-12-05 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 00:09:34 --> URI Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Router Class Initialized
DEBUG - 2012-12-05 00:09:34 --> No URI present. Default controller set.
DEBUG - 2012-12-05 00:09:34 --> Output Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Security Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Input Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-05 00:09:34 --> Language Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Loader Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Helper loaded: url_helper
DEBUG - 2012-12-05 00:09:34 --> Database Driver Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Session Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Helper loaded: string_helper
DEBUG - 2012-12-05 00:09:34 --> A session cookie was not found.
DEBUG - 2012-12-05 00:09:34 --> Session routines successfully run
DEBUG - 2012-12-05 00:09:34 --> Model Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Model Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Controller Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Pagination Class Initialized
DEBUG - 2012-12-05 00:09:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-12-05 00:09:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-12-05 00:09:34 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2012-12-05 00:09:34 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2012-12-05 00:09:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-12-05 00:09:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-12-05 00:09:34 --> Final output sent to browser
DEBUG - 2012-12-05 00:09:34 --> Total execution time: 0.5799
DEBUG - 2012-12-05 00:09:34 --> Config Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Hooks Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Utf8 Class Initialized
DEBUG - 2012-12-05 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 00:09:34 --> URI Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Router Class Initialized
ERROR - 2012-12-05 00:09:34 --> 404 Page Not Found --> lessons
DEBUG - 2012-12-05 00:09:34 --> Config Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Hooks Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Utf8 Class Initialized
DEBUG - 2012-12-05 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 00:09:34 --> URI Class Initialized
DEBUG - 2012-12-05 00:09:34 --> Router Class Initialized
ERROR - 2012-12-05 00:09:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-12-05 12:04:09 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:09 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:09 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Router Class Initialized
DEBUG - 2012-12-05 12:04:09 --> No URI present. Default controller set.
DEBUG - 2012-12-05 12:04:09 --> Output Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Security Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Input Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-05 12:04:09 --> Language Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Loader Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Helper loaded: url_helper
DEBUG - 2012-12-05 12:04:09 --> Database Driver Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Session Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Helper loaded: string_helper
DEBUG - 2012-12-05 12:04:09 --> A session cookie was not found.
DEBUG - 2012-12-05 12:04:09 --> Session routines successfully run
DEBUG - 2012-12-05 12:04:09 --> Model Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Model Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Controller Class Initialized
DEBUG - 2012-12-05 12:04:09 --> Pagination Class Initialized
DEBUG - 2012-12-05 12:04:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-12-05 12:04:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-12-05 12:04:09 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2012-12-05 12:04:09 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2012-12-05 12:04:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-12-05 12:04:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-12-05 12:04:09 --> Final output sent to browser
DEBUG - 2012-12-05 12:04:09 --> Total execution time: 0.5572
DEBUG - 2012-12-05 12:04:10 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:10 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:10 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:10 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:10 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:10 --> Router Class Initialized
ERROR - 2012-12-05 12:04:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-12-05 12:04:41 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:41 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Router Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Output Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Security Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Input Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-05 12:04:41 --> Language Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:41 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:41 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:41 --> Router Class Initialized
ERROR - 2012-12-05 12:04:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-12-05 12:04:48 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:48 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:48 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:48 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:48 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:48 --> Router Class Initialized
ERROR - 2012-12-05 12:04:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-12-05 12:04:49 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:50 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:50 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Router Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Output Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Security Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Input Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-05 12:04:50 --> Language Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:50 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:50 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:50 --> Router Class Initialized
ERROR - 2012-12-05 12:04:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-12-05 12:04:51 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:51 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:51 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:51 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:51 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:51 --> Router Class Initialized
ERROR - 2012-12-05 12:04:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-12-05 12:04:54 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:54 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:54 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Router Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Output Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Security Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Input Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-05 12:04:54 --> Language Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Loader Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Helper loaded: url_helper
DEBUG - 2012-12-05 12:04:54 --> Database Driver Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Session Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Helper loaded: string_helper
DEBUG - 2012-12-05 12:04:54 --> A session cookie was not found.
DEBUG - 2012-12-05 12:04:54 --> Session routines successfully run
DEBUG - 2012-12-05 12:04:54 --> Model Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Model Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Controller Class Initialized
DEBUG - 2012-12-05 12:04:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-12-05 12:04:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-12-05 12:04:54 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2012-12-05 12:04:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-12-05 12:04:54 --> File loaded: application/views/user/article.php
DEBUG - 2012-12-05 12:04:54 --> Final output sent to browser
DEBUG - 2012-12-05 12:04:54 --> Total execution time: 0.2177
DEBUG - 2012-12-05 12:04:54 --> Config Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:04:54 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:04:54 --> URI Class Initialized
DEBUG - 2012-12-05 12:04:54 --> Router Class Initialized
ERROR - 2012-12-05 12:04:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-12-05 12:05:40 --> Config Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:05:40 --> URI Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Router Class Initialized
DEBUG - 2012-12-05 12:05:40 --> No URI present. Default controller set.
DEBUG - 2012-12-05 12:05:40 --> Output Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Security Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Input Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-12-05 12:05:40 --> Language Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Loader Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Helper loaded: url_helper
DEBUG - 2012-12-05 12:05:40 --> Database Driver Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Session Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Helper loaded: string_helper
DEBUG - 2012-12-05 12:05:40 --> Session routines successfully run
DEBUG - 2012-12-05 12:05:40 --> Model Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Model Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Controller Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Pagination Class Initialized
DEBUG - 2012-12-05 12:05:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-12-05 12:05:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-12-05 12:05:40 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2012-12-05 12:05:40 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2012-12-05 12:05:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-12-05 12:05:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-12-05 12:05:40 --> Final output sent to browser
DEBUG - 2012-12-05 12:05:40 --> Total execution time: 0.2288
DEBUG - 2012-12-05 12:05:40 --> Config Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:05:40 --> URI Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Router Class Initialized
ERROR - 2012-12-05 12:05:40 --> 404 Page Not Found --> lessons
DEBUG - 2012-12-05 12:05:40 --> Config Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Hooks Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Utf8 Class Initialized
DEBUG - 2012-12-05 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2012-12-05 12:05:40 --> URI Class Initialized
DEBUG - 2012-12-05 12:05:40 --> Router Class Initialized
ERROR - 2012-12-05 12:05:40 --> 404 Page Not Found --> favicon.ico

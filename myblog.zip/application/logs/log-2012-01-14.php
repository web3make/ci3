<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-14 00:08:11 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:11 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:11 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:11 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:11 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:11 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:11 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 00:08:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 00:08:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 00:08:11 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 00:08:11 --> Final output sent to browser
DEBUG - 2012-01-14 00:08:11 --> Total execution time: 0.1986
DEBUG - 2012-01-14 00:08:16 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:16 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:16 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:16 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:16 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:17 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:17 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:17 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:17 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:17 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:17 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:17 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:17 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:17 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:17 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 00:08:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 00:08:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 00:08:17 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 00:08:17 --> Final output sent to browser
DEBUG - 2012-01-14 00:08:17 --> Total execution time: 0.1777
DEBUG - 2012-01-14 00:08:21 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:21 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:21 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:21 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:21 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:21 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:21 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 00:08:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 00:08:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 00:08:21 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 00:08:21 --> Final output sent to browser
DEBUG - 2012-01-14 00:08:21 --> Total execution time: 0.2753
DEBUG - 2012-01-14 00:08:24 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:24 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:24 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:24 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:24 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:24 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:24 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:24 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:24 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:24 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:24 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:24 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 00:08:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 00:08:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 00:08:24 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 00:08:24 --> Final output sent to browser
DEBUG - 2012-01-14 00:08:24 --> Total execution time: 0.2018
DEBUG - 2012-01-14 00:08:26 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:26 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:26 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:26 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:26 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:26 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:26 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 00:08:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 00:08:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 00:08:26 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 00:08:26 --> Final output sent to browser
DEBUG - 2012-01-14 00:08:26 --> Total execution time: 0.2102
DEBUG - 2012-01-14 00:08:43 --> Config Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:08:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:08:43 --> URI Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Router Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Output Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Security Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Input Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:08:43 --> Language Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Loader Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:08:43 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Session Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:08:43 --> Session routines successfully run
DEBUG - 2012-01-14 00:08:43 --> Controller Class Initialized
DEBUG - 2012-01-14 00:08:43 --> Pagination Class Initialized
DEBUG - 2012-01-14 00:08:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 00:08:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 00:08:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 00:08:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 00:08:43 --> Final output sent to browser
DEBUG - 2012-01-14 00:08:43 --> Total execution time: 0.1615
DEBUG - 2012-01-14 00:18:25 --> Config Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:18:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:18:25 --> URI Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Router Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Output Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Security Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Input Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:18:25 --> Language Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Loader Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:18:25 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Session Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:18:25 --> Session routines successfully run
DEBUG - 2012-01-14 00:18:25 --> Controller Class Initialized
DEBUG - 2012-01-14 00:18:25 --> Pagination Class Initialized
DEBUG - 2012-01-14 00:18:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 00:18:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 00:18:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 00:18:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 00:18:25 --> Final output sent to browser
DEBUG - 2012-01-14 00:18:25 --> Total execution time: 0.2198
DEBUG - 2012-01-14 00:18:49 --> Config Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:18:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:18:49 --> URI Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Router Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Output Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Security Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Input Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:18:49 --> Language Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Loader Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:18:49 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Session Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:18:49 --> Session routines successfully run
DEBUG - 2012-01-14 00:18:49 --> Controller Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Config Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:18:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:18:49 --> URI Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Router Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Output Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Security Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Input Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 00:18:49 --> Language Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Loader Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Helper loaded: url_helper
DEBUG - 2012-01-14 00:18:49 --> Database Driver Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Session Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Helper loaded: string_helper
DEBUG - 2012-01-14 00:18:49 --> Session routines successfully run
DEBUG - 2012-01-14 00:18:49 --> Controller Class Initialized
DEBUG - 2012-01-14 00:18:49 --> Pagination Class Initialized
DEBUG - 2012-01-14 00:18:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 00:18:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 00:18:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 00:18:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 00:18:50 --> Final output sent to browser
DEBUG - 2012-01-14 00:18:50 --> Total execution time: 0.2131
DEBUG - 2012-01-14 00:22:40 --> Config Class Initialized
DEBUG - 2012-01-14 00:22:40 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:22:40 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:22:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:22:40 --> URI Class Initialized
DEBUG - 2012-01-14 00:22:40 --> Router Class Initialized
ERROR - 2012-01-14 00:22:40 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:23:47 --> Config Class Initialized
DEBUG - 2012-01-14 00:23:47 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:23:47 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:23:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:23:47 --> URI Class Initialized
DEBUG - 2012-01-14 00:23:47 --> Router Class Initialized
ERROR - 2012-01-14 00:23:47 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:26:10 --> Config Class Initialized
DEBUG - 2012-01-14 00:26:10 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:26:10 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:26:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:26:10 --> URI Class Initialized
DEBUG - 2012-01-14 00:26:10 --> Router Class Initialized
ERROR - 2012-01-14 00:26:10 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:26:17 --> Config Class Initialized
DEBUG - 2012-01-14 00:26:17 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:26:17 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:26:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:26:17 --> URI Class Initialized
DEBUG - 2012-01-14 00:26:17 --> Router Class Initialized
ERROR - 2012-01-14 00:26:17 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:26:24 --> Config Class Initialized
DEBUG - 2012-01-14 00:26:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:26:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:26:24 --> URI Class Initialized
DEBUG - 2012-01-14 00:26:24 --> Router Class Initialized
ERROR - 2012-01-14 00:26:24 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:26:29 --> Config Class Initialized
DEBUG - 2012-01-14 00:26:29 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:26:29 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:26:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:26:29 --> URI Class Initialized
DEBUG - 2012-01-14 00:26:29 --> Router Class Initialized
ERROR - 2012-01-14 00:26:29 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:27:56 --> Config Class Initialized
DEBUG - 2012-01-14 00:27:56 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:27:56 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:27:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:27:56 --> URI Class Initialized
DEBUG - 2012-01-14 00:27:56 --> Router Class Initialized
ERROR - 2012-01-14 00:27:56 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:28:39 --> Config Class Initialized
DEBUG - 2012-01-14 00:28:39 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:28:39 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:28:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:28:39 --> URI Class Initialized
DEBUG - 2012-01-14 00:28:39 --> Router Class Initialized
ERROR - 2012-01-14 00:28:39 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:28:40 --> Config Class Initialized
DEBUG - 2012-01-14 00:28:40 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:28:40 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:28:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:28:40 --> URI Class Initialized
DEBUG - 2012-01-14 00:28:40 --> Router Class Initialized
ERROR - 2012-01-14 00:28:40 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:28:46 --> Config Class Initialized
DEBUG - 2012-01-14 00:28:46 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:28:46 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:28:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:28:46 --> URI Class Initialized
DEBUG - 2012-01-14 00:28:46 --> Router Class Initialized
ERROR - 2012-01-14 00:28:46 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:33:21 --> Config Class Initialized
DEBUG - 2012-01-14 00:33:21 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:33:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:33:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:33:21 --> URI Class Initialized
DEBUG - 2012-01-14 00:33:21 --> Router Class Initialized
ERROR - 2012-01-14 00:33:21 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:33:28 --> Config Class Initialized
DEBUG - 2012-01-14 00:33:28 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:33:28 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:33:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:33:28 --> URI Class Initialized
DEBUG - 2012-01-14 00:33:28 --> Router Class Initialized
ERROR - 2012-01-14 00:33:28 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:34:14 --> Config Class Initialized
DEBUG - 2012-01-14 00:34:14 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:34:14 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:34:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:34:14 --> URI Class Initialized
DEBUG - 2012-01-14 00:34:14 --> Router Class Initialized
ERROR - 2012-01-14 00:34:14 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:35:24 --> Config Class Initialized
DEBUG - 2012-01-14 00:35:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:35:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:35:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:35:24 --> URI Class Initialized
DEBUG - 2012-01-14 00:35:24 --> Router Class Initialized
ERROR - 2012-01-14 00:35:24 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 00:35:27 --> Config Class Initialized
DEBUG - 2012-01-14 00:35:27 --> Hooks Class Initialized
DEBUG - 2012-01-14 00:35:27 --> Utf8 Class Initialized
DEBUG - 2012-01-14 00:35:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 00:35:27 --> URI Class Initialized
DEBUG - 2012-01-14 00:35:27 --> Router Class Initialized
ERROR - 2012-01-14 00:35:27 --> 404 Page Not Found --> lessons
DEBUG - 2012-01-14 01:37:38 --> Config Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:37:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:37:38 --> URI Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Router Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Output Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Security Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Input Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:37:38 --> Language Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Loader Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:37:38 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Session Class Initialized
DEBUG - 2012-01-14 01:37:38 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:37:38 --> Session routines successfully run
DEBUG - 2012-01-14 01:37:38 --> Controller Class Initialized
DEBUG - 2012-01-14 01:37:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:37:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:37:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:37:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 01:37:38 --> Final output sent to browser
DEBUG - 2012-01-14 01:37:38 --> Total execution time: 0.2380
DEBUG - 2012-01-14 01:37:43 --> Config Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:37:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:37:43 --> URI Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Router Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Output Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Security Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Input Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:37:43 --> Language Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Loader Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:37:43 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Session Class Initialized
DEBUG - 2012-01-14 01:37:43 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:37:43 --> Session routines successfully run
DEBUG - 2012-01-14 01:37:43 --> Controller Class Initialized
DEBUG - 2012-01-14 01:37:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:37:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:37:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:37:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 01:37:43 --> Final output sent to browser
DEBUG - 2012-01-14 01:37:43 --> Total execution time: 0.2034
DEBUG - 2012-01-14 01:37:45 --> Config Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:37:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:37:45 --> URI Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Router Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Output Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Security Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Input Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:37:45 --> Language Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Loader Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:37:45 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Session Class Initialized
DEBUG - 2012-01-14 01:37:45 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:37:45 --> Session routines successfully run
DEBUG - 2012-01-14 01:37:45 --> Controller Class Initialized
DEBUG - 2012-01-14 01:37:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:37:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:37:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:37:45 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 01:37:45 --> Final output sent to browser
DEBUG - 2012-01-14 01:37:45 --> Total execution time: 0.2626
DEBUG - 2012-01-14 01:37:47 --> Config Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:37:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:37:47 --> URI Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Router Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Output Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Security Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Input Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:37:47 --> Language Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Loader Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:37:47 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Session Class Initialized
DEBUG - 2012-01-14 01:37:47 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:37:47 --> Session routines successfully run
DEBUG - 2012-01-14 01:37:47 --> Controller Class Initialized
DEBUG - 2012-01-14 01:37:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:37:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:37:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:37:47 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 01:37:47 --> Final output sent to browser
DEBUG - 2012-01-14 01:37:47 --> Total execution time: 0.3424
DEBUG - 2012-01-14 01:37:50 --> Config Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:37:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:37:50 --> URI Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Router Class Initialized
DEBUG - 2012-01-14 01:37:50 --> No URI present. Default controller set.
DEBUG - 2012-01-14 01:37:50 --> Output Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Security Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Input Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:37:50 --> Language Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Loader Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:37:50 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Session Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:37:50 --> Session routines successfully run
DEBUG - 2012-01-14 01:37:50 --> Controller Class Initialized
DEBUG - 2012-01-14 01:37:50 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:37:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:37:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:37:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:37:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:37:50 --> Final output sent to browser
DEBUG - 2012-01-14 01:37:50 --> Total execution time: 0.1928
DEBUG - 2012-01-14 01:37:52 --> Config Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:37:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:37:52 --> URI Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Router Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Output Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Security Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Input Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:37:52 --> Language Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Loader Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:37:52 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Session Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:37:52 --> Session routines successfully run
DEBUG - 2012-01-14 01:37:52 --> Controller Class Initialized
DEBUG - 2012-01-14 01:37:52 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:37:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:37:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:37:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:37:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:37:53 --> Final output sent to browser
DEBUG - 2012-01-14 01:37:53 --> Total execution time: 0.3008
DEBUG - 2012-01-14 01:40:52 --> Config Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:40:52 --> URI Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Router Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Output Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Security Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Input Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:40:52 --> Language Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Loader Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:40:52 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Session Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:40:52 --> Session routines successfully run
DEBUG - 2012-01-14 01:40:52 --> Controller Class Initialized
DEBUG - 2012-01-14 01:40:52 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:40:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:40:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:40:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:40:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:40:53 --> Final output sent to browser
DEBUG - 2012-01-14 01:40:53 --> Total execution time: 0.5338
DEBUG - 2012-01-14 01:41:10 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:10 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:10 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:10 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:10 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:10 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:10 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:11 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:11 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:11 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:11 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:11 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:11 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:11 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:11 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:11 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:41:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:41:11 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 01:41:11 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:11 --> Total execution time: 0.4855
DEBUG - 2012-01-14 01:41:12 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:12 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:12 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:12 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:12 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:12 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:12 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:13 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:13 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:13 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:13 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:13 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:13 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:13 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:13 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:13 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:41:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:41:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 01:41:13 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:13 --> Total execution time: 0.5707
DEBUG - 2012-01-14 01:41:17 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:17 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:17 --> No URI present. Default controller set.
DEBUG - 2012-01-14 01:41:17 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:17 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:17 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:17 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:17 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:17 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:18 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:41:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:41:18 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:18 --> Total execution time: 1.2348
DEBUG - 2012-01-14 01:41:21 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:21 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:21 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:21 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:21 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:22 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:22 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:22 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:22 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:41:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:41:22 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:22 --> Total execution time: 0.7774
DEBUG - 2012-01-14 01:41:24 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:24 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:24 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:24 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:24 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:24 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:24 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:25 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:25 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:25 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:25 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:25 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:25 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:25 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:25 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:41:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:41:25 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:25 --> Total execution time: 1.1347
DEBUG - 2012-01-14 01:41:33 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:33 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:33 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:33 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:33 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:33 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:33 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 01:41:33 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:34 --> Total execution time: 0.4881
DEBUG - 2012-01-14 01:41:35 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:35 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:35 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:35 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:35 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:35 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:35 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 01:41:35 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:35 --> Total execution time: 0.4809
DEBUG - 2012-01-14 01:41:37 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:37 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:37 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:37 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:37 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:38 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:38 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:38 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 01:41:38 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:38 --> Total execution time: 0.5983
DEBUG - 2012-01-14 01:41:42 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:42 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:42 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:42 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:42 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:42 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:42 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 01:41:43 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:43 --> Total execution time: 0.5470
DEBUG - 2012-01-14 01:41:45 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:45 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:45 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:45 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:45 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:45 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:45 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:45 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 01:41:45 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:45 --> Total execution time: 0.5621
DEBUG - 2012-01-14 01:41:51 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:51 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:51 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:51 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:51 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:51 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:51 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:51 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 01:41:51 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:51 --> Total execution time: 0.4634
DEBUG - 2012-01-14 01:41:53 --> Config Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:41:53 --> URI Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Router Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Output Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Security Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Input Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:41:53 --> Language Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Loader Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:41:53 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Session Class Initialized
DEBUG - 2012-01-14 01:41:53 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:41:53 --> Session routines successfully run
DEBUG - 2012-01-14 01:41:53 --> Controller Class Initialized
DEBUG - 2012-01-14 01:41:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:41:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:41:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:41:54 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 01:41:54 --> Final output sent to browser
DEBUG - 2012-01-14 01:41:54 --> Total execution time: 0.5088
DEBUG - 2012-01-14 01:42:02 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:02 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:02 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:02 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:02 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:02 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:02 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:42:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:42:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:42:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:42:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 01:42:02 --> Final output sent to browser
DEBUG - 2012-01-14 01:42:03 --> Total execution time: 0.5351
DEBUG - 2012-01-14 01:42:05 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:05 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:05 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:05 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:05 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:05 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:05 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:42:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:42:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:42:05 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 01:42:05 --> Final output sent to browser
DEBUG - 2012-01-14 01:42:05 --> Total execution time: 0.6039
DEBUG - 2012-01-14 01:42:07 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:07 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:07 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:07 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:07 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:07 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:07 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:42:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:42:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:42:07 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-14 01:42:07 --> Final output sent to browser
DEBUG - 2012-01-14 01:42:07 --> Total execution time: 0.8381
DEBUG - 2012-01-14 01:42:10 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:10 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:10 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:10 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:10 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:10 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:10 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:42:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:42:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:42:11 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 01:42:11 --> Final output sent to browser
DEBUG - 2012-01-14 01:42:11 --> Total execution time: 0.6340
DEBUG - 2012-01-14 01:42:12 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:12 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:12 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:12 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:12 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:13 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:13 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:13 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:13 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:13 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:14 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:14 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:14 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:14 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:15 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:15 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:42:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:42:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:42:15 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 01:42:15 --> Final output sent to browser
DEBUG - 2012-01-14 01:42:15 --> Total execution time: 1.1133
DEBUG - 2012-01-14 01:42:16 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:16 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:16 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:16 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:16 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:16 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:16 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Config Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:42:17 --> URI Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Router Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Output Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Security Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Input Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:42:17 --> Language Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Loader Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:42:17 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Session Class Initialized
DEBUG - 2012-01-14 01:42:17 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:42:17 --> Session routines successfully run
DEBUG - 2012-01-14 01:42:17 --> Controller Class Initialized
DEBUG - 2012-01-14 01:42:17 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:42:17 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:42:17 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:42:17 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 01:42:17 --> Final output sent to browser
DEBUG - 2012-01-14 01:42:17 --> Total execution time: 0.5049
DEBUG - 2012-01-14 01:49:19 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:19 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:19 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:19 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:19 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:19 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:19 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:49:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:49:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:49:19 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 01:49:19 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:19 --> Total execution time: 0.3014
DEBUG - 2012-01-14 01:49:23 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:23 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:23 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:23 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:23 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:23 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:23 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:49:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:49:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:49:23 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 01:49:23 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:23 --> Total execution time: 0.1722
DEBUG - 2012-01-14 01:49:25 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:25 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:25 --> No URI present. Default controller set.
DEBUG - 2012-01-14 01:49:25 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:25 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:25 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:25 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:25 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:25 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:49:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:49:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:49:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:49:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:49:25 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:25 --> Total execution time: 0.1915
DEBUG - 2012-01-14 01:49:28 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:28 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:28 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:28 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:28 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:28 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:28 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:49:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:49:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:49:29 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-14 01:49:29 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:29 --> Total execution time: 0.2172
DEBUG - 2012-01-14 01:49:30 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:30 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:30 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:30 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:30 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:30 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:30 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:49:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:49:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:49:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:49:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 01:49:30 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:30 --> Total execution time: 0.2088
DEBUG - 2012-01-14 01:49:46 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:46 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:46 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:46 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:46 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:46 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:46 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:46 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:46 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:46 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:46 --> A session cookie was not found.
DEBUG - 2012-01-14 01:49:46 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:46 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:46 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-14 01:49:46 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:46 --> Total execution time: 0.1431
DEBUG - 2012-01-14 01:49:49 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:49 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:49 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:49 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:49 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:49 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:49 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:49 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-14 01:49:49 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:49 --> Total execution time: 0.1593
DEBUG - 2012-01-14 01:49:52 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:52 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:52 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:52 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:52 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:52 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:52 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:52 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-14 01:49:52 --> Final output sent to browser
DEBUG - 2012-01-14 01:49:52 --> Total execution time: 0.2345
DEBUG - 2012-01-14 01:49:59 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:59 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:59 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:59 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:59 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:59 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Config Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:49:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:49:59 --> URI Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Router Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Output Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Security Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Input Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:49:59 --> Language Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Loader Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:49:59 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Session Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:49:59 --> Session routines successfully run
DEBUG - 2012-01-14 01:49:59 --> Controller Class Initialized
DEBUG - 2012-01-14 01:49:59 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:50:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 01:50:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 01:50:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 01:50:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 01:50:00 --> Final output sent to browser
DEBUG - 2012-01-14 01:50:00 --> Total execution time: 0.1921
DEBUG - 2012-01-14 01:50:03 --> Config Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Hooks Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Utf8 Class Initialized
DEBUG - 2012-01-14 01:50:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 01:50:03 --> URI Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Router Class Initialized
DEBUG - 2012-01-14 01:50:03 --> No URI present. Default controller set.
DEBUG - 2012-01-14 01:50:03 --> Output Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Security Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Input Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 01:50:03 --> Language Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Loader Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Helper loaded: url_helper
DEBUG - 2012-01-14 01:50:03 --> Database Driver Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Session Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Helper loaded: string_helper
DEBUG - 2012-01-14 01:50:03 --> Session routines successfully run
DEBUG - 2012-01-14 01:50:03 --> Controller Class Initialized
DEBUG - 2012-01-14 01:50:03 --> Pagination Class Initialized
DEBUG - 2012-01-14 01:50:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 01:50:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 01:50:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 01:50:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 01:50:03 --> Final output sent to browser
DEBUG - 2012-01-14 01:50:03 --> Total execution time: 0.2182
DEBUG - 2012-01-14 02:11:57 --> Config Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Hooks Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Utf8 Class Initialized
DEBUG - 2012-01-14 02:11:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 02:11:57 --> URI Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Router Class Initialized
DEBUG - 2012-01-14 02:11:57 --> No URI present. Default controller set.
DEBUG - 2012-01-14 02:11:57 --> Output Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Security Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Input Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 02:11:57 --> Language Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Loader Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Helper loaded: url_helper
DEBUG - 2012-01-14 02:11:57 --> Database Driver Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Session Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Helper loaded: string_helper
DEBUG - 2012-01-14 02:11:57 --> Session routines successfully run
DEBUG - 2012-01-14 02:11:57 --> Controller Class Initialized
DEBUG - 2012-01-14 02:11:57 --> Pagination Class Initialized
DEBUG - 2012-01-14 02:11:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 02:11:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 02:11:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 02:11:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 02:11:57 --> Final output sent to browser
DEBUG - 2012-01-14 02:11:57 --> Total execution time: 0.2037
DEBUG - 2012-01-14 02:12:04 --> Config Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Hooks Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Utf8 Class Initialized
DEBUG - 2012-01-14 02:12:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 02:12:04 --> URI Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Router Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Output Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Security Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Input Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 02:12:04 --> Language Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Loader Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Helper loaded: url_helper
DEBUG - 2012-01-14 02:12:04 --> Database Driver Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Session Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Helper loaded: string_helper
DEBUG - 2012-01-14 02:12:04 --> Session routines successfully run
DEBUG - 2012-01-14 02:12:04 --> Controller Class Initialized
DEBUG - 2012-01-14 02:12:04 --> Pagination Class Initialized
DEBUG - 2012-01-14 02:12:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 02:12:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 02:12:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 02:12:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 02:12:04 --> Final output sent to browser
DEBUG - 2012-01-14 02:12:04 --> Total execution time: 0.1856
DEBUG - 2012-01-14 19:45:53 --> Config Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:45:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:45:53 --> URI Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Router Class Initialized
DEBUG - 2012-01-14 19:45:53 --> No URI present. Default controller set.
DEBUG - 2012-01-14 19:45:53 --> Output Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Security Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Input Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 19:45:53 --> Language Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Loader Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Helper loaded: url_helper
DEBUG - 2012-01-14 19:45:53 --> Database Driver Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Session Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Helper loaded: string_helper
DEBUG - 2012-01-14 19:45:53 --> A session cookie was not found.
DEBUG - 2012-01-14 19:45:53 --> Session routines successfully run
DEBUG - 2012-01-14 19:45:53 --> Controller Class Initialized
DEBUG - 2012-01-14 19:45:53 --> Pagination Class Initialized
DEBUG - 2012-01-14 19:45:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 19:45:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 19:45:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 19:45:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 19:45:54 --> Final output sent to browser
DEBUG - 2012-01-14 19:45:54 --> Total execution time: 0.5105
DEBUG - 2012-01-14 19:45:54 --> Config Class Initialized
DEBUG - 2012-01-14 19:45:54 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:45:54 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:45:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:45:54 --> URI Class Initialized
DEBUG - 2012-01-14 19:45:54 --> Router Class Initialized
ERROR - 2012-01-14 19:45:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 19:54:49 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:49 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Router Class Initialized
DEBUG - 2012-01-14 19:54:49 --> No URI present. Default controller set.
DEBUG - 2012-01-14 19:54:49 --> Output Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Security Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Input Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 19:54:49 --> Language Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Loader Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Helper loaded: url_helper
DEBUG - 2012-01-14 19:54:49 --> Database Driver Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Session Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Helper loaded: string_helper
DEBUG - 2012-01-14 19:54:49 --> Session routines successfully run
DEBUG - 2012-01-14 19:54:49 --> Controller Class Initialized
DEBUG - 2012-01-14 19:54:49 --> Pagination Class Initialized
DEBUG - 2012-01-14 19:54:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 19:54:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 19:54:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 19:54:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 19:54:49 --> Final output sent to browser
DEBUG - 2012-01-14 19:54:49 --> Total execution time: 0.4492
DEBUG - 2012-01-14 19:54:50 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:50 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:50 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:50 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:50 --> Router Class Initialized
ERROR - 2012-01-14 19:54:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 19:54:53 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:53 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Router Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Output Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Security Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Input Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 19:54:53 --> Language Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Loader Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Helper loaded: url_helper
DEBUG - 2012-01-14 19:54:53 --> Database Driver Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Session Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Helper loaded: string_helper
DEBUG - 2012-01-14 19:54:53 --> Session routines successfully run
DEBUG - 2012-01-14 19:54:53 --> Controller Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Model Class Initialized
DEBUG - 2012-01-14 19:54:53 --> Model Class Initialized
DEBUG - 2012-01-14 19:54:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 19:54:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 19:54:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 19:54:54 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 19:54:54 --> Final output sent to browser
DEBUG - 2012-01-14 19:54:54 --> Total execution time: 0.4989
DEBUG - 2012-01-14 19:54:54 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:54 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:54 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:54 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:54 --> Router Class Initialized
ERROR - 2012-01-14 19:54:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 19:54:56 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:56 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Router Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Output Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Security Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Input Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 19:54:56 --> Language Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Loader Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Helper loaded: url_helper
DEBUG - 2012-01-14 19:54:56 --> Database Driver Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Session Class Initialized
DEBUG - 2012-01-14 19:54:56 --> Helper loaded: string_helper
DEBUG - 2012-01-14 19:54:56 --> Session routines successfully run
DEBUG - 2012-01-14 19:54:56 --> Controller Class Initialized
DEBUG - 2012-01-14 19:54:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 19:54:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 19:54:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 19:54:57 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 19:54:57 --> Final output sent to browser
DEBUG - 2012-01-14 19:54:57 --> Total execution time: 0.3942
DEBUG - 2012-01-14 19:54:57 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:57 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:57 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:57 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:57 --> Router Class Initialized
ERROR - 2012-01-14 19:54:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 19:54:58 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:58 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Router Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Output Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Security Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Input Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 19:54:58 --> Language Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Loader Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Helper loaded: url_helper
DEBUG - 2012-01-14 19:54:58 --> Database Driver Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Session Class Initialized
DEBUG - 2012-01-14 19:54:58 --> Helper loaded: string_helper
DEBUG - 2012-01-14 19:54:58 --> Session routines successfully run
DEBUG - 2012-01-14 19:54:58 --> Controller Class Initialized
DEBUG - 2012-01-14 19:54:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 19:54:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 19:54:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 19:54:58 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 19:54:58 --> Final output sent to browser
DEBUG - 2012-01-14 19:54:58 --> Total execution time: 0.3920
DEBUG - 2012-01-14 19:54:59 --> Config Class Initialized
DEBUG - 2012-01-14 19:54:59 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:54:59 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:54:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:54:59 --> URI Class Initialized
DEBUG - 2012-01-14 19:54:59 --> Router Class Initialized
ERROR - 2012-01-14 19:54:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 19:55:00 --> Config Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:55:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:55:00 --> URI Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Router Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Output Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Security Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Input Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 19:55:00 --> Language Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Loader Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Helper loaded: url_helper
DEBUG - 2012-01-14 19:55:00 --> Database Driver Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Session Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Helper loaded: string_helper
DEBUG - 2012-01-14 19:55:00 --> Session routines successfully run
DEBUG - 2012-01-14 19:55:00 --> Controller Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Model Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Model Class Initialized
DEBUG - 2012-01-14 19:55:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 19:55:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 19:55:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 19:55:00 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 19:55:00 --> Final output sent to browser
DEBUG - 2012-01-14 19:55:00 --> Total execution time: 0.6401
DEBUG - 2012-01-14 19:55:00 --> Config Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Hooks Class Initialized
DEBUG - 2012-01-14 19:55:00 --> Utf8 Class Initialized
DEBUG - 2012-01-14 19:55:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 19:55:01 --> URI Class Initialized
DEBUG - 2012-01-14 19:55:01 --> Router Class Initialized
ERROR - 2012-01-14 19:55:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:02 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:02 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:02 --> No URI present. Default controller set.
DEBUG - 2012-01-14 20:07:02 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:02 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:02 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:02 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:02 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:02 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:07:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 20:07:02 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:02 --> Total execution time: 0.5092
DEBUG - 2012-01-14 20:07:03 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:03 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:03 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:03 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:03 --> Router Class Initialized
ERROR - 2012-01-14 20:07:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:04 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:04 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:04 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:04 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:05 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:05 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:05 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:07:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 20:07:05 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:05 --> Total execution time: 0.4772
DEBUG - 2012-01-14 20:07:05 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:05 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:05 --> Router Class Initialized
ERROR - 2012-01-14 20:07:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:06 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:06 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:06 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:06 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:06 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:06 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:06 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:07:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 20:07:06 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:06 --> Total execution time: 0.4656
DEBUG - 2012-01-14 20:07:07 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:07 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:07 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:07 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:07 --> Router Class Initialized
ERROR - 2012-01-14 20:07:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:08 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:08 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:08 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:09 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:09 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:09 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:09 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:09 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:07:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 20:07:09 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:09 --> Total execution time: 0.6157
DEBUG - 2012-01-14 20:07:09 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:09 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:09 --> Router Class Initialized
ERROR - 2012-01-14 20:07:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:11 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:11 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:11 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:11 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:11 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:11 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:11 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 20:07:11 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:11 --> Total execution time: 0.4808
DEBUG - 2012-01-14 20:07:11 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:11 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:11 --> Router Class Initialized
ERROR - 2012-01-14 20:07:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:13 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:13 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:13 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:13 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:13 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:13 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:13 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:13 --> Total execution time: 0.4907
DEBUG - 2012-01-14 20:07:13 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:13 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:13 --> Router Class Initialized
ERROR - 2012-01-14 20:07:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:14 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:14 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:14 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:14 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:14 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:14 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:14 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:15 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:15 --> Total execution time: 0.4687
DEBUG - 2012-01-14 20:07:15 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:15 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:15 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:15 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:15 --> Router Class Initialized
ERROR - 2012-01-14 20:07:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:16 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:16 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:16 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:16 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:16 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:16 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:16 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:16 --> Total execution time: 0.4196
DEBUG - 2012-01-14 20:07:16 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:16 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:16 --> Router Class Initialized
ERROR - 2012-01-14 20:07:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:17 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:17 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:17 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:17 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:17 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:17 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:17 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:18 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:18 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:18 --> Total execution time: 0.4019
DEBUG - 2012-01-14 20:07:18 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:18 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:18 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:18 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:18 --> Router Class Initialized
ERROR - 2012-01-14 20:07:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:19 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:19 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:19 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:19 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:19 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:19 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:19 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:19 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:19 --> Total execution time: 0.4534
DEBUG - 2012-01-14 20:07:20 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:20 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:20 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:20 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:20 --> Router Class Initialized
ERROR - 2012-01-14 20:07:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:20 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:20 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:21 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:21 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:21 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:21 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:21 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:21 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 20:07:21 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:21 --> Total execution time: 0.4723
DEBUG - 2012-01-14 20:07:21 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:21 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:21 --> Router Class Initialized
ERROR - 2012-01-14 20:07:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:24 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:24 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:24 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:24 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:24 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:24 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:25 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:25 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:25 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:25 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:25 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:25 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 20:07:25 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:25 --> Total execution time: 0.4105
DEBUG - 2012-01-14 20:07:25 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:25 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:25 --> Router Class Initialized
ERROR - 2012-01-14 20:07:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:27 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:27 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:27 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:27 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:27 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:27 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:27 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:27 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:27 --> Total execution time: 0.4151
DEBUG - 2012-01-14 20:07:28 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:28 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:28 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:28 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:28 --> Router Class Initialized
ERROR - 2012-01-14 20:07:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:29 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:29 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:29 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:29 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:29 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:29 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:29 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:29 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:30 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:30 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:30 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:30 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:30 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:30 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:30 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:30 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:30 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:30 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:30 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:30 --> Total execution time: 1.0152
DEBUG - 2012-01-14 20:07:30 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:31 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Router Class Initialized
ERROR - 2012-01-14 20:07:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:31 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:31 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:31 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:31 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:31 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:31 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:31 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:31 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:31 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:31 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:31 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:31 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:31 --> Total execution time: 0.4333
DEBUG - 2012-01-14 20:07:32 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:32 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Router Class Initialized
ERROR - 2012-01-14 20:07:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:07:32 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:32 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Router Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Output Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Security Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Input Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:07:32 --> Language Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Loader Class Initialized
DEBUG - 2012-01-14 20:07:32 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:07:33 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:07:33 --> Session Class Initialized
DEBUG - 2012-01-14 20:07:33 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:07:33 --> Session routines successfully run
DEBUG - 2012-01-14 20:07:33 --> Controller Class Initialized
DEBUG - 2012-01-14 20:07:33 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:33 --> Model Class Initialized
DEBUG - 2012-01-14 20:07:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:07:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:07:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:07:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:07:33 --> Final output sent to browser
DEBUG - 2012-01-14 20:07:33 --> Total execution time: 0.4112
DEBUG - 2012-01-14 20:07:33 --> Config Class Initialized
DEBUG - 2012-01-14 20:07:33 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:07:33 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:07:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:07:33 --> URI Class Initialized
DEBUG - 2012-01-14 20:07:33 --> Router Class Initialized
ERROR - 2012-01-14 20:07:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:08:08 --> Config Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:08:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:08:08 --> URI Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Router Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Output Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Security Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Input Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:08:08 --> Language Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Loader Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:08:08 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Session Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:08:08 --> Session routines successfully run
DEBUG - 2012-01-14 20:08:08 --> Controller Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Model Class Initialized
DEBUG - 2012-01-14 20:08:08 --> Model Class Initialized
DEBUG - 2012-01-14 20:08:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:08:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:08:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:08:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:08:08 --> Final output sent to browser
DEBUG - 2012-01-14 20:08:08 --> Total execution time: 0.4518
DEBUG - 2012-01-14 20:08:09 --> Config Class Initialized
DEBUG - 2012-01-14 20:08:09 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:08:09 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:08:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:08:09 --> URI Class Initialized
DEBUG - 2012-01-14 20:08:09 --> Router Class Initialized
ERROR - 2012-01-14 20:08:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:11:36 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:36 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:36 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:36 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:36 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:36 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:36 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:37 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:37 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:37 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:37 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:37 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:37 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-14 20:11:37 --> Final output sent to browser
DEBUG - 2012-01-14 20:11:37 --> Total execution time: 0.5640
DEBUG - 2012-01-14 20:11:37 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:37 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:37 --> Router Class Initialized
ERROR - 2012-01-14 20:11:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:11:39 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:39 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:39 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:39 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:39 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:39 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:39 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:39 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:39 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:39 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:39 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:39 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:11:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:11:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:11:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:11:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:11:39 --> Final output sent to browser
DEBUG - 2012-01-14 20:11:39 --> Total execution time: 0.3905
DEBUG - 2012-01-14 20:11:40 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:40 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:40 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:40 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:40 --> Router Class Initialized
ERROR - 2012-01-14 20:11:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:11:41 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:41 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:41 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:41 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:41 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:41 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Model Class Initialized
DEBUG - 2012-01-14 20:11:41 --> Model Class Initialized
DEBUG - 2012-01-14 20:11:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:11:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:11:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:11:41 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-14 20:11:41 --> Final output sent to browser
DEBUG - 2012-01-14 20:11:41 --> Total execution time: 0.8790
DEBUG - 2012-01-14 20:11:42 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:42 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:42 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:42 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:42 --> Router Class Initialized
ERROR - 2012-01-14 20:11:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:11:44 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:44 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:44 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:44 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:44 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:44 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:44 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:44 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:44 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:45 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:45 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:45 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Model Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Model Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:45 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:45 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:45 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:45 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:45 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Model Class Initialized
DEBUG - 2012-01-14 20:11:45 --> Model Class Initialized
DEBUG - 2012-01-14 20:11:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:11:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:11:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:11:45 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-14 20:11:45 --> Final output sent to browser
DEBUG - 2012-01-14 20:11:45 --> Total execution time: 0.3785
DEBUG - 2012-01-14 20:11:46 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:46 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:46 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:46 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:46 --> Router Class Initialized
ERROR - 2012-01-14 20:11:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:11:48 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:48 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Router Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Output Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Security Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Input Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:11:48 --> Language Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Loader Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:11:48 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Session Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:11:48 --> Session routines successfully run
DEBUG - 2012-01-14 20:11:48 --> Controller Class Initialized
DEBUG - 2012-01-14 20:11:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:11:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:11:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:11:48 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 20:11:48 --> Final output sent to browser
DEBUG - 2012-01-14 20:11:48 --> Total execution time: 0.4075
DEBUG - 2012-01-14 20:11:48 --> Config Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:11:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:11:48 --> URI Class Initialized
DEBUG - 2012-01-14 20:11:48 --> Router Class Initialized
ERROR - 2012-01-14 20:11:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:15:24 --> Config Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:15:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:15:24 --> URI Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Router Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Output Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Security Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Input Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:15:24 --> Language Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Loader Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:15:24 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Session Class Initialized
DEBUG - 2012-01-14 20:15:24 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:15:24 --> Session routines successfully run
DEBUG - 2012-01-14 20:15:24 --> Model Class Initialized
DEBUG - 2012-01-14 20:15:25 --> Config Class Initialized
DEBUG - 2012-01-14 20:15:25 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:15:25 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:15:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:15:25 --> URI Class Initialized
DEBUG - 2012-01-14 20:15:25 --> Router Class Initialized
ERROR - 2012-01-14 20:15:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:15:35 --> Config Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:15:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:15:35 --> URI Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Router Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Output Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Security Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Input Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:15:35 --> Language Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Loader Class Initialized
DEBUG - 2012-01-14 20:15:35 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:15:35 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:15:36 --> Session Class Initialized
DEBUG - 2012-01-14 20:15:36 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:15:36 --> Session routines successfully run
DEBUG - 2012-01-14 20:15:36 --> Model Class Initialized
DEBUG - 2012-01-14 20:15:36 --> Config Class Initialized
DEBUG - 2012-01-14 20:15:36 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:15:36 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:15:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:15:36 --> URI Class Initialized
DEBUG - 2012-01-14 20:15:36 --> Router Class Initialized
ERROR - 2012-01-14 20:15:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:16:53 --> Config Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:16:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:16:53 --> URI Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Router Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Output Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Security Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Input Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:16:53 --> Language Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Loader Class Initialized
DEBUG - 2012-01-14 20:16:53 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:16:53 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:16:54 --> Session Class Initialized
DEBUG - 2012-01-14 20:16:54 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:16:54 --> Session routines successfully run
DEBUG - 2012-01-14 20:16:54 --> Model Class Initialized
DEBUG - 2012-01-14 20:16:54 --> Model Class Initialized
DEBUG - 2012-01-14 20:16:54 --> Controller Class Initialized
DEBUG - 2012-01-14 20:16:54 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:16:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:16:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:16:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:16:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:16:54 --> Final output sent to browser
DEBUG - 2012-01-14 20:16:54 --> Total execution time: 1.6808
DEBUG - 2012-01-14 20:16:55 --> Config Class Initialized
DEBUG - 2012-01-14 20:16:55 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:16:55 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:16:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:16:55 --> URI Class Initialized
DEBUG - 2012-01-14 20:16:55 --> Router Class Initialized
ERROR - 2012-01-14 20:16:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:10 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:11 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:11 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:11 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:11 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:11 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:19:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:19:11 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:11 --> Total execution time: 0.4256
DEBUG - 2012-01-14 20:19:11 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:11 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:11 --> Router Class Initialized
ERROR - 2012-01-14 20:19:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:13 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:13 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:13 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:13 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:13 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:13 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:13 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 20:19:13 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:13 --> Total execution time: 0.4600
DEBUG - 2012-01-14 20:19:14 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:14 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:14 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:14 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:14 --> Router Class Initialized
ERROR - 2012-01-14 20:19:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:15 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:15 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:15 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:15 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:15 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:15 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:15 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:15 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 20:19:15 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:15 --> Total execution time: 0.4653
DEBUG - 2012-01-14 20:19:16 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:16 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:16 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:16 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:16 --> Router Class Initialized
ERROR - 2012-01-14 20:19:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:16 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:16 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:16 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:16 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:16 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:17 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:17 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:17 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:17 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:17 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:17 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:17 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:17 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:17 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 20:19:17 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:17 --> Total execution time: 0.9837
DEBUG - 2012-01-14 20:19:18 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:18 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:18 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:18 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:18 --> Router Class Initialized
ERROR - 2012-01-14 20:19:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:19 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:19 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:19 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:19 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:19 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:19 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:19 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:19 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:20 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:20 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:20 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:20 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:20 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-14 20:19:20 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:20 --> Total execution time: 0.4745
DEBUG - 2012-01-14 20:19:20 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:20 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:20 --> Router Class Initialized
ERROR - 2012-01-14 20:19:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:22 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:22 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:22 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:22 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:22 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:22 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:22 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:22 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 20:19:22 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:22 --> Total execution time: 1.0294
DEBUG - 2012-01-14 20:19:23 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:23 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:23 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:23 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:23 --> Router Class Initialized
ERROR - 2012-01-14 20:19:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:24 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:24 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:24 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:24 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:24 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:24 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:24 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:24 --> File loaded: application/views/admin/comment_edit.php
DEBUG - 2012-01-14 20:19:24 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:24 --> Total execution time: 0.4535
DEBUG - 2012-01-14 20:19:25 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:25 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:25 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:25 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:25 --> Router Class Initialized
ERROR - 2012-01-14 20:19:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:19:30 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:30 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:30 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:30 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:30 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:30 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:30 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Router Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Output Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Security Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Input Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:19:30 --> Language Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Loader Class Initialized
DEBUG - 2012-01-14 20:19:30 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:19:30 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:19:31 --> Session Class Initialized
DEBUG - 2012-01-14 20:19:31 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:19:31 --> Session routines successfully run
DEBUG - 2012-01-14 20:19:31 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:31 --> Model Class Initialized
DEBUG - 2012-01-14 20:19:31 --> Controller Class Initialized
DEBUG - 2012-01-14 20:19:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:19:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:19:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:19:31 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 20:19:31 --> Final output sent to browser
DEBUG - 2012-01-14 20:19:31 --> Total execution time: 0.4355
DEBUG - 2012-01-14 20:19:31 --> Config Class Initialized
DEBUG - 2012-01-14 20:19:31 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:19:31 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:19:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:19:31 --> URI Class Initialized
DEBUG - 2012-01-14 20:19:31 --> Router Class Initialized
ERROR - 2012-01-14 20:19:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:20:23 --> Config Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:20:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:20:23 --> URI Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Router Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Output Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Security Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Input Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:20:23 --> Language Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Loader Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:20:23 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Session Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:20:23 --> Session routines successfully run
DEBUG - 2012-01-14 20:20:23 --> Model Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Model Class Initialized
DEBUG - 2012-01-14 20:20:23 --> Controller Class Initialized
DEBUG - 2012-01-14 20:20:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:20:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:20:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:20:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:20:23 --> Final output sent to browser
DEBUG - 2012-01-14 20:20:23 --> Total execution time: 0.4502
DEBUG - 2012-01-14 20:20:24 --> Config Class Initialized
DEBUG - 2012-01-14 20:20:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:20:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:20:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:20:24 --> URI Class Initialized
DEBUG - 2012-01-14 20:20:24 --> Router Class Initialized
ERROR - 2012-01-14 20:20:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:20:26 --> Config Class Initialized
DEBUG - 2012-01-14 20:20:26 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:20:26 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:20:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:20:26 --> URI Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Router Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Output Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Security Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Input Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:20:27 --> Language Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Loader Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:20:27 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Session Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:20:27 --> Session routines successfully run
DEBUG - 2012-01-14 20:20:27 --> Model Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Model Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Controller Class Initialized
DEBUG - 2012-01-14 20:20:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:20:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:20:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:20:27 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 20:20:27 --> Final output sent to browser
DEBUG - 2012-01-14 20:20:27 --> Total execution time: 0.6811
DEBUG - 2012-01-14 20:20:27 --> Config Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:20:27 --> URI Class Initialized
DEBUG - 2012-01-14 20:20:27 --> Router Class Initialized
ERROR - 2012-01-14 20:20:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:21:06 --> Config Class Initialized
DEBUG - 2012-01-14 20:21:06 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:21:06 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:21:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:21:06 --> URI Class Initialized
DEBUG - 2012-01-14 20:21:06 --> Router Class Initialized
DEBUG - 2012-01-14 20:21:06 --> Output Class Initialized
DEBUG - 2012-01-14 20:21:06 --> Security Class Initialized
DEBUG - 2012-01-14 20:21:06 --> Input Class Initialized
DEBUG - 2012-01-14 20:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:21:06 --> Language Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Loader Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:21:07 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Session Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:21:07 --> Session routines successfully run
DEBUG - 2012-01-14 20:21:07 --> Model Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Model Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Controller Class Initialized
DEBUG - 2012-01-14 20:21:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:21:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:21:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:21:07 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 20:21:07 --> Final output sent to browser
DEBUG - 2012-01-14 20:21:07 --> Total execution time: 0.4094
DEBUG - 2012-01-14 20:21:07 --> Config Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:21:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:21:07 --> URI Class Initialized
DEBUG - 2012-01-14 20:21:07 --> Router Class Initialized
ERROR - 2012-01-14 20:21:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:18 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:18 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:18 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:18 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:18 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:18 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:24:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:24:18 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-14 20:24:18 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:18 --> Total execution time: 0.1840
DEBUG - 2012-01-14 20:24:18 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:18 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:18 --> Router Class Initialized
ERROR - 2012-01-14 20:24:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:21 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:21 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:21 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:21 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:21 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:21 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:24:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:24:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:24:21 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:21 --> Total execution time: 0.1823
DEBUG - 2012-01-14 20:24:21 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:21 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:21 --> Router Class Initialized
ERROR - 2012-01-14 20:24:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:22 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:22 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:22 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:22 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:23 --> No URI present. Default controller set.
DEBUG - 2012-01-14 20:24:23 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:23 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:23 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:23 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:23 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:24:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:24:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:24:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-14 20:24:23 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:23 --> Total execution time: 0.1855
DEBUG - 2012-01-14 20:24:23 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:23 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:23 --> Router Class Initialized
ERROR - 2012-01-14 20:24:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:24 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:24 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:24 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:24 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:24 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:24 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:24:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:24:24 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-14 20:24:24 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:24 --> Total execution time: 0.2016
DEBUG - 2012-01-14 20:24:24 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:24 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:24 --> Router Class Initialized
ERROR - 2012-01-14 20:24:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:25 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:25 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:25 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:25 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:26 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:26 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:26 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:24:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:24:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:24:26 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:26 --> Total execution time: 0.2227
DEBUG - 2012-01-14 20:24:26 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:26 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Router Class Initialized
ERROR - 2012-01-14 20:24:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:26 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:26 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:26 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:26 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:26 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:26 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:26 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:24:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:24:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:24:27 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:27 --> Total execution time: 0.2213
DEBUG - 2012-01-14 20:24:27 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:27 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:27 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:27 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:27 --> Router Class Initialized
ERROR - 2012-01-14 20:24:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:29 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:29 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:29 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:29 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:29 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:29 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:24:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:24:29 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 20:24:29 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:29 --> Total execution time: 0.2387
DEBUG - 2012-01-14 20:24:29 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:29 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:29 --> Router Class Initialized
ERROR - 2012-01-14 20:24:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:30 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:30 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:30 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:30 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:30 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:30 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:24:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:24:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-14 20:24:30 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:30 --> Total execution time: 0.3011
DEBUG - 2012-01-14 20:24:30 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:30 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:30 --> Router Class Initialized
ERROR - 2012-01-14 20:24:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:31 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:31 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:31 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:31 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:31 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:31 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:31 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:24:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:24:31 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-14 20:24:31 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:31 --> Total execution time: 0.1966
DEBUG - 2012-01-14 20:24:32 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:32 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Router Class Initialized
ERROR - 2012-01-14 20:24:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:24:32 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:32 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Router Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Output Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Security Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Input Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:24:32 --> Language Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Loader Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:24:32 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Session Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:24:32 --> Session routines successfully run
DEBUG - 2012-01-14 20:24:32 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Model Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Controller Class Initialized
DEBUG - 2012-01-14 20:24:32 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:24:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:24:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:24:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:24:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:24:32 --> Final output sent to browser
DEBUG - 2012-01-14 20:24:32 --> Total execution time: 0.2530
DEBUG - 2012-01-14 20:24:33 --> Config Class Initialized
DEBUG - 2012-01-14 20:24:33 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:24:33 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:24:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:24:33 --> URI Class Initialized
DEBUG - 2012-01-14 20:24:33 --> Router Class Initialized
ERROR - 2012-01-14 20:24:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:25:50 --> Config Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:25:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:25:50 --> URI Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Router Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Output Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Security Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Input Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:25:50 --> Language Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Loader Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:25:50 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Session Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:25:50 --> Session routines successfully run
DEBUG - 2012-01-14 20:25:50 --> Model Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Model Class Initialized
DEBUG - 2012-01-14 20:25:50 --> Controller Class Initialized
DEBUG - 2012-01-14 20:25:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-14 20:25:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-14 20:25:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-14 20:25:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-14 20:25:50 --> Final output sent to browser
DEBUG - 2012-01-14 20:25:50 --> Total execution time: 0.1689
DEBUG - 2012-01-14 20:25:51 --> Config Class Initialized
DEBUG - 2012-01-14 20:25:51 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:25:51 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:25:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:25:51 --> URI Class Initialized
DEBUG - 2012-01-14 20:25:51 --> Router Class Initialized
ERROR - 2012-01-14 20:25:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:25:52 --> Config Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:25:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:25:52 --> URI Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Router Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Output Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Security Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Input Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:25:52 --> Language Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Loader Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:25:52 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Session Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:25:52 --> Session routines successfully run
DEBUG - 2012-01-14 20:25:52 --> Model Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Model Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Controller Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:25:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:25:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:25:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:25:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:25:52 --> Final output sent to browser
DEBUG - 2012-01-14 20:25:52 --> Total execution time: 0.1873
DEBUG - 2012-01-14 20:25:52 --> Config Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:25:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:25:52 --> URI Class Initialized
DEBUG - 2012-01-14 20:25:52 --> Router Class Initialized
ERROR - 2012-01-14 20:25:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:31:14 --> Config Class Initialized
DEBUG - 2012-01-14 20:31:14 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:31:14 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:31:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:31:14 --> URI Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Router Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Output Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Security Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Input Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:31:15 --> Language Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Loader Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:31:15 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Session Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:31:15 --> Session routines successfully run
DEBUG - 2012-01-14 20:31:15 --> Model Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Model Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Controller Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:31:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:31:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:31:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:31:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:31:15 --> Final output sent to browser
DEBUG - 2012-01-14 20:31:15 --> Total execution time: 0.4903
DEBUG - 2012-01-14 20:31:15 --> Config Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:31:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:31:15 --> URI Class Initialized
DEBUG - 2012-01-14 20:31:15 --> Router Class Initialized
ERROR - 2012-01-14 20:31:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:31:17 --> Config Class Initialized
DEBUG - 2012-01-14 20:31:17 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:31:17 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:31:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:31:17 --> URI Class Initialized
DEBUG - 2012-01-14 20:31:17 --> Router Class Initialized
DEBUG - 2012-01-14 20:31:17 --> Output Class Initialized
DEBUG - 2012-01-14 20:31:17 --> Security Class Initialized
DEBUG - 2012-01-14 20:31:17 --> Input Class Initialized
DEBUG - 2012-01-14 20:31:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:31:18 --> Language Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Loader Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:31:18 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Session Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:31:18 --> Session routines successfully run
DEBUG - 2012-01-14 20:31:18 --> Model Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Model Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Controller Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:31:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:31:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:31:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:31:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:31:18 --> Final output sent to browser
DEBUG - 2012-01-14 20:31:18 --> Total execution time: 0.5809
DEBUG - 2012-01-14 20:31:18 --> Config Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:31:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:31:18 --> URI Class Initialized
DEBUG - 2012-01-14 20:31:18 --> Router Class Initialized
ERROR - 2012-01-14 20:31:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-14 20:31:19 --> Config Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:31:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:31:19 --> URI Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Router Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Output Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Security Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Input Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-14 20:31:19 --> Language Class Initialized
DEBUG - 2012-01-14 20:31:19 --> Loader Class Initialized
DEBUG - 2012-01-14 20:31:20 --> Helper loaded: url_helper
DEBUG - 2012-01-14 20:31:20 --> Database Driver Class Initialized
DEBUG - 2012-01-14 20:31:20 --> Session Class Initialized
DEBUG - 2012-01-14 20:31:20 --> Helper loaded: string_helper
DEBUG - 2012-01-14 20:31:20 --> Session routines successfully run
DEBUG - 2012-01-14 20:31:20 --> Model Class Initialized
DEBUG - 2012-01-14 20:31:20 --> Model Class Initialized
DEBUG - 2012-01-14 20:31:20 --> Controller Class Initialized
DEBUG - 2012-01-14 20:31:20 --> Pagination Class Initialized
DEBUG - 2012-01-14 20:31:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-14 20:31:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-14 20:31:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-14 20:31:20 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-14 20:31:20 --> Final output sent to browser
DEBUG - 2012-01-14 20:31:20 --> Total execution time: 1.1145
DEBUG - 2012-01-14 20:31:21 --> Config Class Initialized
DEBUG - 2012-01-14 20:31:21 --> Hooks Class Initialized
DEBUG - 2012-01-14 20:31:21 --> Utf8 Class Initialized
DEBUG - 2012-01-14 20:31:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-14 20:31:21 --> URI Class Initialized
DEBUG - 2012-01-14 20:31:21 --> Router Class Initialized
ERROR - 2012-01-14 20:31:21 --> 404 Page Not Found --> favicon.ico

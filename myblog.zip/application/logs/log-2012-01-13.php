<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-13 00:00:05 --> Config Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:00:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:00:05 --> URI Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Router Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Output Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Security Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Input Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:00:05 --> Language Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Loader Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:00:05 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:00:05 --> Session Class Initialized
DEBUG - 2012-01-13 00:00:06 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:00:06 --> Session routines successfully run
DEBUG - 2012-01-13 00:00:06 --> Controller Class Initialized
DEBUG - 2012-01-13 00:00:06 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:00:06 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:00:06 --> Final output sent to browser
DEBUG - 2012-01-13 00:00:06 --> Total execution time: 0.4762
DEBUG - 2012-01-13 00:00:07 --> Config Class Initialized
DEBUG - 2012-01-13 00:00:07 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:00:07 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:00:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:00:07 --> URI Class Initialized
DEBUG - 2012-01-13 00:00:07 --> Router Class Initialized
DEBUG - 2012-01-13 00:00:07 --> Output Class Initialized
DEBUG - 2012-01-13 00:00:08 --> Security Class Initialized
DEBUG - 2012-01-13 00:00:08 --> Input Class Initialized
DEBUG - 2012-01-13 00:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:00:08 --> Language Class Initialized
DEBUG - 2012-01-13 00:00:08 --> Loader Class Initialized
DEBUG - 2012-01-13 00:00:08 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:00:08 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:00:08 --> Session Class Initialized
DEBUG - 2012-01-13 00:00:08 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:00:08 --> Session routines successfully run
DEBUG - 2012-01-13 00:00:08 --> Controller Class Initialized
DEBUG - 2012-01-13 00:00:08 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:00:08 --> Final output sent to browser
DEBUG - 2012-01-13 00:00:08 --> Total execution time: 0.4909
DEBUG - 2012-01-13 00:02:22 --> Config Class Initialized
DEBUG - 2012-01-13 00:02:22 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:02:22 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:02:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:02:22 --> URI Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Router Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Output Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Security Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Input Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:02:23 --> Language Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Loader Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:02:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Session Class Initialized
DEBUG - 2012-01-13 00:02:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:02:23 --> Session routines successfully run
DEBUG - 2012-01-13 00:02:23 --> Controller Class Initialized
DEBUG - 2012-01-13 00:02:23 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:02:23 --> Final output sent to browser
DEBUG - 2012-01-13 00:02:23 --> Total execution time: 0.8747
DEBUG - 2012-01-13 00:02:32 --> Config Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:02:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:02:32 --> URI Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Router Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Output Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Security Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Input Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:02:32 --> Language Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Loader Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:02:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Session Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:02:32 --> Session routines successfully run
DEBUG - 2012-01-13 00:02:32 --> Controller Class Initialized
DEBUG - 2012-01-13 00:02:32 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:02:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:02:32 --> Final output sent to browser
DEBUG - 2012-01-13 00:02:32 --> Total execution time: 0.5218
DEBUG - 2012-01-13 00:02:36 --> Config Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:02:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:02:36 --> URI Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Router Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Output Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Security Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Input Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:02:36 --> Language Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Loader Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:02:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Session Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:02:36 --> Session routines successfully run
DEBUG - 2012-01-13 00:02:36 --> Controller Class Initialized
DEBUG - 2012-01-13 00:02:36 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:02:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:02:36 --> Final output sent to browser
DEBUG - 2012-01-13 00:02:36 --> Total execution time: 0.5081
DEBUG - 2012-01-13 00:02:37 --> Config Class Initialized
DEBUG - 2012-01-13 00:02:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:02:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:02:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:02:38 --> URI Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Router Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Output Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Security Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Input Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:02:38 --> Language Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Loader Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:02:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Session Class Initialized
DEBUG - 2012-01-13 00:02:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:02:38 --> Session routines successfully run
DEBUG - 2012-01-13 00:02:38 --> Controller Class Initialized
DEBUG - 2012-01-13 00:02:38 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:02:38 --> Final output sent to browser
DEBUG - 2012-01-13 00:02:38 --> Total execution time: 1.0513
DEBUG - 2012-01-13 00:02:58 --> Config Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:02:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:02:58 --> URI Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Router Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Output Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Security Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Input Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:02:58 --> Language Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Loader Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:02:58 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Session Class Initialized
DEBUG - 2012-01-13 00:02:58 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:02:58 --> Session routines successfully run
DEBUG - 2012-01-13 00:02:58 --> Controller Class Initialized
DEBUG - 2012-01-13 00:02:58 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:02:58 --> Final output sent to browser
DEBUG - 2012-01-13 00:02:58 --> Total execution time: 0.3893
DEBUG - 2012-01-13 00:04:06 --> Config Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:04:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:04:06 --> URI Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Router Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Output Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Security Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Input Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:04:06 --> Language Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Loader Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:04:06 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Session Class Initialized
DEBUG - 2012-01-13 00:04:06 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:04:06 --> Session routines successfully run
DEBUG - 2012-01-13 00:04:06 --> Controller Class Initialized
DEBUG - 2012-01-13 00:04:06 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:04:06 --> Final output sent to browser
DEBUG - 2012-01-13 00:04:06 --> Total execution time: 0.4187
DEBUG - 2012-01-13 00:05:52 --> Config Class Initialized
DEBUG - 2012-01-13 00:05:52 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:05:52 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:05:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:05:52 --> URI Class Initialized
DEBUG - 2012-01-13 00:05:52 --> Router Class Initialized
DEBUG - 2012-01-13 00:05:52 --> Output Class Initialized
DEBUG - 2012-01-13 00:05:53 --> Security Class Initialized
DEBUG - 2012-01-13 00:05:53 --> Input Class Initialized
DEBUG - 2012-01-13 00:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:05:53 --> Language Class Initialized
DEBUG - 2012-01-13 00:05:53 --> Loader Class Initialized
DEBUG - 2012-01-13 00:05:53 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:05:53 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:05:53 --> Session Class Initialized
DEBUG - 2012-01-13 00:05:53 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:05:53 --> Session routines successfully run
DEBUG - 2012-01-13 00:05:53 --> Controller Class Initialized
DEBUG - 2012-01-13 00:05:53 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:05:53 --> Final output sent to browser
DEBUG - 2012-01-13 00:05:53 --> Total execution time: 0.4030
DEBUG - 2012-01-13 00:06:16 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:16 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:16 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:16 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:16 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:16 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:06:16 --> Final output sent to browser
DEBUG - 2012-01-13 00:06:16 --> Total execution time: 0.4214
DEBUG - 2012-01-13 00:06:26 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:26 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:26 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:26 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:26 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:26 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:06:26 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:06:26 --> Final output sent to browser
DEBUG - 2012-01-13 00:06:26 --> Total execution time: 0.4872
DEBUG - 2012-01-13 00:06:28 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:29 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:29 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:29 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:29 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:29 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-13 00:06:29 --> Final output sent to browser
DEBUG - 2012-01-13 00:06:29 --> Total execution time: 0.4398
DEBUG - 2012-01-13 00:06:35 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:35 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:35 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:35 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:35 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:36 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:36 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:36 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:36 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:36 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:36 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:36 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:36 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:06:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:06:36 --> Final output sent to browser
DEBUG - 2012-01-13 00:06:36 --> Total execution time: 0.4201
DEBUG - 2012-01-13 00:06:38 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:38 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:38 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:38 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:38 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:38 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:39 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:39 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:39 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:39 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:39 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:39 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:39 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:39 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:39 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-13 00:06:39 --> Final output sent to browser
DEBUG - 2012-01-13 00:06:39 --> Total execution time: 0.5362
DEBUG - 2012-01-13 00:06:43 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:43 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:43 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:43 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:43 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:43 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:43 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:44 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:44 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:44 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:44 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:44 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:06:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:06:44 --> Final output sent to browser
DEBUG - 2012-01-13 00:06:44 --> Total execution time: 0.4220
DEBUG - 2012-01-13 00:06:47 --> Config Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:06:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:06:47 --> URI Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Router Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Output Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Security Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Input Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:06:47 --> Language Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Loader Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:06:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Session Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:06:47 --> Session routines successfully run
DEBUG - 2012-01-13 00:06:47 --> Controller Class Initialized
DEBUG - 2012-01-13 00:06:47 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:06:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:06:47 --> Final output sent to browser
DEBUG - 2012-01-13 00:06:47 --> Total execution time: 0.4791
DEBUG - 2012-01-13 00:10:02 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:02 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:02 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:02 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:02 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:02 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:02 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:02 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:02 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:03 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:03 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:03 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:03 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:03 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:03 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:03 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:03 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:10:03 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:10:03 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:03 --> Total execution time: 0.4670
DEBUG - 2012-01-13 00:10:07 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:07 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:07 --> No URI present. Default controller set.
DEBUG - 2012-01-13 00:10:07 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:07 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:07 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:07 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:07 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:07 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:10:07 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:10:07 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:07 --> Total execution time: 0.5718
DEBUG - 2012-01-13 00:10:32 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:32 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:32 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:32 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:32 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:32 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:10:33 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:33 --> Total execution time: 0.4530
DEBUG - 2012-01-13 00:10:34 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:34 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:34 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:34 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:34 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:34 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:34 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:10:34 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:34 --> Total execution time: 0.3948
DEBUG - 2012-01-13 00:10:36 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:36 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:36 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:36 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:36 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:36 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:10:36 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:36 --> Total execution time: 0.3951
DEBUG - 2012-01-13 00:10:38 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:38 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:38 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:38 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:38 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:10:39 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:39 --> Total execution time: 1.0984
DEBUG - 2012-01-13 00:10:39 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:39 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:40 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:40 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:40 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:40 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:40 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:40 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:10:40 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:40 --> Total execution time: 0.4898
DEBUG - 2012-01-13 00:10:44 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:44 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:44 --> No URI present. Default controller set.
DEBUG - 2012-01-13 00:10:44 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:44 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:44 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:44 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:44 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:10:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:10:44 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:44 --> Total execution time: 0.5243
DEBUG - 2012-01-13 00:10:47 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:47 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:47 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:47 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:48 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:48 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:48 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:10:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:10:48 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:48 --> Total execution time: 0.5199
DEBUG - 2012-01-13 00:10:50 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:50 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:51 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:51 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:51 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:51 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:10:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:10:51 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:51 --> Total execution time: 0.6409
DEBUG - 2012-01-13 00:10:53 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:53 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:53 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:53 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:53 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:53 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:53 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:54 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:54 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:54 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:54 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:54 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:54 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:10:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:10:54 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:54 --> Total execution time: 0.6990
DEBUG - 2012-01-13 00:10:55 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:55 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:55 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:55 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:55 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:55 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 00:10:55 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:55 --> Total execution time: 0.4094
DEBUG - 2012-01-13 00:10:58 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:58 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:58 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:59 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:59 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:59 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:59 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Config Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:10:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:10:59 --> URI Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Router Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Output Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Security Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Input Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:10:59 --> Language Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Loader Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:10:59 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Session Class Initialized
DEBUG - 2012-01-13 00:10:59 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:10:59 --> Session routines successfully run
DEBUG - 2012-01-13 00:10:59 --> Controller Class Initialized
DEBUG - 2012-01-13 00:10:59 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 00:10:59 --> Final output sent to browser
DEBUG - 2012-01-13 00:10:59 --> Total execution time: 0.4143
DEBUG - 2012-01-13 00:11:08 --> Config Class Initialized
DEBUG - 2012-01-13 00:11:08 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:11:08 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:11:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:11:08 --> URI Class Initialized
DEBUG - 2012-01-13 00:11:08 --> Router Class Initialized
DEBUG - 2012-01-13 00:11:08 --> Output Class Initialized
DEBUG - 2012-01-13 00:11:09 --> Security Class Initialized
DEBUG - 2012-01-13 00:11:09 --> Input Class Initialized
DEBUG - 2012-01-13 00:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:11:09 --> Language Class Initialized
DEBUG - 2012-01-13 00:11:09 --> Loader Class Initialized
DEBUG - 2012-01-13 00:11:09 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:11:09 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:11:09 --> Session Class Initialized
DEBUG - 2012-01-13 00:11:09 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:11:09 --> Session routines successfully run
DEBUG - 2012-01-13 00:11:09 --> Controller Class Initialized
DEBUG - 2012-01-13 00:11:09 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:11:09 --> Final output sent to browser
DEBUG - 2012-01-13 00:11:09 --> Total execution time: 0.4700
DEBUG - 2012-01-13 00:11:11 --> Config Class Initialized
DEBUG - 2012-01-13 00:11:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:11:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:11:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:11:11 --> URI Class Initialized
DEBUG - 2012-01-13 00:11:11 --> Router Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Output Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Security Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Input Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:11:12 --> Language Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Loader Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:11:12 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Session Class Initialized
DEBUG - 2012-01-13 00:11:12 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:11:12 --> Session routines successfully run
DEBUG - 2012-01-13 00:11:12 --> Controller Class Initialized
DEBUG - 2012-01-13 00:11:12 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:11:12 --> Final output sent to browser
DEBUG - 2012-01-13 00:11:12 --> Total execution time: 0.4115
DEBUG - 2012-01-13 00:11:14 --> Config Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:11:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:11:14 --> URI Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Router Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Output Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Security Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Input Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:11:14 --> Language Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Loader Class Initialized
DEBUG - 2012-01-13 00:11:14 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:11:14 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:11:15 --> Session Class Initialized
DEBUG - 2012-01-13 00:11:15 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:11:15 --> Session routines successfully run
DEBUG - 2012-01-13 00:11:15 --> Controller Class Initialized
DEBUG - 2012-01-13 00:11:15 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:11:15 --> Final output sent to browser
DEBUG - 2012-01-13 00:11:15 --> Total execution time: 1.0538
DEBUG - 2012-01-13 00:14:35 --> Config Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:14:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:14:35 --> URI Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Router Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Output Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Security Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Input Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:14:35 --> Language Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Loader Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:14:35 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Session Class Initialized
DEBUG - 2012-01-13 00:14:35 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:14:35 --> Session routines successfully run
DEBUG - 2012-01-13 00:14:35 --> Controller Class Initialized
DEBUG - 2012-01-13 00:14:35 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:14:35 --> Final output sent to browser
DEBUG - 2012-01-13 00:14:35 --> Total execution time: 0.4733
DEBUG - 2012-01-13 00:15:43 --> Config Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:15:43 --> URI Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Router Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Output Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Security Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Input Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:15:43 --> Language Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Loader Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:15:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Session Class Initialized
DEBUG - 2012-01-13 00:15:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:15:43 --> Session routines successfully run
DEBUG - 2012-01-13 00:15:43 --> Controller Class Initialized
DEBUG - 2012-01-13 00:15:43 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:15:43 --> Final output sent to browser
DEBUG - 2012-01-13 00:15:43 --> Total execution time: 0.4158
DEBUG - 2012-01-13 00:15:51 --> Config Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:15:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:15:51 --> URI Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Router Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Output Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Security Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Input Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:15:51 --> Language Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Loader Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:15:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Session Class Initialized
DEBUG - 2012-01-13 00:15:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:15:51 --> Session routines successfully run
DEBUG - 2012-01-13 00:15:51 --> Controller Class Initialized
DEBUG - 2012-01-13 00:15:51 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:15:51 --> Final output sent to browser
DEBUG - 2012-01-13 00:15:51 --> Total execution time: 0.4271
DEBUG - 2012-01-13 00:15:55 --> Config Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:15:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:15:55 --> URI Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Router Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Output Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Security Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Input Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:15:55 --> Language Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Loader Class Initialized
DEBUG - 2012-01-13 00:15:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:15:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:15:56 --> Session Class Initialized
DEBUG - 2012-01-13 00:15:56 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:15:56 --> Session routines successfully run
DEBUG - 2012-01-13 00:15:56 --> Controller Class Initialized
DEBUG - 2012-01-13 00:15:56 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 00:15:56 --> Final output sent to browser
DEBUG - 2012-01-13 00:15:56 --> Total execution time: 0.5884
DEBUG - 2012-01-13 00:16:32 --> Config Class Initialized
DEBUG - 2012-01-13 00:16:32 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:16:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:16:33 --> URI Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Router Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Output Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Security Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Input Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:16:33 --> Language Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Loader Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:16:33 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Session Class Initialized
DEBUG - 2012-01-13 00:16:33 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:16:33 --> Session routines successfully run
DEBUG - 2012-01-13 00:16:33 --> Controller Class Initialized
DEBUG - 2012-01-13 00:16:33 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 00:16:33 --> Final output sent to browser
DEBUG - 2012-01-13 00:16:33 --> Total execution time: 0.4315
DEBUG - 2012-01-13 00:16:51 --> Config Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:16:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:16:51 --> URI Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Router Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Output Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Security Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Input Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:16:51 --> Language Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Loader Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:16:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Session Class Initialized
DEBUG - 2012-01-13 00:16:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:16:51 --> Session routines successfully run
DEBUG - 2012-01-13 00:16:51 --> Controller Class Initialized
DEBUG - 2012-01-13 00:16:51 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:16:51 --> Final output sent to browser
DEBUG - 2012-01-13 00:16:51 --> Total execution time: 0.4360
DEBUG - 2012-01-13 00:16:55 --> Config Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:16:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:16:55 --> URI Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Router Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Output Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Security Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Input Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:16:55 --> Language Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Loader Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:16:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Session Class Initialized
DEBUG - 2012-01-13 00:16:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:16:55 --> Session routines successfully run
DEBUG - 2012-01-13 00:16:55 --> Controller Class Initialized
DEBUG - 2012-01-13 00:16:55 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:16:55 --> Final output sent to browser
DEBUG - 2012-01-13 00:16:55 --> Total execution time: 0.4172
DEBUG - 2012-01-13 00:16:58 --> Config Class Initialized
DEBUG - 2012-01-13 00:16:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:16:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:16:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:16:58 --> URI Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Router Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Output Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Security Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Input Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:16:59 --> Language Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Loader Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:16:59 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Session Class Initialized
DEBUG - 2012-01-13 00:16:59 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:16:59 --> Session routines successfully run
DEBUG - 2012-01-13 00:16:59 --> Controller Class Initialized
DEBUG - 2012-01-13 00:16:59 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 00:16:59 --> Final output sent to browser
DEBUG - 2012-01-13 00:16:59 --> Total execution time: 0.4758
DEBUG - 2012-01-13 00:17:04 --> Config Class Initialized
DEBUG - 2012-01-13 00:17:04 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:17:04 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:17:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:17:04 --> URI Class Initialized
DEBUG - 2012-01-13 00:17:04 --> Router Class Initialized
DEBUG - 2012-01-13 00:17:04 --> Output Class Initialized
DEBUG - 2012-01-13 00:17:04 --> Security Class Initialized
DEBUG - 2012-01-13 00:17:04 --> Input Class Initialized
DEBUG - 2012-01-13 00:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:17:05 --> Language Class Initialized
DEBUG - 2012-01-13 00:17:05 --> Loader Class Initialized
DEBUG - 2012-01-13 00:17:05 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:17:05 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:17:05 --> Session Class Initialized
DEBUG - 2012-01-13 00:17:05 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:17:05 --> Session routines successfully run
DEBUG - 2012-01-13 00:17:05 --> Controller Class Initialized
DEBUG - 2012-01-13 00:17:05 --> File loaded: application/views/admin/comment_edit.php
DEBUG - 2012-01-13 00:17:05 --> Final output sent to browser
DEBUG - 2012-01-13 00:17:05 --> Total execution time: 0.5356
DEBUG - 2012-01-13 00:18:44 --> Config Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:18:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:18:44 --> URI Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Router Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Output Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Security Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Input Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:18:44 --> Language Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Loader Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:18:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Session Class Initialized
DEBUG - 2012-01-13 00:18:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:18:45 --> Session routines successfully run
DEBUG - 2012-01-13 00:18:45 --> Controller Class Initialized
DEBUG - 2012-01-13 00:18:45 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:18:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:18:45 --> Final output sent to browser
DEBUG - 2012-01-13 00:18:45 --> Total execution time: 0.5089
DEBUG - 2012-01-13 00:19:24 --> Config Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:19:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:19:24 --> URI Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Router Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Output Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Security Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Input Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:19:24 --> Language Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Loader Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:19:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Session Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:19:24 --> Session routines successfully run
DEBUG - 2012-01-13 00:19:24 --> Controller Class Initialized
DEBUG - 2012-01-13 00:19:24 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:19:24 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:19:24 --> Final output sent to browser
DEBUG - 2012-01-13 00:19:25 --> Total execution time: 0.4561
DEBUG - 2012-01-13 00:19:35 --> Config Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:19:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:19:35 --> URI Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Router Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Output Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Security Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Input Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:19:35 --> Language Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Loader Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:19:35 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Session Class Initialized
DEBUG - 2012-01-13 00:19:35 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:19:35 --> Session routines successfully run
DEBUG - 2012-01-13 00:19:35 --> Controller Class Initialized
DEBUG - 2012-01-13 00:19:35 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:19:35 --> Final output sent to browser
DEBUG - 2012-01-13 00:19:35 --> Total execution time: 0.4212
DEBUG - 2012-01-13 00:19:39 --> Config Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:19:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:19:39 --> URI Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Router Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Output Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Security Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Input Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:19:39 --> Language Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Loader Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:19:39 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Session Class Initialized
DEBUG - 2012-01-13 00:19:39 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:19:39 --> Session routines successfully run
DEBUG - 2012-01-13 00:19:39 --> Controller Class Initialized
DEBUG - 2012-01-13 00:19:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:19:39 --> Final output sent to browser
DEBUG - 2012-01-13 00:19:39 --> Total execution time: 0.4864
DEBUG - 2012-01-13 00:19:46 --> Config Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:19:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:19:46 --> URI Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Router Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Output Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Security Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Input Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:19:46 --> Language Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Loader Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:19:46 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Session Class Initialized
DEBUG - 2012-01-13 00:19:46 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:19:46 --> Session routines successfully run
DEBUG - 2012-01-13 00:19:46 --> Controller Class Initialized
DEBUG - 2012-01-13 00:19:46 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 00:19:46 --> Final output sent to browser
DEBUG - 2012-01-13 00:19:46 --> Total execution time: 0.4727
DEBUG - 2012-01-13 00:19:56 --> Config Class Initialized
DEBUG - 2012-01-13 00:19:56 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:19:56 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:19:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:19:56 --> URI Class Initialized
DEBUG - 2012-01-13 00:19:56 --> Router Class Initialized
DEBUG - 2012-01-13 00:19:56 --> Output Class Initialized
DEBUG - 2012-01-13 00:19:57 --> Security Class Initialized
DEBUG - 2012-01-13 00:19:57 --> Input Class Initialized
DEBUG - 2012-01-13 00:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:19:57 --> Language Class Initialized
DEBUG - 2012-01-13 00:19:57 --> Loader Class Initialized
DEBUG - 2012-01-13 00:19:57 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:19:57 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:19:57 --> Session Class Initialized
DEBUG - 2012-01-13 00:19:57 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:19:57 --> Session routines successfully run
DEBUG - 2012-01-13 00:19:57 --> Controller Class Initialized
DEBUG - 2012-01-13 00:19:57 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:19:57 --> Final output sent to browser
DEBUG - 2012-01-13 00:19:57 --> Total execution time: 0.4578
DEBUG - 2012-01-13 00:19:58 --> Config Class Initialized
DEBUG - 2012-01-13 00:19:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:19:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:19:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:19:58 --> URI Class Initialized
DEBUG - 2012-01-13 00:19:58 --> Router Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Output Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Security Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Input Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:19:59 --> Language Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Loader Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:19:59 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Session Class Initialized
DEBUG - 2012-01-13 00:19:59 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:19:59 --> Session routines successfully run
DEBUG - 2012-01-13 00:19:59 --> Controller Class Initialized
DEBUG - 2012-01-13 00:19:59 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:19:59 --> Final output sent to browser
DEBUG - 2012-01-13 00:19:59 --> Total execution time: 0.4636
DEBUG - 2012-01-13 00:20:00 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:00 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:00 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:00 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:01 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:01 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:01 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:01 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:01 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:01 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:01 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:20:01 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:01 --> Total execution time: 0.5171
DEBUG - 2012-01-13 00:20:02 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:02 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:02 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:02 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:02 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:03 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:03 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:03 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:03 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:03 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:03 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:20:03 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:03 --> Total execution time: 0.9279
DEBUG - 2012-01-13 00:20:05 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:05 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:05 --> No URI present. Default controller set.
DEBUG - 2012-01-13 00:20:05 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:05 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:05 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:05 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:05 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:05 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:20:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:20:06 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:06 --> Total execution time: 0.5445
DEBUG - 2012-01-13 00:20:08 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:08 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:08 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:08 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:09 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:09 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:09 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:09 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:09 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:09 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:09 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:20:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:20:09 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:09 --> Total execution time: 1.0745
DEBUG - 2012-01-13 00:20:10 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:10 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:10 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:11 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:11 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:11 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:11 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:11 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:20:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:20:11 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:11 --> Total execution time: 0.5489
DEBUG - 2012-01-13 00:20:12 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:12 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:12 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:12 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:12 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:12 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:12 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:12 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:13 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:13 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:13 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:13 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:13 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:13 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:13 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:13 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:13 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:20:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:20:13 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:13 --> Total execution time: 0.5583
DEBUG - 2012-01-13 00:20:19 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:19 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:19 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:19 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:19 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:19 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:19 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 00:20:19 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:19 --> Total execution time: 0.4701
DEBUG - 2012-01-13 00:20:25 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:25 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:25 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:25 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:25 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:20:26 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:26 --> Total execution time: 0.8448
DEBUG - 2012-01-13 00:20:35 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:35 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:35 --> No URI present. Default controller set.
DEBUG - 2012-01-13 00:20:35 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:35 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:35 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:35 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:35 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:35 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:20:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:20:35 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:35 --> Total execution time: 0.5799
DEBUG - 2012-01-13 00:20:38 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:38 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:38 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:38 --> Session routines successfully run
DEBUG - 2012-01-13 00:20:38 --> Controller Class Initialized
DEBUG - 2012-01-13 00:20:38 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:20:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:20:38 --> Final output sent to browser
DEBUG - 2012-01-13 00:20:38 --> Total execution time: 0.4909
DEBUG - 2012-01-13 00:20:59 --> Config Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:20:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:20:59 --> URI Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Router Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Output Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Security Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Input Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:20:59 --> Language Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Loader Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:20:59 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Session Class Initialized
DEBUG - 2012-01-13 00:20:59 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:20:59 --> Session routines successfully run
DEBUG - 2012-01-13 00:21:00 --> Controller Class Initialized
DEBUG - 2012-01-13 00:21:00 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:21:00 --> Final output sent to browser
DEBUG - 2012-01-13 00:21:00 --> Total execution time: 0.4244
DEBUG - 2012-01-13 00:21:05 --> Config Class Initialized
DEBUG - 2012-01-13 00:21:05 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:21:05 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:21:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:21:05 --> URI Class Initialized
DEBUG - 2012-01-13 00:21:05 --> Router Class Initialized
DEBUG - 2012-01-13 00:21:05 --> Output Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Security Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Input Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:21:06 --> Language Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Loader Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:21:06 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Session Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:21:06 --> Session routines successfully run
DEBUG - 2012-01-13 00:21:06 --> Controller Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:21:06 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:21:06 --> Final output sent to browser
DEBUG - 2012-01-13 00:21:06 --> Total execution time: 0.4203
DEBUG - 2012-01-13 00:21:06 --> Config Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:21:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:21:06 --> URI Class Initialized
DEBUG - 2012-01-13 00:21:06 --> Router Class Initialized
ERROR - 2012-01-13 00:21:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:21:16 --> Config Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:21:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:21:16 --> URI Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Router Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Output Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Security Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Input Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:21:16 --> Language Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Loader Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:21:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Session Class Initialized
DEBUG - 2012-01-13 00:21:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:21:16 --> Session routines successfully run
DEBUG - 2012-01-13 00:21:16 --> Controller Class Initialized
DEBUG - 2012-01-13 00:21:16 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:21:16 --> Final output sent to browser
DEBUG - 2012-01-13 00:21:16 --> Total execution time: 0.3612
DEBUG - 2012-01-13 00:21:17 --> Config Class Initialized
DEBUG - 2012-01-13 00:21:17 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:21:17 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:21:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:21:17 --> URI Class Initialized
DEBUG - 2012-01-13 00:21:17 --> Router Class Initialized
ERROR - 2012-01-13 00:21:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:25:20 --> Config Class Initialized
DEBUG - 2012-01-13 00:25:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:25:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:25:20 --> URI Class Initialized
DEBUG - 2012-01-13 00:25:20 --> Router Class Initialized
DEBUG - 2012-01-13 00:25:20 --> Output Class Initialized
DEBUG - 2012-01-13 00:25:20 --> Security Class Initialized
DEBUG - 2012-01-13 00:25:20 --> Input Class Initialized
DEBUG - 2012-01-13 00:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:25:20 --> Language Class Initialized
DEBUG - 2012-01-13 00:25:21 --> Loader Class Initialized
DEBUG - 2012-01-13 00:25:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:25:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:25:21 --> Session Class Initialized
DEBUG - 2012-01-13 00:25:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:25:21 --> Session routines successfully run
DEBUG - 2012-01-13 00:25:21 --> Controller Class Initialized
DEBUG - 2012-01-13 00:25:21 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:25:21 --> Final output sent to browser
DEBUG - 2012-01-13 00:25:21 --> Total execution time: 0.4288
DEBUG - 2012-01-13 00:25:25 --> Config Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:25:25 --> URI Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Router Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Output Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Security Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Input Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:25:25 --> Language Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Loader Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:25:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Session Class Initialized
DEBUG - 2012-01-13 00:25:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:25:25 --> Session routines successfully run
DEBUG - 2012-01-13 00:25:25 --> Controller Class Initialized
DEBUG - 2012-01-13 00:25:25 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:25:25 --> Final output sent to browser
DEBUG - 2012-01-13 00:25:25 --> Total execution time: 0.6213
DEBUG - 2012-01-13 00:29:43 --> Config Class Initialized
DEBUG - 2012-01-13 00:29:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:29:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:29:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:29:43 --> URI Class Initialized
DEBUG - 2012-01-13 00:29:43 --> Router Class Initialized
DEBUG - 2012-01-13 00:29:43 --> Output Class Initialized
DEBUG - 2012-01-13 00:29:44 --> Security Class Initialized
DEBUG - 2012-01-13 00:29:44 --> Input Class Initialized
DEBUG - 2012-01-13 00:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:29:44 --> Language Class Initialized
DEBUG - 2012-01-13 00:29:44 --> Loader Class Initialized
DEBUG - 2012-01-13 00:29:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:29:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:29:44 --> Session Class Initialized
DEBUG - 2012-01-13 00:29:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:29:44 --> Session routines successfully run
DEBUG - 2012-01-13 00:29:44 --> Controller Class Initialized
DEBUG - 2012-01-13 00:29:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:29:44 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:29:44 --> Final output sent to browser
DEBUG - 2012-01-13 00:29:44 --> Total execution time: 0.5033
DEBUG - 2012-01-13 00:30:25 --> Config Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:30:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:30:25 --> URI Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Router Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Output Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Security Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Input Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:30:25 --> Language Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Loader Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:30:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Session Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:30:25 --> Session routines successfully run
DEBUG - 2012-01-13 00:30:25 --> Controller Class Initialized
DEBUG - 2012-01-13 00:30:25 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:30:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:30:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:30:25 --> Final output sent to browser
DEBUG - 2012-01-13 00:30:25 --> Total execution time: 0.5442
DEBUG - 2012-01-13 00:30:27 --> Config Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:30:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:30:27 --> URI Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Router Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Output Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Security Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Input Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:30:27 --> Language Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Loader Class Initialized
DEBUG - 2012-01-13 00:30:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:30:28 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:30:28 --> Session Class Initialized
DEBUG - 2012-01-13 00:30:28 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:30:28 --> Session routines successfully run
DEBUG - 2012-01-13 00:30:28 --> Controller Class Initialized
DEBUG - 2012-01-13 00:30:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:30:28 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:30:28 --> Final output sent to browser
DEBUG - 2012-01-13 00:30:28 --> Total execution time: 0.5495
DEBUG - 2012-01-13 00:30:30 --> Config Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:30:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:30:30 --> URI Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Router Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Output Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Security Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Input Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:30:30 --> Language Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Loader Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:30:30 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Session Class Initialized
DEBUG - 2012-01-13 00:30:30 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:30:30 --> Session routines successfully run
DEBUG - 2012-01-13 00:30:30 --> Controller Class Initialized
DEBUG - 2012-01-13 00:30:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:30:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:30:30 --> Final output sent to browser
DEBUG - 2012-01-13 00:30:30 --> Total execution time: 0.4534
DEBUG - 2012-01-13 00:30:31 --> Config Class Initialized
DEBUG - 2012-01-13 00:30:31 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:30:31 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:30:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:30:31 --> URI Class Initialized
DEBUG - 2012-01-13 00:30:31 --> Router Class Initialized
DEBUG - 2012-01-13 00:30:31 --> Output Class Initialized
DEBUG - 2012-01-13 00:30:32 --> Security Class Initialized
DEBUG - 2012-01-13 00:30:32 --> Input Class Initialized
DEBUG - 2012-01-13 00:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:30:32 --> Language Class Initialized
DEBUG - 2012-01-13 00:30:32 --> Loader Class Initialized
DEBUG - 2012-01-13 00:30:32 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:30:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:30:32 --> Session Class Initialized
DEBUG - 2012-01-13 00:30:32 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:30:32 --> Session routines successfully run
DEBUG - 2012-01-13 00:30:32 --> Controller Class Initialized
DEBUG - 2012-01-13 00:30:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:30:32 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:30:32 --> Final output sent to browser
DEBUG - 2012-01-13 00:30:32 --> Total execution time: 0.4796
DEBUG - 2012-01-13 00:32:20 --> Config Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:32:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:32:20 --> URI Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Router Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Output Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Security Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Input Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:32:20 --> Language Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Loader Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:32:20 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Session Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:32:20 --> Session routines successfully run
DEBUG - 2012-01-13 00:32:20 --> Controller Class Initialized
DEBUG - 2012-01-13 00:32:20 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:32:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:32:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:32:20 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:32:20 --> Final output sent to browser
DEBUG - 2012-01-13 00:32:20 --> Total execution time: 0.5343
DEBUG - 2012-01-13 00:33:16 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:16 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:16 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:16 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:16 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:16 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:33:17 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:17 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:17 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:33:17 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:17 --> Total execution time: 0.4884
DEBUG - 2012-01-13 00:33:18 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:18 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:18 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:18 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:18 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:19 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:33:19 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:19 --> Total execution time: 0.5020
DEBUG - 2012-01-13 00:33:20 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:20 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:20 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:20 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:21 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:21 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:21 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:21 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:33:21 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:21 --> Total execution time: 0.5298
DEBUG - 2012-01-13 00:33:22 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:23 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:23 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:23 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:23 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:23 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:33:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:23 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:33:23 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:23 --> Total execution time: 0.5255
DEBUG - 2012-01-13 00:33:25 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:25 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:25 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:25 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:25 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:25 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:33:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:33:25 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:25 --> Total execution time: 0.5661
DEBUG - 2012-01-13 00:33:27 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:27 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:27 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:27 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:27 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:27 --> File loaded: application/views/admin/article_create.php
DEBUG - 2012-01-13 00:33:27 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:27 --> Total execution time: 0.4180
DEBUG - 2012-01-13 00:33:30 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:30 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:30 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:30 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:30 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:30 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:30 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:33:30 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:30 --> Total execution time: 0.5200
DEBUG - 2012-01-13 00:33:31 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:31 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:31 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:31 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:31 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:31 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:31 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:31 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:33:31 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:31 --> Total execution time: 0.4650
DEBUG - 2012-01-13 00:33:34 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:35 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:35 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:35 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:35 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:35 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:35 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:35 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-13 00:33:35 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:35 --> Total execution time: 0.6719
DEBUG - 2012-01-13 00:33:37 --> Config Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:33:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:33:37 --> URI Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Router Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Output Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Security Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Input Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:33:37 --> Language Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Loader Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:33:37 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Session Class Initialized
DEBUG - 2012-01-13 00:33:37 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:33:37 --> Session routines successfully run
DEBUG - 2012-01-13 00:33:37 --> Controller Class Initialized
DEBUG - 2012-01-13 00:33:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:33:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:33:37 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:33:37 --> Final output sent to browser
DEBUG - 2012-01-13 00:33:37 --> Total execution time: 0.4949
DEBUG - 2012-01-13 00:37:45 --> Config Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:37:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:37:45 --> URI Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Router Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Output Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Security Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Input Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:37:45 --> Language Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Loader Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:37:45 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Session Class Initialized
DEBUG - 2012-01-13 00:37:45 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:37:45 --> Session routines successfully run
DEBUG - 2012-01-13 00:37:45 --> Controller Class Initialized
DEBUG - 2012-01-13 00:37:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:37:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:37:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:37:45 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:37:45 --> Final output sent to browser
DEBUG - 2012-01-13 00:37:45 --> Total execution time: 0.2011
DEBUG - 2012-01-13 00:37:48 --> Config Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:37:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:37:48 --> URI Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Router Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Output Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Security Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Input Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:37:48 --> Language Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Loader Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:37:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Session Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:37:48 --> Session routines successfully run
DEBUG - 2012-01-13 00:37:48 --> Controller Class Initialized
DEBUG - 2012-01-13 00:37:48 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:37:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:37:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:37:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:37:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:37:48 --> Final output sent to browser
DEBUG - 2012-01-13 00:37:48 --> Total execution time: 0.2433
DEBUG - 2012-01-13 00:39:38 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:38 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Router Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Output Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Security Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Input Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:39:38 --> Language Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Loader Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:39:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Session Class Initialized
DEBUG - 2012-01-13 00:39:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:39:39 --> Session routines successfully run
DEBUG - 2012-01-13 00:39:39 --> Controller Class Initialized
DEBUG - 2012-01-13 00:39:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:39:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:39:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:39:39 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:39:39 --> Final output sent to browser
DEBUG - 2012-01-13 00:39:39 --> Total execution time: 0.3499
DEBUG - 2012-01-13 00:39:39 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:39 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:39 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:39 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:39 --> Router Class Initialized
ERROR - 2012-01-13 00:39:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:39:42 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:42 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Router Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Output Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Security Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Input Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:39:42 --> Language Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Loader Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:39:42 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Session Class Initialized
DEBUG - 2012-01-13 00:39:42 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:39:42 --> Session routines successfully run
DEBUG - 2012-01-13 00:39:42 --> Controller Class Initialized
DEBUG - 2012-01-13 00:39:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:39:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:39:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:39:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:39:42 --> Final output sent to browser
DEBUG - 2012-01-13 00:39:42 --> Total execution time: 0.3892
DEBUG - 2012-01-13 00:39:43 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:43 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:43 --> Router Class Initialized
ERROR - 2012-01-13 00:39:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:39:44 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:44 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:44 --> Router Class Initialized
DEBUG - 2012-01-13 00:39:44 --> Output Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Security Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Input Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:39:45 --> Language Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Loader Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:39:45 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Session Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:39:45 --> Session routines successfully run
DEBUG - 2012-01-13 00:39:45 --> Controller Class Initialized
DEBUG - 2012-01-13 00:39:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:39:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:39:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:39:45 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:39:45 --> Final output sent to browser
DEBUG - 2012-01-13 00:39:45 --> Total execution time: 0.3728
DEBUG - 2012-01-13 00:39:45 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:45 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:45 --> Router Class Initialized
ERROR - 2012-01-13 00:39:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:39:49 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:49 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Router Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Output Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Security Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Input Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:39:49 --> Language Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Loader Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:39:49 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Session Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:39:49 --> Session routines successfully run
DEBUG - 2012-01-13 00:39:49 --> Controller Class Initialized
DEBUG - 2012-01-13 00:39:49 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:39:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:39:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:39:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:39:49 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:39:49 --> Final output sent to browser
DEBUG - 2012-01-13 00:39:49 --> Total execution time: 0.5644
DEBUG - 2012-01-13 00:39:50 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:50 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:50 --> Router Class Initialized
ERROR - 2012-01-13 00:39:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:39:58 --> Config Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:39:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:39:58 --> URI Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Router Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Output Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Security Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Input Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:39:58 --> Language Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Loader Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:39:58 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Session Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:39:58 --> Session routines successfully run
DEBUG - 2012-01-13 00:39:58 --> Controller Class Initialized
DEBUG - 2012-01-13 00:39:58 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:39:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:39:58 --> Final output sent to browser
DEBUG - 2012-01-13 00:39:58 --> Total execution time: 0.4420
DEBUG - 2012-01-13 00:40:02 --> Config Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:40:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:40:02 --> URI Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Router Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Output Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Security Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Input Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:40:02 --> Language Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Loader Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:40:02 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Session Class Initialized
DEBUG - 2012-01-13 00:40:02 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:40:02 --> Session routines successfully run
DEBUG - 2012-01-13 00:40:02 --> Controller Class Initialized
DEBUG - 2012-01-13 00:40:02 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 00:40:02 --> Final output sent to browser
DEBUG - 2012-01-13 00:40:02 --> Total execution time: 0.5631
DEBUG - 2012-01-13 00:40:44 --> Config Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:40:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:40:44 --> URI Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Router Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Output Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Security Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Input Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:40:44 --> Language Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Loader Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:40:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Session Class Initialized
DEBUG - 2012-01-13 00:40:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:40:44 --> Session routines successfully run
DEBUG - 2012-01-13 00:40:44 --> Controller Class Initialized
DEBUG - 2012-01-13 00:40:44 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 00:40:44 --> Final output sent to browser
DEBUG - 2012-01-13 00:40:44 --> Total execution time: 0.4501
DEBUG - 2012-01-13 00:40:46 --> Config Class Initialized
DEBUG - 2012-01-13 00:40:46 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:40:46 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:40:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:40:46 --> URI Class Initialized
DEBUG - 2012-01-13 00:40:46 --> Router Class Initialized
DEBUG - 2012-01-13 00:40:46 --> No URI present. Default controller set.
DEBUG - 2012-01-13 00:40:46 --> Output Class Initialized
DEBUG - 2012-01-13 00:40:46 --> Security Class Initialized
DEBUG - 2012-01-13 00:40:46 --> Input Class Initialized
DEBUG - 2012-01-13 00:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:40:47 --> Language Class Initialized
DEBUG - 2012-01-13 00:40:47 --> Loader Class Initialized
DEBUG - 2012-01-13 00:40:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:40:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:40:47 --> Session Class Initialized
DEBUG - 2012-01-13 00:40:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:40:47 --> Session routines successfully run
DEBUG - 2012-01-13 00:40:47 --> Controller Class Initialized
DEBUG - 2012-01-13 00:40:47 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:40:47 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:40:47 --> Final output sent to browser
DEBUG - 2012-01-13 00:40:47 --> Total execution time: 1.1179
DEBUG - 2012-01-13 00:40:51 --> Config Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:40:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:40:51 --> URI Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Router Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Output Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Security Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Input Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:40:51 --> Language Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Loader Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:40:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Session Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:40:51 --> Session routines successfully run
DEBUG - 2012-01-13 00:40:51 --> Controller Class Initialized
DEBUG - 2012-01-13 00:40:51 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:40:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:40:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:40:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:40:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:40:51 --> Final output sent to browser
DEBUG - 2012-01-13 00:40:51 --> Total execution time: 0.5724
DEBUG - 2012-01-13 00:41:37 --> Config Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:41:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:41:37 --> URI Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Router Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Output Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Security Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Input Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:41:37 --> Language Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Loader Class Initialized
DEBUG - 2012-01-13 00:41:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:41:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:41:38 --> Session Class Initialized
DEBUG - 2012-01-13 00:41:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:41:38 --> Session routines successfully run
DEBUG - 2012-01-13 00:41:38 --> Controller Class Initialized
DEBUG - 2012-01-13 00:41:38 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:41:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:41:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:41:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:41:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:41:38 --> Final output sent to browser
DEBUG - 2012-01-13 00:41:38 --> Total execution time: 0.5553
DEBUG - 2012-01-13 00:41:45 --> Config Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:41:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:41:45 --> URI Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Router Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Output Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Security Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Input Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:41:45 --> Language Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Loader Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:41:45 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Session Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:41:45 --> Session routines successfully run
DEBUG - 2012-01-13 00:41:45 --> Controller Class Initialized
DEBUG - 2012-01-13 00:41:45 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:41:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:41:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:41:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:41:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:41:45 --> Final output sent to browser
DEBUG - 2012-01-13 00:41:45 --> Total execution time: 0.5549
DEBUG - 2012-01-13 00:41:47 --> Config Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:41:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:41:47 --> URI Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Router Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Output Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Security Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Input Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:41:47 --> Language Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Loader Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:41:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Session Class Initialized
DEBUG - 2012-01-13 00:41:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:41:47 --> Session routines successfully run
DEBUG - 2012-01-13 00:41:47 --> Controller Class Initialized
DEBUG - 2012-01-13 00:41:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:41:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:41:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:41:47 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:41:47 --> Final output sent to browser
DEBUG - 2012-01-13 00:41:47 --> Total execution time: 0.4731
DEBUG - 2012-01-13 00:41:51 --> Config Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:41:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:41:51 --> URI Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Router Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Output Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Security Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Input Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:41:51 --> Language Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Loader Class Initialized
DEBUG - 2012-01-13 00:41:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:41:52 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:41:52 --> Session Class Initialized
DEBUG - 2012-01-13 00:41:52 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:41:52 --> Session routines successfully run
DEBUG - 2012-01-13 00:41:52 --> Controller Class Initialized
DEBUG - 2012-01-13 00:41:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:41:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:41:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:41:52 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:41:52 --> Final output sent to browser
DEBUG - 2012-01-13 00:41:52 --> Total execution time: 0.5850
DEBUG - 2012-01-13 00:42:59 --> Config Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:42:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:42:59 --> URI Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Router Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Output Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Security Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Input Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:42:59 --> Language Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Loader Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:42:59 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Session Class Initialized
DEBUG - 2012-01-13 00:42:59 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:42:59 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:00 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:43:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:43:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:43:00 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:43:00 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:00 --> Total execution time: 0.5376
DEBUG - 2012-01-13 00:43:03 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:03 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:03 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:03 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:03 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:04 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:04 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:04 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:04 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:04 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:43:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:43:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:43:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:43:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:43:04 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:04 --> Total execution time: 0.6915
DEBUG - 2012-01-13 00:43:05 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:05 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:05 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:05 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:05 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:05 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:05 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:05 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:05 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:06 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:06 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:06 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:06 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:06 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:06 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:06 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:06 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:43:06 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:43:06 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:43:06 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:43:06 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:06 --> Total execution time: 1.0834
DEBUG - 2012-01-13 00:43:10 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:10 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:10 --> No URI present. Default controller set.
DEBUG - 2012-01-13 00:43:10 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:10 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:10 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:11 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:11 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:11 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:11 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:43:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:43:11 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:11 --> Total execution time: 0.9309
DEBUG - 2012-01-13 00:43:13 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:13 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:13 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:13 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:13 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:13 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:13 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:43:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:43:13 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:13 --> Total execution time: 0.4794
DEBUG - 2012-01-13 00:43:15 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:15 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:15 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:15 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:15 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:15 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:16 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:16 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:43:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:43:16 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:16 --> Total execution time: 0.8841
DEBUG - 2012-01-13 00:43:18 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:18 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:18 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:18 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:18 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:18 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:43:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:43:18 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:18 --> Total execution time: 0.5310
DEBUG - 2012-01-13 00:43:20 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:20 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:20 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:20 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:20 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:20 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:20 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:21 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:21 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:21 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:21 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:21 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 00:43:21 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:21 --> Total execution time: 0.9518
DEBUG - 2012-01-13 00:43:26 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:26 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:26 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:26 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:26 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:43:27 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:27 --> Total execution time: 0.9759
DEBUG - 2012-01-13 00:43:28 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:28 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:28 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:28 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:28 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:28 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:28 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:43:28 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:28 --> Total execution time: 0.4776
DEBUG - 2012-01-13 00:43:30 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:30 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:30 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:30 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:30 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:30 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:30 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:43:30 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:30 --> Total execution time: 0.4738
DEBUG - 2012-01-13 00:43:33 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:33 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:33 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:34 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:34 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:34 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:34 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:34 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:34 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:43:34 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:34 --> Total execution time: 0.4716
DEBUG - 2012-01-13 00:43:37 --> Config Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:43:37 --> URI Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Router Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Output Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Security Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Input Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:43:37 --> Language Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Loader Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:43:37 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Session Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:43:37 --> Session routines successfully run
DEBUG - 2012-01-13 00:43:37 --> Controller Class Initialized
DEBUG - 2012-01-13 00:43:37 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:43:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:43:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:43:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:43:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:43:37 --> Final output sent to browser
DEBUG - 2012-01-13 00:43:37 --> Total execution time: 0.5456
DEBUG - 2012-01-13 00:44:37 --> Config Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:44:37 --> URI Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Router Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Output Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Security Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Input Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:44:37 --> Language Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Loader Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:44:37 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Session Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:44:37 --> Session routines successfully run
DEBUG - 2012-01-13 00:44:37 --> Controller Class Initialized
DEBUG - 2012-01-13 00:44:37 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:44:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:44:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:44:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:44:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:44:37 --> Final output sent to browser
DEBUG - 2012-01-13 00:44:37 --> Total execution time: 0.4507
DEBUG - 2012-01-13 00:44:38 --> Config Class Initialized
DEBUG - 2012-01-13 00:44:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:44:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:44:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:44:38 --> URI Class Initialized
DEBUG - 2012-01-13 00:44:38 --> Router Class Initialized
ERROR - 2012-01-13 00:44:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:44:42 --> Config Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:44:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:44:42 --> URI Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Router Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Output Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Security Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Input Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:44:42 --> Language Class Initialized
DEBUG - 2012-01-13 00:44:42 --> Loader Class Initialized
DEBUG - 2012-01-13 00:44:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:44:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:44:43 --> Session Class Initialized
DEBUG - 2012-01-13 00:44:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:44:43 --> Session routines successfully run
DEBUG - 2012-01-13 00:44:43 --> Controller Class Initialized
DEBUG - 2012-01-13 00:44:43 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:44:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:44:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:44:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:44:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:44:43 --> Final output sent to browser
DEBUG - 2012-01-13 00:44:43 --> Total execution time: 0.9240
DEBUG - 2012-01-13 00:44:43 --> Config Class Initialized
DEBUG - 2012-01-13 00:44:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:44:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:44:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:44:43 --> URI Class Initialized
DEBUG - 2012-01-13 00:44:43 --> Router Class Initialized
ERROR - 2012-01-13 00:44:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 00:45:27 --> Config Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:45:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:45:27 --> URI Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Router Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Output Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Security Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Input Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:45:27 --> Language Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Loader Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:45:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Session Class Initialized
DEBUG - 2012-01-13 00:45:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:45:27 --> Session routines successfully run
DEBUG - 2012-01-13 00:45:27 --> Controller Class Initialized
DEBUG - 2012-01-13 00:45:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:45:27 --> Final output sent to browser
DEBUG - 2012-01-13 00:45:27 --> Total execution time: 0.3390
DEBUG - 2012-01-13 00:46:01 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:01 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:01 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:01 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:01 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:01 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:01 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:01 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 00:46:01 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:01 --> Total execution time: 0.4527
DEBUG - 2012-01-13 00:46:04 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:04 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:04 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:04 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:04 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:04 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:04 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:04 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:04 --> Total execution time: 0.5686
DEBUG - 2012-01-13 00:46:11 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:11 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:11 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:11 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:11 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:11 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:11 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:11 --> Total execution time: 0.5055
DEBUG - 2012-01-13 00:46:13 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:13 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:13 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:13 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:13 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:13 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:13 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:13 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:13 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:14 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:14 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:14 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:14 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:14 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:14 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:14 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:14 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:14 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:14 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:14 --> Total execution time: 0.6779
DEBUG - 2012-01-13 00:46:18 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:19 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:19 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:19 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:19 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:19 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:19 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:19 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:19 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:19 --> Total execution time: 0.4861
DEBUG - 2012-01-13 00:46:21 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:21 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:21 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:21 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:21 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:21 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:46:21 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:21 --> Total execution time: 0.5396
DEBUG - 2012-01-13 00:46:23 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:23 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:23 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:23 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:23 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:23 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-13 00:46:23 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:23 --> Total execution time: 0.3960
DEBUG - 2012-01-13 00:46:25 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:25 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:25 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:25 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:25 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:25 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:25 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:25 --> Total execution time: 0.5296
DEBUG - 2012-01-13 00:46:27 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:27 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:27 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:27 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:27 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:27 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:28 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:28 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:28 --> Total execution time: 0.4404
DEBUG - 2012-01-13 00:46:29 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:29 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:29 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:29 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:29 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:30 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:30 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:30 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:30 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:30 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:30 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:30 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:30 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:30 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:30 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:30 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:30 --> Total execution time: 0.7438
DEBUG - 2012-01-13 00:46:31 --> Config Class Initialized
DEBUG - 2012-01-13 00:46:31 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:46:31 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:46:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:46:31 --> URI Class Initialized
DEBUG - 2012-01-13 00:46:31 --> Router Class Initialized
DEBUG - 2012-01-13 00:46:31 --> Output Class Initialized
DEBUG - 2012-01-13 00:46:31 --> Security Class Initialized
DEBUG - 2012-01-13 00:46:31 --> Input Class Initialized
DEBUG - 2012-01-13 00:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:46:32 --> Language Class Initialized
DEBUG - 2012-01-13 00:46:32 --> Loader Class Initialized
DEBUG - 2012-01-13 00:46:32 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:46:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:46:32 --> Session Class Initialized
DEBUG - 2012-01-13 00:46:32 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:46:32 --> Session routines successfully run
DEBUG - 2012-01-13 00:46:32 --> Controller Class Initialized
DEBUG - 2012-01-13 00:46:32 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:46:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:46:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:46:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:46:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:46:32 --> Final output sent to browser
DEBUG - 2012-01-13 00:46:32 --> Total execution time: 0.5003
DEBUG - 2012-01-13 00:47:02 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:02 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:02 --> No URI present. Default controller set.
DEBUG - 2012-01-13 00:47:02 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:02 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:02 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:02 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:02 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:02 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:47:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 00:47:02 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:02 --> Total execution time: 0.4312
DEBUG - 2012-01-13 00:47:16 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:16 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:16 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:16 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:16 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:16 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:47:16 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:16 --> Total execution time: 0.5211
DEBUG - 2012-01-13 00:47:18 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:18 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:18 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:18 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:18 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:18 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:47:18 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:18 --> Total execution time: 0.4403
DEBUG - 2012-01-13 00:47:19 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:19 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:19 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:19 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:19 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:19 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:19 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:19 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:47:19 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:19 --> Total execution time: 0.4532
DEBUG - 2012-01-13 00:47:21 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:21 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:21 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:22 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:22 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:22 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:22 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:22 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:22 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:47:22 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:22 --> Total execution time: 0.8506
DEBUG - 2012-01-13 00:47:23 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:23 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:23 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:23 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:23 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:23 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:24 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:24 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:24 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:24 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:24 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:24 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 00:47:24 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:24 --> Total execution time: 0.4164
DEBUG - 2012-01-13 00:47:25 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:25 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:26 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:26 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:26 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:26 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:26 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:26 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:26 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:27 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 00:47:27 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:27 --> Total execution time: 0.6735
DEBUG - 2012-01-13 00:47:29 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:29 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:29 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:29 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:29 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:29 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:47:29 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:29 --> Total execution time: 0.4725
DEBUG - 2012-01-13 00:47:31 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:31 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:31 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:31 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:32 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:32 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:32 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:32 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:32 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:47:32 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:32 --> Total execution time: 0.8078
DEBUG - 2012-01-13 00:47:34 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:34 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:34 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:34 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:34 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:34 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:34 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:34 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:47:34 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:34 --> Total execution time: 0.3801
DEBUG - 2012-01-13 00:47:36 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:36 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:36 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:36 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:36 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:36 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:47:36 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:36 --> Total execution time: 0.5193
DEBUG - 2012-01-13 00:47:38 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:38 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:38 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:38 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:38 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:38 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 00:47:38 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:38 --> Total execution time: 0.4549
DEBUG - 2012-01-13 00:47:41 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:41 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:41 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:41 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:41 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:41 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:41 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Router Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Output Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Security Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Input Class Initialized
DEBUG - 2012-01-13 00:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:47:41 --> Language Class Initialized
DEBUG - 2012-01-13 00:47:42 --> Loader Class Initialized
DEBUG - 2012-01-13 00:47:42 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:47:42 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:47:42 --> Session Class Initialized
DEBUG - 2012-01-13 00:47:42 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:47:42 --> Session routines successfully run
DEBUG - 2012-01-13 00:47:42 --> Controller Class Initialized
DEBUG - 2012-01-13 00:47:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:47:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:47:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:47:42 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 00:47:42 --> Final output sent to browser
DEBUG - 2012-01-13 00:47:42 --> Total execution time: 0.7399
DEBUG - 2012-01-13 00:47:59 --> Config Class Initialized
DEBUG - 2012-01-13 00:47:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:47:59 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:47:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:47:59 --> URI Class Initialized
DEBUG - 2012-01-13 00:47:59 --> Router Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Output Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Security Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Input Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:48:00 --> Language Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Loader Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:48:00 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Session Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:48:00 --> Session routines successfully run
DEBUG - 2012-01-13 00:48:00 --> Controller Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Config Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:48:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:48:00 --> URI Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Router Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Output Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Security Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Input Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:48:00 --> Language Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Loader Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:48:00 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Session Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:48:00 --> Session routines successfully run
DEBUG - 2012-01-13 00:48:00 --> Controller Class Initialized
DEBUG - 2012-01-13 00:48:00 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:48:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:48:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:48:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:48:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:48:00 --> Final output sent to browser
DEBUG - 2012-01-13 00:48:00 --> Total execution time: 0.3796
DEBUG - 2012-01-13 00:48:11 --> Config Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:48:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:48:11 --> URI Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Router Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Output Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Security Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Input Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:48:11 --> Language Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Loader Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:48:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Session Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:48:11 --> Session routines successfully run
DEBUG - 2012-01-13 00:48:11 --> Controller Class Initialized
DEBUG - 2012-01-13 00:48:11 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:48:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:48:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:48:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:48:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:48:11 --> Final output sent to browser
DEBUG - 2012-01-13 00:48:11 --> Total execution time: 0.4728
DEBUG - 2012-01-13 00:48:14 --> Config Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:48:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:48:14 --> URI Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Router Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Output Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Security Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Input Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:48:14 --> Language Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Loader Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:48:14 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Session Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:48:14 --> Session routines successfully run
DEBUG - 2012-01-13 00:48:14 --> Controller Class Initialized
DEBUG - 2012-01-13 00:48:14 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:48:14 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:48:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:48:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:48:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:48:14 --> Final output sent to browser
DEBUG - 2012-01-13 00:48:14 --> Total execution time: 0.4372
DEBUG - 2012-01-13 00:48:43 --> Config Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:48:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:48:43 --> URI Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Router Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Output Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Security Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Input Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:48:43 --> Language Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Loader Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:48:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Session Class Initialized
DEBUG - 2012-01-13 00:48:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:48:43 --> Session routines successfully run
DEBUG - 2012-01-13 00:48:43 --> Controller Class Initialized
DEBUG - 2012-01-13 00:48:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:48:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:48:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:48:43 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 00:48:43 --> Final output sent to browser
DEBUG - 2012-01-13 00:48:43 --> Total execution time: 0.4478
DEBUG - 2012-01-13 00:48:56 --> Config Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:48:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:48:56 --> URI Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Router Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Output Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Security Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Input Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:48:56 --> Language Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Loader Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:48:56 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Session Class Initialized
DEBUG - 2012-01-13 00:48:56 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:48:56 --> Session routines successfully run
DEBUG - 2012-01-13 00:48:56 --> Controller Class Initialized
DEBUG - 2012-01-13 00:48:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:48:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:48:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:48:57 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 00:48:57 --> Final output sent to browser
DEBUG - 2012-01-13 00:48:57 --> Total execution time: 0.3817
DEBUG - 2012-01-13 00:50:35 --> Config Class Initialized
DEBUG - 2012-01-13 00:50:35 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:50:35 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:50:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:50:35 --> URI Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Router Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Output Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Security Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Input Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 00:50:36 --> Language Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Loader Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 00:50:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Session Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 00:50:36 --> Session routines successfully run
DEBUG - 2012-01-13 00:50:36 --> Controller Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Pagination Class Initialized
DEBUG - 2012-01-13 00:50:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 00:50:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 00:50:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 00:50:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 00:50:36 --> Final output sent to browser
DEBUG - 2012-01-13 00:50:36 --> Total execution time: 0.4164
DEBUG - 2012-01-13 00:50:36 --> Config Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 00:50:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 00:50:36 --> URI Class Initialized
DEBUG - 2012-01-13 00:50:36 --> Router Class Initialized
ERROR - 2012-01-13 00:50:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 21:08:25 --> Config Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:08:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:08:25 --> URI Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Router Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Output Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Security Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Input Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:08:25 --> Language Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Loader Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:08:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Session Class Initialized
DEBUG - 2012-01-13 21:08:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:08:25 --> A session cookie was not found.
DEBUG - 2012-01-13 21:08:25 --> Session routines successfully run
DEBUG - 2012-01-13 21:08:25 --> Controller Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Config Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:08:26 --> URI Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Router Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Output Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Security Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Input Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:08:26 --> Language Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Loader Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:08:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Session Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:08:26 --> Session routines successfully run
DEBUG - 2012-01-13 21:08:26 --> Controller Class Initialized
DEBUG - 2012-01-13 21:08:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:08:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:08:26 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 21:08:26 --> Final output sent to browser
DEBUG - 2012-01-13 21:08:26 --> Total execution time: 0.2331
DEBUG - 2012-01-13 21:08:26 --> Config Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:08:26 --> URI Class Initialized
DEBUG - 2012-01-13 21:08:26 --> Router Class Initialized
ERROR - 2012-01-13 21:08:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 21:08:29 --> Config Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:08:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:08:29 --> URI Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Router Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Output Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Security Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Input Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:08:29 --> Language Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Loader Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:08:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Session Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:08:29 --> Session routines successfully run
DEBUG - 2012-01-13 21:08:29 --> Controller Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Config Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:08:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:08:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:08:30 --> URI Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Router Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Output Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Security Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Input Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:08:30 --> Language Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Loader Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:08:30 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Session Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:08:30 --> Session routines successfully run
DEBUG - 2012-01-13 21:08:30 --> Controller Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:08:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:08:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:08:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:08:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 21:08:30 --> Final output sent to browser
DEBUG - 2012-01-13 21:08:30 --> Total execution time: 0.3449
DEBUG - 2012-01-13 21:08:30 --> Config Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:08:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:08:30 --> URI Class Initialized
DEBUG - 2012-01-13 21:08:30 --> Router Class Initialized
ERROR - 2012-01-13 21:08:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-13 21:09:09 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:09 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:09 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:09 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:09 --> A session cookie was not found.
DEBUG - 2012-01-13 21:09:09 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:09 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:09 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:09 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:09 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:09 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:09 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:09 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:09:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:09:09 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 21:09:09 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:09 --> Total execution time: 0.1630
DEBUG - 2012-01-13 21:09:11 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:11 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:11 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:11 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:11 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:11 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:11 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:12 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:12 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:12 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:12 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:12 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:09:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:09:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:09:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:09:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 21:09:12 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:12 --> Total execution time: 0.3048
DEBUG - 2012-01-13 21:09:20 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:20 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:20 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:09:20 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:20 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:20 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:20 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:20 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:20 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:09:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:09:20 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:20 --> Total execution time: 0.2382
DEBUG - 2012-01-13 21:09:24 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:24 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:24 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:24 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:24 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:24 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:09:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:09:24 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:24 --> Total execution time: 0.1718
DEBUG - 2012-01-13 21:09:26 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:26 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:26 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:26 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:26 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:26 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:09:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:09:26 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:26 --> Total execution time: 0.1707
DEBUG - 2012-01-13 21:09:28 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:28 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:28 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:28 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:28 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:28 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:28 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:09:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:09:28 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:28 --> Total execution time: 0.2280
DEBUG - 2012-01-13 21:09:32 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:32 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:32 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:32 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:32 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:32 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:09:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:09:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:09:32 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 21:09:32 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:32 --> Total execution time: 0.2619
DEBUG - 2012-01-13 21:09:33 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:33 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:33 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:33 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:33 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:33 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:33 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:09:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:09:33 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:09:33 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 21:09:33 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:33 --> Total execution time: 0.1865
DEBUG - 2012-01-13 21:09:42 --> Config Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:09:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:09:42 --> URI Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Router Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Output Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Security Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Input Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:09:42 --> Language Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Loader Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:09:42 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Session Class Initialized
DEBUG - 2012-01-13 21:09:42 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:09:42 --> Session routines successfully run
DEBUG - 2012-01-13 21:09:42 --> Controller Class Initialized
DEBUG - 2012-01-13 21:09:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:09:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:09:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:09:42 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 21:09:42 --> Final output sent to browser
DEBUG - 2012-01-13 21:09:42 --> Total execution time: 0.2383
DEBUG - 2012-01-13 21:11:44 --> Config Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:11:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:11:44 --> URI Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Router Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Output Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Security Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Input Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:11:44 --> Language Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Loader Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:11:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Session Class Initialized
DEBUG - 2012-01-13 21:11:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:11:45 --> Session routines successfully run
DEBUG - 2012-01-13 21:11:45 --> Controller Class Initialized
DEBUG - 2012-01-13 21:11:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:11:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:11:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:11:45 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 21:11:45 --> Final output sent to browser
DEBUG - 2012-01-13 21:11:45 --> Total execution time: 0.5711
DEBUG - 2012-01-13 21:12:23 --> Config Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:12:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:12:23 --> URI Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Router Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Output Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Security Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Input Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:12:23 --> Language Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Loader Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:12:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Session Class Initialized
DEBUG - 2012-01-13 21:12:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:12:23 --> Session routines successfully run
DEBUG - 2012-01-13 21:12:23 --> Controller Class Initialized
DEBUG - 2012-01-13 21:12:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:12:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:12:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:12:23 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 21:12:23 --> Final output sent to browser
DEBUG - 2012-01-13 21:12:23 --> Total execution time: 0.4681
DEBUG - 2012-01-13 21:12:50 --> Config Class Initialized
DEBUG - 2012-01-13 21:12:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:12:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:12:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:12:50 --> URI Class Initialized
DEBUG - 2012-01-13 21:12:50 --> Router Class Initialized
DEBUG - 2012-01-13 21:12:50 --> Output Class Initialized
DEBUG - 2012-01-13 21:12:50 --> Security Class Initialized
DEBUG - 2012-01-13 21:12:50 --> Input Class Initialized
DEBUG - 2012-01-13 21:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:12:51 --> Language Class Initialized
DEBUG - 2012-01-13 21:12:51 --> Loader Class Initialized
DEBUG - 2012-01-13 21:12:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:12:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:12:51 --> Session Class Initialized
DEBUG - 2012-01-13 21:12:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:12:51 --> Session routines successfully run
DEBUG - 2012-01-13 21:12:51 --> Controller Class Initialized
DEBUG - 2012-01-13 21:12:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:12:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:12:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:12:51 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 21:12:51 --> Final output sent to browser
DEBUG - 2012-01-13 21:12:51 --> Total execution time: 0.5434
DEBUG - 2012-01-13 21:13:56 --> Config Class Initialized
DEBUG - 2012-01-13 21:13:56 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:13:56 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:13:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:13:56 --> URI Class Initialized
DEBUG - 2012-01-13 21:13:56 --> Router Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Output Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Security Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Input Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:13:57 --> Language Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Loader Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:13:57 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Session Class Initialized
DEBUG - 2012-01-13 21:13:57 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:13:57 --> Session routines successfully run
DEBUG - 2012-01-13 21:13:57 --> Controller Class Initialized
DEBUG - 2012-01-13 21:13:57 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:13:57 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:13:57 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:13:57 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 21:13:57 --> Final output sent to browser
DEBUG - 2012-01-13 21:13:57 --> Total execution time: 2.2126
DEBUG - 2012-01-13 21:14:50 --> Config Class Initialized
DEBUG - 2012-01-13 21:14:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:14:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:14:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:14:51 --> URI Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Router Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Output Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Security Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Input Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:14:51 --> Language Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Loader Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:14:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Session Class Initialized
DEBUG - 2012-01-13 21:14:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:14:51 --> Session routines successfully run
DEBUG - 2012-01-13 21:14:51 --> Controller Class Initialized
DEBUG - 2012-01-13 21:14:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:14:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:14:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:14:51 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 21:14:51 --> Final output sent to browser
DEBUG - 2012-01-13 21:14:51 --> Total execution time: 0.5085
DEBUG - 2012-01-13 21:14:59 --> Config Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:15:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:15:00 --> URI Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Router Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Output Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Security Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Input Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:15:00 --> Language Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Loader Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:15:00 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Session Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:15:00 --> Session routines successfully run
DEBUG - 2012-01-13 21:15:00 --> Controller Class Initialized
DEBUG - 2012-01-13 21:15:00 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:15:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:15:00 --> Final output sent to browser
DEBUG - 2012-01-13 21:15:00 --> Total execution time: 0.5230
DEBUG - 2012-01-13 21:17:34 --> Config Class Initialized
DEBUG - 2012-01-13 21:17:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:17:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:17:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:17:34 --> URI Class Initialized
DEBUG - 2012-01-13 21:17:34 --> Router Class Initialized
DEBUG - 2012-01-13 21:17:35 --> Output Class Initialized
DEBUG - 2012-01-13 21:17:35 --> Security Class Initialized
DEBUG - 2012-01-13 21:17:35 --> Input Class Initialized
DEBUG - 2012-01-13 21:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:17:36 --> Language Class Initialized
DEBUG - 2012-01-13 21:17:36 --> Loader Class Initialized
DEBUG - 2012-01-13 21:17:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:17:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:17:36 --> Session Class Initialized
DEBUG - 2012-01-13 21:17:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:17:36 --> Session routines successfully run
DEBUG - 2012-01-13 21:17:36 --> Controller Class Initialized
DEBUG - 2012-01-13 21:17:36 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:17:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:17:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:17:36 --> Final output sent to browser
DEBUG - 2012-01-13 21:17:36 --> Total execution time: 1.9061
DEBUG - 2012-01-13 21:17:38 --> Config Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:17:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:17:38 --> URI Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Router Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Output Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Security Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Input Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:17:38 --> Language Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Loader Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:17:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Session Class Initialized
DEBUG - 2012-01-13 21:17:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:17:38 --> Session routines successfully run
DEBUG - 2012-01-13 21:17:38 --> Controller Class Initialized
DEBUG - 2012-01-13 21:17:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:17:38 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:17:38 --> Final output sent to browser
DEBUG - 2012-01-13 21:17:38 --> Total execution time: 0.5641
DEBUG - 2012-01-13 21:17:41 --> Config Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:17:41 --> URI Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Router Class Initialized
DEBUG - 2012-01-13 21:17:41 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:17:41 --> Output Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Security Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Input Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:17:41 --> Language Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Loader Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:17:41 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Session Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:17:41 --> Session routines successfully run
DEBUG - 2012-01-13 21:17:41 --> Controller Class Initialized
DEBUG - 2012-01-13 21:17:41 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:17:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:17:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:17:42 --> Final output sent to browser
DEBUG - 2012-01-13 21:17:42 --> Total execution time: 0.6241
DEBUG - 2012-01-13 21:17:43 --> Config Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:17:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:17:43 --> URI Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Router Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Output Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Security Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Input Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:17:43 --> Language Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Loader Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:17:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Session Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:17:43 --> Session routines successfully run
DEBUG - 2012-01-13 21:17:43 --> Controller Class Initialized
DEBUG - 2012-01-13 21:17:43 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:17:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:17:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:17:43 --> Final output sent to browser
DEBUG - 2012-01-13 21:17:43 --> Total execution time: 0.4980
DEBUG - 2012-01-13 21:17:45 --> Config Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:17:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:17:45 --> URI Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Router Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Output Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Security Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Input Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:17:45 --> Language Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Loader Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:17:45 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Session Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:17:45 --> Session routines successfully run
DEBUG - 2012-01-13 21:17:45 --> Controller Class Initialized
DEBUG - 2012-01-13 21:17:45 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:17:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:17:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:17:45 --> Final output sent to browser
DEBUG - 2012-01-13 21:17:45 --> Total execution time: 0.5857
DEBUG - 2012-01-13 21:22:20 --> Config Class Initialized
DEBUG - 2012-01-13 21:22:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:22:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:22:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:22:21 --> URI Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Router Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Output Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Security Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Input Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:22:21 --> Language Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Loader Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:22:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Session Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:22:21 --> Session routines successfully run
DEBUG - 2012-01-13 21:22:21 --> Controller Class Initialized
DEBUG - 2012-01-13 21:22:21 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:22:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:22:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:22:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:22:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:22:21 --> Final output sent to browser
DEBUG - 2012-01-13 21:22:21 --> Total execution time: 0.5448
DEBUG - 2012-01-13 21:22:24 --> Config Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:22:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:22:24 --> URI Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Router Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Output Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Security Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Input Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:22:24 --> Language Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Loader Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:22:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Session Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:22:24 --> Session routines successfully run
DEBUG - 2012-01-13 21:22:24 --> Controller Class Initialized
DEBUG - 2012-01-13 21:22:24 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:22:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:22:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:22:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:22:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:22:24 --> Final output sent to browser
DEBUG - 2012-01-13 21:22:24 --> Total execution time: 0.5682
DEBUG - 2012-01-13 21:22:25 --> Config Class Initialized
DEBUG - 2012-01-13 21:22:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:22:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:22:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:22:25 --> URI Class Initialized
DEBUG - 2012-01-13 21:22:25 --> Router Class Initialized
DEBUG - 2012-01-13 21:22:25 --> Output Class Initialized
DEBUG - 2012-01-13 21:22:25 --> Security Class Initialized
DEBUG - 2012-01-13 21:22:26 --> Input Class Initialized
DEBUG - 2012-01-13 21:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:22:26 --> Language Class Initialized
DEBUG - 2012-01-13 21:22:26 --> Loader Class Initialized
DEBUG - 2012-01-13 21:22:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:22:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:22:26 --> Session Class Initialized
DEBUG - 2012-01-13 21:22:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:22:26 --> Session routines successfully run
DEBUG - 2012-01-13 21:22:26 --> Controller Class Initialized
DEBUG - 2012-01-13 21:22:26 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:22:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:22:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:22:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:22:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:22:26 --> Final output sent to browser
DEBUG - 2012-01-13 21:22:26 --> Total execution time: 1.0585
DEBUG - 2012-01-13 21:27:04 --> Config Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:27:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:27:04 --> URI Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Router Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Output Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Security Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Input Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:27:04 --> Language Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Loader Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:27:04 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Session Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:27:04 --> Session routines successfully run
DEBUG - 2012-01-13 21:27:04 --> Controller Class Initialized
DEBUG - 2012-01-13 21:27:04 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:27:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:27:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:27:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:27:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:27:04 --> Final output sent to browser
DEBUG - 2012-01-13 21:27:04 --> Total execution time: 0.5667
DEBUG - 2012-01-13 21:27:08 --> Config Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:27:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:27:08 --> URI Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Router Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Output Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Security Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Input Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:27:08 --> Language Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Loader Class Initialized
DEBUG - 2012-01-13 21:27:08 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:27:09 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:27:09 --> Session Class Initialized
DEBUG - 2012-01-13 21:27:09 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:27:09 --> Session routines successfully run
DEBUG - 2012-01-13 21:27:09 --> Controller Class Initialized
DEBUG - 2012-01-13 21:27:09 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:27:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:27:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:27:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:27:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:27:09 --> Final output sent to browser
DEBUG - 2012-01-13 21:27:09 --> Total execution time: 1.3226
DEBUG - 2012-01-13 21:27:11 --> Config Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:27:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:27:11 --> URI Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Router Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Output Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Security Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Input Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:27:11 --> Language Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Loader Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:27:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Session Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:27:11 --> Session routines successfully run
DEBUG - 2012-01-13 21:27:11 --> Controller Class Initialized
DEBUG - 2012-01-13 21:27:11 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:27:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:27:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:27:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:27:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:27:11 --> Final output sent to browser
DEBUG - 2012-01-13 21:27:11 --> Total execution time: 0.4987
DEBUG - 2012-01-13 21:27:13 --> Config Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:27:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:27:13 --> URI Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Router Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Output Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Security Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Input Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:27:13 --> Language Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Loader Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:27:13 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Session Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:27:13 --> Session routines successfully run
DEBUG - 2012-01-13 21:27:13 --> Controller Class Initialized
DEBUG - 2012-01-13 21:27:13 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:27:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:27:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:27:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:27:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:27:14 --> Final output sent to browser
DEBUG - 2012-01-13 21:27:14 --> Total execution time: 1.0990
DEBUG - 2012-01-13 21:27:21 --> Config Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:27:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:27:21 --> URI Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Router Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Output Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Security Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Input Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:27:21 --> Language Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Loader Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:27:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Session Class Initialized
DEBUG - 2012-01-13 21:27:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:27:21 --> Session routines successfully run
DEBUG - 2012-01-13 21:27:21 --> Controller Class Initialized
DEBUG - 2012-01-13 21:27:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:27:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:27:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:27:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:27:22 --> Final output sent to browser
DEBUG - 2012-01-13 21:27:22 --> Total execution time: 0.5542
DEBUG - 2012-01-13 21:27:23 --> Config Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:27:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:27:23 --> URI Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Router Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Output Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Security Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Input Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:27:23 --> Language Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Loader Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:27:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Session Class Initialized
DEBUG - 2012-01-13 21:27:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:27:23 --> Session routines successfully run
DEBUG - 2012-01-13 21:27:23 --> Controller Class Initialized
DEBUG - 2012-01-13 21:27:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:27:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:27:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:27:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:27:24 --> Final output sent to browser
DEBUG - 2012-01-13 21:27:24 --> Total execution time: 0.5272
DEBUG - 2012-01-13 21:27:25 --> Config Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:27:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:27:25 --> URI Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Router Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Output Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Security Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Input Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:27:25 --> Language Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Loader Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:27:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Session Class Initialized
DEBUG - 2012-01-13 21:27:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:27:25 --> Session routines successfully run
DEBUG - 2012-01-13 21:27:25 --> Controller Class Initialized
DEBUG - 2012-01-13 21:27:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:27:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:27:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:27:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:27:25 --> Final output sent to browser
DEBUG - 2012-01-13 21:27:25 --> Total execution time: 0.5715
DEBUG - 2012-01-13 21:30:11 --> Config Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:30:12 --> URI Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Router Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Output Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Security Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Input Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:30:12 --> Language Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Loader Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:30:12 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Session Class Initialized
DEBUG - 2012-01-13 21:30:12 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:30:12 --> Session routines successfully run
DEBUG - 2012-01-13 21:30:12 --> Controller Class Initialized
DEBUG - 2012-01-13 21:30:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:31:54 --> Config Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:31:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:31:54 --> URI Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Router Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Output Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Security Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Input Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:31:54 --> Language Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Loader Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:31:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Session Class Initialized
DEBUG - 2012-01-13 21:31:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:31:54 --> Session routines successfully run
DEBUG - 2012-01-13 21:31:54 --> Controller Class Initialized
DEBUG - 2012-01-13 21:31:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:33:46 --> Config Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:33:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:33:46 --> URI Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Router Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Output Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Security Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Input Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:33:46 --> Language Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Loader Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:33:46 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:33:46 --> Session Class Initialized
DEBUG - 2012-01-13 21:33:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:33:47 --> Session routines successfully run
DEBUG - 2012-01-13 21:33:47 --> Controller Class Initialized
DEBUG - 2012-01-13 21:33:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:33:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:33:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:33:48 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:33:48 --> Final output sent to browser
DEBUG - 2012-01-13 21:33:48 --> Total execution time: 1.8920
DEBUG - 2012-01-13 21:34:07 --> Config Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:34:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:34:07 --> URI Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Router Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Output Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Security Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Input Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:34:07 --> Language Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Loader Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:34:07 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Session Class Initialized
DEBUG - 2012-01-13 21:34:07 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:34:07 --> Session routines successfully run
DEBUG - 2012-01-13 21:34:07 --> Controller Class Initialized
DEBUG - 2012-01-13 21:34:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:34:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:34:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:34:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:34:07 --> Final output sent to browser
DEBUG - 2012-01-13 21:34:07 --> Total execution time: 0.1780
DEBUG - 2012-01-13 21:35:32 --> Config Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:35:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:35:32 --> URI Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Router Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Output Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Security Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Input Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:35:32 --> Language Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Loader Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:35:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Session Class Initialized
DEBUG - 2012-01-13 21:35:32 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:35:32 --> Session routines successfully run
DEBUG - 2012-01-13 21:35:32 --> Controller Class Initialized
DEBUG - 2012-01-13 21:35:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:35:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:35:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:35:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:35:32 --> Final output sent to browser
DEBUG - 2012-01-13 21:35:32 --> Total execution time: 0.9218
DEBUG - 2012-01-13 21:35:47 --> Config Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:35:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:35:47 --> URI Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Router Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Output Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Security Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Input Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:35:47 --> Language Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Loader Class Initialized
DEBUG - 2012-01-13 21:35:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:35:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:35:48 --> Session Class Initialized
DEBUG - 2012-01-13 21:35:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:35:48 --> Session routines successfully run
DEBUG - 2012-01-13 21:35:48 --> Controller Class Initialized
DEBUG - 2012-01-13 21:35:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:35:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:35:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:35:48 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:35:48 --> Final output sent to browser
DEBUG - 2012-01-13 21:35:48 --> Total execution time: 0.4615
DEBUG - 2012-01-13 21:35:50 --> Config Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:35:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:35:50 --> URI Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Router Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Output Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Security Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Input Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:35:50 --> Language Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Loader Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:35:50 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Session Class Initialized
DEBUG - 2012-01-13 21:35:50 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:35:50 --> Session routines successfully run
DEBUG - 2012-01-13 21:35:50 --> Controller Class Initialized
DEBUG - 2012-01-13 21:35:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:35:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:35:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:35:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:35:50 --> Final output sent to browser
DEBUG - 2012-01-13 21:35:50 --> Total execution time: 0.7116
DEBUG - 2012-01-13 21:35:52 --> Config Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:35:52 --> URI Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Router Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Output Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Security Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Input Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:35:52 --> Language Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Loader Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:35:52 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Session Class Initialized
DEBUG - 2012-01-13 21:35:52 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:35:52 --> Session routines successfully run
DEBUG - 2012-01-13 21:35:52 --> Controller Class Initialized
DEBUG - 2012-01-13 21:35:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:35:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:35:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:35:52 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:35:52 --> Final output sent to browser
DEBUG - 2012-01-13 21:35:52 --> Total execution time: 0.5027
DEBUG - 2012-01-13 21:35:54 --> Config Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:35:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:35:54 --> URI Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Router Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Output Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Security Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Input Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:35:54 --> Language Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Loader Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:35:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Session Class Initialized
DEBUG - 2012-01-13 21:35:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:35:54 --> Session routines successfully run
DEBUG - 2012-01-13 21:35:54 --> Controller Class Initialized
DEBUG - 2012-01-13 21:35:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:35:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:35:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:35:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:35:54 --> Final output sent to browser
DEBUG - 2012-01-13 21:35:54 --> Total execution time: 0.4952
DEBUG - 2012-01-13 21:35:57 --> Config Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:35:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:35:57 --> URI Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Router Class Initialized
DEBUG - 2012-01-13 21:35:57 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:35:57 --> Output Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Security Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Input Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:35:57 --> Language Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Loader Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:35:57 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Session Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:35:57 --> Session routines successfully run
DEBUG - 2012-01-13 21:35:57 --> Controller Class Initialized
DEBUG - 2012-01-13 21:35:57 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:35:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:35:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:35:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:35:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:35:57 --> Final output sent to browser
DEBUG - 2012-01-13 21:35:57 --> Total execution time: 0.5542
DEBUG - 2012-01-13 21:35:59 --> Config Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:35:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:35:59 --> URI Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Router Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Output Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Security Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Input Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:35:59 --> Language Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Loader Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:35:59 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Session Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:35:59 --> Session routines successfully run
DEBUG - 2012-01-13 21:35:59 --> Controller Class Initialized
DEBUG - 2012-01-13 21:35:59 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:35:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:35:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:35:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:35:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:35:59 --> Final output sent to browser
DEBUG - 2012-01-13 21:35:59 --> Total execution time: 0.5995
DEBUG - 2012-01-13 21:36:01 --> Config Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:36:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:36:01 --> URI Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Router Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Output Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Security Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Input Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:36:01 --> Language Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Loader Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:36:01 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Session Class Initialized
DEBUG - 2012-01-13 21:36:01 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:36:01 --> Session routines successfully run
DEBUG - 2012-01-13 21:36:01 --> Controller Class Initialized
DEBUG - 2012-01-13 21:36:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:36:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:36:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:36:01 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:36:01 --> Final output sent to browser
DEBUG - 2012-01-13 21:36:01 --> Total execution time: 0.6129
DEBUG - 2012-01-13 21:39:24 --> Config Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:39:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:39:24 --> URI Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Router Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Output Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Security Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Input Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:39:24 --> Language Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Loader Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:39:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Session Class Initialized
DEBUG - 2012-01-13 21:39:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:39:24 --> Session routines successfully run
DEBUG - 2012-01-13 21:39:24 --> Controller Class Initialized
DEBUG - 2012-01-13 21:39:24 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Undefined variable: item A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 3
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 3
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Undefined variable: item A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 4
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 4
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 13
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 13
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 13
ERROR - 2012-01-13 21:39:24 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 13
DEBUG - 2012-01-13 21:39:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:39:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:39:24 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:39:24 --> Final output sent to browser
DEBUG - 2012-01-13 21:39:25 --> Total execution time: 0.5917
DEBUG - 2012-01-13 21:40:06 --> Config Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:40:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:40:06 --> URI Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Router Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Output Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Security Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Input Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:40:06 --> Language Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Loader Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:40:06 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Session Class Initialized
DEBUG - 2012-01-13 21:40:06 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:40:06 --> Session routines successfully run
DEBUG - 2012-01-13 21:40:06 --> Controller Class Initialized
DEBUG - 2012-01-13 21:40:06 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 21:40:06 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 13
ERROR - 2012-01-13 21:40:06 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 13
DEBUG - 2012-01-13 21:40:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:40:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:40:06 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:40:06 --> Final output sent to browser
DEBUG - 2012-01-13 21:40:06 --> Total execution time: 0.5396
DEBUG - 2012-01-13 21:41:20 --> Config Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:41:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:41:20 --> URI Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Router Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Output Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Security Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Input Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:41:20 --> Language Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Loader Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:41:20 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Session Class Initialized
DEBUG - 2012-01-13 21:41:20 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:41:20 --> Session routines successfully run
DEBUG - 2012-01-13 21:41:20 --> Controller Class Initialized
DEBUG - 2012-01-13 21:41:20 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 21:41:20 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:20 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:20 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:20 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
DEBUG - 2012-01-13 21:41:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:41:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:41:20 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:41:20 --> Final output sent to browser
DEBUG - 2012-01-13 21:41:20 --> Total execution time: 0.5901
DEBUG - 2012-01-13 21:41:46 --> Config Class Initialized
DEBUG - 2012-01-13 21:41:46 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:41:46 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:41:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:41:46 --> URI Class Initialized
DEBUG - 2012-01-13 21:41:46 --> Router Class Initialized
DEBUG - 2012-01-13 21:41:46 --> Output Class Initialized
DEBUG - 2012-01-13 21:41:46 --> Security Class Initialized
DEBUG - 2012-01-13 21:41:47 --> Input Class Initialized
DEBUG - 2012-01-13 21:41:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:41:47 --> Language Class Initialized
DEBUG - 2012-01-13 21:41:47 --> Loader Class Initialized
DEBUG - 2012-01-13 21:41:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:41:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:41:47 --> Session Class Initialized
DEBUG - 2012-01-13 21:41:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:41:47 --> Session routines successfully run
DEBUG - 2012-01-13 21:41:47 --> Controller Class Initialized
DEBUG - 2012-01-13 21:41:47 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 21:41:47 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:47 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:47 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:47 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
DEBUG - 2012-01-13 21:41:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:41:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:41:47 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:41:47 --> Final output sent to browser
DEBUG - 2012-01-13 21:41:47 --> Total execution time: 0.5969
DEBUG - 2012-01-13 21:41:50 --> Config Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:41:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:41:50 --> URI Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Router Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Output Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Security Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Input Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:41:50 --> Language Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Loader Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:41:50 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Session Class Initialized
DEBUG - 2012-01-13 21:41:50 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:41:50 --> Session routines successfully run
DEBUG - 2012-01-13 21:41:50 --> Controller Class Initialized
DEBUG - 2012-01-13 21:41:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:41:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:41:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:41:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:41:50 --> Final output sent to browser
DEBUG - 2012-01-13 21:41:50 --> Total execution time: 0.5326
DEBUG - 2012-01-13 21:41:52 --> Config Class Initialized
DEBUG - 2012-01-13 21:41:52 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:41:52 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:41:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:41:52 --> URI Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Router Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Output Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Security Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Input Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:41:53 --> Language Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Loader Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:41:53 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Session Class Initialized
DEBUG - 2012-01-13 21:41:53 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:41:53 --> Session routines successfully run
DEBUG - 2012-01-13 21:41:53 --> Controller Class Initialized
DEBUG - 2012-01-13 21:41:53 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 21:41:53 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:53 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
DEBUG - 2012-01-13 21:41:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:41:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:41:53 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:41:53 --> Final output sent to browser
DEBUG - 2012-01-13 21:41:53 --> Total execution time: 0.5407
DEBUG - 2012-01-13 21:41:55 --> Config Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:41:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:41:55 --> URI Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Router Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Output Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Security Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Input Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:41:55 --> Language Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Loader Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:41:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Session Class Initialized
DEBUG - 2012-01-13 21:41:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:41:55 --> Session routines successfully run
DEBUG - 2012-01-13 21:41:55 --> Controller Class Initialized
DEBUG - 2012-01-13 21:41:55 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 21:41:55 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:55 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
ERROR - 2012-01-13 21:41:55 --> Severity: Notice  --> Undefined variable: curent A:\home\codeigniter.blog\www\application\views\user\blocks\sidebar.php 7
DEBUG - 2012-01-13 21:41:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:41:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:41:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:41:55 --> Final output sent to browser
DEBUG - 2012-01-13 21:41:55 --> Total execution time: 0.8419
DEBUG - 2012-01-13 21:42:47 --> Config Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:42:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:42:47 --> URI Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Router Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Output Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Security Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Input Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:42:47 --> Language Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Loader Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:42:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Session Class Initialized
DEBUG - 2012-01-13 21:42:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:42:47 --> Session routines successfully run
DEBUG - 2012-01-13 21:42:47 --> Controller Class Initialized
DEBUG - 2012-01-13 21:42:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:42:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:42:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:42:48 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:42:48 --> Final output sent to browser
DEBUG - 2012-01-13 21:42:48 --> Total execution time: 1.0941
DEBUG - 2012-01-13 21:42:50 --> Config Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:42:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:42:50 --> URI Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Router Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Output Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Security Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Input Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:42:50 --> Language Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Loader Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:42:50 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Session Class Initialized
DEBUG - 2012-01-13 21:42:50 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:42:50 --> Session routines successfully run
DEBUG - 2012-01-13 21:42:50 --> Controller Class Initialized
DEBUG - 2012-01-13 21:42:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:42:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:42:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:42:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:42:50 --> Final output sent to browser
DEBUG - 2012-01-13 21:42:50 --> Total execution time: 0.5705
DEBUG - 2012-01-13 21:42:52 --> Config Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:42:52 --> URI Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Router Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Output Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Security Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Input Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:42:52 --> Language Class Initialized
DEBUG - 2012-01-13 21:42:52 --> Loader Class Initialized
DEBUG - 2012-01-13 21:42:53 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:42:53 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:42:53 --> Session Class Initialized
DEBUG - 2012-01-13 21:42:53 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:42:53 --> Session routines successfully run
DEBUG - 2012-01-13 21:42:53 --> Controller Class Initialized
DEBUG - 2012-01-13 21:42:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:42:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:42:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:42:53 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:42:53 --> Final output sent to browser
DEBUG - 2012-01-13 21:42:53 --> Total execution time: 1.3114
DEBUG - 2012-01-13 21:42:54 --> Config Class Initialized
DEBUG - 2012-01-13 21:42:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:42:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:42:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:42:55 --> URI Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Router Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Output Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Security Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Input Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:42:55 --> Language Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Loader Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:42:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Session Class Initialized
DEBUG - 2012-01-13 21:42:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:42:55 --> Session routines successfully run
DEBUG - 2012-01-13 21:42:55 --> Controller Class Initialized
DEBUG - 2012-01-13 21:42:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:42:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:42:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:42:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:42:55 --> Final output sent to browser
DEBUG - 2012-01-13 21:42:55 --> Total execution time: 0.6097
DEBUG - 2012-01-13 21:43:06 --> Config Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:43:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:43:06 --> URI Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Router Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Output Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Security Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Input Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:43:06 --> Language Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Loader Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:43:06 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Session Class Initialized
DEBUG - 2012-01-13 21:43:06 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:43:06 --> Session routines successfully run
DEBUG - 2012-01-13 21:43:06 --> Controller Class Initialized
DEBUG - 2012-01-13 21:43:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:43:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:43:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:43:06 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:43:06 --> Final output sent to browser
DEBUG - 2012-01-13 21:43:06 --> Total execution time: 0.4954
DEBUG - 2012-01-13 21:43:10 --> Config Class Initialized
DEBUG - 2012-01-13 21:43:10 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:43:10 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:43:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:43:10 --> URI Class Initialized
DEBUG - 2012-01-13 21:43:10 --> Router Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Output Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Security Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Input Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:43:11 --> Language Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Loader Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:43:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Session Class Initialized
DEBUG - 2012-01-13 21:43:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:43:11 --> Session routines successfully run
DEBUG - 2012-01-13 21:43:11 --> Controller Class Initialized
DEBUG - 2012-01-13 21:43:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:43:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:43:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:43:11 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:43:11 --> Final output sent to browser
DEBUG - 2012-01-13 21:43:11 --> Total execution time: 0.5212
DEBUG - 2012-01-13 21:43:18 --> Config Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:43:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:43:18 --> URI Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Router Class Initialized
DEBUG - 2012-01-13 21:43:18 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:43:18 --> Output Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Security Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Input Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:43:18 --> Language Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Loader Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:43:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Session Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:43:18 --> Session routines successfully run
DEBUG - 2012-01-13 21:43:18 --> Controller Class Initialized
DEBUG - 2012-01-13 21:43:18 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:43:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:43:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:43:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:43:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:43:18 --> Final output sent to browser
DEBUG - 2012-01-13 21:43:18 --> Total execution time: 0.4954
DEBUG - 2012-01-13 21:43:20 --> Config Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:43:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:43:20 --> URI Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Router Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Output Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Security Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Input Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:43:20 --> Language Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Loader Class Initialized
DEBUG - 2012-01-13 21:43:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:43:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:43:21 --> Session Class Initialized
DEBUG - 2012-01-13 21:43:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:43:21 --> Session routines successfully run
DEBUG - 2012-01-13 21:43:21 --> Controller Class Initialized
DEBUG - 2012-01-13 21:43:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:43:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:43:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:43:21 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:43:21 --> Final output sent to browser
DEBUG - 2012-01-13 21:43:21 --> Total execution time: 0.5527
DEBUG - 2012-01-13 21:45:05 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:05 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:05 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:05 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:05 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:05 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:05 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:05 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:45:05 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:05 --> Total execution time: 0.4831
DEBUG - 2012-01-13 21:45:08 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:08 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:08 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:09 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:09 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:09 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:09 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:09 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:09 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:45:09 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:09 --> Total execution time: 0.5156
DEBUG - 2012-01-13 21:45:11 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:11 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:11 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:11 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:11 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:45:11 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:11 --> Total execution time: 0.6977
DEBUG - 2012-01-13 21:45:13 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:13 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:13 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:13 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:13 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:13 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:13 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:45:13 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:13 --> Total execution time: 0.5134
DEBUG - 2012-01-13 21:45:15 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:15 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:15 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:15 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:15 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:15 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:15 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:45:15 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:15 --> Total execution time: 0.5120
DEBUG - 2012-01-13 21:45:19 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:20 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:20 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:20 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:20 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:20 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:20 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:45:20 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:20 --> Total execution time: 0.6799
DEBUG - 2012-01-13 21:45:23 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:23 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:23 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:45:23 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:23 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:23 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:23 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:23 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:45:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:45:23 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:24 --> Total execution time: 0.4912
DEBUG - 2012-01-13 21:45:26 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:26 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:26 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:26 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:26 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:45:26 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:26 --> Total execution time: 0.5079
DEBUG - 2012-01-13 21:45:29 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:29 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:29 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:29 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:29 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:29 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:45:29 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:29 --> Total execution time: 0.4796
DEBUG - 2012-01-13 21:45:31 --> Config Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:45:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:45:31 --> URI Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Router Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Output Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Security Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Input Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:45:31 --> Language Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Loader Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:45:31 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Session Class Initialized
DEBUG - 2012-01-13 21:45:31 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:45:31 --> Session routines successfully run
DEBUG - 2012-01-13 21:45:32 --> Controller Class Initialized
DEBUG - 2012-01-13 21:45:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:45:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:45:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:45:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:45:32 --> Final output sent to browser
DEBUG - 2012-01-13 21:45:32 --> Total execution time: 0.9989
DEBUG - 2012-01-13 21:48:03 --> Config Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:48:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:48:03 --> URI Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Router Class Initialized
DEBUG - 2012-01-13 21:48:03 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:48:03 --> Output Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Security Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Input Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:48:03 --> Language Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Loader Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:48:03 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Session Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:48:03 --> Session routines successfully run
DEBUG - 2012-01-13 21:48:03 --> Controller Class Initialized
DEBUG - 2012-01-13 21:48:03 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:48:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:48:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:48:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:48:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:48:03 --> Final output sent to browser
DEBUG - 2012-01-13 21:48:03 --> Total execution time: 0.5005
DEBUG - 2012-01-13 21:48:11 --> Config Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:48:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:48:11 --> URI Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Router Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Output Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Security Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Input Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:48:11 --> Language Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Loader Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:48:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Session Class Initialized
DEBUG - 2012-01-13 21:48:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:48:11 --> Session routines successfully run
DEBUG - 2012-01-13 21:48:11 --> Controller Class Initialized
DEBUG - 2012-01-13 21:48:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:48:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:48:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:48:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:48:11 --> Final output sent to browser
DEBUG - 2012-01-13 21:48:11 --> Total execution time: 0.5197
DEBUG - 2012-01-13 21:50:54 --> Config Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:50:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:50:54 --> URI Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Router Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Output Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Security Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Input Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:50:54 --> Language Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Loader Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:50:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Session Class Initialized
DEBUG - 2012-01-13 21:50:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:50:54 --> Session routines successfully run
DEBUG - 2012-01-13 21:50:54 --> Controller Class Initialized
DEBUG - 2012-01-13 21:50:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:50:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:50:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:50:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:50:54 --> Final output sent to browser
DEBUG - 2012-01-13 21:50:54 --> Total execution time: 0.5154
DEBUG - 2012-01-13 21:51:17 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:17 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:17 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:51:17 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:17 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:17 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:18 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:18 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:18 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:18 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:51:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:51:18 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:18 --> Total execution time: 0.5388
DEBUG - 2012-01-13 21:51:21 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:21 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:21 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:21 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:21 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:21 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:51:21 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:21 --> Total execution time: 0.5246
DEBUG - 2012-01-13 21:51:25 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:25 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:25 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:25 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:25 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:51:25 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:26 --> Total execution time: 0.5667
DEBUG - 2012-01-13 21:51:33 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:33 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:33 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:33 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:33 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:33 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:33 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:51:33 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:33 --> Total execution time: 0.5433
DEBUG - 2012-01-13 21:51:37 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:38 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:38 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:38 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:38 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:51:38 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:38 --> Total execution time: 0.8359
DEBUG - 2012-01-13 21:51:39 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:39 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:39 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:39 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:39 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:39 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:51:39 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:39 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:39 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:40 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:40 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:40 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:40 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:40 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:40 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:40 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:40 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:40 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:51:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:51:40 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:40 --> Total execution time: 0.8418
DEBUG - 2012-01-13 21:51:44 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:44 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:44 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:44 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:44 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:44 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 21:51:44 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:44 --> Total execution time: 0.6169
DEBUG - 2012-01-13 21:51:47 --> Config Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:51:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:51:47 --> URI Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Router Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Output Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Security Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Input Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:51:47 --> Language Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Loader Class Initialized
DEBUG - 2012-01-13 21:51:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:51:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:51:48 --> Session Class Initialized
DEBUG - 2012-01-13 21:51:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:51:48 --> Session routines successfully run
DEBUG - 2012-01-13 21:51:48 --> Controller Class Initialized
DEBUG - 2012-01-13 21:51:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:51:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:51:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:51:48 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:51:48 --> Final output sent to browser
DEBUG - 2012-01-13 21:51:48 --> Total execution time: 0.5499
DEBUG - 2012-01-13 21:53:12 --> Config Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:53:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:53:12 --> URI Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Router Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Output Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Security Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Input Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:53:12 --> Language Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Loader Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:53:12 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Session Class Initialized
DEBUG - 2012-01-13 21:53:12 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:53:12 --> Session routines successfully run
DEBUG - 2012-01-13 21:53:12 --> Controller Class Initialized
DEBUG - 2012-01-13 21:53:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:53:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:53:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:53:12 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:53:12 --> Final output sent to browser
DEBUG - 2012-01-13 21:53:12 --> Total execution time: 0.4331
DEBUG - 2012-01-13 21:53:23 --> Config Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:53:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:53:23 --> URI Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Router Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Output Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Security Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Input Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:53:23 --> Language Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Loader Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:53:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Session Class Initialized
DEBUG - 2012-01-13 21:53:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:53:23 --> Session routines successfully run
DEBUG - 2012-01-13 21:53:23 --> Controller Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Config Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:53:24 --> URI Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Router Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Output Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Security Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Input Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:53:24 --> Language Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Loader Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:53:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Session Class Initialized
DEBUG - 2012-01-13 21:53:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:53:24 --> Session routines successfully run
DEBUG - 2012-01-13 21:53:24 --> Controller Class Initialized
DEBUG - 2012-01-13 21:53:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:53:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:53:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:53:24 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:53:24 --> Final output sent to browser
DEBUG - 2012-01-13 21:53:24 --> Total execution time: 0.4571
DEBUG - 2012-01-13 21:53:54 --> Config Class Initialized
DEBUG - 2012-01-13 21:53:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:53:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:53:54 --> URI Class Initialized
DEBUG - 2012-01-13 21:53:54 --> Router Class Initialized
DEBUG - 2012-01-13 21:53:54 --> Output Class Initialized
DEBUG - 2012-01-13 21:53:54 --> Security Class Initialized
DEBUG - 2012-01-13 21:53:55 --> Input Class Initialized
DEBUG - 2012-01-13 21:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:53:55 --> Language Class Initialized
DEBUG - 2012-01-13 21:53:55 --> Loader Class Initialized
DEBUG - 2012-01-13 21:53:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:53:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:53:55 --> Session Class Initialized
DEBUG - 2012-01-13 21:53:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:53:55 --> Session routines successfully run
DEBUG - 2012-01-13 21:53:55 --> Controller Class Initialized
DEBUG - 2012-01-13 21:53:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:53:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:53:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:53:55 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 21:53:55 --> Final output sent to browser
DEBUG - 2012-01-13 21:53:55 --> Total execution time: 1.0494
DEBUG - 2012-01-13 21:54:11 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:12 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:12 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:12 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:12 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:12 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:12 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:12 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 21:54:12 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:12 --> Total execution time: 0.9729
DEBUG - 2012-01-13 21:54:15 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:15 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:15 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:15 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:15 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:15 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:15 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:15 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 21:54:15 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:15 --> Total execution time: 0.4415
DEBUG - 2012-01-13 21:54:18 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:18 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:18 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:18 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:18 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:18 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 21:54:18 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:18 --> Total execution time: 0.4782
DEBUG - 2012-01-13 21:54:20 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:20 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:20 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:20 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:20 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:20 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:20 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:20 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 21:54:20 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:20 --> Total execution time: 0.4430
DEBUG - 2012-01-13 21:54:22 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:22 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:22 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:22 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:22 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:22 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:22 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:22 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 21:54:22 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:22 --> Total execution time: 0.5036
DEBUG - 2012-01-13 21:54:24 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:24 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:24 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:24 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:24 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:24 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 21:54:24 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:24 --> Total execution time: 0.5340
DEBUG - 2012-01-13 21:54:26 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:26 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:26 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:26 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:27 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:27 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:27 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:27 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:27 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:27 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:27 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:27 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 21:54:28 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:28 --> Total execution time: 0.4942
DEBUG - 2012-01-13 21:54:30 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:30 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:30 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:30 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:30 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:30 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:30 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:31 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:54:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:31 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 21:54:31 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:31 --> Total execution time: 1.1153
DEBUG - 2012-01-13 21:54:34 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:34 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:34 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:34 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:34 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:34 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:34 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:54:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 21:54:34 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:34 --> Total execution time: 0.5280
DEBUG - 2012-01-13 21:54:36 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:36 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:36 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:36 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:37 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:37 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:54:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 21:54:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 21:54:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 21:54:37 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:37 --> Total execution time: 0.5967
DEBUG - 2012-01-13 21:54:54 --> Config Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:54:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:54:54 --> URI Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Router Class Initialized
DEBUG - 2012-01-13 21:54:54 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:54:54 --> Output Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Security Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Input Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:54:54 --> Language Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Loader Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:54:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Session Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:54:54 --> Session routines successfully run
DEBUG - 2012-01-13 21:54:54 --> Controller Class Initialized
DEBUG - 2012-01-13 21:54:54 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:54:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:54:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:54:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:54:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:54:54 --> Final output sent to browser
DEBUG - 2012-01-13 21:54:54 --> Total execution time: 0.2447
DEBUG - 2012-01-13 21:55:56 --> Config Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:55:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:55:56 --> URI Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Router Class Initialized
DEBUG - 2012-01-13 21:55:56 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:55:56 --> Output Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Security Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Input Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:55:56 --> Language Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Loader Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:55:56 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Session Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:55:56 --> Session routines successfully run
DEBUG - 2012-01-13 21:55:56 --> Controller Class Initialized
DEBUG - 2012-01-13 21:55:56 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:55:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:55:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:55:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:55:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:55:56 --> Final output sent to browser
DEBUG - 2012-01-13 21:55:56 --> Total execution time: 0.5047
DEBUG - 2012-01-13 21:56:25 --> Config Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:56:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:56:25 --> URI Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Router Class Initialized
DEBUG - 2012-01-13 21:56:25 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:56:25 --> Output Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Security Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Input Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:56:25 --> Language Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Loader Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:56:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Session Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:56:25 --> Session routines successfully run
DEBUG - 2012-01-13 21:56:25 --> Controller Class Initialized
DEBUG - 2012-01-13 21:56:25 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:56:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:56:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:56:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:56:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:56:25 --> Final output sent to browser
DEBUG - 2012-01-13 21:56:25 --> Total execution time: 0.5130
DEBUG - 2012-01-13 21:58:34 --> Config Class Initialized
DEBUG - 2012-01-13 21:58:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 21:58:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 21:58:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 21:58:35 --> URI Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Router Class Initialized
DEBUG - 2012-01-13 21:58:35 --> No URI present. Default controller set.
DEBUG - 2012-01-13 21:58:35 --> Output Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Security Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Input Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 21:58:35 --> Language Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Loader Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 21:58:35 --> Database Driver Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Session Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Helper loaded: string_helper
DEBUG - 2012-01-13 21:58:35 --> Session routines successfully run
DEBUG - 2012-01-13 21:58:35 --> Controller Class Initialized
DEBUG - 2012-01-13 21:58:35 --> Pagination Class Initialized
DEBUG - 2012-01-13 21:58:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 21:58:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 21:58:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 21:58:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 21:58:35 --> Final output sent to browser
DEBUG - 2012-01-13 21:58:35 --> Total execution time: 0.5912
DEBUG - 2012-01-13 22:01:18 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:18 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:18 --> No URI present. Default controller set.
DEBUG - 2012-01-13 22:01:18 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:18 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:18 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:18 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:18 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:01:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:01:18 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:18 --> Total execution time: 0.5181
DEBUG - 2012-01-13 22:01:20 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:20 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:21 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:21 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:21 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:21 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:01:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:01:21 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:21 --> Total execution time: 0.6060
DEBUG - 2012-01-13 22:01:23 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:23 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:23 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:23 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:23 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:23 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:24 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:24 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:01:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:01:24 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:24 --> Total execution time: 0.5846
DEBUG - 2012-01-13 22:01:26 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:26 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:26 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:27 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:27 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:27 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:27 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:01:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:01:27 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:27 --> Total execution time: 1.1788
DEBUG - 2012-01-13 22:01:28 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:28 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:28 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:28 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:28 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:28 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:29 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:29 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:29 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:29 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:29 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:29 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:29 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:29 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 22:01:29 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:29 --> Total execution time: 0.5396
DEBUG - 2012-01-13 22:01:36 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:36 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:36 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:36 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:36 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:36 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:36 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:37 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:37 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:37 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:37 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:37 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:37 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:01:37 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:37 --> Total execution time: 0.5217
DEBUG - 2012-01-13 22:01:39 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:39 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:39 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:39 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:39 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:40 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:40 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:01:40 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:40 --> Total execution time: 0.5046
DEBUG - 2012-01-13 22:01:41 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:41 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:41 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:41 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:41 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:41 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:42 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:42 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:42 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:42 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:42 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:42 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:42 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:42 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:42 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:01:42 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:42 --> Total execution time: 0.9552
DEBUG - 2012-01-13 22:01:44 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:44 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:44 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:44 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:44 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:44 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:01:44 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:44 --> Total execution time: 0.5759
DEBUG - 2012-01-13 22:01:49 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:49 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:49 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:49 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:49 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:49 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:49 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:49 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:01:49 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:49 --> Total execution time: 0.4359
DEBUG - 2012-01-13 22:01:51 --> Config Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:01:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:01:51 --> URI Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Router Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Output Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Security Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Input Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:01:51 --> Language Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Loader Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:01:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Session Class Initialized
DEBUG - 2012-01-13 22:01:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:01:51 --> Session routines successfully run
DEBUG - 2012-01-13 22:01:51 --> Controller Class Initialized
DEBUG - 2012-01-13 22:01:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:01:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:01:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:01:51 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:01:51 --> Final output sent to browser
DEBUG - 2012-01-13 22:01:51 --> Total execution time: 0.5614
DEBUG - 2012-01-13 22:05:38 --> Config Class Initialized
DEBUG - 2012-01-13 22:05:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:05:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:05:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:05:38 --> URI Class Initialized
DEBUG - 2012-01-13 22:05:38 --> Router Class Initialized
DEBUG - 2012-01-13 22:05:38 --> Output Class Initialized
DEBUG - 2012-01-13 22:05:38 --> Security Class Initialized
DEBUG - 2012-01-13 22:05:38 --> Input Class Initialized
DEBUG - 2012-01-13 22:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:05:38 --> Language Class Initialized
DEBUG - 2012-01-13 22:05:39 --> Loader Class Initialized
DEBUG - 2012-01-13 22:05:39 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:05:39 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:05:39 --> Session Class Initialized
DEBUG - 2012-01-13 22:05:39 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:05:39 --> Session routines successfully run
DEBUG - 2012-01-13 22:05:39 --> Controller Class Initialized
DEBUG - 2012-01-13 22:05:39 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:05:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:05:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:05:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:05:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:05:39 --> Final output sent to browser
DEBUG - 2012-01-13 22:05:39 --> Total execution time: 0.5374
DEBUG - 2012-01-13 22:05:48 --> Config Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:05:48 --> URI Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Router Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Output Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Security Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Input Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:05:48 --> Language Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Loader Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:05:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Session Class Initialized
DEBUG - 2012-01-13 22:05:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:05:48 --> Session routines successfully run
DEBUG - 2012-01-13 22:05:48 --> Controller Class Initialized
DEBUG - 2012-01-13 22:05:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:05:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:05:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:05:48 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:05:48 --> Final output sent to browser
DEBUG - 2012-01-13 22:05:48 --> Total execution time: 0.4895
DEBUG - 2012-01-13 22:05:51 --> Config Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:05:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:05:51 --> URI Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Router Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Output Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Security Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Input Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:05:51 --> Language Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Loader Class Initialized
DEBUG - 2012-01-13 22:05:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:05:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:05:52 --> Session Class Initialized
DEBUG - 2012-01-13 22:05:52 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:05:52 --> Session routines successfully run
DEBUG - 2012-01-13 22:05:52 --> Controller Class Initialized
DEBUG - 2012-01-13 22:05:52 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:05:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:05:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:05:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:05:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:05:52 --> Final output sent to browser
DEBUG - 2012-01-13 22:05:52 --> Total execution time: 0.5206
DEBUG - 2012-01-13 22:05:53 --> Config Class Initialized
DEBUG - 2012-01-13 22:05:53 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:05:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:05:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:05:53 --> URI Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Router Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Output Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Security Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Input Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:05:54 --> Language Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Loader Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:05:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Session Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:05:54 --> Session routines successfully run
DEBUG - 2012-01-13 22:05:54 --> Controller Class Initialized
DEBUG - 2012-01-13 22:05:54 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:05:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:05:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:05:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:05:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:05:54 --> Final output sent to browser
DEBUG - 2012-01-13 22:05:54 --> Total execution time: 1.1362
DEBUG - 2012-01-13 22:05:57 --> Config Class Initialized
DEBUG - 2012-01-13 22:05:57 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:05:57 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:05:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:05:57 --> URI Class Initialized
DEBUG - 2012-01-13 22:05:57 --> Router Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Output Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Security Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Input Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:05:58 --> Language Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Loader Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:05:58 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Session Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:05:58 --> Session routines successfully run
DEBUG - 2012-01-13 22:05:58 --> Controller Class Initialized
DEBUG - 2012-01-13 22:05:58 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:05:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:05:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:05:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:05:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:05:58 --> Final output sent to browser
DEBUG - 2012-01-13 22:05:58 --> Total execution time: 0.5198
DEBUG - 2012-01-13 22:05:59 --> Config Class Initialized
DEBUG - 2012-01-13 22:05:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:06:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:06:00 --> URI Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Router Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Output Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Security Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Input Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:06:00 --> Language Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Loader Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:06:00 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Session Class Initialized
DEBUG - 2012-01-13 22:06:00 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:06:00 --> Session routines successfully run
DEBUG - 2012-01-13 22:06:00 --> Controller Class Initialized
DEBUG - 2012-01-13 22:06:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:06:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:06:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:06:00 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-13 22:06:00 --> Final output sent to browser
DEBUG - 2012-01-13 22:06:00 --> Total execution time: 1.0093
DEBUG - 2012-01-13 22:06:50 --> Config Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:06:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:06:50 --> URI Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Router Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Output Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Security Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Input Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:06:50 --> Language Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Loader Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:06:50 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Session Class Initialized
DEBUG - 2012-01-13 22:06:50 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:06:50 --> Session routines successfully run
DEBUG - 2012-01-13 22:06:50 --> Controller Class Initialized
DEBUG - 2012-01-13 22:06:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:06:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:06:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:06:50 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-13 22:06:50 --> Final output sent to browser
DEBUG - 2012-01-13 22:06:50 --> Total execution time: 0.4705
DEBUG - 2012-01-13 22:06:54 --> Config Class Initialized
DEBUG - 2012-01-13 22:06:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:06:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:06:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:06:55 --> URI Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Router Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Output Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Security Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Input Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:06:55 --> Language Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Loader Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:06:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Session Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:06:55 --> Session routines successfully run
DEBUG - 2012-01-13 22:06:55 --> Controller Class Initialized
DEBUG - 2012-01-13 22:06:55 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:06:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:06:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:06:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:06:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:06:55 --> Final output sent to browser
DEBUG - 2012-01-13 22:06:55 --> Total execution time: 0.5302
DEBUG - 2012-01-13 22:07:14 --> Config Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:07:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:07:14 --> URI Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Router Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Output Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Security Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Input Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:07:14 --> Language Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Loader Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:07:14 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Session Class Initialized
DEBUG - 2012-01-13 22:07:14 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:07:14 --> Session routines successfully run
DEBUG - 2012-01-13 22:07:14 --> Controller Class Initialized
DEBUG - 2012-01-13 22:07:14 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:07:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:07:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:07:14 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 22:07:14 --> Final output sent to browser
DEBUG - 2012-01-13 22:07:14 --> Total execution time: 0.6008
DEBUG - 2012-01-13 22:07:18 --> Config Class Initialized
DEBUG - 2012-01-13 22:07:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:07:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:07:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:07:18 --> URI Class Initialized
DEBUG - 2012-01-13 22:07:18 --> Router Class Initialized
DEBUG - 2012-01-13 22:07:18 --> Output Class Initialized
DEBUG - 2012-01-13 22:07:18 --> Security Class Initialized
DEBUG - 2012-01-13 22:07:18 --> Input Class Initialized
DEBUG - 2012-01-13 22:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:07:19 --> Language Class Initialized
DEBUG - 2012-01-13 22:07:19 --> Loader Class Initialized
DEBUG - 2012-01-13 22:07:19 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:07:19 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:07:19 --> Session Class Initialized
DEBUG - 2012-01-13 22:07:19 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:07:19 --> Session routines successfully run
DEBUG - 2012-01-13 22:07:19 --> Controller Class Initialized
DEBUG - 2012-01-13 22:07:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:07:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:07:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:07:19 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:07:19 --> Final output sent to browser
DEBUG - 2012-01-13 22:07:19 --> Total execution time: 0.7519
DEBUG - 2012-01-13 22:07:21 --> Config Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:07:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:07:21 --> URI Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Router Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Output Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Security Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Input Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:07:21 --> Language Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Loader Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:07:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Session Class Initialized
DEBUG - 2012-01-13 22:07:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:07:21 --> Session routines successfully run
DEBUG - 2012-01-13 22:07:21 --> Controller Class Initialized
DEBUG - 2012-01-13 22:07:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:07:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:07:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:07:21 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 22:07:22 --> Final output sent to browser
DEBUG - 2012-01-13 22:07:22 --> Total execution time: 0.4672
DEBUG - 2012-01-13 22:07:23 --> Config Class Initialized
DEBUG - 2012-01-13 22:07:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:07:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:07:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:07:23 --> URI Class Initialized
DEBUG - 2012-01-13 22:07:23 --> Router Class Initialized
DEBUG - 2012-01-13 22:07:23 --> Output Class Initialized
DEBUG - 2012-01-13 22:07:24 --> Security Class Initialized
DEBUG - 2012-01-13 22:07:24 --> Input Class Initialized
DEBUG - 2012-01-13 22:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:07:24 --> Language Class Initialized
DEBUG - 2012-01-13 22:07:24 --> Loader Class Initialized
DEBUG - 2012-01-13 22:07:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:07:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:07:24 --> Session Class Initialized
DEBUG - 2012-01-13 22:07:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:07:24 --> Session routines successfully run
DEBUG - 2012-01-13 22:07:24 --> Controller Class Initialized
DEBUG - 2012-01-13 22:07:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:07:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:07:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:07:24 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 22:07:24 --> Final output sent to browser
DEBUG - 2012-01-13 22:07:24 --> Total execution time: 0.6074
DEBUG - 2012-01-13 22:10:51 --> Config Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:10:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:10:51 --> URI Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Router Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Output Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Security Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Input Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:10:51 --> Language Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Loader Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:10:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Session Class Initialized
DEBUG - 2012-01-13 22:10:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:10:51 --> Session routines successfully run
DEBUG - 2012-01-13 22:10:51 --> Controller Class Initialized
DEBUG - 2012-01-13 22:10:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:10:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:10:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:10:51 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 22:10:51 --> Final output sent to browser
DEBUG - 2012-01-13 22:10:51 --> Total execution time: 0.4576
DEBUG - 2012-01-13 22:10:54 --> Config Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:10:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:10:54 --> URI Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Router Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Output Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Security Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Input Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:10:54 --> Language Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Loader Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:10:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Session Class Initialized
DEBUG - 2012-01-13 22:10:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:10:54 --> Session routines successfully run
DEBUG - 2012-01-13 22:10:54 --> Controller Class Initialized
DEBUG - 2012-01-13 22:10:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:10:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:10:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:10:55 --> File loaded: application/views/admin/comment_edit.php
DEBUG - 2012-01-13 22:10:55 --> Final output sent to browser
DEBUG - 2012-01-13 22:10:55 --> Total execution time: 0.5838
DEBUG - 2012-01-13 22:11:03 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:03 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:03 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:03 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:03 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:03 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:03 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:03 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:03 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:03 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:04 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:04 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:04 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:04 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:04 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 22:11:04 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:04 --> Total execution time: 0.4794
DEBUG - 2012-01-13 22:11:10 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:10 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:10 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:10 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:10 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:10 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:10 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:11:10 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:10 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:10 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:11:10 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:10 --> Total execution time: 0.6286
DEBUG - 2012-01-13 22:11:16 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:16 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:16 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:16 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:16 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:16 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:11:16 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:16 --> Total execution time: 0.5540
DEBUG - 2012-01-13 22:11:21 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:21 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:21 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:22 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:22 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:22 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:22 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:22 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:11:22 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:22 --> Total execution time: 0.9913
DEBUG - 2012-01-13 22:11:40 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:40 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:40 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:40 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:40 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:40 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:40 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:40 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:11:40 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:40 --> Total execution time: 0.3058
DEBUG - 2012-01-13 22:11:41 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:41 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:41 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:41 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:41 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:41 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:41 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:41 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:11:41 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:41 --> Total execution time: 0.2042
DEBUG - 2012-01-13 22:11:42 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:42 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:42 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:42 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:42 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:42 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:42 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:11:42 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:42 --> Total execution time: 0.1845
DEBUG - 2012-01-13 22:11:43 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:43 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:43 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:43 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:43 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:11:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:11:43 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:11:43 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:43 --> Total execution time: 0.1654
DEBUG - 2012-01-13 22:11:47 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:47 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:47 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:47 --> No URI present. Default controller set.
DEBUG - 2012-01-13 22:11:47 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:48 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:48 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:48 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:48 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:11:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:11:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:11:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:11:48 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:48 --> Total execution time: 0.2347
DEBUG - 2012-01-13 22:11:50 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:50 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:50 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:50 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:50 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:50 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:50 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:11:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:11:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:11:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:11:50 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:50 --> Total execution time: 0.2278
DEBUG - 2012-01-13 22:11:51 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:51 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:51 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:51 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:51 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:51 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:11:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:11:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:11:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:11:51 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:51 --> Total execution time: 0.2179
DEBUG - 2012-01-13 22:11:53 --> Config Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:11:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:11:53 --> URI Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Router Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Output Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Security Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Input Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:11:53 --> Language Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Loader Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:11:53 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Session Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:11:53 --> Session routines successfully run
DEBUG - 2012-01-13 22:11:53 --> Controller Class Initialized
DEBUG - 2012-01-13 22:11:53 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:11:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:11:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:11:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:11:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:11:53 --> Final output sent to browser
DEBUG - 2012-01-13 22:11:53 --> Total execution time: 0.3263
DEBUG - 2012-01-13 22:12:31 --> Config Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:12:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:12:31 --> URI Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Router Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Output Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Security Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Input Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:12:31 --> Language Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Loader Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:12:31 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Session Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:12:31 --> Session routines successfully run
DEBUG - 2012-01-13 22:12:31 --> Controller Class Initialized
DEBUG - 2012-01-13 22:12:31 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:12:31 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:12:31 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:12:31 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:12:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:12:31 --> Final output sent to browser
DEBUG - 2012-01-13 22:12:31 --> Total execution time: 0.5387
DEBUG - 2012-01-13 22:12:37 --> Config Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:12:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:12:37 --> URI Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Router Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Output Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Security Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Input Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:12:37 --> Language Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Loader Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:12:37 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Session Class Initialized
DEBUG - 2012-01-13 22:12:37 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:12:37 --> Session routines successfully run
DEBUG - 2012-01-13 22:12:37 --> Controller Class Initialized
DEBUG - 2012-01-13 22:12:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:12:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:12:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:12:37 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:12:38 --> Final output sent to browser
DEBUG - 2012-01-13 22:12:38 --> Total execution time: 0.4695
DEBUG - 2012-01-13 22:13:41 --> Config Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:13:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:13:41 --> URI Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Router Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Output Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Security Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Input Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:13:41 --> Language Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Loader Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:13:41 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Session Class Initialized
DEBUG - 2012-01-13 22:13:41 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:13:42 --> Session routines successfully run
DEBUG - 2012-01-13 22:13:42 --> Controller Class Initialized
DEBUG - 2012-01-13 22:13:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:13:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:13:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:13:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:13:42 --> Final output sent to browser
DEBUG - 2012-01-13 22:13:42 --> Total execution time: 0.9066
DEBUG - 2012-01-13 22:16:37 --> Config Class Initialized
DEBUG - 2012-01-13 22:16:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:16:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:16:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:16:37 --> URI Class Initialized
DEBUG - 2012-01-13 22:16:37 --> Router Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Output Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Security Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Input Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:16:38 --> Language Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Loader Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:16:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Session Class Initialized
DEBUG - 2012-01-13 22:16:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:16:38 --> Session routines successfully run
DEBUG - 2012-01-13 22:16:38 --> Controller Class Initialized
DEBUG - 2012-01-13 22:16:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:16:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:16:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:16:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:16:38 --> Final output sent to browser
DEBUG - 2012-01-13 22:16:38 --> Total execution time: 0.5759
DEBUG - 2012-01-13 22:16:41 --> Config Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:16:41 --> URI Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Router Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Output Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Security Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Input Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:16:41 --> Language Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Loader Class Initialized
DEBUG - 2012-01-13 22:16:41 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:16:42 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Session Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:16:42 --> Session routines successfully run
DEBUG - 2012-01-13 22:16:42 --> Controller Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Config Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:16:42 --> URI Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Router Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Output Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Security Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Input Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:16:42 --> Language Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Loader Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:16:42 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Session Class Initialized
DEBUG - 2012-01-13 22:16:42 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:16:42 --> A session cookie was not found.
DEBUG - 2012-01-13 22:16:42 --> Session routines successfully run
DEBUG - 2012-01-13 22:16:42 --> Controller Class Initialized
DEBUG - 2012-01-13 22:16:42 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 22:16:42 --> Final output sent to browser
DEBUG - 2012-01-13 22:16:42 --> Total execution time: 0.5199
DEBUG - 2012-01-13 22:16:48 --> Config Class Initialized
DEBUG - 2012-01-13 22:16:48 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:16:48 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:16:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:16:48 --> URI Class Initialized
DEBUG - 2012-01-13 22:16:48 --> Router Class Initialized
DEBUG - 2012-01-13 22:16:48 --> Output Class Initialized
DEBUG - 2012-01-13 22:16:48 --> Security Class Initialized
DEBUG - 2012-01-13 22:16:48 --> Input Class Initialized
DEBUG - 2012-01-13 22:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:16:48 --> Language Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Loader Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:16:49 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Session Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:16:49 --> Session routines successfully run
DEBUG - 2012-01-13 22:16:49 --> Controller Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Config Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:16:49 --> URI Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Router Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Output Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Security Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Input Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:16:49 --> Language Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Loader Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:16:49 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Session Class Initialized
DEBUG - 2012-01-13 22:16:49 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:16:49 --> Session routines successfully run
DEBUG - 2012-01-13 22:16:49 --> Controller Class Initialized
DEBUG - 2012-01-13 22:16:49 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 22:16:49 --> Final output sent to browser
DEBUG - 2012-01-13 22:16:49 --> Total execution time: 0.3782
DEBUG - 2012-01-13 22:16:52 --> Config Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:16:52 --> URI Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Router Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Output Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Security Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Input Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:16:52 --> Language Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Loader Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:16:52 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Session Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:16:52 --> Session routines successfully run
DEBUG - 2012-01-13 22:16:52 --> Controller Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Config Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:16:52 --> URI Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Router Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Output Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Security Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Input Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:16:52 --> Language Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Loader Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:16:52 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Session Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:16:52 --> Session routines successfully run
DEBUG - 2012-01-13 22:16:52 --> Controller Class Initialized
DEBUG - 2012-01-13 22:16:52 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:16:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:16:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:16:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:16:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:16:53 --> Final output sent to browser
DEBUG - 2012-01-13 22:16:53 --> Total execution time: 0.4346
DEBUG - 2012-01-13 22:17:26 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:26 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:26 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:26 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:26 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:26 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:26 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:27 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:27 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:27 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:27 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:27 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:17:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:17:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:17:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:17:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:17:27 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:27 --> Total execution time: 1.3948
DEBUG - 2012-01-13 22:17:34 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:34 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:34 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:34 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:34 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:34 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:34 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:35 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:17:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:17:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:17:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:17:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:17:35 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:35 --> Total execution time: 0.4651
DEBUG - 2012-01-13 22:17:36 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:36 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:36 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:36 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:36 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:36 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:36 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:36 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:36 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:37 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:37 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:37 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:37 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:37 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:37 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:17:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:17:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:17:37 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:17:37 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:37 --> Total execution time: 0.5959
DEBUG - 2012-01-13 22:17:38 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:38 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:38 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:38 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:38 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:17:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:17:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:17:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 22:17:38 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:38 --> Total execution time: 0.5938
DEBUG - 2012-01-13 22:17:40 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:40 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:40 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:40 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:40 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:41 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:41 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:41 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:41 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:17:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:17:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:17:41 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-13 22:17:41 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:41 --> Total execution time: 1.1812
DEBUG - 2012-01-13 22:17:43 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:43 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:43 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:43 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:43 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:17:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:17:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:17:43 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-13 22:17:43 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:43 --> Total execution time: 0.5303
DEBUG - 2012-01-13 22:17:53 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:53 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:53 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:53 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:54 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:54 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:54 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:54 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:54 --> A session cookie was not found.
DEBUG - 2012-01-13 22:17:54 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:54 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:54 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 22:17:54 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:54 --> Total execution time: 0.4914
DEBUG - 2012-01-13 22:17:57 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:57 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:57 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:57 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:57 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:57 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:57 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Config Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:17:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:17:58 --> URI Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Router Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Output Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Security Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Input Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:17:58 --> Language Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Loader Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:17:58 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Session Class Initialized
DEBUG - 2012-01-13 22:17:58 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:17:58 --> Session routines successfully run
DEBUG - 2012-01-13 22:17:58 --> Controller Class Initialized
DEBUG - 2012-01-13 22:17:58 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 22:17:58 --> Final output sent to browser
DEBUG - 2012-01-13 22:17:58 --> Total execution time: 0.4585
DEBUG - 2012-01-13 22:18:00 --> Config Class Initialized
DEBUG - 2012-01-13 22:18:00 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:18:00 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:18:00 --> URI Class Initialized
DEBUG - 2012-01-13 22:18:00 --> Router Class Initialized
DEBUG - 2012-01-13 22:18:00 --> Output Class Initialized
DEBUG - 2012-01-13 22:18:00 --> Security Class Initialized
DEBUG - 2012-01-13 22:18:00 --> Input Class Initialized
DEBUG - 2012-01-13 22:18:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:18:01 --> Language Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Loader Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:18:01 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Session Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:18:01 --> Session routines successfully run
DEBUG - 2012-01-13 22:18:01 --> Controller Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Config Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:18:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:18:01 --> URI Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Router Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Output Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Security Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Input Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:18:01 --> Language Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Loader Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:18:01 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Session Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:18:01 --> Session routines successfully run
DEBUG - 2012-01-13 22:18:01 --> Controller Class Initialized
DEBUG - 2012-01-13 22:18:01 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:18:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:18:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:18:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:18:01 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:18:01 --> Final output sent to browser
DEBUG - 2012-01-13 22:18:01 --> Total execution time: 0.4390
DEBUG - 2012-01-13 22:20:24 --> Config Class Initialized
DEBUG - 2012-01-13 22:20:24 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:20:24 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:20:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:20:24 --> URI Class Initialized
DEBUG - 2012-01-13 22:20:24 --> Router Class Initialized
DEBUG - 2012-01-13 22:20:24 --> Output Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Security Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Input Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:20:25 --> Language Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Loader Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:20:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Session Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:20:25 --> Session routines successfully run
DEBUG - 2012-01-13 22:20:25 --> Controller Class Initialized
DEBUG - 2012-01-13 22:20:25 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:20:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:20:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:20:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:20:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:20:25 --> Final output sent to browser
DEBUG - 2012-01-13 22:20:25 --> Total execution time: 0.5491
DEBUG - 2012-01-13 22:21:01 --> Config Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:21:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:21:01 --> URI Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Router Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Output Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Security Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Input Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:21:01 --> Language Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Loader Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:21:01 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Session Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:21:01 --> Session routines successfully run
DEBUG - 2012-01-13 22:21:01 --> Controller Class Initialized
DEBUG - 2012-01-13 22:21:01 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:21:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:21:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:21:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:21:01 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:21:01 --> Final output sent to browser
DEBUG - 2012-01-13 22:21:01 --> Total execution time: 0.4775
DEBUG - 2012-01-13 22:23:35 --> Config Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:23:35 --> URI Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Router Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Output Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Security Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Input Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:23:35 --> Language Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Loader Class Initialized
DEBUG - 2012-01-13 22:23:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:23:36 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:23:36 --> Session Class Initialized
DEBUG - 2012-01-13 22:23:36 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:23:36 --> Session routines successfully run
DEBUG - 2012-01-13 22:23:36 --> Controller Class Initialized
DEBUG - 2012-01-13 22:23:36 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:23:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:23:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:23:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:23:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:23:36 --> Final output sent to browser
DEBUG - 2012-01-13 22:23:36 --> Total execution time: 0.6299
DEBUG - 2012-01-13 22:23:39 --> Config Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:23:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:23:39 --> URI Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Router Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Output Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Security Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Input Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:23:39 --> Language Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Loader Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:23:39 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Session Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:23:39 --> Session routines successfully run
DEBUG - 2012-01-13 22:23:39 --> Controller Class Initialized
DEBUG - 2012-01-13 22:23:39 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:23:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:23:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:23:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:23:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-13 22:23:39 --> Final output sent to browser
DEBUG - 2012-01-13 22:23:39 --> Total execution time: 0.4973
DEBUG - 2012-01-13 22:23:45 --> Config Class Initialized
DEBUG - 2012-01-13 22:23:45 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:23:45 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:23:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:23:46 --> URI Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Router Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Output Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Security Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Input Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:23:46 --> Language Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Loader Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:23:46 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Session Class Initialized
DEBUG - 2012-01-13 22:23:46 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:23:46 --> Session routines successfully run
DEBUG - 2012-01-13 22:23:46 --> Controller Class Initialized
DEBUG - 2012-01-13 22:23:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:23:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:23:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:23:46 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:23:46 --> Final output sent to browser
DEBUG - 2012-01-13 22:23:46 --> Total execution time: 0.4854
DEBUG - 2012-01-13 22:23:48 --> Config Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:23:48 --> URI Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Router Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Output Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Security Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Input Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:23:48 --> Language Class Initialized
DEBUG - 2012-01-13 22:23:48 --> Loader Class Initialized
DEBUG - 2012-01-13 22:23:49 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:23:49 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:23:49 --> Session Class Initialized
DEBUG - 2012-01-13 22:23:49 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:23:49 --> Session routines successfully run
DEBUG - 2012-01-13 22:23:49 --> Controller Class Initialized
DEBUG - 2012-01-13 22:23:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:23:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:23:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:23:49 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 22:23:49 --> Final output sent to browser
DEBUG - 2012-01-13 22:23:49 --> Total execution time: 0.5729
DEBUG - 2012-01-13 22:23:55 --> Config Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:23:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:23:55 --> URI Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Router Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Output Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Security Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Input Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:23:55 --> Language Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Loader Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:23:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Session Class Initialized
DEBUG - 2012-01-13 22:23:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:23:55 --> Session routines successfully run
DEBUG - 2012-01-13 22:23:55 --> Controller Class Initialized
DEBUG - 2012-01-13 22:23:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:23:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:23:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:23:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:23:55 --> Final output sent to browser
DEBUG - 2012-01-13 22:23:56 --> Total execution time: 0.9463
DEBUG - 2012-01-13 22:23:58 --> Config Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:23:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:23:58 --> URI Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Router Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Output Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Security Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Input Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:23:58 --> Language Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Loader Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:23:58 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Session Class Initialized
DEBUG - 2012-01-13 22:23:58 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:23:58 --> Session routines successfully run
DEBUG - 2012-01-13 22:23:58 --> Controller Class Initialized
DEBUG - 2012-01-13 22:23:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:23:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:23:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:23:59 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 22:23:59 --> Final output sent to browser
DEBUG - 2012-01-13 22:23:59 --> Total execution time: 0.4882
DEBUG - 2012-01-13 22:24:01 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:01 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:01 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:01 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:01 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:01 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:01 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:01 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:01 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:01 --> Total execution time: 0.7479
DEBUG - 2012-01-13 22:24:03 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:03 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:03 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:03 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:03 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:03 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:03 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:03 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:03 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:03 --> Total execution time: 0.4451
DEBUG - 2012-01-13 22:24:05 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:05 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:05 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:05 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:05 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:05 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:05 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:05 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:05 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:05 --> Total execution time: 0.4832
DEBUG - 2012-01-13 22:24:06 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:06 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:06 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:06 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:07 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:07 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:07 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:07 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:07 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:07 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:07 --> Total execution time: 1.0452
DEBUG - 2012-01-13 22:24:09 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:09 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:09 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:09 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:09 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:09 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:09 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:24:09 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:24:09 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-13 22:24:09 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:09 --> Total execution time: 0.7221
DEBUG - 2012-01-13 22:24:11 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:11 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:11 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:11 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:11 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:12 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:12 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:12 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:12 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:13 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:13 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:13 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:13 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:13 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:24:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:24:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:24:13 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:24:13 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:13 --> Total execution time: 0.9863
DEBUG - 2012-01-13 22:24:16 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:16 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:16 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:16 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:16 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:16 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:16 --> Total execution time: 0.5335
DEBUG - 2012-01-13 22:24:20 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:21 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:21 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:21 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:21 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:24:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:24:21 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-13 22:24:21 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:21 --> Total execution time: 0.5770
DEBUG - 2012-01-13 22:24:26 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:26 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:27 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:27 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:27 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:27 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:27 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:27 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:27 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:27 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:27 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:24:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:24:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:24:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:24:27 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:27 --> Total execution time: 0.4867
DEBUG - 2012-01-13 22:24:32 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:32 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:32 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:32 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:32 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:33 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:33 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:33 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:33 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:33 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:33 --> Total execution time: 1.0359
DEBUG - 2012-01-13 22:24:35 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:35 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:35 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:35 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:35 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:35 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:35 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:35 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:35 --> Total execution time: 0.4678
DEBUG - 2012-01-13 22:24:39 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:39 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:39 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:39 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:39 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:39 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:39 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:40 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:40 --> Total execution time: 0.4821
DEBUG - 2012-01-13 22:24:41 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:41 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:41 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:41 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:41 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:41 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:41 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:41 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:41 --> Total execution time: 0.4919
DEBUG - 2012-01-13 22:24:43 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:43 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:43 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:43 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:43 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:43 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:43 --> Total execution time: 0.4628
DEBUG - 2012-01-13 22:24:47 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:47 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:47 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:47 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:47 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:48 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:48 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:48 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:48 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:48 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:24:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:24:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:24:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:24:48 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:48 --> Total execution time: 0.5271
DEBUG - 2012-01-13 22:24:53 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:53 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:53 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:53 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:53 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:53 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:53 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:54 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:54 --> Total execution time: 0.8649
DEBUG - 2012-01-13 22:24:55 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:55 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:55 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:55 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:55 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:55 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:55 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:55 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:56 --> Total execution time: 0.5426
DEBUG - 2012-01-13 22:24:56 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:56 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:56 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:56 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:56 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:56 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:56 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:56 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:56 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:57 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:57 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:57 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:57 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:57 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:57 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:57 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:57 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:57 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:57 --> Total execution time: 0.4538
DEBUG - 2012-01-13 22:24:58 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:58 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:24:58 --> Language Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Loader Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:24:58 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Session Class Initialized
DEBUG - 2012-01-13 22:24:58 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:24:58 --> Session routines successfully run
DEBUG - 2012-01-13 22:24:58 --> Controller Class Initialized
DEBUG - 2012-01-13 22:24:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:24:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:24:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:24:58 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:24:58 --> Final output sent to browser
DEBUG - 2012-01-13 22:24:58 --> Total execution time: 0.6911
DEBUG - 2012-01-13 22:24:59 --> Config Class Initialized
DEBUG - 2012-01-13 22:24:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:24:59 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:24:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:24:59 --> URI Class Initialized
DEBUG - 2012-01-13 22:24:59 --> Router Class Initialized
DEBUG - 2012-01-13 22:24:59 --> Output Class Initialized
DEBUG - 2012-01-13 22:24:59 --> Security Class Initialized
DEBUG - 2012-01-13 22:24:59 --> Input Class Initialized
DEBUG - 2012-01-13 22:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:00 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:00 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:00 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:00 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:00 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:00 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:00 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:00 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:25:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:25:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:25:00 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:25:00 --> Final output sent to browser
DEBUG - 2012-01-13 22:25:00 --> Total execution time: 0.6926
DEBUG - 2012-01-13 22:25:11 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:11 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:11 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:12 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:12 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:12 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:25:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:25:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:25:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:25:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:25:12 --> Final output sent to browser
DEBUG - 2012-01-13 22:25:12 --> Total execution time: 0.7088
DEBUG - 2012-01-13 22:25:15 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:15 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:15 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:15 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:15 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:15 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:15 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:15 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:16 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:16 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:16 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:16 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:16 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:16 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:16 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:16 --> A session cookie was not found.
DEBUG - 2012-01-13 22:25:16 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:16 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:16 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 22:25:16 --> Final output sent to browser
DEBUG - 2012-01-13 22:25:17 --> Total execution time: 0.7515
DEBUG - 2012-01-13 22:25:20 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:20 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:20 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:20 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:20 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:20 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:20 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 22:25:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 22:25:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 22:25:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 22:25:20 --> Final output sent to browser
DEBUG - 2012-01-13 22:25:20 --> Total execution time: 0.5689
DEBUG - 2012-01-13 22:25:29 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:29 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:29 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:29 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:29 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:29 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:29 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:29 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:29 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:29 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-13 22:25:29 --> Final output sent to browser
DEBUG - 2012-01-13 22:25:29 --> Total execution time: 0.3645
DEBUG - 2012-01-13 22:25:46 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:46 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:46 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:46 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:46 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:46 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:46 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Config Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 22:25:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 22:25:47 --> URI Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Router Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Output Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Security Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Input Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 22:25:47 --> Language Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Loader Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 22:25:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Session Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 22:25:47 --> Session routines successfully run
DEBUG - 2012-01-13 22:25:47 --> Controller Class Initialized
DEBUG - 2012-01-13 22:25:47 --> Pagination Class Initialized
DEBUG - 2012-01-13 22:25:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 22:25:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 22:25:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 22:25:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 22:25:47 --> Final output sent to browser
DEBUG - 2012-01-13 22:25:47 --> Total execution time: 0.4793
DEBUG - 2012-01-13 23:51:54 --> Config Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:51:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:51:54 --> URI Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Router Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Output Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Security Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Input Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:51:54 --> Language Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Loader Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:51:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Session Class Initialized
DEBUG - 2012-01-13 23:51:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:51:54 --> Session routines successfully run
DEBUG - 2012-01-13 23:51:54 --> Controller Class Initialized
DEBUG - 2012-01-13 23:51:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:51:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:51:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:51:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:51:54 --> Final output sent to browser
DEBUG - 2012-01-13 23:51:54 --> Total execution time: 0.2263
DEBUG - 2012-01-13 23:53:44 --> Config Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:53:44 --> URI Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Router Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Output Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Security Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Input Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:53:44 --> Language Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Loader Class Initialized
DEBUG - 2012-01-13 23:53:44 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:53:45 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:53:45 --> Session Class Initialized
DEBUG - 2012-01-13 23:53:45 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:53:45 --> Session routines successfully run
DEBUG - 2012-01-13 23:53:45 --> Controller Class Initialized
DEBUG - 2012-01-13 23:53:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:53:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:53:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:53:45 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:53:45 --> Final output sent to browser
DEBUG - 2012-01-13 23:53:45 --> Total execution time: 0.4418
DEBUG - 2012-01-13 23:53:47 --> Config Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:53:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:53:47 --> URI Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Router Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Output Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Security Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Input Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:53:47 --> Language Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Loader Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:53:47 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Session Class Initialized
DEBUG - 2012-01-13 23:53:47 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:53:47 --> Session routines successfully run
DEBUG - 2012-01-13 23:53:47 --> Controller Class Initialized
DEBUG - 2012-01-13 23:53:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:53:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:53:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:53:47 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:53:47 --> Final output sent to browser
DEBUG - 2012-01-13 23:53:47 --> Total execution time: 0.5510
DEBUG - 2012-01-13 23:53:48 --> Config Class Initialized
DEBUG - 2012-01-13 23:53:48 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:53:48 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:53:48 --> URI Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Router Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Output Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Security Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Input Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:53:49 --> Language Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Loader Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:53:49 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Session Class Initialized
DEBUG - 2012-01-13 23:53:49 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:53:49 --> Session routines successfully run
DEBUG - 2012-01-13 23:53:49 --> Controller Class Initialized
DEBUG - 2012-01-13 23:53:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:53:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:53:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:53:49 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:53:49 --> Final output sent to browser
DEBUG - 2012-01-13 23:53:49 --> Total execution time: 0.6766
DEBUG - 2012-01-13 23:53:51 --> Config Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:53:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:53:51 --> URI Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Router Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Output Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Security Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Input Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:53:51 --> Language Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Loader Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:53:51 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Session Class Initialized
DEBUG - 2012-01-13 23:53:51 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:53:51 --> Session routines successfully run
DEBUG - 2012-01-13 23:53:51 --> Controller Class Initialized
DEBUG - 2012-01-13 23:53:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:53:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:53:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:53:51 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:53:51 --> Final output sent to browser
DEBUG - 2012-01-13 23:53:51 --> Total execution time: 0.4693
DEBUG - 2012-01-13 23:53:53 --> Config Class Initialized
DEBUG - 2012-01-13 23:53:53 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:53:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:53:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:53:53 --> URI Class Initialized
DEBUG - 2012-01-13 23:53:53 --> Router Class Initialized
DEBUG - 2012-01-13 23:53:53 --> Output Class Initialized
DEBUG - 2012-01-13 23:53:53 --> Security Class Initialized
DEBUG - 2012-01-13 23:53:53 --> Input Class Initialized
DEBUG - 2012-01-13 23:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:53:54 --> Language Class Initialized
DEBUG - 2012-01-13 23:53:54 --> Loader Class Initialized
DEBUG - 2012-01-13 23:53:54 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:53:54 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:53:54 --> Session Class Initialized
DEBUG - 2012-01-13 23:53:54 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:53:54 --> Session routines successfully run
DEBUG - 2012-01-13 23:53:54 --> Controller Class Initialized
DEBUG - 2012-01-13 23:53:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:53:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:53:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:53:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:53:54 --> Final output sent to browser
DEBUG - 2012-01-13 23:53:54 --> Total execution time: 0.8995
DEBUG - 2012-01-13 23:53:56 --> Config Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:53:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:53:56 --> URI Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Router Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Output Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Security Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Input Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:53:56 --> Language Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Loader Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:53:56 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Session Class Initialized
DEBUG - 2012-01-13 23:53:56 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:53:56 --> Session routines successfully run
DEBUG - 2012-01-13 23:53:56 --> Controller Class Initialized
DEBUG - 2012-01-13 23:53:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:53:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:53:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:53:56 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:53:57 --> Final output sent to browser
DEBUG - 2012-01-13 23:53:57 --> Total execution time: 0.5007
DEBUG - 2012-01-13 23:54:45 --> Config Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:54:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:54:45 --> URI Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Router Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Output Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Security Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Input Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:54:45 --> Language Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Loader Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:54:45 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Session Class Initialized
DEBUG - 2012-01-13 23:54:45 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:54:45 --> Session routines successfully run
DEBUG - 2012-01-13 23:54:45 --> Controller Class Initialized
DEBUG - 2012-01-13 23:54:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:54:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:54:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:54:45 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:54:45 --> Final output sent to browser
DEBUG - 2012-01-13 23:54:45 --> Total execution time: 0.5227
DEBUG - 2012-01-13 23:54:48 --> Config Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:54:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:54:48 --> URI Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Router Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Output Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Security Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Input Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:54:48 --> Language Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Loader Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:54:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Session Class Initialized
DEBUG - 2012-01-13 23:54:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:54:48 --> Session routines successfully run
DEBUG - 2012-01-13 23:54:48 --> Controller Class Initialized
DEBUG - 2012-01-13 23:54:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:54:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:54:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:54:48 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:54:48 --> Final output sent to browser
DEBUG - 2012-01-13 23:54:48 --> Total execution time: 0.5297
DEBUG - 2012-01-13 23:54:49 --> Config Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:54:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:54:49 --> URI Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Router Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Output Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Security Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Input Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:54:49 --> Language Class Initialized
DEBUG - 2012-01-13 23:54:49 --> Loader Class Initialized
DEBUG - 2012-01-13 23:54:50 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:54:50 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:54:50 --> Session Class Initialized
DEBUG - 2012-01-13 23:54:50 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:54:50 --> Session routines successfully run
DEBUG - 2012-01-13 23:54:50 --> Controller Class Initialized
DEBUG - 2012-01-13 23:54:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:54:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:54:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:54:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:54:50 --> Final output sent to browser
DEBUG - 2012-01-13 23:54:50 --> Total execution time: 0.5558
DEBUG - 2012-01-13 23:55:08 --> Config Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:55:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:55:08 --> URI Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Router Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Output Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Security Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Input Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:55:08 --> Language Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Loader Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:55:08 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Session Class Initialized
DEBUG - 2012-01-13 23:55:08 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:55:08 --> Session routines successfully run
DEBUG - 2012-01-13 23:55:08 --> Controller Class Initialized
DEBUG - 2012-01-13 23:55:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:55:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:55:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:55:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:55:08 --> Final output sent to browser
DEBUG - 2012-01-13 23:55:08 --> Total execution time: 0.4788
DEBUG - 2012-01-13 23:55:11 --> Config Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:55:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:55:11 --> URI Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Router Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Output Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Security Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Input Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:55:11 --> Language Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Loader Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:55:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Session Class Initialized
DEBUG - 2012-01-13 23:55:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:55:11 --> Session routines successfully run
DEBUG - 2012-01-13 23:55:11 --> Controller Class Initialized
DEBUG - 2012-01-13 23:55:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:55:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:55:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:55:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:55:11 --> Final output sent to browser
DEBUG - 2012-01-13 23:55:11 --> Total execution time: 0.4703
DEBUG - 2012-01-13 23:55:13 --> Config Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:55:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:55:13 --> URI Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Router Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Output Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Security Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Input Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:55:13 --> Language Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Loader Class Initialized
DEBUG - 2012-01-13 23:55:13 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:55:13 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:55:14 --> Session Class Initialized
DEBUG - 2012-01-13 23:55:14 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:55:14 --> Session routines successfully run
DEBUG - 2012-01-13 23:55:14 --> Controller Class Initialized
DEBUG - 2012-01-13 23:55:14 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 23:55:14 --> Severity: Notice  --> Undefined index: 4 A:\home\codeigniter.blog\www\application\views\user\category.php 4
ERROR - 2012-01-13 23:55:14 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\user\category.php 4
DEBUG - 2012-01-13 23:55:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:55:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:55:14 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:55:14 --> Final output sent to browser
DEBUG - 2012-01-13 23:55:14 --> Total execution time: 1.2347
DEBUG - 2012-01-13 23:55:17 --> Config Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:55:17 --> URI Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Router Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Output Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Security Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Input Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:55:17 --> Language Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Loader Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:55:17 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Session Class Initialized
DEBUG - 2012-01-13 23:55:17 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:55:17 --> Session routines successfully run
DEBUG - 2012-01-13 23:55:17 --> Controller Class Initialized
DEBUG - 2012-01-13 23:55:17 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 23:55:17 --> Severity: Notice  --> Undefined index: 4 A:\home\codeigniter.blog\www\application\views\user\category.php 4
ERROR - 2012-01-13 23:55:17 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\user\category.php 4
DEBUG - 2012-01-13 23:55:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:55:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:55:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:55:17 --> Final output sent to browser
DEBUG - 2012-01-13 23:55:17 --> Total execution time: 0.4993
DEBUG - 2012-01-13 23:55:21 --> Config Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:55:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:55:21 --> URI Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Router Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Output Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Security Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Input Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:55:21 --> Language Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Loader Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:55:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Session Class Initialized
DEBUG - 2012-01-13 23:55:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:55:21 --> Session routines successfully run
DEBUG - 2012-01-13 23:55:21 --> Controller Class Initialized
DEBUG - 2012-01-13 23:55:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:55:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:55:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:55:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:55:21 --> Final output sent to browser
DEBUG - 2012-01-13 23:55:21 --> Total execution time: 0.4552
DEBUG - 2012-01-13 23:56:21 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:21 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:21 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:21 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:21 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:21 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:21 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:21 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:21 --> Total execution time: 0.4572
DEBUG - 2012-01-13 23:56:23 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:23 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:23 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:23 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:23 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:23 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:23 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:23 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:23 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:24 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:24 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:24 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:24 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:24 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:24 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:24 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:24 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:24 --> Total execution time: 1.1641
DEBUG - 2012-01-13 23:56:26 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:26 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:26 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:26 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:26 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:26 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:26 --> Total execution time: 0.5693
DEBUG - 2012-01-13 23:56:28 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:28 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:28 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:28 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:29 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:29 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:29 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:29 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:29 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:29 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:29 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:29 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:29 --> Total execution time: 1.1387
DEBUG - 2012-01-13 23:56:34 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:34 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:34 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:34 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:34 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:34 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:34 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:35 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:35 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:35 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:35 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:35 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:35 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:35 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:35 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:35 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:35 --> File loaded: application/views/user/blocks/header.php
ERROR - 2012-01-13 23:56:35 --> Severity: Notice  --> Undefined offset: 0 A:\home\codeigniter.blog\www\application\views\user\category.php 4
ERROR - 2012-01-13 23:56:35 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\user\category.php 4
DEBUG - 2012-01-13 23:56:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:35 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:35 --> Total execution time: 1.1338
DEBUG - 2012-01-13 23:56:41 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:41 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:41 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:41 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:41 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:41 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:41 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:41 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:41 --> Total execution time: 0.8052
DEBUG - 2012-01-13 23:56:43 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:43 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:43 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:43 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:43 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:43 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:43 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:43 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:43 --> Total execution time: 0.4763
DEBUG - 2012-01-13 23:56:45 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:45 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:45 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:45 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:46 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:46 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:46 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:46 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:46 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:46 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:46 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:46 --> Total execution time: 0.7248
DEBUG - 2012-01-13 23:56:49 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:49 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:49 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:49 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:49 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:49 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:49 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:49 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-13 23:56:49 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:49 --> Total execution time: 0.4731
DEBUG - 2012-01-13 23:56:53 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:53 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:53 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Loader Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:56:53 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Session Class Initialized
DEBUG - 2012-01-13 23:56:53 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:56:53 --> Session routines successfully run
DEBUG - 2012-01-13 23:56:53 --> Controller Class Initialized
DEBUG - 2012-01-13 23:56:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:56:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:56:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:56:53 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:56:53 --> Final output sent to browser
DEBUG - 2012-01-13 23:56:53 --> Total execution time: 0.4648
DEBUG - 2012-01-13 23:56:59 --> Config Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:56:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:56:59 --> URI Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Router Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Output Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Security Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Input Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:56:59 --> Language Class Initialized
DEBUG - 2012-01-13 23:56:59 --> Loader Class Initialized
DEBUG - 2012-01-13 23:57:00 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:57:00 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:57:00 --> Session Class Initialized
DEBUG - 2012-01-13 23:57:00 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:57:00 --> Session routines successfully run
DEBUG - 2012-01-13 23:57:00 --> Controller Class Initialized
DEBUG - 2012-01-13 23:57:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:57:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:57:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:57:00 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:57:00 --> Final output sent to browser
DEBUG - 2012-01-13 23:57:00 --> Total execution time: 0.9798
DEBUG - 2012-01-13 23:57:12 --> Config Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:57:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:57:12 --> URI Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Router Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Output Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Security Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Input Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:57:12 --> Language Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Loader Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:57:12 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Session Class Initialized
DEBUG - 2012-01-13 23:57:12 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:57:12 --> Session routines successfully run
DEBUG - 2012-01-13 23:57:12 --> Controller Class Initialized
DEBUG - 2012-01-13 23:57:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:57:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:57:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:57:12 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:57:12 --> Final output sent to browser
DEBUG - 2012-01-13 23:57:12 --> Total execution time: 0.4923
DEBUG - 2012-01-13 23:57:18 --> Config Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:57:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:57:18 --> URI Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Router Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Output Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Security Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Input Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:57:18 --> Language Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Loader Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:57:18 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Session Class Initialized
DEBUG - 2012-01-13 23:57:18 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:57:18 --> Session routines successfully run
DEBUG - 2012-01-13 23:57:18 --> Controller Class Initialized
DEBUG - 2012-01-13 23:57:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:57:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:57:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:57:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:57:19 --> Final output sent to browser
DEBUG - 2012-01-13 23:57:19 --> Total execution time: 0.5070
DEBUG - 2012-01-13 23:57:20 --> Config Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:57:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:57:20 --> URI Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Router Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Output Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Security Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Input Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:57:20 --> Language Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Loader Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:57:20 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Session Class Initialized
DEBUG - 2012-01-13 23:57:20 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:57:20 --> Session routines successfully run
DEBUG - 2012-01-13 23:57:20 --> Controller Class Initialized
DEBUG - 2012-01-13 23:57:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:57:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:57:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:57:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:57:20 --> Final output sent to browser
DEBUG - 2012-01-13 23:57:20 --> Total execution time: 0.4729
DEBUG - 2012-01-13 23:57:22 --> Config Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:57:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:57:22 --> URI Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Router Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Output Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Security Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Input Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:57:22 --> Language Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Loader Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:57:22 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Session Class Initialized
DEBUG - 2012-01-13 23:57:22 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:57:22 --> Session routines successfully run
DEBUG - 2012-01-13 23:57:22 --> Controller Class Initialized
DEBUG - 2012-01-13 23:57:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:57:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:57:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:57:22 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:57:22 --> Final output sent to browser
DEBUG - 2012-01-13 23:57:22 --> Total execution time: 0.4885
DEBUG - 2012-01-13 23:57:25 --> Config Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:57:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:57:25 --> URI Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Router Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Output Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Security Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Input Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:57:25 --> Language Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Loader Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:57:25 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Session Class Initialized
DEBUG - 2012-01-13 23:57:25 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:57:25 --> Session routines successfully run
DEBUG - 2012-01-13 23:57:25 --> Controller Class Initialized
DEBUG - 2012-01-13 23:57:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:57:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:57:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:57:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:57:25 --> Final output sent to browser
DEBUG - 2012-01-13 23:57:25 --> Total execution time: 0.5864
DEBUG - 2012-01-13 23:57:27 --> Config Class Initialized
DEBUG - 2012-01-13 23:57:27 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:57:27 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:57:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:57:27 --> URI Class Initialized
DEBUG - 2012-01-13 23:57:27 --> Router Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Output Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Security Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Input Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:57:28 --> Language Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Loader Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:57:28 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Session Class Initialized
DEBUG - 2012-01-13 23:57:28 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:57:28 --> Session routines successfully run
DEBUG - 2012-01-13 23:57:28 --> Controller Class Initialized
DEBUG - 2012-01-13 23:57:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-13 23:57:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-13 23:57:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-13 23:57:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-13 23:57:28 --> Final output sent to browser
DEBUG - 2012-01-13 23:57:28 --> Total execution time: 0.5193
DEBUG - 2012-01-13 23:58:25 --> Config Class Initialized
DEBUG - 2012-01-13 23:58:25 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:58:25 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:58:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:58:25 --> URI Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Router Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Output Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Security Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Input Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:58:26 --> Language Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Loader Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:58:26 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Session Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:58:26 --> Session routines successfully run
DEBUG - 2012-01-13 23:58:26 --> Controller Class Initialized
DEBUG - 2012-01-13 23:58:26 --> Pagination Class Initialized
DEBUG - 2012-01-13 23:58:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:58:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:58:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:58:26 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-13 23:58:26 --> Final output sent to browser
DEBUG - 2012-01-13 23:58:26 --> Total execution time: 1.0229
DEBUG - 2012-01-13 23:58:28 --> Config Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:58:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:58:28 --> URI Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Router Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Output Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Security Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Input Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:58:28 --> Language Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Loader Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:58:28 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Session Class Initialized
DEBUG - 2012-01-13 23:58:28 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:58:28 --> Session routines successfully run
DEBUG - 2012-01-13 23:58:28 --> Controller Class Initialized
DEBUG - 2012-01-13 23:58:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:58:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:58:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:58:28 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 23:58:28 --> Final output sent to browser
DEBUG - 2012-01-13 23:58:28 --> Total execution time: 0.5057
DEBUG - 2012-01-13 23:58:30 --> Config Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:58:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:58:30 --> URI Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Router Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Output Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Security Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Input Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:58:30 --> Language Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Loader Class Initialized
DEBUG - 2012-01-13 23:58:30 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:58:31 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:58:31 --> Session Class Initialized
DEBUG - 2012-01-13 23:58:31 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:58:31 --> Session routines successfully run
DEBUG - 2012-01-13 23:58:31 --> Controller Class Initialized
DEBUG - 2012-01-13 23:58:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:58:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:58:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:58:31 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 23:58:31 --> Final output sent to browser
DEBUG - 2012-01-13 23:58:31 --> Total execution time: 0.6019
DEBUG - 2012-01-13 23:58:33 --> Config Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:58:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:58:33 --> URI Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Router Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Output Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Security Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Input Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:58:33 --> Language Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Loader Class Initialized
DEBUG - 2012-01-13 23:58:33 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:58:34 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:58:34 --> Session Class Initialized
DEBUG - 2012-01-13 23:58:34 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:58:34 --> Session routines successfully run
DEBUG - 2012-01-13 23:58:34 --> Controller Class Initialized
DEBUG - 2012-01-13 23:58:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:58:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:58:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:58:34 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-13 23:58:34 --> Final output sent to browser
DEBUG - 2012-01-13 23:58:34 --> Total execution time: 0.5652
DEBUG - 2012-01-13 23:59:06 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:06 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:06 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:06 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:06 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:06 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:06 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:06 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:06 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:06 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:06 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-01-13 23:59:06 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:06 --> Total execution time: 0.4903
DEBUG - 2012-01-13 23:59:11 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:11 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:11 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:11 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:11 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:11 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:11 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:11 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-13 23:59:11 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:11 --> Total execution time: 0.4851
DEBUG - 2012-01-13 23:59:37 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:37 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:37 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:37 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:38 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:38 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:38 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:38 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:38 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:38 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-01-13 23:59:38 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:38 --> Total execution time: 0.8337
DEBUG - 2012-01-13 23:59:43 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:43 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:43 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:43 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:44 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:44 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:44 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:44 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:44 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:44 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:44 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:44 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 23:59:44 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:44 --> Total execution time: 1.2341
DEBUG - 2012-01-13 23:59:47 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:47 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:47 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:47 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:47 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:47 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:47 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:47 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:48 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:48 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:48 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:48 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:48 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:48 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:48 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:48 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 23:59:48 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:48 --> Total execution time: 0.6132
DEBUG - 2012-01-13 23:59:49 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:49 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:49 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:50 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:50 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:50 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:50 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:50 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:50 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:50 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 23:59:50 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:50 --> Total execution time: 0.6831
DEBUG - 2012-01-13 23:59:52 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:52 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:53 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:53 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:53 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:53 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:53 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:53 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:53 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 23:59:53 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:53 --> Total execution time: 0.5672
DEBUG - 2012-01-13 23:59:57 --> Config Class Initialized
DEBUG - 2012-01-13 23:59:57 --> Hooks Class Initialized
DEBUG - 2012-01-13 23:59:57 --> Utf8 Class Initialized
DEBUG - 2012-01-13 23:59:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-13 23:59:57 --> URI Class Initialized
DEBUG - 2012-01-13 23:59:57 --> Router Class Initialized
DEBUG - 2012-01-13 23:59:57 --> Output Class Initialized
DEBUG - 2012-01-13 23:59:57 --> Security Class Initialized
DEBUG - 2012-01-13 23:59:57 --> Input Class Initialized
DEBUG - 2012-01-13 23:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-13 23:59:57 --> Language Class Initialized
DEBUG - 2012-01-13 23:59:58 --> Loader Class Initialized
DEBUG - 2012-01-13 23:59:58 --> Helper loaded: url_helper
DEBUG - 2012-01-13 23:59:58 --> Database Driver Class Initialized
DEBUG - 2012-01-13 23:59:58 --> Session Class Initialized
DEBUG - 2012-01-13 23:59:58 --> Helper loaded: string_helper
DEBUG - 2012-01-13 23:59:58 --> Session routines successfully run
DEBUG - 2012-01-13 23:59:58 --> Controller Class Initialized
DEBUG - 2012-01-13 23:59:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-13 23:59:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-13 23:59:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-13 23:59:58 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-13 23:59:58 --> Final output sent to browser
DEBUG - 2012-01-13 23:59:58 --> Total execution time: 0.5309

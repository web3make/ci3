<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-02-11 20:30:02 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:02 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:02 --> No URI present. Default controller set.
DEBUG - 2012-02-11 20:30:02 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:02 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:02 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:02 --> A session cookie was not found.
DEBUG - 2012-02-11 20:30:02 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:02 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:02 --> Pagination Class Initialized
DEBUG - 2012-02-11 20:30:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:03 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-11 20:30:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-11 20:30:03 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:03 --> Total execution time: 1.4454
DEBUG - 2012-02-11 20:30:04 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:04 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:04 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:04 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:04 --> Router Class Initialized
ERROR - 2012-02-11 20:30:04 --> 404 Page Not Found --> lessons
DEBUG - 2012-02-11 20:30:05 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:05 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:05 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:05 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:05 --> Router Class Initialized
ERROR - 2012-02-11 20:30:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-11 20:30:07 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:07 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:07 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:07 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:07 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:07 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:07 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:08 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-11 20:30:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-11 20:30:08 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:08 --> Total execution time: 0.4714
DEBUG - 2012-02-11 20:30:08 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:08 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:08 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:08 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:08 --> Router Class Initialized
ERROR - 2012-02-11 20:30:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-11 20:30:09 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:09 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:09 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:09 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:09 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:09 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:09 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-11 20:30:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-11 20:30:09 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:09 --> Total execution time: 0.2183
DEBUG - 2012-02-11 20:30:09 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:09 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:09 --> Router Class Initialized
ERROR - 2012-02-11 20:30:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-11 20:30:10 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:10 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:10 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:10 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:10 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:10 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:10 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:10 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-11 20:30:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:10 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-11 20:30:10 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:10 --> Total execution time: 0.2293
DEBUG - 2012-02-11 20:30:11 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:11 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:11 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:11 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:11 --> Router Class Initialized
ERROR - 2012-02-11 20:30:11 --> 404 Page Not Found --> lessons
DEBUG - 2012-02-11 20:30:11 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:11 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:11 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:11 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:11 --> Router Class Initialized
ERROR - 2012-02-11 20:30:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-11 20:30:12 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:12 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:12 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:12 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:12 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:12 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:12 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-11 20:30:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:12 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-11 20:30:12 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:12 --> Total execution time: 0.2023
DEBUG - 2012-02-11 20:30:12 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:12 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:12 --> Router Class Initialized
ERROR - 2012-02-11 20:30:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-11 20:30:13 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:13 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:13 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:13 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:13 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:13 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:13 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:14 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2012-02-11 20:30:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:14 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-11 20:30:14 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:14 --> Total execution time: 0.4915
DEBUG - 2012-02-11 20:30:15 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:15 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:15 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:15 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:15 --> Router Class Initialized
ERROR - 2012-02-11 20:30:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-11 20:30:22 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:22 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:22 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:22 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:22 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:23 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:23 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:23 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:23 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:23 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-11 20:30:23 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:23 --> Total execution time: 0.2880
DEBUG - 2012-02-11 20:30:23 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:23 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Router Class Initialized
ERROR - 2012-02-11 20:30:23 --> 404 Page Not Found --> lessons
DEBUG - 2012-02-11 20:30:23 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:23 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:23 --> Router Class Initialized
ERROR - 2012-02-11 20:30:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-11 20:30:33 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:33 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Router Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Output Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Security Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Input Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-11 20:30:33 --> Language Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Loader Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Helper loaded: url_helper
DEBUG - 2012-02-11 20:30:33 --> Database Driver Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Session Class Initialized
DEBUG - 2012-02-11 20:30:33 --> Helper loaded: string_helper
DEBUG - 2012-02-11 20:30:33 --> Session routines successfully run
DEBUG - 2012-02-11 20:30:33 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Model Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Controller Class Initialized
DEBUG - 2012-02-11 20:30:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-11 20:30:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-11 20:30:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-11 20:30:34 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-11 20:30:34 --> Final output sent to browser
DEBUG - 2012-02-11 20:30:34 --> Total execution time: 0.2107
DEBUG - 2012-02-11 20:30:34 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:34 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Router Class Initialized
ERROR - 2012-02-11 20:30:34 --> 404 Page Not Found --> lessons
DEBUG - 2012-02-11 20:30:34 --> Config Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Hooks Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Utf8 Class Initialized
DEBUG - 2012-02-11 20:30:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-11 20:30:34 --> URI Class Initialized
DEBUG - 2012-02-11 20:30:34 --> Router Class Initialized
ERROR - 2012-02-11 20:30:34 --> 404 Page Not Found --> favicon.ico

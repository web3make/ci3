<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-01-07 06:56:02 --> Config Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Hooks Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Utf8 Class Initialized
DEBUG - 2007-01-07 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 06:56:02 --> URI Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Router Class Initialized
DEBUG - 2007-01-07 06:56:02 --> No URI present. Default controller set.
DEBUG - 2007-01-07 06:56:02 --> Output Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Security Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Input Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 06:56:02 --> Language Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Loader Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Helper loaded: url_helper
DEBUG - 2007-01-07 06:56:02 --> Database Driver Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Session Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Helper loaded: string_helper
DEBUG - 2007-01-07 06:56:02 --> A session cookie was not found.
DEBUG - 2007-01-07 06:56:02 --> Session routines successfully run
DEBUG - 2007-01-07 06:56:02 --> Model Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Model Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Controller Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Pagination Class Initialized
DEBUG - 2007-01-07 06:56:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 06:56:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 06:56:02 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-07 06:56:02 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-07 06:56:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 06:56:02 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-07 06:56:02 --> Final output sent to browser
DEBUG - 2007-01-07 06:56:02 --> Total execution time: 0.2036
DEBUG - 2007-01-07 06:56:02 --> Config Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Hooks Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Utf8 Class Initialized
DEBUG - 2007-01-07 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 06:56:02 --> URI Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Router Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Config Class Initialized
ERROR - 2007-01-07 06:56:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-07 06:56:02 --> Hooks Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Utf8 Class Initialized
DEBUG - 2007-01-07 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 06:56:02 --> URI Class Initialized
DEBUG - 2007-01-07 06:56:02 --> Router Class Initialized
ERROR - 2007-01-07 06:56:02 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-07 10:52:50 --> Config Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:52:50 --> URI Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Router Class Initialized
DEBUG - 2007-01-07 10:52:50 --> No URI present. Default controller set.
DEBUG - 2007-01-07 10:52:50 --> Output Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Security Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Input Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:52:50 --> Language Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Loader Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:52:50 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Session Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:52:50 --> A session cookie was not found.
DEBUG - 2007-01-07 10:52:50 --> Session routines successfully run
DEBUG - 2007-01-07 10:52:50 --> Model Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Model Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Controller Class Initialized
DEBUG - 2007-01-07 10:52:50 --> Pagination Class Initialized
DEBUG - 2007-01-07 10:52:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:52:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:52:51 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-07 10:52:51 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-07 10:52:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:52:51 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-07 10:52:51 --> Final output sent to browser
DEBUG - 2007-01-07 10:52:51 --> Total execution time: 0.3496
DEBUG - 2007-01-07 10:52:51 --> Config Class Initialized
DEBUG - 2007-01-07 10:52:51 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:52:51 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:52:51 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:52:51 --> URI Class Initialized
DEBUG - 2007-01-07 10:52:51 --> Router Class Initialized
ERROR - 2007-01-07 10:52:51 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-07 10:52:51 --> Config Class Initialized
DEBUG - 2007-01-07 10:52:51 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:52:51 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:52:51 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:52:51 --> URI Class Initialized
DEBUG - 2007-01-07 10:52:51 --> Router Class Initialized
ERROR - 2007-01-07 10:52:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-07 10:54:38 --> Config Class Initialized
DEBUG - 2007-01-07 10:54:38 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:54:38 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:54:38 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:54:38 --> URI Class Initialized
DEBUG - 2007-01-07 10:54:38 --> Router Class Initialized
DEBUG - 2007-01-07 10:54:38 --> Output Class Initialized
DEBUG - 2007-01-07 10:54:38 --> Security Class Initialized
DEBUG - 2007-01-07 10:54:38 --> Input Class Initialized
DEBUG - 2007-01-07 10:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:54:38 --> Language Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Config Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:54:44 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:54:44 --> URI Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Router Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Output Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Security Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Input Class Initialized
DEBUG - 2007-01-07 10:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:54:44 --> Language Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Config Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:54:54 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:54:54 --> URI Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Router Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Output Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Security Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Input Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:54:54 --> Language Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Loader Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:54:54 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Session Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:54:54 --> Session routines successfully run
DEBUG - 2007-01-07 10:54:54 --> Model Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Model Class Initialized
DEBUG - 2007-01-07 10:54:54 --> Controller Class Initialized
DEBUG - 2007-01-07 10:54:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:54:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:54:54 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:54:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:54:54 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:54:54 --> Final output sent to browser
DEBUG - 2007-01-07 10:54:54 --> Total execution time: 0.0940
DEBUG - 2007-01-07 10:55:39 --> Config Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:55:39 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:55:39 --> URI Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Router Class Initialized
DEBUG - 2007-01-07 10:55:39 --> No URI present. Default controller set.
DEBUG - 2007-01-07 10:55:39 --> Output Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Security Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Input Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:55:39 --> Language Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Loader Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:55:39 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Session Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:55:39 --> Session routines successfully run
DEBUG - 2007-01-07 10:55:39 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Controller Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Pagination Class Initialized
DEBUG - 2007-01-07 10:55:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:55:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:55:39 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-07 10:55:39 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-07 10:55:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:55:39 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-07 10:55:39 --> Final output sent to browser
DEBUG - 2007-01-07 10:55:39 --> Total execution time: 0.0712
DEBUG - 2007-01-07 10:55:39 --> Config Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:55:39 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:55:39 --> URI Class Initialized
DEBUG - 2007-01-07 10:55:39 --> Router Class Initialized
ERROR - 2007-01-07 10:55:39 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-07 10:55:40 --> Config Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:55:40 --> URI Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Router Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Output Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Security Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Input Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:55:40 --> Language Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Loader Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:55:40 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Session Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:55:40 --> Session routines successfully run
DEBUG - 2007-01-07 10:55:40 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Controller Class Initialized
DEBUG - 2007-01-07 10:55:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:55:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:55:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:55:40 --> File loaded: application/views/user/page.php
DEBUG - 2007-01-07 10:55:40 --> Final output sent to browser
DEBUG - 2007-01-07 10:55:40 --> Total execution time: 0.0634
DEBUG - 2007-01-07 10:55:40 --> Config Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:55:40 --> URI Class Initialized
DEBUG - 2007-01-07 10:55:40 --> Router Class Initialized
ERROR - 2007-01-07 10:55:40 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-07 10:55:42 --> Config Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:55:42 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:55:42 --> URI Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Router Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Output Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Security Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Input Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:55:42 --> Language Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Loader Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:55:42 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Session Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:55:42 --> Session routines successfully run
DEBUG - 2007-01-07 10:55:42 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:42 --> Controller Class Initialized
DEBUG - 2007-01-07 10:55:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:55:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:55:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:55:42 --> File loaded: application/views/user/page.php
DEBUG - 2007-01-07 10:55:42 --> Final output sent to browser
DEBUG - 2007-01-07 10:55:42 --> Total execution time: 0.0525
DEBUG - 2007-01-07 10:55:47 --> Config Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:55:47 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:55:47 --> URI Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Router Class Initialized
DEBUG - 2007-01-07 10:55:47 --> No URI present. Default controller set.
DEBUG - 2007-01-07 10:55:47 --> Output Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Security Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Input Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:55:47 --> Language Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Loader Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:55:47 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Session Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:55:47 --> Session routines successfully run
DEBUG - 2007-01-07 10:55:47 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Model Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Controller Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Pagination Class Initialized
DEBUG - 2007-01-07 10:55:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:55:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:55:47 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-07 10:55:47 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-07 10:55:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:55:47 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-07 10:55:47 --> Final output sent to browser
DEBUG - 2007-01-07 10:55:47 --> Total execution time: 0.0703
DEBUG - 2007-01-07 10:55:47 --> Config Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:55:47 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:55:47 --> URI Class Initialized
DEBUG - 2007-01-07 10:55:47 --> Router Class Initialized
ERROR - 2007-01-07 10:55:47 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-07 10:56:04 --> Config Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:56:04 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:56:04 --> URI Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Router Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Output Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Security Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Input Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:56:04 --> Language Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Loader Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:56:04 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Session Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:56:04 --> Session routines successfully run
DEBUG - 2007-01-07 10:56:04 --> Model Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Model Class Initialized
DEBUG - 2007-01-07 10:56:04 --> Controller Class Initialized
DEBUG - 2007-01-07 10:56:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:56:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:56:04 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:56:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:56:04 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:56:04 --> Final output sent to browser
DEBUG - 2007-01-07 10:56:04 --> Total execution time: 0.0770
DEBUG - 2007-01-07 10:56:20 --> Config Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:56:20 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:56:20 --> URI Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Router Class Initialized
DEBUG - 2007-01-07 10:56:20 --> No URI present. Default controller set.
DEBUG - 2007-01-07 10:56:20 --> Output Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Security Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Input Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:56:20 --> Language Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Loader Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:56:20 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Session Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:56:20 --> Session routines successfully run
DEBUG - 2007-01-07 10:56:20 --> Model Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Model Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Controller Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Pagination Class Initialized
DEBUG - 2007-01-07 10:56:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:56:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:56:20 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-07 10:56:20 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-07 10:56:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:56:20 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-07 10:56:20 --> Final output sent to browser
DEBUG - 2007-01-07 10:56:20 --> Total execution time: 0.0713
DEBUG - 2007-01-07 10:56:20 --> Config Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:56:20 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:56:20 --> URI Class Initialized
DEBUG - 2007-01-07 10:56:20 --> Router Class Initialized
ERROR - 2007-01-07 10:56:20 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-07 10:56:22 --> Config Class Initialized
DEBUG - 2007-01-07 10:56:22 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:56:22 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:56:22 --> URI Class Initialized
DEBUG - 2007-01-07 10:56:22 --> Router Class Initialized
DEBUG - 2007-01-07 10:56:22 --> Output Class Initialized
DEBUG - 2007-01-07 10:56:22 --> Security Class Initialized
DEBUG - 2007-01-07 10:56:22 --> Input Class Initialized
DEBUG - 2007-01-07 10:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:56:22 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:15 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:15 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:15 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:15 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:15 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:15 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:15 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:15 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:15 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:15 --> Total execution time: 0.0650
DEBUG - 2007-01-07 10:57:18 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:18 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:18 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:18 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:18 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:18 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:18 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:18 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:18 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:18 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:18 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:18 --> Total execution time: 0.0678
DEBUG - 2007-01-07 10:57:19 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:19 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:19 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:19 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:19 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:19 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:19 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:19 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:19 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:19 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:19 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:19 --> Total execution time: 0.0546
DEBUG - 2007-01-07 10:57:20 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:20 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:20 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:20 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:20 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:20 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:20 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:20 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:20 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:20 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:20 --> Total execution time: 0.0650
DEBUG - 2007-01-07 10:57:22 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:22 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:22 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:22 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:22 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:22 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:22 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:22 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:22 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:22 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:22 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:22 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:22 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:22 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:22 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:22 --> Total execution time: 0.0648
DEBUG - 2007-01-07 10:57:25 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:25 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:25 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:25 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:25 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:25 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:25 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:25 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:25 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:25 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:25 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:25 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:25 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:25 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:25 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:25 --> Total execution time: 0.0645
DEBUG - 2007-01-07 10:57:26 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:26 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:27 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:27 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:27 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:27 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:27 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:27 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:27 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:27 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:27 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:27 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:27 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:27 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:27 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:27 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:27 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:27 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:27 --> Total execution time: 0.0645
DEBUG - 2007-01-07 10:57:28 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:28 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:28 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:28 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:28 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:28 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:28 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:28 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:28 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:28 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:28 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:28 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:28 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:28 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:28 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:28 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:28 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:28 --> Total execution time: 0.0652
DEBUG - 2007-01-07 10:57:33 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:33 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:33 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:33 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:33 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:33 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:33 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:34 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:34 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:34 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:34 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:34 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:34 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:34 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-07 10:57:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:34 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-07 10:57:34 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:34 --> Total execution time: 0.0546
DEBUG - 2007-01-07 10:57:37 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:37 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:37 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Router Class Initialized
DEBUG - 2007-01-07 10:57:37 --> No URI present. Default controller set.
DEBUG - 2007-01-07 10:57:37 --> Output Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Security Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Input Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-07 10:57:37 --> Language Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Loader Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Helper loaded: url_helper
DEBUG - 2007-01-07 10:57:37 --> Database Driver Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Session Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Helper loaded: string_helper
DEBUG - 2007-01-07 10:57:37 --> Session routines successfully run
DEBUG - 2007-01-07 10:57:37 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Model Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Controller Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Pagination Class Initialized
DEBUG - 2007-01-07 10:57:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-07 10:57:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-07 10:57:37 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-07 10:57:37 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-07 10:57:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-07 10:57:37 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-07 10:57:37 --> Final output sent to browser
DEBUG - 2007-01-07 10:57:37 --> Total execution time: 0.0709
DEBUG - 2007-01-07 10:57:37 --> Config Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Hooks Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Utf8 Class Initialized
DEBUG - 2007-01-07 10:57:37 --> UTF-8 Support Enabled
DEBUG - 2007-01-07 10:57:37 --> URI Class Initialized
DEBUG - 2007-01-07 10:57:37 --> Router Class Initialized
ERROR - 2007-01-07 10:57:37 --> 404 Page Not Found --> lessons

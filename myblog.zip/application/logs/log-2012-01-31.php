<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-31 00:03:15 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:15 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:15 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:15 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:15 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:15 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:15 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:03:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:03:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:03:15 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 00:03:15 --> Final output sent to browser
DEBUG - 2012-01-31 00:03:15 --> Total execution time: 0.2151
DEBUG - 2012-01-31 00:03:16 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:16 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:16 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:16 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:16 --> Router Class Initialized
ERROR - 2012-01-31 00:03:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:03:24 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:24 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:24 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:24 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:24 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:24 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:24 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:24 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:24 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:24 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:03:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:03:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:03:24 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 00:03:24 --> Final output sent to browser
DEBUG - 2012-01-31 00:03:24 --> Total execution time: 0.1826
DEBUG - 2012-01-31 00:03:25 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:25 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:25 --> Router Class Initialized
ERROR - 2012-01-31 00:03:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:03:28 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:28 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:28 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:28 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:28 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:28 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Pagination Class Initialized
DEBUG - 2012-01-31 00:03:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:03:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:03:28 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 00:03:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:03:28 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 00:03:28 --> Final output sent to browser
DEBUG - 2012-01-31 00:03:28 --> Total execution time: 0.1955
DEBUG - 2012-01-31 00:03:28 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:28 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:28 --> Router Class Initialized
ERROR - 2012-01-31 00:03:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:03:38 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:38 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:38 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:38 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:38 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:38 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:38 --> DB Transaction Failure
ERROR - 2012-01-31 00:03:38 --> Query error: Unknown column 'o.name' in 'field list'
DEBUG - 2012-01-31 00:03:38 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-31 00:03:38 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:38 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:38 --> Router Class Initialized
ERROR - 2012-01-31 00:03:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:03:40 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:40 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:40 --> Router Class Initialized
ERROR - 2012-01-31 00:03:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:03:47 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:47 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:47 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:47 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:47 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:03:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:03:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:03:47 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 00:03:47 --> Final output sent to browser
DEBUG - 2012-01-31 00:03:47 --> Total execution time: 0.1882
DEBUG - 2012-01-31 00:03:47 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:47 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:47 --> Router Class Initialized
ERROR - 2012-01-31 00:03:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:03:51 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:51 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:51 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:51 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:51 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:51 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:51 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:51 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:51 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:52 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:52 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:52 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:03:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:03:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:03:52 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 00:03:52 --> Final output sent to browser
DEBUG - 2012-01-31 00:03:52 --> Total execution time: 0.1866
DEBUG - 2012-01-31 00:03:52 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:52 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:52 --> Router Class Initialized
ERROR - 2012-01-31 00:03:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:03:58 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:59 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Router Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Output Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Security Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Input Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:03:59 --> Language Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Loader Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:03:59 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Session Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:03:59 --> Session routines successfully run
DEBUG - 2012-01-31 00:03:59 --> Cart Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Model Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Controller Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Pagination Class Initialized
DEBUG - 2012-01-31 00:03:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:03:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:03:59 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 00:03:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:03:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 00:03:59 --> Final output sent to browser
DEBUG - 2012-01-31 00:03:59 --> Total execution time: 0.2118
DEBUG - 2012-01-31 00:03:59 --> Config Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:03:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:03:59 --> URI Class Initialized
DEBUG - 2012-01-31 00:03:59 --> Router Class Initialized
ERROR - 2012-01-31 00:03:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:06:57 --> Config Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:06:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:06:57 --> URI Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Router Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Output Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Security Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Input Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:06:57 --> Language Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Loader Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:06:57 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Session Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:06:57 --> Session routines successfully run
DEBUG - 2012-01-31 00:06:57 --> Cart Class Initialized
DEBUG - 2012-01-31 00:06:57 --> Model Class Initialized
DEBUG - 2012-01-31 00:06:58 --> Model Class Initialized
DEBUG - 2012-01-31 00:06:58 --> Controller Class Initialized
DEBUG - 2012-01-31 00:06:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:06:58 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 9
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 10
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 11
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 12
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 13
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 14
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 15
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 16
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 17
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:06:58 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 21
DEBUG - 2012-01-31 00:06:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:06:58 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:06:58 --> Final output sent to browser
DEBUG - 2012-01-31 00:06:58 --> Total execution time: 0.6271
DEBUG - 2012-01-31 00:06:58 --> Config Class Initialized
DEBUG - 2012-01-31 00:06:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:06:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:06:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:06:58 --> URI Class Initialized
DEBUG - 2012-01-31 00:06:58 --> Router Class Initialized
ERROR - 2012-01-31 00:06:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:07:12 --> Config Class Initialized
DEBUG - 2012-01-31 00:07:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:07:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:07:13 --> URI Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Router Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Output Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Security Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Input Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:07:13 --> Language Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Loader Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:07:13 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Session Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:07:13 --> Session routines successfully run
DEBUG - 2012-01-31 00:07:13 --> Cart Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Model Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Model Class Initialized
DEBUG - 2012-01-31 00:07:13 --> Controller Class Initialized
DEBUG - 2012-01-31 00:07:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:07:13 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 9
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 10
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 11
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 12
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 13
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 14
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 15
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 16
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 17
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:07:13 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 21
DEBUG - 2012-01-31 00:07:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:07:13 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:07:13 --> Final output sent to browser
DEBUG - 2012-01-31 00:07:13 --> Total execution time: 0.6312
DEBUG - 2012-01-31 00:07:14 --> Config Class Initialized
DEBUG - 2012-01-31 00:07:14 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:07:14 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:07:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:07:14 --> URI Class Initialized
DEBUG - 2012-01-31 00:07:14 --> Router Class Initialized
ERROR - 2012-01-31 00:07:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:08:22 --> Config Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:08:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:08:22 --> URI Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Router Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Output Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Security Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Input Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:08:22 --> Language Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Loader Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:08:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Session Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:08:22 --> Session routines successfully run
DEBUG - 2012-01-31 00:08:22 --> Cart Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Model Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Model Class Initialized
DEBUG - 2012-01-31 00:08:22 --> Controller Class Initialized
DEBUG - 2012-01-31 00:08:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:08:22 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:08:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 10
ERROR - 2012-01-31 00:08:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 11
ERROR - 2012-01-31 00:08:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 12
ERROR - 2012-01-31 00:08:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 13
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 14
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 15
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 16
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 17
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:08:23 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 21
DEBUG - 2012-01-31 00:08:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:08:23 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:08:23 --> Final output sent to browser
DEBUG - 2012-01-31 00:08:23 --> Total execution time: 0.7952
DEBUG - 2012-01-31 00:08:23 --> Config Class Initialized
DEBUG - 2012-01-31 00:08:23 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:08:23 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:08:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:08:23 --> URI Class Initialized
DEBUG - 2012-01-31 00:08:24 --> Router Class Initialized
ERROR - 2012-01-31 00:08:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:09:29 --> Config Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:09:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:09:29 --> URI Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Router Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Output Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Security Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Input Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:09:29 --> Language Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Loader Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:09:29 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Session Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:09:29 --> Session routines successfully run
DEBUG - 2012-01-31 00:09:29 --> Cart Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Model Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Model Class Initialized
DEBUG - 2012-01-31 00:09:29 --> Controller Class Initialized
DEBUG - 2012-01-31 00:09:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:09:29 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:09:29 --> Severity: Notice  --> Undefined property: stdClass::$date A:\home\codeigniter.fool\www\application\views\admin\order.php 13
ERROR - 2012-01-31 00:09:29 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 14
ERROR - 2012-01-31 00:09:29 --> Severity: Notice  --> Undefined property: stdClass::$sum A:\home\codeigniter.fool\www\application\views\admin\order.php 17
ERROR - 2012-01-31 00:09:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:09:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:09:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:09:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 21
DEBUG - 2012-01-31 00:09:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:09:29 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:09:29 --> Final output sent to browser
DEBUG - 2012-01-31 00:09:29 --> Total execution time: 0.5898
DEBUG - 2012-01-31 00:09:30 --> Config Class Initialized
DEBUG - 2012-01-31 00:09:30 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:09:30 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:09:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:09:30 --> URI Class Initialized
DEBUG - 2012-01-31 00:09:30 --> Router Class Initialized
ERROR - 2012-01-31 00:09:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:09:58 --> Config Class Initialized
DEBUG - 2012-01-31 00:09:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:09:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:09:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:09:58 --> URI Class Initialized
DEBUG - 2012-01-31 00:09:58 --> Router Class Initialized
DEBUG - 2012-01-31 00:09:58 --> Output Class Initialized
DEBUG - 2012-01-31 00:09:58 --> Security Class Initialized
DEBUG - 2012-01-31 00:09:58 --> Input Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:09:59 --> Language Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Loader Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:09:59 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Session Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:09:59 --> Session routines successfully run
DEBUG - 2012-01-31 00:09:59 --> Cart Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Model Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Model Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Controller Class Initialized
DEBUG - 2012-01-31 00:09:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:09:59 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:09:59 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 14
ERROR - 2012-01-31 00:09:59 --> Severity: Notice  --> Undefined property: stdClass::$sum A:\home\codeigniter.fool\www\application\views\admin\order.php 17
ERROR - 2012-01-31 00:09:59 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:09:59 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:09:59 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 19
ERROR - 2012-01-31 00:09:59 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 21
DEBUG - 2012-01-31 00:09:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:09:59 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:09:59 --> Final output sent to browser
DEBUG - 2012-01-31 00:09:59 --> Total execution time: 0.5264
DEBUG - 2012-01-31 00:09:59 --> Config Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:09:59 --> URI Class Initialized
DEBUG - 2012-01-31 00:09:59 --> Router Class Initialized
ERROR - 2012-01-31 00:10:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:14:29 --> Config Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:14:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:14:29 --> URI Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Router Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Output Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Security Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Input Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:14:29 --> Language Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Loader Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:14:29 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Session Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:14:29 --> Session routines successfully run
DEBUG - 2012-01-31 00:14:29 --> Cart Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Model Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Model Class Initialized
DEBUG - 2012-01-31 00:14:29 --> Controller Class Initialized
DEBUG - 2012-01-31 00:14:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:14:29 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:14:29 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 18
ERROR - 2012-01-31 00:14:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 22
ERROR - 2012-01-31 00:14:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 22
ERROR - 2012-01-31 00:14:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 22
ERROR - 2012-01-31 00:14:29 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 24
DEBUG - 2012-01-31 00:14:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:14:30 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:14:30 --> Final output sent to browser
DEBUG - 2012-01-31 00:14:30 --> Total execution time: 0.5173
DEBUG - 2012-01-31 00:14:30 --> Config Class Initialized
DEBUG - 2012-01-31 00:14:30 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:14:30 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:14:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:14:30 --> URI Class Initialized
DEBUG - 2012-01-31 00:14:30 --> Router Class Initialized
ERROR - 2012-01-31 00:14:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:18:55 --> Config Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:18:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:18:55 --> URI Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Router Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Output Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Security Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Input Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:18:55 --> Language Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Loader Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:18:55 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Session Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:18:55 --> Session routines successfully run
DEBUG - 2012-01-31 00:18:55 --> Cart Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Model Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Model Class Initialized
DEBUG - 2012-01-31 00:18:55 --> Controller Class Initialized
DEBUG - 2012-01-31 00:18:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:18:55 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 10
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 10
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 10
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 28
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 32
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 32
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 32
ERROR - 2012-01-31 00:18:55 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 34
DEBUG - 2012-01-31 00:18:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:18:55 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:18:55 --> Final output sent to browser
DEBUG - 2012-01-31 00:18:56 --> Total execution time: 0.5607
DEBUG - 2012-01-31 00:18:56 --> Config Class Initialized
DEBUG - 2012-01-31 00:18:56 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:18:56 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:18:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:18:56 --> URI Class Initialized
DEBUG - 2012-01-31 00:18:56 --> Router Class Initialized
ERROR - 2012-01-31 00:18:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:19:21 --> Config Class Initialized
DEBUG - 2012-01-31 00:19:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:19:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:19:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:19:21 --> URI Class Initialized
DEBUG - 2012-01-31 00:19:21 --> Router Class Initialized
DEBUG - 2012-01-31 00:19:21 --> Output Class Initialized
DEBUG - 2012-01-31 00:19:21 --> Security Class Initialized
DEBUG - 2012-01-31 00:19:21 --> Input Class Initialized
DEBUG - 2012-01-31 00:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:19:22 --> Language Class Initialized
DEBUG - 2012-01-31 00:19:22 --> Loader Class Initialized
DEBUG - 2012-01-31 00:19:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:19:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:19:22 --> Session Class Initialized
DEBUG - 2012-01-31 00:19:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:19:22 --> Session routines successfully run
DEBUG - 2012-01-31 00:19:22 --> Cart Class Initialized
DEBUG - 2012-01-31 00:19:22 --> Model Class Initialized
DEBUG - 2012-01-31 00:19:22 --> Model Class Initialized
DEBUG - 2012-01-31 00:19:22 --> Controller Class Initialized
DEBUG - 2012-01-31 00:19:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:19:22 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:19:22 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 28
ERROR - 2012-01-31 00:19:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 32
ERROR - 2012-01-31 00:19:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 32
ERROR - 2012-01-31 00:19:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 32
ERROR - 2012-01-31 00:19:22 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 34
DEBUG - 2012-01-31 00:19:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:19:22 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:19:23 --> Final output sent to browser
DEBUG - 2012-01-31 00:19:23 --> Total execution time: 1.1820
DEBUG - 2012-01-31 00:19:24 --> Config Class Initialized
DEBUG - 2012-01-31 00:19:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:19:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:19:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:19:24 --> URI Class Initialized
DEBUG - 2012-01-31 00:19:24 --> Router Class Initialized
ERROR - 2012-01-31 00:19:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:20:04 --> Config Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:20:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:20:04 --> URI Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Router Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Output Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Security Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Input Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:20:04 --> Language Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Loader Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:20:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Session Class Initialized
DEBUG - 2012-01-31 00:20:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:20:04 --> Session routines successfully run
DEBUG - 2012-01-31 00:20:05 --> Cart Class Initialized
DEBUG - 2012-01-31 00:20:05 --> Model Class Initialized
DEBUG - 2012-01-31 00:20:05 --> Model Class Initialized
DEBUG - 2012-01-31 00:20:05 --> Controller Class Initialized
DEBUG - 2012-01-31 00:20:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:20:05 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:20:05 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 28
ERROR - 2012-01-31 00:20:05 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 28
ERROR - 2012-01-31 00:20:05 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 28
ERROR - 2012-01-31 00:20:05 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 30
DEBUG - 2012-01-31 00:20:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:20:05 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:20:05 --> Final output sent to browser
DEBUG - 2012-01-31 00:20:05 --> Total execution time: 0.5593
DEBUG - 2012-01-31 00:20:05 --> Config Class Initialized
DEBUG - 2012-01-31 00:20:05 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:20:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:20:06 --> URI Class Initialized
DEBUG - 2012-01-31 00:20:06 --> Router Class Initialized
ERROR - 2012-01-31 00:20:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:20:40 --> Config Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:20:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:20:40 --> URI Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Router Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Output Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Security Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Input Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:20:40 --> Language Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Loader Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:20:40 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Session Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:20:40 --> Session routines successfully run
DEBUG - 2012-01-31 00:20:40 --> Cart Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Model Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Model Class Initialized
DEBUG - 2012-01-31 00:20:40 --> Controller Class Initialized
DEBUG - 2012-01-31 00:20:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:20:40 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:20:40 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 28
ERROR - 2012-01-31 00:20:40 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.fool\www\application\views\admin\order.php 28
DEBUG - 2012-01-31 00:20:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:20:40 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:20:40 --> Final output sent to browser
DEBUG - 2012-01-31 00:20:40 --> Total execution time: 0.5112
DEBUG - 2012-01-31 00:20:41 --> Config Class Initialized
DEBUG - 2012-01-31 00:20:41 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:20:41 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:20:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:20:41 --> URI Class Initialized
DEBUG - 2012-01-31 00:20:41 --> Router Class Initialized
ERROR - 2012-01-31 00:20:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:21:25 --> Config Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:21:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:21:25 --> URI Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Router Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Output Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Security Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Input Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:21:25 --> Language Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Loader Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:21:25 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Session Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:21:25 --> Session routines successfully run
DEBUG - 2012-01-31 00:21:25 --> Cart Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Model Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Model Class Initialized
DEBUG - 2012-01-31 00:21:25 --> Controller Class Initialized
DEBUG - 2012-01-31 00:21:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:21:25 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 00:21:25 --> Severity: Notice  --> Undefined property: stdClass::$id_product A:\home\codeigniter.fool\www\application\views\admin\order.php 28
DEBUG - 2012-01-31 00:21:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:21:25 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:21:25 --> Final output sent to browser
DEBUG - 2012-01-31 00:21:26 --> Total execution time: 0.6968
DEBUG - 2012-01-31 00:21:29 --> Config Class Initialized
DEBUG - 2012-01-31 00:21:29 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:21:29 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:21:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:21:29 --> URI Class Initialized
DEBUG - 2012-01-31 00:21:29 --> Router Class Initialized
ERROR - 2012-01-31 00:21:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:21:47 --> Config Class Initialized
DEBUG - 2012-01-31 00:21:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:21:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:21:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:21:47 --> URI Class Initialized
DEBUG - 2012-01-31 00:21:47 --> Router Class Initialized
DEBUG - 2012-01-31 00:21:48 --> Output Class Initialized
DEBUG - 2012-01-31 00:21:48 --> Security Class Initialized
DEBUG - 2012-01-31 00:21:48 --> Input Class Initialized
DEBUG - 2012-01-31 00:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:21:48 --> Language Class Initialized
DEBUG - 2012-01-31 00:21:48 --> Loader Class Initialized
DEBUG - 2012-01-31 00:21:48 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:21:48 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:21:49 --> Session Class Initialized
DEBUG - 2012-01-31 00:21:49 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:21:49 --> Session routines successfully run
DEBUG - 2012-01-31 00:21:49 --> Cart Class Initialized
DEBUG - 2012-01-31 00:21:49 --> Model Class Initialized
DEBUG - 2012-01-31 00:21:49 --> Model Class Initialized
DEBUG - 2012-01-31 00:21:49 --> Controller Class Initialized
DEBUG - 2012-01-31 00:21:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:21:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:21:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:21:49 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:21:49 --> Final output sent to browser
DEBUG - 2012-01-31 00:21:49 --> Total execution time: 1.8705
DEBUG - 2012-01-31 00:21:50 --> Config Class Initialized
DEBUG - 2012-01-31 00:21:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:21:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:21:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:21:50 --> URI Class Initialized
DEBUG - 2012-01-31 00:21:50 --> Router Class Initialized
ERROR - 2012-01-31 00:21:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:22:02 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:02 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:02 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:02 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:02 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Pagination Class Initialized
DEBUG - 2012-01-31 00:22:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:22:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:22:02 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 00:22:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:22:02 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 00:22:02 --> Final output sent to browser
DEBUG - 2012-01-31 00:22:02 --> Total execution time: 0.4920
DEBUG - 2012-01-31 00:22:02 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:02 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:02 --> Router Class Initialized
ERROR - 2012-01-31 00:22:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:22:04 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:04 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:04 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:04 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:04 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:04 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:04 --> No URI present. Default controller set.
DEBUG - 2012-01-31 00:22:04 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:04 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:04 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:04 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:04 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:05 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:05 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:05 --> Pagination Class Initialized
DEBUG - 2012-01-31 00:22:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:22:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:22:05 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 00:22:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:22:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 00:22:05 --> Final output sent to browser
DEBUG - 2012-01-31 00:22:05 --> Total execution time: 0.5005
DEBUG - 2012-01-31 00:22:05 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:05 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:05 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:05 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:05 --> Router Class Initialized
ERROR - 2012-01-31 00:22:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:22:08 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:08 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:08 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:08 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:08 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:08 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:09 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:09 --> No URI present. Default controller set.
DEBUG - 2012-01-31 00:22:09 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:09 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:09 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:09 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:09 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Pagination Class Initialized
DEBUG - 2012-01-31 00:22:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:22:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:22:09 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 00:22:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:22:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 00:22:09 --> Final output sent to browser
DEBUG - 2012-01-31 00:22:09 --> Total execution time: 0.5727
DEBUG - 2012-01-31 00:22:09 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:09 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:09 --> Router Class Initialized
ERROR - 2012-01-31 00:22:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:22:10 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:10 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:10 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:10 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:10 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:10 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:10 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:22:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:22:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:22:11 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-31 00:22:11 --> Final output sent to browser
DEBUG - 2012-01-31 00:22:11 --> Total execution time: 0.5030
DEBUG - 2012-01-31 00:22:11 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:11 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:11 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:11 --> Router Class Initialized
ERROR - 2012-01-31 00:22:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:22:44 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:44 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:44 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:44 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:44 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:44 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:45 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:45 --> No URI present. Default controller set.
DEBUG - 2012-01-31 00:22:45 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:45 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:45 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:45 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:45 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:45 --> Pagination Class Initialized
DEBUG - 2012-01-31 00:22:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:22:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:22:45 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 00:22:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:22:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 00:22:45 --> Final output sent to browser
DEBUG - 2012-01-31 00:22:45 --> Total execution time: 0.5077
DEBUG - 2012-01-31 00:22:46 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:46 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:46 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:46 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:46 --> Router Class Initialized
ERROR - 2012-01-31 00:22:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:22:49 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:49 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:49 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:49 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:49 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:49 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:49 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:22:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:22:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:22:49 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:22:49 --> Final output sent to browser
DEBUG - 2012-01-31 00:22:49 --> Total execution time: 0.6092
DEBUG - 2012-01-31 00:22:50 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:50 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:50 --> Router Class Initialized
ERROR - 2012-01-31 00:22:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:22:53 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:53 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Router Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Output Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Security Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Input Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:22:53 --> Language Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Loader Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:22:53 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Session Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:22:53 --> Session routines successfully run
DEBUG - 2012-01-31 00:22:53 --> Cart Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Model Class Initialized
DEBUG - 2012-01-31 00:22:53 --> Controller Class Initialized
DEBUG - 2012-01-31 00:22:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:22:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:22:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:22:53 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:22:53 --> Final output sent to browser
DEBUG - 2012-01-31 00:22:53 --> Total execution time: 0.5266
DEBUG - 2012-01-31 00:22:53 --> Config Class Initialized
DEBUG - 2012-01-31 00:22:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:22:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:22:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:22:54 --> URI Class Initialized
DEBUG - 2012-01-31 00:22:54 --> Router Class Initialized
ERROR - 2012-01-31 00:22:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:23:03 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:04 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Router Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Output Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Security Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Input Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:23:04 --> Language Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Loader Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:23:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Session Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:23:04 --> Session routines successfully run
DEBUG - 2012-01-31 00:23:04 --> Cart Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Controller Class Initialized
DEBUG - 2012-01-31 00:23:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:23:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:23:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:23:04 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:23:04 --> Final output sent to browser
DEBUG - 2012-01-31 00:23:04 --> Total execution time: 0.5464
DEBUG - 2012-01-31 00:23:04 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:05 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:05 --> Router Class Initialized
ERROR - 2012-01-31 00:23:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:23:41 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:41 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Router Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Output Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Security Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Input Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:23:41 --> Language Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Loader Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:23:41 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Session Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:23:41 --> Session routines successfully run
DEBUG - 2012-01-31 00:23:41 --> Cart Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:41 --> Controller Class Initialized
DEBUG - 2012-01-31 00:23:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:23:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:23:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:23:41 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-31 00:23:41 --> Final output sent to browser
DEBUG - 2012-01-31 00:23:41 --> Total execution time: 0.5345
DEBUG - 2012-01-31 00:23:42 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:42 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:42 --> Router Class Initialized
ERROR - 2012-01-31 00:23:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:23:44 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:44 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Router Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Output Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Security Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Input Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:23:44 --> Language Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Loader Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:23:44 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Session Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:23:44 --> Session routines successfully run
DEBUG - 2012-01-31 00:23:44 --> Cart Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Controller Class Initialized
DEBUG - 2012-01-31 00:23:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:23:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:23:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:23:44 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 00:23:44 --> Final output sent to browser
DEBUG - 2012-01-31 00:23:44 --> Total execution time: 0.4605
DEBUG - 2012-01-31 00:23:44 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:45 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:45 --> Router Class Initialized
ERROR - 2012-01-31 00:23:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:23:50 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:50 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Router Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Output Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Security Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Input Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:23:50 --> Language Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Loader Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:23:50 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Session Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:23:50 --> Session routines successfully run
DEBUG - 2012-01-31 00:23:50 --> Cart Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:50 --> Controller Class Initialized
DEBUG - 2012-01-31 00:23:51 --> DB Transaction Failure
ERROR - 2012-01-31 00:23:51 --> Query error: Unknown column 'name' in 'field list'
DEBUG - 2012-01-31 00:23:51 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-31 00:23:51 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:51 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:51 --> Router Class Initialized
ERROR - 2012-01-31 00:23:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:23:57 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:57 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:57 --> Router Class Initialized
ERROR - 2012-01-31 00:23:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:23:58 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:58 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Router Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Output Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Security Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Input Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:23:58 --> Language Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Loader Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:23:58 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Session Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:23:58 --> Session routines successfully run
DEBUG - 2012-01-31 00:23:58 --> Cart Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Model Class Initialized
DEBUG - 2012-01-31 00:23:58 --> Controller Class Initialized
DEBUG - 2012-01-31 00:23:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:23:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:23:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:23:58 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:23:58 --> Final output sent to browser
DEBUG - 2012-01-31 00:23:58 --> Total execution time: 0.4756
DEBUG - 2012-01-31 00:23:59 --> Config Class Initialized
DEBUG - 2012-01-31 00:23:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:23:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:23:59 --> URI Class Initialized
DEBUG - 2012-01-31 00:23:59 --> Router Class Initialized
ERROR - 2012-01-31 00:23:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:24:24 --> Config Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:24:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:24:24 --> URI Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Router Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Output Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Security Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Input Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:24:24 --> Language Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Loader Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:24:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Session Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:24:24 --> Session routines successfully run
DEBUG - 2012-01-31 00:24:24 --> Cart Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Model Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Model Class Initialized
DEBUG - 2012-01-31 00:24:24 --> Controller Class Initialized
DEBUG - 2012-01-31 00:24:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 00:24:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 00:24:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 00:24:25 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 00:24:25 --> Final output sent to browser
DEBUG - 2012-01-31 00:24:25 --> Total execution time: 0.1717
DEBUG - 2012-01-31 00:24:26 --> Config Class Initialized
DEBUG - 2012-01-31 00:24:26 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:24:26 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:24:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:24:26 --> URI Class Initialized
DEBUG - 2012-01-31 00:24:26 --> Router Class Initialized
ERROR - 2012-01-31 00:24:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:24:31 --> Config Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:24:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:24:31 --> URI Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Router Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Output Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Security Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Input Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:24:31 --> Language Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Loader Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:24:31 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Session Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:24:31 --> Session routines successfully run
DEBUG - 2012-01-31 00:24:31 --> Cart Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Model Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Model Class Initialized
DEBUG - 2012-01-31 00:24:31 --> Controller Class Initialized
ERROR - 2012-01-31 00:24:31 --> Severity: Notice  --> Undefined index: name A:\home\codeigniter.fool\www\application\controllers\user\cart.php 61
ERROR - 2012-01-31 00:24:31 --> Severity: Notice  --> Undefined index: phone A:\home\codeigniter.fool\www\application\controllers\user\cart.php 62
ERROR - 2012-01-31 00:24:31 --> Severity: Notice  --> Undefined index: address A:\home\codeigniter.fool\www\application\controllers\user\cart.php 63
DEBUG - 2012-01-31 00:24:32 --> Config Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:24:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:24:32 --> URI Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Router Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Output Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Security Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Input Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 00:24:32 --> Language Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Loader Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Helper loaded: url_helper
DEBUG - 2012-01-31 00:24:32 --> Database Driver Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Session Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Helper loaded: string_helper
DEBUG - 2012-01-31 00:24:32 --> Session routines successfully run
DEBUG - 2012-01-31 00:24:32 --> Cart Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Model Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Model Class Initialized
DEBUG - 2012-01-31 00:24:32 --> Controller Class Initialized
DEBUG - 2012-01-31 00:24:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 00:24:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 00:24:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 00:24:32 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 00:24:32 --> Final output sent to browser
DEBUG - 2012-01-31 00:24:32 --> Total execution time: 0.1816
ERROR - 2012-01-31 00:24:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.fool\www\system\core\Exceptions.php:185) A:\home\codeigniter.fool\www\system\libraries\Session.php 672
ERROR - 2012-01-31 00:24:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.fool\www\system\core\Exceptions.php:185) A:\home\codeigniter.fool\www\system\helpers\url_helper.php 546
DEBUG - 2012-01-31 00:24:33 --> Config Class Initialized
DEBUG - 2012-01-31 00:24:33 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:24:33 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:24:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:24:33 --> URI Class Initialized
DEBUG - 2012-01-31 00:24:33 --> Router Class Initialized
ERROR - 2012-01-31 00:24:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 00:24:33 --> Config Class Initialized
DEBUG - 2012-01-31 00:24:33 --> Hooks Class Initialized
DEBUG - 2012-01-31 00:24:33 --> Utf8 Class Initialized
DEBUG - 2012-01-31 00:24:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 00:24:33 --> URI Class Initialized
DEBUG - 2012-01-31 00:24:33 --> Router Class Initialized
ERROR - 2012-01-31 00:24:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:36 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:36 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:36 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:36 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:36 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:37 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:37 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:37 --> A session cookie was not found.
DEBUG - 2012-01-31 20:53:37 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:37 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:37 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:37 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:37 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:37 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:37 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:37 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:37 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-31 20:53:37 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:37 --> Total execution time: 0.1654
DEBUG - 2012-01-31 20:53:38 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:38 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:38 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:38 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:38 --> Router Class Initialized
ERROR - 2012-01-31 20:53:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:39 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:39 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:39 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:39 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:39 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:39 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:39 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:53:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:53:39 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 20:53:39 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:39 --> Total execution time: 0.3960
DEBUG - 2012-01-31 20:53:40 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:40 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:40 --> Router Class Initialized
ERROR - 2012-01-31 20:53:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:42 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:42 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:42 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:42 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:42 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:42 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:42 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:42 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:43 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:43 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:43 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:43 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:53:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:53:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:43 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 20:53:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:53:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 20:53:43 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:43 --> Total execution time: 0.4904
DEBUG - 2012-01-31 20:53:43 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:43 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:43 --> Router Class Initialized
ERROR - 2012-01-31 20:53:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:46 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:46 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:46 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:46 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:46 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:46 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:53:46 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:46 --> Total execution time: 0.2466
DEBUG - 2012-01-31 20:53:46 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:46 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:46 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:46 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:46 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:46 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:53:46 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:53:46 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:46 --> Total execution time: 0.1807
DEBUG - 2012-01-31 20:53:46 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:46 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:46 --> Router Class Initialized
ERROR - 2012-01-31 20:53:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:49 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:49 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:49 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:49 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:49 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:49 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:49 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:53:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:53:49 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:53:49 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:49 --> Total execution time: 0.1597
DEBUG - 2012-01-31 20:53:50 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:50 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:50 --> Router Class Initialized
ERROR - 2012-01-31 20:53:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:51 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:51 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:51 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:51 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:51 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:51 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:53:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:53:51 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:53:51 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:51 --> Total execution time: 0.1717
DEBUG - 2012-01-31 20:53:51 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:51 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:51 --> Router Class Initialized
ERROR - 2012-01-31 20:53:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:56 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:56 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:56 --> No URI present. Default controller set.
DEBUG - 2012-01-31 20:53:56 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:56 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:56 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:56 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:56 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:53:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:53:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:56 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:53:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:53:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:53:56 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:56 --> Total execution time: 0.2890
DEBUG - 2012-01-31 20:53:56 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:56 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:56 --> Router Class Initialized
ERROR - 2012-01-31 20:53:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:53:58 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:58 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Router Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Output Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Security Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Input Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:53:58 --> Language Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Loader Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:53:58 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Session Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:53:58 --> Session routines successfully run
DEBUG - 2012-01-31 20:53:58 --> Cart Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Model Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Controller Class Initialized
DEBUG - 2012-01-31 20:53:58 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:53:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:53:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:53:58 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:53:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:53:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:53:58 --> Final output sent to browser
DEBUG - 2012-01-31 20:53:58 --> Total execution time: 0.1890
DEBUG - 2012-01-31 20:53:59 --> Config Class Initialized
DEBUG - 2012-01-31 20:53:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:53:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:53:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:53:59 --> URI Class Initialized
DEBUG - 2012-01-31 20:53:59 --> Router Class Initialized
ERROR - 2012-01-31 20:53:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:00 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:00 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:00 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:00 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:00 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:00 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:00 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:00 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:00 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:00 --> Total execution time: 0.2432
DEBUG - 2012-01-31 20:54:01 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:01 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:01 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:01 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:01 --> Router Class Initialized
ERROR - 2012-01-31 20:54:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:02 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:02 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:02 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:02 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:02 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:02 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:02 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:02 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:02 --> Total execution time: 0.2007
DEBUG - 2012-01-31 20:54:03 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:03 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:03 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:03 --> Router Class Initialized
ERROR - 2012-01-31 20:54:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:04 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:04 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:04 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:04 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:04 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:04 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:04 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:04 --> Total execution time: 0.2267
DEBUG - 2012-01-31 20:54:04 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:04 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:04 --> Router Class Initialized
ERROR - 2012-01-31 20:54:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:06 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:06 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:06 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:06 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:06 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:06 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:06 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:06 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:06 --> Total execution time: 0.1647
DEBUG - 2012-01-31 20:54:06 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:06 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:06 --> Router Class Initialized
ERROR - 2012-01-31 20:54:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:08 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:08 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:08 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:08 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:08 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:08 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:08 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:08 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:08 --> Total execution time: 0.1639
DEBUG - 2012-01-31 20:54:08 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:08 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:08 --> Router Class Initialized
ERROR - 2012-01-31 20:54:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:10 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:10 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:10 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:10 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:10 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:10 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:10 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:10 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:10 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:10 --> Total execution time: 0.1659
DEBUG - 2012-01-31 20:54:11 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:11 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:11 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:11 --> Router Class Initialized
ERROR - 2012-01-31 20:54:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:12 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:12 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:12 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:12 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:12 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:12 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:12 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:12 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:12 --> Total execution time: 0.1977
DEBUG - 2012-01-31 20:54:12 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:12 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:12 --> Router Class Initialized
ERROR - 2012-01-31 20:54:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:13 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:13 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:13 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:13 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:13 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:13 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:13 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:13 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:14 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:14 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:14 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:14 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:14 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:14 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:14 --> Total execution time: 0.1970
DEBUG - 2012-01-31 20:54:14 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:14 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:14 --> Router Class Initialized
ERROR - 2012-01-31 20:54:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:15 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:15 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:15 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:15 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:15 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:15 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Pagination Class Initialized
DEBUG - 2012-01-31 20:54:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 20:54:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:15 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 20:54:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 20:54:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 20:54:15 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:15 --> Total execution time: 0.1687
DEBUG - 2012-01-31 20:54:15 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:15 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:15 --> Router Class Initialized
ERROR - 2012-01-31 20:54:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:19 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:19 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:19 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:19 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:19 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:19 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:54:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:54:19 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:54:19 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:19 --> Total execution time: 0.1601
DEBUG - 2012-01-31 20:54:19 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:19 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:20 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:20 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:20 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:20 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:54:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:54:20 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:54:20 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:20 --> Total execution time: 0.1850
DEBUG - 2012-01-31 20:54:20 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:20 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:20 --> Router Class Initialized
ERROR - 2012-01-31 20:54:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:24 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:24 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:24 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:24 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:24 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:24 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:54:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:54:24 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:54:24 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:24 --> Total execution time: 0.1559
DEBUG - 2012-01-31 20:54:25 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:25 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:25 --> Router Class Initialized
ERROR - 2012-01-31 20:54:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:26 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:26 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:26 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:26 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:26 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:26 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:54:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:54:26 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:54:26 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:26 --> Total execution time: 0.1586
DEBUG - 2012-01-31 20:54:26 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:26 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:26 --> Router Class Initialized
ERROR - 2012-01-31 20:54:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 20:54:28 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:28 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:28 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:28 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:28 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:28 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:28 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:54:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:54:28 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:54:28 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:28 --> Total execution time: 0.1596
DEBUG - 2012-01-31 20:54:29 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:29 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Router Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Output Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Security Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Input Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 20:54:29 --> Language Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Loader Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Helper loaded: url_helper
DEBUG - 2012-01-31 20:54:29 --> Database Driver Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Session Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Helper loaded: string_helper
DEBUG - 2012-01-31 20:54:29 --> Session routines successfully run
DEBUG - 2012-01-31 20:54:29 --> Cart Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Model Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Controller Class Initialized
DEBUG - 2012-01-31 20:54:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 20:54:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 20:54:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 20:54:29 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 20:54:29 --> Final output sent to browser
DEBUG - 2012-01-31 20:54:29 --> Total execution time: 0.1741
DEBUG - 2012-01-31 20:54:29 --> Config Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Hooks Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Utf8 Class Initialized
DEBUG - 2012-01-31 20:54:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 20:54:29 --> URI Class Initialized
DEBUG - 2012-01-31 20:54:29 --> Router Class Initialized
ERROR - 2012-01-31 20:54:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 21:16:34 --> Config Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:16:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:16:34 --> URI Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Router Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Output Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Security Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Input Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:16:34 --> Language Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Loader Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:16:34 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Session Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:16:34 --> Session routines successfully run
DEBUG - 2012-01-31 21:16:34 --> Cart Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Model Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Model Class Initialized
DEBUG - 2012-01-31 21:16:34 --> Controller Class Initialized
DEBUG - 2012-01-31 21:16:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:16:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:16:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:16:34 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:16:34 --> Final output sent to browser
DEBUG - 2012-01-31 21:16:34 --> Total execution time: 0.4446
DEBUG - 2012-01-31 21:16:35 --> Config Class Initialized
DEBUG - 2012-01-31 21:16:35 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:16:35 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:16:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:16:35 --> URI Class Initialized
DEBUG - 2012-01-31 21:16:35 --> Router Class Initialized
ERROR - 2012-01-31 21:16:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 21:22:40 --> Config Class Initialized
DEBUG - 2012-01-31 21:22:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:22:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:22:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:22:40 --> URI Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Router Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Output Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Security Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Input Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:22:41 --> Language Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Loader Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:22:41 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Session Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:22:41 --> A session cookie was not found.
DEBUG - 2012-01-31 21:22:41 --> Session routines successfully run
DEBUG - 2012-01-31 21:22:41 --> Cart Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Model Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Model Class Initialized
DEBUG - 2012-01-31 21:22:41 --> Controller Class Initialized
DEBUG - 2012-01-31 21:22:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:22:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:22:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:22:41 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:22:41 --> Final output sent to browser
DEBUG - 2012-01-31 21:22:41 --> Total execution time: 0.5603
DEBUG - 2012-01-31 21:33:50 --> Config Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:33:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:33:50 --> URI Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Router Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Output Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Security Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Input Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:33:50 --> Language Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Loader Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:33:50 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Session Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:33:50 --> Session routines successfully run
DEBUG - 2012-01-31 21:33:50 --> Cart Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Model Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Model Class Initialized
DEBUG - 2012-01-31 21:33:50 --> Controller Class Initialized
DEBUG - 2012-01-31 21:33:50 --> XSS Filtering completed
DEBUG - 2012-01-31 21:33:50 --> XSS Filtering completed
DEBUG - 2012-01-31 21:33:50 --> XSS Filtering completed
DEBUG - 2012-01-31 21:33:50 --> DB Transaction Failure
ERROR - 2012-01-31 21:33:50 --> Query error: Unknown column 'price' in 'field list'
DEBUG - 2012-01-31 21:33:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-31 21:36:04 --> Config Class Initialized
DEBUG - 2012-01-31 21:36:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:36:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:36:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:36:05 --> URI Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Router Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Output Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Security Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Input Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:36:05 --> Language Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Loader Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:36:05 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Session Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:36:05 --> Session routines successfully run
DEBUG - 2012-01-31 21:36:05 --> Cart Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Model Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Model Class Initialized
DEBUG - 2012-01-31 21:36:05 --> Controller Class Initialized
DEBUG - 2012-01-31 21:36:05 --> XSS Filtering completed
DEBUG - 2012-01-31 21:36:05 --> XSS Filtering completed
DEBUG - 2012-01-31 21:36:05 --> XSS Filtering completed
DEBUG - 2012-01-31 21:36:05 --> DB Transaction Failure
ERROR - 2012-01-31 21:36:05 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.fool`.`order_product`, CONSTRAINT `fk_products_has_orders_products1` FOREIGN KEY (`id_product`, `id_category`) REFERENCES `products` (`id_product`, `id_category`) ON DELETE CASCAD)
DEBUG - 2012-01-31 21:36:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-31 21:36:37 --> Config Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:36:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:36:37 --> URI Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Router Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Output Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Security Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Input Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:36:37 --> Language Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Loader Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:36:37 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Session Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:36:37 --> Session routines successfully run
DEBUG - 2012-01-31 21:36:37 --> Cart Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Model Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Model Class Initialized
DEBUG - 2012-01-31 21:36:37 --> Controller Class Initialized
DEBUG - 2012-01-31 21:36:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:36:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:36:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:36:37 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:36:37 --> Final output sent to browser
DEBUG - 2012-01-31 21:36:37 --> Total execution time: 0.4479
DEBUG - 2012-01-31 21:37:22 --> Config Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:37:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:37:22 --> URI Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Router Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Output Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Security Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Input Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:37:22 --> Language Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Loader Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:37:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Session Class Initialized
DEBUG - 2012-01-31 21:37:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:37:23 --> Session routines successfully run
DEBUG - 2012-01-31 21:37:23 --> Cart Class Initialized
DEBUG - 2012-01-31 21:37:23 --> Model Class Initialized
DEBUG - 2012-01-31 21:37:23 --> Model Class Initialized
DEBUG - 2012-01-31 21:37:23 --> Controller Class Initialized
DEBUG - 2012-01-31 21:37:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:37:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:37:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:37:23 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:37:23 --> Final output sent to browser
DEBUG - 2012-01-31 21:37:23 --> Total execution time: 0.5936
DEBUG - 2012-01-31 21:38:10 --> Config Class Initialized
DEBUG - 2012-01-31 21:38:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:38:10 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:38:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:38:10 --> URI Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Router Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Output Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Security Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Input Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:38:11 --> Language Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Loader Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:38:11 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Session Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:38:11 --> Session routines successfully run
DEBUG - 2012-01-31 21:38:11 --> Cart Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Model Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Model Class Initialized
DEBUG - 2012-01-31 21:38:11 --> Controller Class Initialized
DEBUG - 2012-01-31 21:38:11 --> XSS Filtering completed
DEBUG - 2012-01-31 21:38:11 --> XSS Filtering completed
DEBUG - 2012-01-31 21:38:11 --> XSS Filtering completed
ERROR - 2012-01-31 21:38:11 --> Severity: Notice  --> Undefined variable: data A:\home\codeigniter.fool\www\application\controllers\user\order.php 64
ERROR - 2012-01-31 21:38:11 --> Severity: Notice  --> Undefined variable: data A:\home\codeigniter.fool\www\application\controllers\user\order.php 65
ERROR - 2012-01-31 21:38:12 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.fool\www\system\core\Exceptions.php:185) A:\home\codeigniter.fool\www\system\helpers\url_helper.php 546
DEBUG - 2012-01-31 21:41:23 --> Config Class Initialized
DEBUG - 2012-01-31 21:41:23 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:41:23 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:41:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:41:23 --> URI Class Initialized
DEBUG - 2012-01-31 21:41:23 --> Router Class Initialized
DEBUG - 2012-01-31 21:41:23 --> Output Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Security Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Input Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:41:24 --> Language Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Loader Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:41:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Session Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:41:24 --> Session routines successfully run
DEBUG - 2012-01-31 21:41:24 --> Cart Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Controller Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Config Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:41:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:41:24 --> URI Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Router Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Output Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Security Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Input Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:41:24 --> Language Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Loader Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:41:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Session Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:41:24 --> Session routines successfully run
DEBUG - 2012-01-31 21:41:24 --> Cart Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Controller Class Initialized
DEBUG - 2012-01-31 21:41:24 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:41:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:41:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:41:25 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 21:41:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:41:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 21:41:25 --> Final output sent to browser
DEBUG - 2012-01-31 21:41:25 --> Total execution time: 0.4652
DEBUG - 2012-01-31 21:41:25 --> Config Class Initialized
DEBUG - 2012-01-31 21:41:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:41:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:41:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:41:25 --> URI Class Initialized
DEBUG - 2012-01-31 21:41:25 --> Router Class Initialized
ERROR - 2012-01-31 21:41:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 21:41:27 --> Config Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:41:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:41:27 --> URI Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Router Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Output Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Security Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Input Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:41:27 --> Language Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Loader Class Initialized
DEBUG - 2012-01-31 21:41:27 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:41:28 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Session Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:41:28 --> Session routines successfully run
DEBUG - 2012-01-31 21:41:28 --> Cart Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Model Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Model Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Controller Class Initialized
DEBUG - 2012-01-31 21:41:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:41:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:41:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:41:28 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:41:28 --> Final output sent to browser
DEBUG - 2012-01-31 21:41:28 --> Total execution time: 0.4415
DEBUG - 2012-01-31 21:41:28 --> Config Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:41:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:41:28 --> URI Class Initialized
DEBUG - 2012-01-31 21:41:28 --> Router Class Initialized
ERROR - 2012-01-31 21:41:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 21:43:48 --> Config Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:43:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:43:48 --> URI Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Router Class Initialized
DEBUG - 2012-01-31 21:43:48 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:43:48 --> Output Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Security Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Input Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:43:48 --> Language Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Loader Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:43:48 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Session Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:43:48 --> Session routines successfully run
DEBUG - 2012-01-31 21:43:48 --> Cart Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Controller Class Initialized
DEBUG - 2012-01-31 21:43:48 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:43:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:43:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:43:48 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:43:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:43:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:43:48 --> Final output sent to browser
DEBUG - 2012-01-31 21:43:48 --> Total execution time: 0.6567
DEBUG - 2012-01-31 21:43:51 --> Config Class Initialized
DEBUG - 2012-01-31 21:43:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:43:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:43:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:43:51 --> URI Class Initialized
DEBUG - 2012-01-31 21:43:51 --> Router Class Initialized
DEBUG - 2012-01-31 21:43:51 --> Output Class Initialized
DEBUG - 2012-01-31 21:43:51 --> Security Class Initialized
DEBUG - 2012-01-31 21:43:51 --> Input Class Initialized
DEBUG - 2012-01-31 21:43:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:43:52 --> Language Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Loader Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:43:52 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Session Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:43:52 --> Session routines successfully run
DEBUG - 2012-01-31 21:43:52 --> Cart Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Controller Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Config Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:43:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:43:52 --> URI Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Router Class Initialized
DEBUG - 2012-01-31 21:43:52 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:43:52 --> Output Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Security Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Input Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:43:52 --> Language Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Loader Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:43:52 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Session Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:43:52 --> Session routines successfully run
DEBUG - 2012-01-31 21:43:52 --> Cart Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Controller Class Initialized
DEBUG - 2012-01-31 21:43:52 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:43:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:43:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:43:52 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:43:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:43:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:43:52 --> Final output sent to browser
DEBUG - 2012-01-31 21:43:52 --> Total execution time: 0.5855
DEBUG - 2012-01-31 21:43:54 --> Config Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:43:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:43:54 --> URI Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Router Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Output Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Security Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Input Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:43:54 --> Language Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Loader Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:43:54 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Session Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:43:54 --> Session routines successfully run
DEBUG - 2012-01-31 21:43:54 --> Cart Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Controller Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Config Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:43:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:43:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:43:55 --> URI Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Router Class Initialized
DEBUG - 2012-01-31 21:43:55 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:43:55 --> Output Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Security Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Input Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:43:55 --> Language Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Loader Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:43:55 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Session Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:43:55 --> Session routines successfully run
DEBUG - 2012-01-31 21:43:55 --> Cart Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Controller Class Initialized
DEBUG - 2012-01-31 21:43:55 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:43:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:43:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:43:55 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:43:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:43:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:43:55 --> Final output sent to browser
DEBUG - 2012-01-31 21:43:55 --> Total execution time: 0.6246
DEBUG - 2012-01-31 21:43:57 --> Config Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:43:57 --> URI Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Router Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Output Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Security Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Input Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:43:57 --> Language Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Loader Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:43:57 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Session Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:43:57 --> Session routines successfully run
DEBUG - 2012-01-31 21:43:57 --> Cart Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Controller Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Config Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:43:57 --> URI Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Router Class Initialized
DEBUG - 2012-01-31 21:43:57 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:43:57 --> Output Class Initialized
DEBUG - 2012-01-31 21:43:57 --> Security Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Input Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:43:58 --> Language Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Loader Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:43:58 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Session Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:43:58 --> Session routines successfully run
DEBUG - 2012-01-31 21:43:58 --> Cart Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Model Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Controller Class Initialized
DEBUG - 2012-01-31 21:43:58 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:43:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:43:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:43:58 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:43:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:43:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:43:58 --> Final output sent to browser
DEBUG - 2012-01-31 21:43:58 --> Total execution time: 0.5837
DEBUG - 2012-01-31 21:44:02 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:02 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:02 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:02 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:02 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:02 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:44:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:44:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:44:02 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:44:02 --> Final output sent to browser
DEBUG - 2012-01-31 21:44:02 --> Total execution time: 0.4776
DEBUG - 2012-01-31 21:44:36 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:36 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:36 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:36 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:36 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:36 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:36 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:36 --> XSS Filtering completed
DEBUG - 2012-01-31 21:44:36 --> XSS Filtering completed
DEBUG - 2012-01-31 21:44:36 --> XSS Filtering completed
DEBUG - 2012-01-31 21:44:37 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:37 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:37 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:44:37 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:37 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:37 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:38 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:38 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:38 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:38 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:38 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:38 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:38 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:38 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:38 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:44:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:44:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:44:38 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:44:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:44:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:44:38 --> Final output sent to browser
DEBUG - 2012-01-31 21:44:38 --> Total execution time: 0.4920
DEBUG - 2012-01-31 21:44:44 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:44 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:44 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:44 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:44 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:44 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:45 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:45 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:45 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:45 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:45 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:45 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:45 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-31 21:44:45 --> Final output sent to browser
DEBUG - 2012-01-31 21:44:45 --> Total execution time: 0.3869
DEBUG - 2012-01-31 21:44:47 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:47 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:47 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:47 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:47 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:47 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:47 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:47 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:48 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:48 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:48 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:48 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:48 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:48 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:48 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:48 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:48 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:48 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:44:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:44:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:44:48 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 21:44:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:44:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 21:44:48 --> Final output sent to browser
DEBUG - 2012-01-31 21:44:48 --> Total execution time: 1.0028
DEBUG - 2012-01-31 21:44:52 --> Config Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:44:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:44:52 --> URI Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Router Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Output Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Security Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Input Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:44:52 --> Language Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Loader Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:44:52 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Session Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:44:52 --> Session routines successfully run
DEBUG - 2012-01-31 21:44:52 --> Cart Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:44:52 --> Controller Class Initialized
DEBUG - 2012-01-31 21:44:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:44:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:44:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:44:52 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:44:52 --> Final output sent to browser
DEBUG - 2012-01-31 21:44:52 --> Total execution time: 0.5278
DEBUG - 2012-01-31 21:47:18 --> Config Class Initialized
DEBUG - 2012-01-31 21:47:18 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:47:18 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:47:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:47:18 --> URI Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Router Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Output Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Security Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Input Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:47:19 --> Language Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Loader Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:47:19 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Session Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:47:19 --> Session routines successfully run
DEBUG - 2012-01-31 21:47:19 --> Cart Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Model Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Model Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Controller Class Initialized
DEBUG - 2012-01-31 21:47:19 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:47:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:47:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:47:19 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:47:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:47:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:47:19 --> Final output sent to browser
DEBUG - 2012-01-31 21:47:19 --> Total execution time: 0.5216
DEBUG - 2012-01-31 21:47:21 --> Config Class Initialized
DEBUG - 2012-01-31 21:47:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:47:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:47:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:47:21 --> URI Class Initialized
DEBUG - 2012-01-31 21:47:21 --> Router Class Initialized
DEBUG - 2012-01-31 21:47:21 --> Output Class Initialized
DEBUG - 2012-01-31 21:47:21 --> Security Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Input Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:47:22 --> Language Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Loader Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:47:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Session Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:47:22 --> Session routines successfully run
DEBUG - 2012-01-31 21:47:22 --> Cart Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Model Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Model Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Controller Class Initialized
DEBUG - 2012-01-31 21:47:22 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:47:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:47:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:47:22 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:47:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:47:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:47:22 --> Final output sent to browser
DEBUG - 2012-01-31 21:47:22 --> Total execution time: 0.5133
DEBUG - 2012-01-31 21:47:25 --> Config Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:47:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:47:25 --> URI Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Router Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Output Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Security Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Input Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:47:25 --> Language Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Loader Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:47:25 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Session Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:47:25 --> Session routines successfully run
DEBUG - 2012-01-31 21:47:25 --> Cart Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Model Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Model Class Initialized
DEBUG - 2012-01-31 21:47:25 --> Controller Class Initialized
DEBUG - 2012-01-31 21:47:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:47:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:47:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:47:25 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:47:25 --> Final output sent to browser
DEBUG - 2012-01-31 21:47:25 --> Total execution time: 0.4390
DEBUG - 2012-01-31 21:48:35 --> Config Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:48:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:48:35 --> URI Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Router Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Output Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Security Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Input Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:48:35 --> Language Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Loader Class Initialized
DEBUG - 2012-01-31 21:48:35 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:48:36 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:48:36 --> Session Class Initialized
DEBUG - 2012-01-31 21:48:36 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:48:36 --> Session routines successfully run
DEBUG - 2012-01-31 21:48:36 --> Cart Class Initialized
DEBUG - 2012-01-31 21:48:36 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:36 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:36 --> Controller Class Initialized
DEBUG - 2012-01-31 21:48:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:48:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:48:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:48:36 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:48:36 --> Final output sent to browser
DEBUG - 2012-01-31 21:48:36 --> Total execution time: 0.4477
DEBUG - 2012-01-31 21:48:54 --> Config Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:48:54 --> URI Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Router Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Output Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Security Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Input Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:48:54 --> Language Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Loader Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:48:54 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Session Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:48:54 --> Session routines successfully run
DEBUG - 2012-01-31 21:48:54 --> Cart Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:54 --> Controller Class Initialized
DEBUG - 2012-01-31 21:48:54 --> XSS Filtering completed
DEBUG - 2012-01-31 21:48:54 --> XSS Filtering completed
DEBUG - 2012-01-31 21:48:54 --> XSS Filtering completed
DEBUG - 2012-01-31 21:48:55 --> Config Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:48:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:48:55 --> URI Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Router Class Initialized
DEBUG - 2012-01-31 21:48:55 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:48:55 --> Output Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Security Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Input Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:48:55 --> Language Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Loader Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:48:55 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Session Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:48:55 --> Session routines successfully run
DEBUG - 2012-01-31 21:48:55 --> Cart Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Controller Class Initialized
DEBUG - 2012-01-31 21:48:55 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:48:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:48:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:48:55 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:48:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:48:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:48:55 --> Final output sent to browser
DEBUG - 2012-01-31 21:48:55 --> Total execution time: 0.5023
DEBUG - 2012-01-31 21:48:58 --> Config Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:48:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:48:58 --> URI Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Router Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Output Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Security Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Input Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:48:58 --> Language Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Loader Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:48:58 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Session Class Initialized
DEBUG - 2012-01-31 21:48:58 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:48:58 --> Session routines successfully run
DEBUG - 2012-01-31 21:48:58 --> Cart Class Initialized
DEBUG - 2012-01-31 21:48:59 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:59 --> Model Class Initialized
DEBUG - 2012-01-31 21:48:59 --> Controller Class Initialized
DEBUG - 2012-01-31 21:48:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:48:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:48:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:48:59 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:48:59 --> Final output sent to browser
DEBUG - 2012-01-31 21:48:59 --> Total execution time: 0.4430
DEBUG - 2012-01-31 21:49:02 --> Config Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:49:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:49:02 --> URI Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Router Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Output Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Security Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Input Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:49:02 --> Language Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Loader Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:49:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Session Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:49:02 --> Session routines successfully run
DEBUG - 2012-01-31 21:49:02 --> Cart Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Model Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Model Class Initialized
DEBUG - 2012-01-31 21:49:02 --> Controller Class Initialized
DEBUG - 2012-01-31 21:49:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:49:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:49:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:49:03 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:49:03 --> Final output sent to browser
DEBUG - 2012-01-31 21:49:03 --> Total execution time: 0.4259
DEBUG - 2012-01-31 21:49:04 --> Config Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:49:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:49:04 --> URI Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Router Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Output Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Security Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Input Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:49:04 --> Language Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Loader Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:49:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Session Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:49:04 --> Session routines successfully run
DEBUG - 2012-01-31 21:49:04 --> Cart Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Model Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Model Class Initialized
DEBUG - 2012-01-31 21:49:04 --> Controller Class Initialized
DEBUG - 2012-01-31 21:49:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:49:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:49:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:49:04 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:49:04 --> Final output sent to browser
DEBUG - 2012-01-31 21:49:04 --> Total execution time: 0.4665
DEBUG - 2012-01-31 21:53:14 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:14 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:14 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:14 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:15 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:15 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:15 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:15 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:15 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:15 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:15 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:15 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:15 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:53:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:53:15 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:53:15 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:15 --> Total execution time: 0.4676
DEBUG - 2012-01-31 21:53:18 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:18 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:18 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:18 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:18 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:19 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:19 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:19 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:19 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:19 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:19 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:53:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:53:19 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:53:19 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:19 --> Total execution time: 0.4587
DEBUG - 2012-01-31 21:53:21 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:21 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:21 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:21 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:21 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:21 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:21 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:53:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:53:21 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:53:21 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:21 --> Total execution time: 0.5510
DEBUG - 2012-01-31 21:53:24 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:24 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:24 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:24 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:24 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:24 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:53:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:53:24 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:53:24 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:24 --> Total execution time: 0.4636
DEBUG - 2012-01-31 21:53:27 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:27 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:27 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:27 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:27 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:27 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:27 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:28 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:28 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:28 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:28 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:28 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:28 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:53:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:53:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:29 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 21:53:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:53:29 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 21:53:29 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:29 --> Total execution time: 0.4847
DEBUG - 2012-01-31 21:53:34 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:34 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:34 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:34 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:34 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:34 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:34 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:34 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:35 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:35 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:35 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:35 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:35 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:53:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:53:35 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:53:35 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:35 --> Total execution time: 0.5180
DEBUG - 2012-01-31 21:53:43 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:43 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:43 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:43 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:43 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:43 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:43 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:53:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:53:43 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 21:53:43 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:43 --> Total execution time: 0.5007
DEBUG - 2012-01-31 21:53:47 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:47 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:47 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:47 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:47 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:47 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:48 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:48 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:48 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:48 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:48 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:48 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:53:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:53:48 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 21:53:48 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:48 --> Total execution time: 0.5865
DEBUG - 2012-01-31 21:53:52 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:52 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:52 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:52 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:52 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:52 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:52 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:53:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:53:52 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 21:53:52 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:52 --> Total execution time: 0.5064
DEBUG - 2012-01-31 21:53:57 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:57 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:57 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:57 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:58 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:58 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:58 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:58 --> XSS Filtering completed
DEBUG - 2012-01-31 21:53:58 --> XSS Filtering completed
DEBUG - 2012-01-31 21:53:58 --> XSS Filtering completed
DEBUG - 2012-01-31 21:53:58 --> Config Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:53:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:53:58 --> URI Class Initialized
DEBUG - 2012-01-31 21:53:58 --> Router Class Initialized
DEBUG - 2012-01-31 21:53:59 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:53:59 --> Output Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Security Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Input Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:53:59 --> Language Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Loader Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:53:59 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Session Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:53:59 --> Session routines successfully run
DEBUG - 2012-01-31 21:53:59 --> Cart Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Model Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Controller Class Initialized
DEBUG - 2012-01-31 21:53:59 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:53:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:53:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:53:59 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:53:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:53:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:53:59 --> Final output sent to browser
DEBUG - 2012-01-31 21:53:59 --> Total execution time: 0.4996
DEBUG - 2012-01-31 21:54:02 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:02 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:02 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:03 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:03 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:03 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:03 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:03 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:54:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:54:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:54:04 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 21:54:04 --> Final output sent to browser
DEBUG - 2012-01-31 21:54:04 --> Total execution time: 1.2684
DEBUG - 2012-01-31 21:54:05 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:05 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:05 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:05 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:05 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:05 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:05 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:54:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:54:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:54:05 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:54:05 --> Final output sent to browser
DEBUG - 2012-01-31 21:54:05 --> Total execution time: 0.5093
DEBUG - 2012-01-31 21:54:13 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:13 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:13 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:13 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:13 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:13 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:13 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:54:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:54:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:54:13 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-31 21:54:13 --> Final output sent to browser
DEBUG - 2012-01-31 21:54:13 --> Total execution time: 0.5074
DEBUG - 2012-01-31 21:54:20 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:20 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:20 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:20 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:20 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:20 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:21 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:21 --> No URI present. Default controller set.
DEBUG - 2012-01-31 21:54:21 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:21 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:21 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:21 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:21 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:21 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:54:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 21:54:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 21:54:21 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 21:54:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 21:54:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 21:54:21 --> Final output sent to browser
DEBUG - 2012-01-31 21:54:21 --> Total execution time: 0.4763
DEBUG - 2012-01-31 21:54:24 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:24 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:24 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:24 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:24 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:24 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:54:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:54:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:54:24 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:54:24 --> Final output sent to browser
DEBUG - 2012-01-31 21:54:24 --> Total execution time: 0.4611
DEBUG - 2012-01-31 21:54:27 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:27 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:27 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:27 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:27 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:27 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:27 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:54:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:54:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:54:27 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:54:27 --> Final output sent to browser
DEBUG - 2012-01-31 21:54:27 --> Total execution time: 0.4457
DEBUG - 2012-01-31 21:54:41 --> Config Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:54:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:54:41 --> URI Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Router Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Output Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Security Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Input Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:54:41 --> Language Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Loader Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:54:41 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Session Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:54:41 --> Session routines successfully run
DEBUG - 2012-01-31 21:54:41 --> Cart Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Model Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Controller Class Initialized
DEBUG - 2012-01-31 21:54:41 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:54:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:54:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:54:41 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 21:54:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:54:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 21:54:41 --> Final output sent to browser
DEBUG - 2012-01-31 21:54:41 --> Total execution time: 0.5221
DEBUG - 2012-01-31 21:57:30 --> Config Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:57:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:57:30 --> URI Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Router Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Output Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Security Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Input Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:57:30 --> Language Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Loader Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:57:30 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Session Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:57:30 --> Session routines successfully run
DEBUG - 2012-01-31 21:57:30 --> Cart Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Model Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Model Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Controller Class Initialized
DEBUG - 2012-01-31 21:57:30 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:57:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:57:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:57:31 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 21:57:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:57:31 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 21:57:31 --> Final output sent to browser
DEBUG - 2012-01-31 21:57:31 --> Total execution time: 0.4886
DEBUG - 2012-01-31 21:57:34 --> Config Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:57:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:57:34 --> URI Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Router Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Output Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Security Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Input Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:57:34 --> Language Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Loader Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:57:34 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Session Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:57:34 --> Session routines successfully run
DEBUG - 2012-01-31 21:57:34 --> Cart Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Model Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Model Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Controller Class Initialized
DEBUG - 2012-01-31 21:57:34 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:57:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:57:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:57:34 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 21:57:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:57:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 21:57:34 --> Final output sent to browser
DEBUG - 2012-01-31 21:57:34 --> Total execution time: 0.4671
DEBUG - 2012-01-31 21:59:46 --> Config Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:59:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:59:46 --> URI Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Router Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Output Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Security Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Input Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:59:46 --> Language Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Loader Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:59:46 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Session Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:59:46 --> Session routines successfully run
DEBUG - 2012-01-31 21:59:46 --> Cart Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Model Class Initialized
DEBUG - 2012-01-31 21:59:46 --> Model Class Initialized
DEBUG - 2012-01-31 21:59:47 --> Controller Class Initialized
DEBUG - 2012-01-31 21:59:47 --> Pagination Class Initialized
DEBUG - 2012-01-31 21:59:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:59:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:59:47 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 21:59:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:59:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 21:59:47 --> Final output sent to browser
DEBUG - 2012-01-31 21:59:47 --> Total execution time: 0.5031
DEBUG - 2012-01-31 21:59:50 --> Config Class Initialized
DEBUG - 2012-01-31 21:59:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 21:59:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 21:59:50 --> URI Class Initialized
DEBUG - 2012-01-31 21:59:50 --> Router Class Initialized
DEBUG - 2012-01-31 21:59:50 --> Output Class Initialized
DEBUG - 2012-01-31 21:59:50 --> Security Class Initialized
DEBUG - 2012-01-31 21:59:50 --> Input Class Initialized
DEBUG - 2012-01-31 21:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 21:59:50 --> Language Class Initialized
DEBUG - 2012-01-31 21:59:51 --> Loader Class Initialized
DEBUG - 2012-01-31 21:59:51 --> Helper loaded: url_helper
DEBUG - 2012-01-31 21:59:51 --> Database Driver Class Initialized
DEBUG - 2012-01-31 21:59:51 --> Session Class Initialized
DEBUG - 2012-01-31 21:59:51 --> Helper loaded: string_helper
DEBUG - 2012-01-31 21:59:51 --> Session routines successfully run
DEBUG - 2012-01-31 21:59:51 --> Cart Class Initialized
DEBUG - 2012-01-31 21:59:51 --> Model Class Initialized
DEBUG - 2012-01-31 21:59:51 --> Model Class Initialized
DEBUG - 2012-01-31 21:59:51 --> Controller Class Initialized
DEBUG - 2012-01-31 21:59:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 21:59:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 21:59:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 21:59:51 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 21:59:51 --> Final output sent to browser
DEBUG - 2012-01-31 21:59:51 --> Total execution time: 0.5361
DEBUG - 2012-01-31 22:00:00 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:00 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:00 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:00 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:00 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:00 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:00 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:01 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:01 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:01 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:01 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:01 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:01 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:00:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:00:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:01 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:00:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:00:01 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:00:01 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:01 --> Total execution time: 0.5181
DEBUG - 2012-01-31 22:00:03 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:03 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:03 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:03 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:03 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:03 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:03 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:00:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:00:03 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:00:03 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:03 --> Total execution time: 0.5319
DEBUG - 2012-01-31 22:00:06 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:06 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:06 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:06 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:06 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:06 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:06 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:07 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:07 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:07 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:07 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:07 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:07 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:00:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:00:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:07 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:00:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:00:07 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:00:07 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:07 --> Total execution time: 0.4951
DEBUG - 2012-01-31 22:00:11 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:11 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:11 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:11 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:11 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:00:11 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:11 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:11 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:12 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:12 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:12 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:12 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:12 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:00:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:00:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:12 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:00:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:00:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:00:12 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:12 --> Total execution time: 1.0577
DEBUG - 2012-01-31 22:00:15 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:15 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:15 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:15 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:15 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:15 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:15 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:16 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:16 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:16 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:00:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:00:16 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 22:00:16 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:16 --> Total execution time: 0.4255
DEBUG - 2012-01-31 22:00:20 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:20 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:20 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:20 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:21 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:21 --> XSS Filtering completed
DEBUG - 2012-01-31 22:00:21 --> XSS Filtering completed
DEBUG - 2012-01-31 22:00:21 --> XSS Filtering completed
DEBUG - 2012-01-31 22:00:21 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:21 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:21 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:00:21 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:21 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:21 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:22 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:22 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:22 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:22 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:22 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:22 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:22 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:00:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:00:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:22 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:00:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:00:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:00:22 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:22 --> Total execution time: 0.5401
DEBUG - 2012-01-31 22:00:23 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:23 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:23 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:24 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:24 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:24 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:24 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:24 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:00:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:00:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:24 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:00:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:00:24 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:00:24 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:24 --> Total execution time: 0.5766
DEBUG - 2012-01-31 22:00:25 --> Config Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:00:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:00:25 --> URI Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Router Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Output Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Security Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Input Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:00:25 --> Language Class Initialized
DEBUG - 2012-01-31 22:00:25 --> Loader Class Initialized
DEBUG - 2012-01-31 22:00:26 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:00:26 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:00:26 --> Session Class Initialized
DEBUG - 2012-01-31 22:00:26 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:00:26 --> Session routines successfully run
DEBUG - 2012-01-31 22:00:26 --> Cart Class Initialized
DEBUG - 2012-01-31 22:00:26 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:26 --> Model Class Initialized
DEBUG - 2012-01-31 22:00:26 --> Controller Class Initialized
DEBUG - 2012-01-31 22:00:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:00:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:00:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:00:26 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:00:26 --> Final output sent to browser
DEBUG - 2012-01-31 22:00:26 --> Total execution time: 1.1346
DEBUG - 2012-01-31 22:01:53 --> Config Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:01:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:01:53 --> URI Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Router Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Output Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Security Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Input Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:01:53 --> Language Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Loader Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:01:53 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Session Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:01:53 --> Session routines successfully run
DEBUG - 2012-01-31 22:01:53 --> Cart Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:53 --> Controller Class Initialized
DEBUG - 2012-01-31 22:01:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:01:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:01:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:01:53 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:01:53 --> Final output sent to browser
DEBUG - 2012-01-31 22:01:53 --> Total execution time: 0.4507
DEBUG - 2012-01-31 22:01:55 --> Config Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:01:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:01:55 --> URI Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Router Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Output Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Security Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Input Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:01:55 --> Language Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Loader Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:01:55 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Session Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:01:55 --> Session routines successfully run
DEBUG - 2012-01-31 22:01:55 --> Cart Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:55 --> Controller Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Config Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:01:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:01:56 --> URI Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Router Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Output Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Security Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Input Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:01:56 --> Language Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Loader Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:01:56 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Session Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:01:56 --> Session routines successfully run
DEBUG - 2012-01-31 22:01:56 --> Cart Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Controller Class Initialized
DEBUG - 2012-01-31 22:01:56 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:01:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:01:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:01:56 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:01:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:01:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:01:56 --> Final output sent to browser
DEBUG - 2012-01-31 22:01:56 --> Total execution time: 0.4671
DEBUG - 2012-01-31 22:01:59 --> Config Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:01:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:01:59 --> URI Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Router Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Output Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Security Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Input Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:01:59 --> Language Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Loader Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:01:59 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Session Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:01:59 --> Session routines successfully run
DEBUG - 2012-01-31 22:01:59 --> Cart Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Model Class Initialized
DEBUG - 2012-01-31 22:01:59 --> Controller Class Initialized
DEBUG - 2012-01-31 22:01:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:01:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:01:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:01:59 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 22:02:00 --> Final output sent to browser
DEBUG - 2012-01-31 22:02:00 --> Total execution time: 0.5008
DEBUG - 2012-01-31 22:02:04 --> Config Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:02:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:02:04 --> URI Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Router Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Output Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Security Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Input Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:02:04 --> Language Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Loader Class Initialized
DEBUG - 2012-01-31 22:02:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:02:05 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:02:05 --> Session Class Initialized
DEBUG - 2012-01-31 22:02:05 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:02:05 --> Session routines successfully run
DEBUG - 2012-01-31 22:02:05 --> Cart Class Initialized
DEBUG - 2012-01-31 22:02:05 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:05 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:05 --> Controller Class Initialized
DEBUG - 2012-01-31 22:02:05 --> XSS Filtering completed
DEBUG - 2012-01-31 22:02:05 --> XSS Filtering completed
DEBUG - 2012-01-31 22:02:05 --> XSS Filtering completed
DEBUG - 2012-01-31 22:02:06 --> Config Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:02:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:02:06 --> URI Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Router Class Initialized
DEBUG - 2012-01-31 22:02:06 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:02:06 --> Output Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Security Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Input Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:02:06 --> Language Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Loader Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:02:06 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Session Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:02:06 --> Session routines successfully run
DEBUG - 2012-01-31 22:02:06 --> Cart Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Controller Class Initialized
DEBUG - 2012-01-31 22:02:06 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:02:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:02:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:02:06 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:02:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:02:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:02:06 --> Final output sent to browser
DEBUG - 2012-01-31 22:02:06 --> Total execution time: 0.4921
DEBUG - 2012-01-31 22:02:08 --> Config Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:02:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:02:08 --> URI Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Router Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Output Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Security Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Input Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:02:08 --> Language Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Loader Class Initialized
DEBUG - 2012-01-31 22:02:08 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:02:08 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:02:09 --> Session Class Initialized
DEBUG - 2012-01-31 22:02:09 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:02:09 --> Session routines successfully run
DEBUG - 2012-01-31 22:02:09 --> Cart Class Initialized
DEBUG - 2012-01-31 22:02:09 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:09 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:09 --> Controller Class Initialized
DEBUG - 2012-01-31 22:02:09 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:02:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:02:09 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:02:09 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:02:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:02:09 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:02:09 --> Final output sent to browser
DEBUG - 2012-01-31 22:02:09 --> Total execution time: 0.5479
DEBUG - 2012-01-31 22:02:12 --> Config Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:02:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:02:12 --> URI Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Router Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Output Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Security Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Input Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:02:12 --> Language Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Loader Class Initialized
DEBUG - 2012-01-31 22:02:12 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:02:13 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:02:13 --> Session Class Initialized
DEBUG - 2012-01-31 22:02:13 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:02:13 --> Session routines successfully run
DEBUG - 2012-01-31 22:02:13 --> Cart Class Initialized
DEBUG - 2012-01-31 22:02:13 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:13 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:13 --> Controller Class Initialized
DEBUG - 2012-01-31 22:02:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:02:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:02:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:02:13 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:02:13 --> Final output sent to browser
DEBUG - 2012-01-31 22:02:13 --> Total execution time: 0.4573
DEBUG - 2012-01-31 22:02:49 --> Config Class Initialized
DEBUG - 2012-01-31 22:02:49 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:02:49 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:02:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:02:49 --> URI Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Router Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Output Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Security Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Input Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:02:50 --> Language Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Loader Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:02:50 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Session Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:02:50 --> Session routines successfully run
DEBUG - 2012-01-31 22:02:50 --> Cart Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Controller Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Config Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:02:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:02:50 --> URI Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Router Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Output Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Security Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Input Class Initialized
DEBUG - 2012-01-31 22:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:02:51 --> Language Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Loader Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:02:51 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Session Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:02:51 --> Session routines successfully run
DEBUG - 2012-01-31 22:02:51 --> Cart Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Model Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Controller Class Initialized
DEBUG - 2012-01-31 22:02:51 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:02:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:02:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:02:51 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:02:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:02:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:02:51 --> Final output sent to browser
DEBUG - 2012-01-31 22:02:51 --> Total execution time: 0.4840
DEBUG - 2012-01-31 22:03:02 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:02 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:02 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:02 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:02 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:02 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:02 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:03:02 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:02 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:02 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:02 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:02 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:03:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:03:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:03:02 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:03:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:03:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:03:03 --> Final output sent to browser
DEBUG - 2012-01-31 22:03:03 --> Total execution time: 0.5213
DEBUG - 2012-01-31 22:03:06 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:06 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:06 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:06 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:06 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:06 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:07 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:07 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:03:07 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:07 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:07 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:07 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:07 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:07 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:03:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:03:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:03:07 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:03:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:03:07 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:03:07 --> Final output sent to browser
DEBUG - 2012-01-31 22:03:07 --> Total execution time: 0.9001
DEBUG - 2012-01-31 22:03:12 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:12 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:12 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:12 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:12 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:12 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:12 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:03:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:03:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:03:12 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-31 22:03:12 --> Final output sent to browser
DEBUG - 2012-01-31 22:03:13 --> Total execution time: 0.9407
DEBUG - 2012-01-31 22:03:22 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:22 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:22 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:22 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:22 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:22 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:22 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:22 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:23 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:23 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:23 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:23 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:23 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:23 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:03:23 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:23 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:23 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:23 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:23 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:23 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:03:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:03:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:03:23 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:03:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:03:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:03:23 --> Final output sent to browser
DEBUG - 2012-01-31 22:03:24 --> Total execution time: 0.5451
DEBUG - 2012-01-31 22:03:27 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:27 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:27 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:27 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:27 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:27 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:27 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:03:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:03:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:03:27 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:03:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:03:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:03:27 --> Final output sent to browser
DEBUG - 2012-01-31 22:03:27 --> Total execution time: 0.4901
DEBUG - 2012-01-31 22:03:29 --> Config Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:03:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:03:29 --> URI Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Router Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Output Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Security Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Input Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:03:29 --> Language Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Loader Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:03:29 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Session Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:03:29 --> Session routines successfully run
DEBUG - 2012-01-31 22:03:29 --> Cart Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Model Class Initialized
DEBUG - 2012-01-31 22:03:29 --> Controller Class Initialized
DEBUG - 2012-01-31 22:03:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:03:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:03:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:03:29 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:03:29 --> Final output sent to browser
DEBUG - 2012-01-31 22:03:29 --> Total execution time: 0.4644
DEBUG - 2012-01-31 22:10:35 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:35 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:35 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:10:35 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:35 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:35 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:35 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:35 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:10:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:10:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:10:35 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:10:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:10:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:10:35 --> Final output sent to browser
DEBUG - 2012-01-31 22:10:35 --> Total execution time: 0.4880
DEBUG - 2012-01-31 22:10:35 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:35 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:36 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:36 --> Router Class Initialized
ERROR - 2012-01-31 22:10:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:10:37 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:37 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:37 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:37 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:37 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:37 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:37 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:38 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:38 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:10:38 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:38 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:38 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:38 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:38 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:10:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:10:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:10:38 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:10:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:10:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:10:38 --> Final output sent to browser
DEBUG - 2012-01-31 22:10:38 --> Total execution time: 0.4889
DEBUG - 2012-01-31 22:10:38 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:38 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:38 --> Router Class Initialized
ERROR - 2012-01-31 22:10:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:10:39 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:39 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:39 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:39 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:40 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:40 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:40 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:40 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:40 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:40 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:10:40 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:40 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:40 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:41 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:41 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:41 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:41 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:41 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:41 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:41 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:41 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:41 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:41 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:10:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:10:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:10:41 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:10:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:10:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:10:41 --> Final output sent to browser
DEBUG - 2012-01-31 22:10:41 --> Total execution time: 1.0585
DEBUG - 2012-01-31 22:10:42 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:42 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:42 --> Router Class Initialized
ERROR - 2012-01-31 22:10:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:10:43 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:43 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:43 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:43 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:43 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:43 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:43 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:43 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:10:43 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:43 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:43 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:43 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:43 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:43 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:10:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:10:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:10:44 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:10:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:10:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:10:44 --> Final output sent to browser
DEBUG - 2012-01-31 22:10:44 --> Total execution time: 0.5229
DEBUG - 2012-01-31 22:10:44 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:44 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:44 --> Router Class Initialized
ERROR - 2012-01-31 22:10:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:10:46 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:46 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:46 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:46 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:46 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:47 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:47 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:10:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:10:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:10:47 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-31 22:10:47 --> Final output sent to browser
DEBUG - 2012-01-31 22:10:47 --> Total execution time: 0.4491
DEBUG - 2012-01-31 22:10:47 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:47 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:47 --> Router Class Initialized
ERROR - 2012-01-31 22:10:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:10:50 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:50 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:50 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:50 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:50 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:50 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:50 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:51 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:51 --> No URI present. Default controller set.
DEBUG - 2012-01-31 22:10:51 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:51 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:51 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:51 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:51 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:51 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:10:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 22:10:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 22:10:51 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 22:10:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 22:10:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 22:10:51 --> Final output sent to browser
DEBUG - 2012-01-31 22:10:51 --> Total execution time: 0.4801
DEBUG - 2012-01-31 22:10:53 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:53 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:53 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:53 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:53 --> Router Class Initialized
ERROR - 2012-01-31 22:10:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:10:54 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:54 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:54 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:54 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:54 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:54 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:54 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:10:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:10:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:10:54 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:10:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:10:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 22:10:54 --> Final output sent to browser
DEBUG - 2012-01-31 22:10:54 --> Total execution time: 0.4682
DEBUG - 2012-01-31 22:10:55 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:55 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:55 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:55 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:55 --> Router Class Initialized
ERROR - 2012-01-31 22:10:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:10:57 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:57 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Router Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Output Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Security Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Input Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:10:57 --> Language Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Loader Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:10:57 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Session Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:10:57 --> Session routines successfully run
DEBUG - 2012-01-31 22:10:57 --> Cart Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Model Class Initialized
DEBUG - 2012-01-31 22:10:57 --> Controller Class Initialized
DEBUG - 2012-01-31 22:10:57 --> DB Transaction Failure
ERROR - 2012-01-31 22:10:57 --> Query error: Unknown column 'o.count' in 'field list'
DEBUG - 2012-01-31 22:10:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-31 22:10:58 --> Config Class Initialized
DEBUG - 2012-01-31 22:10:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:10:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:10:58 --> URI Class Initialized
DEBUG - 2012-01-31 22:10:58 --> Router Class Initialized
ERROR - 2012-01-31 22:10:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:20:58 --> Config Class Initialized
DEBUG - 2012-01-31 22:20:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:20:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:20:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:20:58 --> URI Class Initialized
DEBUG - 2012-01-31 22:20:58 --> Router Class Initialized
DEBUG - 2012-01-31 22:21:00 --> Output Class Initialized
DEBUG - 2012-01-31 22:21:00 --> Security Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Input Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:21:01 --> Language Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Loader Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:21:01 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Session Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:21:01 --> Session routines successfully run
DEBUG - 2012-01-31 22:21:01 --> Cart Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Model Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Model Class Initialized
DEBUG - 2012-01-31 22:21:01 --> Controller Class Initialized
DEBUG - 2012-01-31 22:21:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:21:01 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 22:21:01 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 13
ERROR - 2012-01-31 22:21:01 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 13
ERROR - 2012-01-31 22:21:01 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 13
ERROR - 2012-01-31 22:21:01 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 24
DEBUG - 2012-01-31 22:21:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:21:01 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:21:01 --> Final output sent to browser
DEBUG - 2012-01-31 22:21:01 --> Total execution time: 2.8658
DEBUG - 2012-01-31 22:21:02 --> Config Class Initialized
DEBUG - 2012-01-31 22:21:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:21:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:21:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:21:02 --> URI Class Initialized
DEBUG - 2012-01-31 22:21:02 --> Router Class Initialized
ERROR - 2012-01-31 22:21:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:25:20 --> Config Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:25:20 --> URI Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Router Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Output Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Security Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Input Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:25:20 --> Language Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Loader Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:25:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Session Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:25:20 --> Session routines successfully run
DEBUG - 2012-01-31 22:25:20 --> Cart Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Model Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Model Class Initialized
DEBUG - 2012-01-31 22:25:20 --> Controller Class Initialized
DEBUG - 2012-01-31 22:25:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:25:20 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 22:25:20 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 24
DEBUG - 2012-01-31 22:25:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:25:20 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:25:20 --> Final output sent to browser
DEBUG - 2012-01-31 22:25:20 --> Total execution time: 0.1925
DEBUG - 2012-01-31 22:25:21 --> Config Class Initialized
DEBUG - 2012-01-31 22:25:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:25:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:25:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:25:21 --> URI Class Initialized
DEBUG - 2012-01-31 22:25:21 --> Router Class Initialized
ERROR - 2012-01-31 22:25:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 22:26:20 --> Config Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:26:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:26:20 --> URI Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Router Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Output Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Security Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Input Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:26:20 --> Language Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Loader Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:26:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Session Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:26:20 --> Session routines successfully run
DEBUG - 2012-01-31 22:26:20 --> Cart Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:20 --> Controller Class Initialized
DEBUG - 2012-01-31 22:26:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:26:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:26:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:26:21 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:26:21 --> Final output sent to browser
DEBUG - 2012-01-31 22:26:21 --> Total execution time: 1.0100
DEBUG - 2012-01-31 22:26:25 --> Config Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:26:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:26:26 --> URI Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Router Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Output Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Security Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Input Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:26:26 --> Language Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Loader Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:26:26 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Session Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:26:26 --> Session routines successfully run
DEBUG - 2012-01-31 22:26:26 --> Cart Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:26 --> Controller Class Initialized
DEBUG - 2012-01-31 22:26:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:26:26 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 22:26:26 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 24
DEBUG - 2012-01-31 22:26:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:26:26 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:26:27 --> Final output sent to browser
DEBUG - 2012-01-31 22:26:27 --> Total execution time: 1.0844
DEBUG - 2012-01-31 22:26:32 --> Config Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:26:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:26:32 --> URI Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Router Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Output Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Security Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Input Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:26:32 --> Language Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Loader Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:26:32 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Session Class Initialized
DEBUG - 2012-01-31 22:26:32 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:26:32 --> Session routines successfully run
DEBUG - 2012-01-31 22:26:33 --> Cart Class Initialized
DEBUG - 2012-01-31 22:26:33 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:33 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:33 --> Controller Class Initialized
DEBUG - 2012-01-31 22:26:33 --> Pagination Class Initialized
DEBUG - 2012-01-31 22:26:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:26:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:26:33 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 22:26:33 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:26:33 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-31 22:26:33 --> Final output sent to browser
DEBUG - 2012-01-31 22:26:33 --> Total execution time: 1.0808
DEBUG - 2012-01-31 22:26:35 --> Config Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:26:35 --> URI Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Router Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Output Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Security Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Input Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:26:35 --> Language Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Loader Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:26:35 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Session Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:26:35 --> Session routines successfully run
DEBUG - 2012-01-31 22:26:35 --> Cart Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Model Class Initialized
DEBUG - 2012-01-31 22:26:35 --> Controller Class Initialized
DEBUG - 2012-01-31 22:26:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:26:35 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 22:26:35 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 24
DEBUG - 2012-01-31 22:26:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:26:35 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:26:35 --> Final output sent to browser
DEBUG - 2012-01-31 22:26:35 --> Total execution time: 0.5396
DEBUG - 2012-01-31 22:27:31 --> Config Class Initialized
DEBUG - 2012-01-31 22:27:31 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:27:31 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:27:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:27:31 --> URI Class Initialized
DEBUG - 2012-01-31 22:27:31 --> Router Class Initialized
DEBUG - 2012-01-31 22:27:31 --> Output Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Security Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Input Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:27:32 --> Language Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Loader Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:27:32 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Session Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:27:32 --> Session routines successfully run
DEBUG - 2012-01-31 22:27:32 --> Cart Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Model Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Model Class Initialized
DEBUG - 2012-01-31 22:27:32 --> Controller Class Initialized
DEBUG - 2012-01-31 22:27:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:27:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:27:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:27:32 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:27:32 --> Final output sent to browser
DEBUG - 2012-01-31 22:27:32 --> Total execution time: 0.4767
DEBUG - 2012-01-31 22:30:45 --> Config Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:30:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:30:45 --> URI Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Router Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Output Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Security Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Input Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:30:45 --> Language Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Loader Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:30:45 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Session Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:30:45 --> Session routines successfully run
DEBUG - 2012-01-31 22:30:45 --> Cart Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Model Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Model Class Initialized
DEBUG - 2012-01-31 22:30:45 --> Controller Class Initialized
DEBUG - 2012-01-31 22:30:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:30:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:30:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:30:45 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:30:45 --> Final output sent to browser
DEBUG - 2012-01-31 22:30:45 --> Total execution time: 0.2585
DEBUG - 2012-01-31 22:37:42 --> Config Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 22:37:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 22:37:42 --> URI Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Router Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Output Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Security Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Input Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 22:37:42 --> Language Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Loader Class Initialized
DEBUG - 2012-01-31 22:37:42 --> Helper loaded: url_helper
DEBUG - 2012-01-31 22:37:42 --> Database Driver Class Initialized
DEBUG - 2012-01-31 22:37:43 --> Session Class Initialized
DEBUG - 2012-01-31 22:37:43 --> Helper loaded: string_helper
DEBUG - 2012-01-31 22:37:43 --> Session routines successfully run
DEBUG - 2012-01-31 22:37:43 --> Cart Class Initialized
DEBUG - 2012-01-31 22:37:43 --> Model Class Initialized
DEBUG - 2012-01-31 22:37:43 --> Model Class Initialized
DEBUG - 2012-01-31 22:37:43 --> Controller Class Initialized
DEBUG - 2012-01-31 22:37:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 22:37:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 22:37:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 22:37:43 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 22:37:43 --> Final output sent to browser
DEBUG - 2012-01-31 22:37:43 --> Total execution time: 0.9960
DEBUG - 2012-01-31 23:01:01 --> Config Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:01:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:01:01 --> URI Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Router Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Output Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Security Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Input Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:01:01 --> Language Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Loader Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:01:01 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Session Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:01:01 --> Session routines successfully run
DEBUG - 2012-01-31 23:01:01 --> Cart Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:01 --> Controller Class Initialized
ERROR - 2012-01-31 23:01:01 --> Severity: Notice  --> Undefined variable: order A:\home\codeigniter.fool\www\application\controllers\admin\order.php 58
ERROR - 2012-01-31 23:01:02 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.fool\www\system\core\Exceptions.php:185) A:\home\codeigniter.fool\www\system\helpers\url_helper.php 546
DEBUG - 2012-01-31 23:01:40 --> Config Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:01:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:01:40 --> URI Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Router Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Output Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Security Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Input Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:01:40 --> Language Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Loader Class Initialized
DEBUG - 2012-01-31 23:01:40 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:01:40 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Session Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:01:41 --> Session routines successfully run
DEBUG - 2012-01-31 23:01:41 --> Cart Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Controller Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Config Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:01:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:01:41 --> URI Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Router Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Output Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Security Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Input Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:01:41 --> Language Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Loader Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:01:41 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Session Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:01:41 --> Session routines successfully run
DEBUG - 2012-01-31 23:01:41 --> Cart Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Controller Class Initialized
DEBUG - 2012-01-31 23:01:41 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:01:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:01:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:01:41 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:01:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:01:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:01:41 --> Final output sent to browser
DEBUG - 2012-01-31 23:01:41 --> Total execution time: 0.4751
DEBUG - 2012-01-31 23:01:54 --> Config Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:01:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:01:54 --> URI Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Router Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Output Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Security Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Input Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:01:54 --> Language Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Loader Class Initialized
DEBUG - 2012-01-31 23:01:54 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:01:55 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:01:55 --> Session Class Initialized
DEBUG - 2012-01-31 23:01:55 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:01:55 --> Session routines successfully run
DEBUG - 2012-01-31 23:01:55 --> Cart Class Initialized
DEBUG - 2012-01-31 23:01:55 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:55 --> Model Class Initialized
DEBUG - 2012-01-31 23:01:55 --> Controller Class Initialized
DEBUG - 2012-01-31 23:01:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:01:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:01:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:01:55 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 23:01:55 --> Final output sent to browser
DEBUG - 2012-01-31 23:01:55 --> Total execution time: 0.4824
DEBUG - 2012-01-31 23:02:00 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:00 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:00 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:00 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:00 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:01 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:01 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:01 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:01 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:01 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:01 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:01 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:01 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:02:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:02:01 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 23:02:01 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:01 --> Total execution time: 0.4459
DEBUG - 2012-01-31 23:02:04 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:04 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:04 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:04 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:04 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:04 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:02:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:04 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:02:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:02:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:02:05 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:05 --> Total execution time: 0.5913
DEBUG - 2012-01-31 23:02:07 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:07 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:07 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:07 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:07 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:07 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:07 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:02:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:02:07 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 23:02:07 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:07 --> Total execution time: 0.4776
DEBUG - 2012-01-31 23:02:11 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:11 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:11 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:11 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:12 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:12 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:12 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:12 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:12 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:12 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:13 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:13 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:13 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:13 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:13 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:13 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:02:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:02:13 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 23:02:13 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:13 --> Total execution time: 1.1328
DEBUG - 2012-01-31 23:02:17 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:17 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:17 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:17 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:17 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:17 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:02:18 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:18 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:18 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:18 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:18 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:18 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:02:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:18 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:02:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:02:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:02:18 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:18 --> Total execution time: 0.8202
DEBUG - 2012-01-31 23:02:21 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:21 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:21 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:21 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:21 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:21 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:21 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:22 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:02:22 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:22 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:22 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:22 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:22 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:02:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:22 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:02:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:02:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:02:22 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:22 --> Total execution time: 0.5353
DEBUG - 2012-01-31 23:02:23 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:23 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:23 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:23 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:23 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:23 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:23 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:24 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:24 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:02:24 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:24 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:24 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:24 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:24 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:24 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:02:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:24 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:02:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:02:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:02:24 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:24 --> Total execution time: 0.4797
DEBUG - 2012-01-31 23:02:25 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:25 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:25 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:25 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:25 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:26 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:26 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:26 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:26 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:26 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:26 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:02:26 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:26 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:26 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:26 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:26 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:26 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:02:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:26 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:02:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:02:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:02:26 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:26 --> Total execution time: 0.5674
DEBUG - 2012-01-31 23:02:33 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:33 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:33 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:33 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:33 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:33 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:33 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:02:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:33 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:02:33 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:02:33 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:02:33 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:33 --> Total execution time: 0.4946
DEBUG - 2012-01-31 23:02:39 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:39 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:39 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:39 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:39 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:39 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:39 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:02:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:40 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:02:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:02:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:02:40 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:40 --> Total execution time: 0.5663
DEBUG - 2012-01-31 23:02:42 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:42 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:42 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:42 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:42 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:42 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:42 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:02:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:02:42 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 23:02:42 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:42 --> Total execution time: 0.5090
DEBUG - 2012-01-31 23:02:48 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:48 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:48 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:48 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:48 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:48 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:48 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:48 --> XSS Filtering completed
DEBUG - 2012-01-31 23:02:48 --> XSS Filtering completed
DEBUG - 2012-01-31 23:02:48 --> XSS Filtering completed
DEBUG - 2012-01-31 23:02:49 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:49 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:49 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:02:49 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:49 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:49 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:49 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:49 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:49 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:02:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:49 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:02:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:02:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:02:49 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:49 --> Total execution time: 0.5065
DEBUG - 2012-01-31 23:02:54 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:54 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:54 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:54 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:54 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:54 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:54 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:02:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:02:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:54 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:02:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:02:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:02:54 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:54 --> Total execution time: 0.9371
DEBUG - 2012-01-31 23:02:57 --> Config Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:02:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:02:57 --> URI Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Router Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Output Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Security Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Input Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:02:57 --> Language Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Loader Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:02:57 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Session Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:02:57 --> Session routines successfully run
DEBUG - 2012-01-31 23:02:57 --> Cart Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Model Class Initialized
DEBUG - 2012-01-31 23:02:57 --> Controller Class Initialized
DEBUG - 2012-01-31 23:02:57 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:02:57 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:02:57 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:02:57 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:02:57 --> Final output sent to browser
DEBUG - 2012-01-31 23:02:57 --> Total execution time: 0.5039
DEBUG - 2012-01-31 23:03:03 --> Config Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:03:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:03:03 --> URI Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Router Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Output Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Security Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Input Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:03:03 --> Language Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Loader Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:03:03 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Session Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:03:03 --> Session routines successfully run
DEBUG - 2012-01-31 23:03:03 --> Cart Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Controller Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Config Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:03:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:03:03 --> URI Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Router Class Initialized
DEBUG - 2012-01-31 23:03:03 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:03:03 --> Output Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Security Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Input Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:03:03 --> Language Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Loader Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:03:03 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Session Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:03:03 --> Session routines successfully run
DEBUG - 2012-01-31 23:03:03 --> Cart Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Controller Class Initialized
DEBUG - 2012-01-31 23:03:03 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:03:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:03:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:03:04 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:03:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:03:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:03:04 --> Final output sent to browser
DEBUG - 2012-01-31 23:03:04 --> Total execution time: 0.4961
DEBUG - 2012-01-31 23:03:09 --> Config Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:03:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:03:09 --> URI Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Router Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Output Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Security Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Input Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:03:09 --> Language Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Loader Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:03:09 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Session Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:03:09 --> Session routines successfully run
DEBUG - 2012-01-31 23:03:09 --> Cart Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:09 --> Controller Class Initialized
DEBUG - 2012-01-31 23:03:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:03:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:03:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:03:09 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-31 23:03:09 --> Final output sent to browser
DEBUG - 2012-01-31 23:03:09 --> Total execution time: 0.4686
DEBUG - 2012-01-31 23:03:15 --> Config Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:03:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:03:15 --> URI Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Router Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Output Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Security Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Input Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:03:15 --> Language Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Loader Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:03:15 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Session Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:03:15 --> Session routines successfully run
DEBUG - 2012-01-31 23:03:15 --> Cart Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Controller Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Config Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:03:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:03:15 --> URI Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Router Class Initialized
DEBUG - 2012-01-31 23:03:15 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:03:15 --> Output Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Security Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Input Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:03:15 --> Language Class Initialized
DEBUG - 2012-01-31 23:03:15 --> Loader Class Initialized
DEBUG - 2012-01-31 23:03:16 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:03:16 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:03:16 --> Session Class Initialized
DEBUG - 2012-01-31 23:03:16 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:03:16 --> Session routines successfully run
DEBUG - 2012-01-31 23:03:16 --> Cart Class Initialized
DEBUG - 2012-01-31 23:03:16 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:16 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:16 --> Controller Class Initialized
DEBUG - 2012-01-31 23:03:16 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:03:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:03:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:03:16 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:03:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:03:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:03:16 --> Final output sent to browser
DEBUG - 2012-01-31 23:03:16 --> Total execution time: 0.5405
DEBUG - 2012-01-31 23:03:19 --> Config Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:03:19 --> URI Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Router Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Output Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Security Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Input Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:03:19 --> Language Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Loader Class Initialized
DEBUG - 2012-01-31 23:03:19 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:03:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:03:20 --> Session Class Initialized
DEBUG - 2012-01-31 23:03:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:03:20 --> Session routines successfully run
DEBUG - 2012-01-31 23:03:20 --> Cart Class Initialized
DEBUG - 2012-01-31 23:03:20 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:20 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:20 --> Controller Class Initialized
DEBUG - 2012-01-31 23:03:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:03:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:03:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:03:20 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:03:20 --> Final output sent to browser
DEBUG - 2012-01-31 23:03:20 --> Total execution time: 0.4051
DEBUG - 2012-01-31 23:03:22 --> Config Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:03:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:03:22 --> URI Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Router Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Output Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Security Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Input Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:03:22 --> Language Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Loader Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:03:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Session Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:03:22 --> Session routines successfully run
DEBUG - 2012-01-31 23:03:22 --> Cart Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:03:22 --> Controller Class Initialized
DEBUG - 2012-01-31 23:03:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:03:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:03:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:03:22 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:03:22 --> Final output sent to browser
DEBUG - 2012-01-31 23:03:22 --> Total execution time: 0.5003
DEBUG - 2012-01-31 23:04:03 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:03 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:03 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:03 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:04 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:04 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:04 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:04:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:04:04 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:04:04 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:04 --> Total execution time: 0.4407
DEBUG - 2012-01-31 23:04:04 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:04 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:04 --> Router Class Initialized
ERROR - 2012-01-31 23:04:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:06 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:06 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:06 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:06 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:07 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:07 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:07 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:04:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:04:07 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:04:07 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:07 --> Total execution time: 0.4359
DEBUG - 2012-01-31 23:04:07 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:07 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:07 --> Router Class Initialized
ERROR - 2012-01-31 23:04:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:08 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:08 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:08 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:08 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:08 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:08 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:08 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:04:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:04:08 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:04:08 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:09 --> Total execution time: 0.4510
DEBUG - 2012-01-31 23:04:09 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:09 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:09 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:09 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:09 --> Router Class Initialized
ERROR - 2012-01-31 23:04:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:11 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:11 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:11 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:11 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:11 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:11 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:11 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:11 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:12 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:12 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:12 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:04:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:04:12 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:04:12 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:12 --> Total execution time: 0.4780
DEBUG - 2012-01-31 23:04:12 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:12 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:12 --> Router Class Initialized
ERROR - 2012-01-31 23:04:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:19 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:19 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:19 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:19 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:19 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:19 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:19 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:20 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:20 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:20 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:04:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:04:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:20 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:04:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:04:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:04:20 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:20 --> Total execution time: 0.6103
DEBUG - 2012-01-31 23:04:20 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:20 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:20 --> Router Class Initialized
ERROR - 2012-01-31 23:04:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:21 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:22 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:22 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:22 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:22 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:04:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:04:22 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-31 23:04:22 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:22 --> Total execution time: 0.5395
DEBUG - 2012-01-31 23:04:22 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:22 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:22 --> Router Class Initialized
ERROR - 2012-01-31 23:04:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:25 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:25 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:25 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:25 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:25 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:25 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:25 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:26 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:26 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:26 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:26 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:26 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:26 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:27 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:27 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:27 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:27 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:04:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:04:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:27 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:04:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:04:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:04:27 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:27 --> Total execution time: 0.4936
DEBUG - 2012-01-31 23:04:27 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:27 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:27 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:27 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:27 --> Router Class Initialized
ERROR - 2012-01-31 23:04:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:32 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:32 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:32 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:32 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:32 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:32 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:32 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:04:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:04:32 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-31 23:04:32 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:32 --> Total execution time: 0.4489
DEBUG - 2012-01-31 23:04:33 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:33 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:33 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:33 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:33 --> Router Class Initialized
ERROR - 2012-01-31 23:04:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:39 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:39 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:39 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:39 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:39 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:39 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:39 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:39 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:40 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:40 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:40 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:40 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:04:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:04:40 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 23:04:40 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:40 --> Total execution time: 0.4375
DEBUG - 2012-01-31 23:04:40 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:40 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:40 --> Router Class Initialized
ERROR - 2012-01-31 23:04:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:43 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:43 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:43 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:44 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:44 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:44 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:44 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:44 --> XSS Filtering completed
DEBUG - 2012-01-31 23:04:44 --> XSS Filtering completed
DEBUG - 2012-01-31 23:04:44 --> XSS Filtering completed
DEBUG - 2012-01-31 23:04:44 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:44 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:44 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:45 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:04:45 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:45 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:45 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:45 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:45 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:45 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:04:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:04:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:45 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:04:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:04:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:04:45 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:45 --> Total execution time: 1.0487
DEBUG - 2012-01-31 23:04:46 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:46 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:46 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:46 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:46 --> Router Class Initialized
ERROR - 2012-01-31 23:04:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:49 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:49 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:49 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:49 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:49 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:50 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:50 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:50 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:50 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:50 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:04:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:04:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:50 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:04:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:04:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:04:50 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:50 --> Total execution time: 1.0119
DEBUG - 2012-01-31 23:04:51 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:51 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:51 --> Router Class Initialized
ERROR - 2012-01-31 23:04:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:04:53 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:53 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Router Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Output Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Security Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Input Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:04:53 --> Language Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Loader Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:04:53 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Session Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:04:53 --> Session routines successfully run
DEBUG - 2012-01-31 23:04:53 --> Cart Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Model Class Initialized
DEBUG - 2012-01-31 23:04:53 --> Controller Class Initialized
DEBUG - 2012-01-31 23:04:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:04:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:04:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:04:53 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:04:53 --> Final output sent to browser
DEBUG - 2012-01-31 23:04:53 --> Total execution time: 0.5023
DEBUG - 2012-01-31 23:04:54 --> Config Class Initialized
DEBUG - 2012-01-31 23:04:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:04:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:04:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:04:54 --> URI Class Initialized
DEBUG - 2012-01-31 23:04:54 --> Router Class Initialized
ERROR - 2012-01-31 23:04:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:05:10 --> Config Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:05:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:05:10 --> URI Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Router Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Output Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Security Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Input Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:05:10 --> Language Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Loader Class Initialized
DEBUG - 2012-01-31 23:05:10 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:05:10 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Session Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:05:11 --> Session routines successfully run
DEBUG - 2012-01-31 23:05:11 --> Cart Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Model Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Model Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Controller Class Initialized
DEBUG - 2012-01-31 23:05:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:05:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:05:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:05:11 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 23:05:11 --> Final output sent to browser
DEBUG - 2012-01-31 23:05:11 --> Total execution time: 0.4301
DEBUG - 2012-01-31 23:05:11 --> Config Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:05:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:05:11 --> URI Class Initialized
DEBUG - 2012-01-31 23:05:11 --> Router Class Initialized
ERROR - 2012-01-31 23:05:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:06:42 --> Config Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:06:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:06:42 --> URI Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Router Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Output Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Security Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Input Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:06:42 --> Language Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Loader Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:06:42 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Session Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:06:42 --> Session routines successfully run
DEBUG - 2012-01-31 23:06:42 --> Cart Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:06:42 --> Controller Class Initialized
DEBUG - 2012-01-31 23:06:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:06:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:06:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:06:43 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:06:43 --> Final output sent to browser
DEBUG - 2012-01-31 23:06:43 --> Total execution time: 0.4781
DEBUG - 2012-01-31 23:06:44 --> Config Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:06:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:06:44 --> URI Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Router Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Output Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Security Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Input Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:06:44 --> Language Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Loader Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:06:44 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Session Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:06:44 --> Session routines successfully run
DEBUG - 2012-01-31 23:06:44 --> Cart Class Initialized
DEBUG - 2012-01-31 23:06:44 --> Model Class Initialized
DEBUG - 2012-01-31 23:06:45 --> Model Class Initialized
DEBUG - 2012-01-31 23:06:45 --> Controller Class Initialized
DEBUG - 2012-01-31 23:06:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:06:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:06:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:06:45 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:06:45 --> Final output sent to browser
DEBUG - 2012-01-31 23:06:45 --> Total execution time: 0.4574
DEBUG - 2012-01-31 23:06:47 --> Config Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:06:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:06:47 --> URI Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Router Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Output Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Security Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Input Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:06:47 --> Language Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Loader Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:06:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Session Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:06:47 --> Session routines successfully run
DEBUG - 2012-01-31 23:06:47 --> Cart Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:06:47 --> Controller Class Initialized
DEBUG - 2012-01-31 23:06:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:06:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:06:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:06:47 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:06:47 --> Final output sent to browser
DEBUG - 2012-01-31 23:06:47 --> Total execution time: 0.5020
DEBUG - 2012-01-31 23:11:21 --> Config Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:11:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:11:21 --> URI Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Router Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Output Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Security Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Input Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:11:21 --> Language Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Loader Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:11:21 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Session Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:11:21 --> Session routines successfully run
DEBUG - 2012-01-31 23:11:21 --> Cart Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:11:21 --> Controller Class Initialized
DEBUG - 2012-01-31 23:11:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:11:21 --> File loaded: application/views//admin/blocks/sidebar.php
ERROR - 2012-01-31 23:11:21 --> Severity: Notice  --> Undefined property: stdClass::$count A:\home\codeigniter.fool\www\application\views\admin\order.php 24
DEBUG - 2012-01-31 23:11:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:11:21 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:11:21 --> Final output sent to browser
DEBUG - 2012-01-31 23:11:21 --> Total execution time: 0.4382
DEBUG - 2012-01-31 23:22:58 --> Config Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:22:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:22:58 --> URI Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Router Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Output Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Security Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Input Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:22:58 --> Language Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Loader Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:22:58 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Session Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:22:58 --> Session routines successfully run
DEBUG - 2012-01-31 23:22:58 --> Cart Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Model Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Model Class Initialized
DEBUG - 2012-01-31 23:22:58 --> Controller Class Initialized
DEBUG - 2012-01-31 23:22:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:22:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:22:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:22:58 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:22:58 --> Final output sent to browser
DEBUG - 2012-01-31 23:22:58 --> Total execution time: 0.4138
DEBUG - 2012-01-31 23:23:01 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:01 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:01 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:01 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:01 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:01 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:01 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:01 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:23:01 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:01 --> Total execution time: 0.4059
DEBUG - 2012-01-31 23:23:03 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:03 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:03 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:03 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:03 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:03 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:03 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:03 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:23:03 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:03 --> Total execution time: 0.4088
DEBUG - 2012-01-31 23:23:10 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:10 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:10 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:10 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:10 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:10 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:11 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:11 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:23:11 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:11 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:11 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:11 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:11 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:11 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:23:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:23:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:11 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:23:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:23:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:23:11 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:11 --> Total execution time: 0.4358
DEBUG - 2012-01-31 23:23:12 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:12 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:12 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:12 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:12 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:12 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:12 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:12 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:13 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:13 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:13 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:13 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:13 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:23:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:23:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:13 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:23:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:23:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:23:13 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:13 --> Total execution time: 0.4882
DEBUG - 2012-01-31 23:23:16 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:16 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:16 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:16 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:16 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:16 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:16 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:16 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:23:16 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:16 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:16 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:17 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:17 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:17 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:23:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:23:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:17 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:23:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:23:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:23:17 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:17 --> Total execution time: 0.7260
DEBUG - 2012-01-31 23:23:17 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:17 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:18 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:18 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:18 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:18 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:18 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:18 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:23:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:23:18 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-31 23:23:18 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:18 --> Total execution time: 0.4816
DEBUG - 2012-01-31 23:23:21 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:21 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:21 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:21 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:22 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:22 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:22 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:22 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:23:22 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:22 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:23 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:23 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:23 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:23 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:23 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:23 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:23 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:23 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:23:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:23:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:23 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:23:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:23:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:23:23 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:23 --> Total execution time: 0.4542
DEBUG - 2012-01-31 23:23:26 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:26 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:26 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:26 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:26 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:26 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:26 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:27 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:23:27 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:27 --> Total execution time: 0.7291
DEBUG - 2012-01-31 23:23:28 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:28 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:28 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:28 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:28 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:28 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:28 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:28 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:23:28 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:28 --> Total execution time: 0.4315
DEBUG - 2012-01-31 23:23:36 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:36 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:36 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:36 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:36 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:36 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:36 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:37 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:37 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:37 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:37 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:37 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:37 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:23:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:37 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:23:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:23:37 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:37 --> Total execution time: 0.4183
DEBUG - 2012-01-31 23:23:38 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:38 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:38 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:39 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:39 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:39 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:39 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:39 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:39 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:39 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:23:39 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:39 --> Total execution time: 0.4477
DEBUG - 2012-01-31 23:23:40 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:40 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:40 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:40 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:40 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:40 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:40 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:41 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:41 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:41 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:41 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:42 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:42 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:42 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:42 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:42 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:42 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:23:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:42 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:23:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:42 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:23:42 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:42 --> Total execution time: 1.0973
DEBUG - 2012-01-31 23:23:43 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:43 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:43 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:43 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:43 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:43 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:43 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:44 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:44 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:44 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:23:44 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:44 --> Total execution time: 0.4775
DEBUG - 2012-01-31 23:23:45 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:45 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:45 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:45 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:46 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:46 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:46 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:46 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:46 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:46 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:46 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:46 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:46 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Config Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:23:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:23:47 --> URI Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Router Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Output Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Security Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Input Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:23:47 --> Language Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Loader Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:23:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Session Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:23:47 --> Session routines successfully run
DEBUG - 2012-01-31 23:23:47 --> Cart Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Controller Class Initialized
DEBUG - 2012-01-31 23:23:47 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:23:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:23:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:23:48 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:23:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:23:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:23:48 --> Final output sent to browser
DEBUG - 2012-01-31 23:23:48 --> Total execution time: 0.9321
DEBUG - 2012-01-31 23:24:15 --> Config Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:24:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:24:15 --> URI Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Router Class Initialized
DEBUG - 2012-01-31 23:24:15 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:24:15 --> Output Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Security Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Input Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:24:15 --> Language Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Loader Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:24:15 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Session Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:24:15 --> Session routines successfully run
DEBUG - 2012-01-31 23:24:15 --> Cart Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Model Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Model Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Controller Class Initialized
DEBUG - 2012-01-31 23:24:15 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:24:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:24:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:24:15 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:24:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:24:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:24:16 --> Final output sent to browser
DEBUG - 2012-01-31 23:24:16 --> Total execution time: 0.4916
DEBUG - 2012-01-31 23:24:21 --> Config Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:24:21 --> URI Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Router Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Output Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Security Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Input Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:24:21 --> Language Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Loader Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:24:21 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Session Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:24:21 --> Session routines successfully run
DEBUG - 2012-01-31 23:24:21 --> Cart Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:24:21 --> Controller Class Initialized
DEBUG - 2012-01-31 23:24:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:24:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:24:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:24:21 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 23:24:21 --> Final output sent to browser
DEBUG - 2012-01-31 23:24:21 --> Total execution time: 0.4617
DEBUG - 2012-01-31 23:24:59 --> Config Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:24:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:24:59 --> URI Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Router Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Output Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Security Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Input Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:24:59 --> Language Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Loader Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:24:59 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Session Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:24:59 --> Session routines successfully run
DEBUG - 2012-01-31 23:24:59 --> Cart Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Model Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Model Class Initialized
DEBUG - 2012-01-31 23:24:59 --> Controller Class Initialized
DEBUG - 2012-01-31 23:24:59 --> XSS Filtering completed
DEBUG - 2012-01-31 23:24:59 --> XSS Filtering completed
DEBUG - 2012-01-31 23:24:59 --> XSS Filtering completed
DEBUG - 2012-01-31 23:25:00 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:00 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:00 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:25:00 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:00 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:00 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:00 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:00 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:00 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:00 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:25:00 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:00 --> Total execution time: 0.4403
DEBUG - 2012-01-31 23:25:04 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:04 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:04 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:04 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:04 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:05 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:05 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:05 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:05 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:05 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:25:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:05 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:25:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:25:05 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:25:05 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:05 --> Total execution time: 1.1978
DEBUG - 2012-01-31 23:25:08 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:08 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:08 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:08 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:08 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:08 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:08 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:25:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:25:08 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:25:08 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:08 --> Total execution time: 0.4077
DEBUG - 2012-01-31 23:25:33 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:33 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:33 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:33 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:33 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:33 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:33 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:33 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:25:33 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:33 --> Total execution time: 0.5836
DEBUG - 2012-01-31 23:25:35 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:35 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:35 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:35 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:35 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:35 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:35 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:36 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:36 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:25:36 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:36 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:36 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:36 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:36 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:36 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:36 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:25:36 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:36 --> Total execution time: 0.6059
DEBUG - 2012-01-31 23:25:39 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:39 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:39 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:39 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:39 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:39 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:39 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:39 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:25:40 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:40 --> Total execution time: 0.5249
DEBUG - 2012-01-31 23:25:41 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:41 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:41 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:42 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:42 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:42 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:42 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:42 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:42 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:42 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:25:42 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:42 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:42 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:42 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:42 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:42 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:42 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:25:42 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:42 --> Total execution time: 0.4438
DEBUG - 2012-01-31 23:25:44 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:44 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:44 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:44 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:44 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:44 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:44 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:44 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:44 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:25:44 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:44 --> Total execution time: 0.5319
DEBUG - 2012-01-31 23:25:47 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:47 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:47 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:47 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:47 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:47 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:47 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:25:47 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:47 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:47 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:47 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:47 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:47 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:47 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:25:47 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:47 --> Total execution time: 0.4464
DEBUG - 2012-01-31 23:25:49 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:49 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:49 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:49 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:49 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:50 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:50 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:50 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:50 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:50 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:50 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:50 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:50 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:25:50 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:50 --> Total execution time: 0.8676
DEBUG - 2012-01-31 23:25:52 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:52 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:52 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:52 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:52 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:52 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:52 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:52 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:52 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:25:52 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:52 --> Total execution time: 0.5067
DEBUG - 2012-01-31 23:25:54 --> Config Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:25:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:25:54 --> URI Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Router Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Output Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Security Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Input Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:25:54 --> Language Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Loader Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:25:54 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Session Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:25:54 --> Session routines successfully run
DEBUG - 2012-01-31 23:25:54 --> Cart Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Model Class Initialized
DEBUG - 2012-01-31 23:25:54 --> Controller Class Initialized
DEBUG - 2012-01-31 23:25:55 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:25:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:25:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:25:55 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:25:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:25:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:25:55 --> Final output sent to browser
DEBUG - 2012-01-31 23:25:55 --> Total execution time: 0.7540
DEBUG - 2012-01-31 23:26:01 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:01 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:01 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:01 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:02 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:02 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:02 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:02 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:26:02 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:02 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:02 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:02 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:02 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:26:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:26:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:02 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:26:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:26:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:26:02 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:02 --> Total execution time: 0.4321
DEBUG - 2012-01-31 23:26:04 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:04 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:04 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:04 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:04 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:04 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:04 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:05 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:05 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:26:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:26:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:05 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:26:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:26:05 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:26:05 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:05 --> Total execution time: 0.5060
DEBUG - 2012-01-31 23:26:07 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:07 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:07 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:07 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:07 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:07 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:07 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:08 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:08 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:08 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:08 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:08 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:26:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:26:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:08 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:26:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:26:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:26:08 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:08 --> Total execution time: 0.4997
DEBUG - 2012-01-31 23:26:10 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:10 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:10 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:10 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:10 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:10 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:10 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:11 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:11 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:26:11 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:11 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:11 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:11 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:11 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:11 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:26:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:26:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:11 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:26:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:26:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:26:11 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:11 --> Total execution time: 0.4188
DEBUG - 2012-01-31 23:26:15 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:16 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:16 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:16 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:16 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:16 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:16 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:26:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:26:16 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-31 23:26:16 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:16 --> Total execution time: 0.5266
DEBUG - 2012-01-31 23:26:39 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:39 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:39 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:39 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:39 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:39 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:39 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:40 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:40 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:26:40 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:40 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:40 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:40 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:40 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:40 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:26:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:26:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:40 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:26:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:26:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:26:40 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:40 --> Total execution time: 0.4428
DEBUG - 2012-01-31 23:26:45 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:45 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:45 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:45 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:45 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:45 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:45 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:26:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:26:45 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:26:45 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:45 --> Total execution time: 0.4791
DEBUG - 2012-01-31 23:26:47 --> Config Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:26:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:26:47 --> URI Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Router Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Output Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Security Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Input Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:26:47 --> Language Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Loader Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:26:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Session Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:26:47 --> Session routines successfully run
DEBUG - 2012-01-31 23:26:47 --> Cart Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:26:47 --> Controller Class Initialized
DEBUG - 2012-01-31 23:26:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:26:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:26:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:26:47 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:26:48 --> Final output sent to browser
DEBUG - 2012-01-31 23:26:48 --> Total execution time: 0.4506
DEBUG - 2012-01-31 23:27:13 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:13 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:13 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:13 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:13 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:13 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:13 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:14 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:14 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:14 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:14 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:14 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:14 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:27:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:27:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:27:15 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:27:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:27:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:27:15 --> Final output sent to browser
DEBUG - 2012-01-31 23:27:15 --> Total execution time: 0.4727
DEBUG - 2012-01-31 23:27:17 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:17 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:17 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:17 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:18 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:18 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:18 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:18 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:18 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:27:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:27:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:27:18 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:27:18 --> Final output sent to browser
DEBUG - 2012-01-31 23:27:18 --> Total execution time: 0.4762
DEBUG - 2012-01-31 23:27:21 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:21 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:21 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:21 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:21 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:21 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:21 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:22 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:22 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:22 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:22 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:22 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:22 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:27:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:27:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:27:22 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:27:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:27:22 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:27:22 --> Final output sent to browser
DEBUG - 2012-01-31 23:27:22 --> Total execution time: 0.4330
DEBUG - 2012-01-31 23:27:25 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:25 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:25 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:27:25 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:25 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:25 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:25 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:25 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:25 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:26 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:26 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:26 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:27:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:27:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:27:26 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:27:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:27:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:27:26 --> Final output sent to browser
DEBUG - 2012-01-31 23:27:26 --> Total execution time: 0.5009
DEBUG - 2012-01-31 23:27:36 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:36 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:36 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:36 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:36 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:36 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:36 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:27:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:27:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:27:36 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 23:27:36 --> Final output sent to browser
DEBUG - 2012-01-31 23:27:36 --> Total execution time: 0.4873
DEBUG - 2012-01-31 23:27:49 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:49 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:49 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:27:49 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:49 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:49 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:49 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:49 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:49 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:27:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:27:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:27:49 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:27:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:27:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:27:50 --> Final output sent to browser
DEBUG - 2012-01-31 23:27:50 --> Total execution time: 0.2998
DEBUG - 2012-01-31 23:27:50 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:50 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:50 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:50 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:50 --> Router Class Initialized
ERROR - 2012-01-31 23:27:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:27:51 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:51 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Router Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Output Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Security Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Input Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:27:51 --> Language Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Loader Class Initialized
DEBUG - 2012-01-31 23:27:51 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:27:51 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Session Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:27:52 --> Session routines successfully run
DEBUG - 2012-01-31 23:27:52 --> Cart Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Model Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Controller Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:27:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:27:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:27:52 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:27:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:27:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:27:52 --> Final output sent to browser
DEBUG - 2012-01-31 23:27:52 --> Total execution time: 0.1953
DEBUG - 2012-01-31 23:27:52 --> Config Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:27:52 --> URI Class Initialized
DEBUG - 2012-01-31 23:27:52 --> Router Class Initialized
ERROR - 2012-01-31 23:27:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:45:39 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:39 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Router Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Output Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Security Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Input Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:45:39 --> Language Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Loader Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:45:39 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Session Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:45:39 --> Session routines successfully run
DEBUG - 2012-01-31 23:45:39 --> Cart Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:39 --> Controller Class Initialized
DEBUG - 2012-01-31 23:45:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:45:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:45:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:45:39 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-31 23:45:39 --> Final output sent to browser
DEBUG - 2012-01-31 23:45:39 --> Total execution time: 0.2066
DEBUG - 2012-01-31 23:45:40 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:40 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Router Class Initialized
ERROR - 2012-01-31 23:45:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:45:40 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:40 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Router Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Output Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Security Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Input Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:45:40 --> Language Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Loader Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:45:40 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Session Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:45:40 --> Session routines successfully run
DEBUG - 2012-01-31 23:45:40 --> Cart Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:40 --> Controller Class Initialized
DEBUG - 2012-01-31 23:45:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:45:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:45:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:45:40 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-31 23:45:40 --> Final output sent to browser
DEBUG - 2012-01-31 23:45:40 --> Total execution time: 0.2572
DEBUG - 2012-01-31 23:45:41 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:41 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:41 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:41 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:41 --> Router Class Initialized
ERROR - 2012-01-31 23:45:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:45:43 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:43 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Router Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Output Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Security Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Input Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:45:43 --> Language Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Loader Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:45:43 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Session Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:45:43 --> Session routines successfully run
DEBUG - 2012-01-31 23:45:43 --> Cart Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Controller Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:45:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:45:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:45:43 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:45:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:45:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:45:43 --> Final output sent to browser
DEBUG - 2012-01-31 23:45:43 --> Total execution time: 0.2359
DEBUG - 2012-01-31 23:45:43 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:43 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:43 --> Router Class Initialized
ERROR - 2012-01-31 23:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:45:47 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:47 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Router Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Output Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Security Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Input Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:45:47 --> Language Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Loader Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:45:47 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Session Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:45:47 --> Session routines successfully run
DEBUG - 2012-01-31 23:45:47 --> Cart Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:47 --> Controller Class Initialized
DEBUG - 2012-01-31 23:45:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:45:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:45:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:45:47 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-31 23:45:47 --> Final output sent to browser
DEBUG - 2012-01-31 23:45:47 --> Total execution time: 0.1939
DEBUG - 2012-01-31 23:45:48 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:48 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:48 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:48 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:48 --> Router Class Initialized
ERROR - 2012-01-31 23:45:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:45:55 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:55 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Router Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Output Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Security Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Input Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:45:55 --> Language Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Loader Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:45:55 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Session Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:45:55 --> Session routines successfully run
DEBUG - 2012-01-31 23:45:55 --> Cart Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:55 --> Controller Class Initialized
DEBUG - 2012-01-31 23:45:55 --> XSS Filtering completed
DEBUG - 2012-01-31 23:45:55 --> XSS Filtering completed
DEBUG - 2012-01-31 23:45:55 --> XSS Filtering completed
DEBUG - 2012-01-31 23:45:56 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:56 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Router Class Initialized
DEBUG - 2012-01-31 23:45:56 --> No URI present. Default controller set.
DEBUG - 2012-01-31 23:45:56 --> Output Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Security Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Input Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:45:56 --> Language Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Loader Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:45:56 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Session Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:45:56 --> Session routines successfully run
DEBUG - 2012-01-31 23:45:56 --> Cart Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Controller Class Initialized
DEBUG - 2012-01-31 23:45:56 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:45:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:45:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:45:56 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:45:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:45:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-31 23:45:56 --> Final output sent to browser
DEBUG - 2012-01-31 23:45:56 --> Total execution time: 0.1708
DEBUG - 2012-01-31 23:45:57 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:57 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:57 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:57 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:57 --> Router Class Initialized
ERROR - 2012-01-31 23:45:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:45:59 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:59 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Router Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Output Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Security Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Input Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:45:59 --> Language Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Loader Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:45:59 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Session Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:45:59 --> Session routines successfully run
DEBUG - 2012-01-31 23:45:59 --> Cart Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Model Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Controller Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:45:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:45:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:45:59 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:45:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:45:59 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:45:59 --> Final output sent to browser
DEBUG - 2012-01-31 23:45:59 --> Total execution time: 0.2002
DEBUG - 2012-01-31 23:45:59 --> Config Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:45:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:45:59 --> URI Class Initialized
DEBUG - 2012-01-31 23:45:59 --> Router Class Initialized
ERROR - 2012-01-31 23:45:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:46:02 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:02 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:02 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:02 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:02 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:02 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:02 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:46:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:46:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:46:02 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:46:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:46:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:46:02 --> Final output sent to browser
DEBUG - 2012-01-31 23:46:03 --> Total execution time: 0.2174
DEBUG - 2012-01-31 23:46:03 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:03 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:03 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:03 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:03 --> Router Class Initialized
ERROR - 2012-01-31 23:46:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:46:04 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:04 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:04 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:04 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:04 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:04 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:04 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:04 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:04 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:05 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:05 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:05 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:46:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:46:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:46:05 --> File loaded: application/views/admin/order.php
DEBUG - 2012-01-31 23:46:05 --> Final output sent to browser
DEBUG - 2012-01-31 23:46:05 --> Total execution time: 0.2435
DEBUG - 2012-01-31 23:46:05 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:05 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:05 --> Router Class Initialized
ERROR - 2012-01-31 23:46:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:46:06 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:06 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:06 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:06 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:06 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:06 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:06 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:07 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:07 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:07 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:07 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:08 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:08 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:46:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:46:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:46:08 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:46:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:46:08 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-31 23:46:08 --> Final output sent to browser
DEBUG - 2012-01-31 23:46:08 --> Total execution time: 0.2202
DEBUG - 2012-01-31 23:46:08 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:08 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:08 --> Router Class Initialized
ERROR - 2012-01-31 23:46:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:46:09 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:09 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:09 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:09 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:09 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:09 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:09 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:10 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:10 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:10 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:10 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:46:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-31 23:46:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-31 23:46:10 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-31 23:46:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-31 23:46:10 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-31 23:46:10 --> Final output sent to browser
DEBUG - 2012-01-31 23:46:10 --> Total execution time: 0.1942
DEBUG - 2012-01-31 23:46:10 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:10 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:10 --> Router Class Initialized
ERROR - 2012-01-31 23:46:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:46:13 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:13 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:13 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:13 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:13 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:13 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:13 --> Pagination Class Initialized
DEBUG - 2012-01-31 23:46:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:46:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:46:13 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-31 23:46:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:46:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-31 23:46:13 --> Final output sent to browser
DEBUG - 2012-01-31 23:46:13 --> Total execution time: 0.2409
DEBUG - 2012-01-31 23:46:14 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:14 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:14 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:14 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:14 --> Router Class Initialized
ERROR - 2012-01-31 23:46:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:46:15 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:15 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:15 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:15 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:15 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:15 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:15 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:46:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:46:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:46:15 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 23:46:15 --> Final output sent to browser
DEBUG - 2012-01-31 23:46:15 --> Total execution time: 0.2173
DEBUG - 2012-01-31 23:46:16 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:16 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:16 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:16 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:16 --> Router Class Initialized
ERROR - 2012-01-31 23:46:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-31 23:46:19 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:19 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:19 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:19 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:19 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:19 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:19 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:20 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Router Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Output Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Security Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Input Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-31 23:46:20 --> Language Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Loader Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Helper loaded: url_helper
DEBUG - 2012-01-31 23:46:20 --> Database Driver Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Session Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Helper loaded: string_helper
DEBUG - 2012-01-31 23:46:20 --> Session routines successfully run
DEBUG - 2012-01-31 23:46:20 --> Cart Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Model Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Controller Class Initialized
DEBUG - 2012-01-31 23:46:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-31 23:46:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-31 23:46:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-31 23:46:20 --> File loaded: application/views/admin/product.php
DEBUG - 2012-01-31 23:46:20 --> Final output sent to browser
DEBUG - 2012-01-31 23:46:20 --> Total execution time: 0.1705
DEBUG - 2012-01-31 23:46:20 --> Config Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Hooks Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Utf8 Class Initialized
DEBUG - 2012-01-31 23:46:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-31 23:46:20 --> URI Class Initialized
DEBUG - 2012-01-31 23:46:20 --> Router Class Initialized
ERROR - 2012-01-31 23:46:20 --> 404 Page Not Found --> favicon.ico

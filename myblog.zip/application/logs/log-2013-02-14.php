<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-02-14 19:45:01 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:01 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:01 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Router Class Initialized
DEBUG - 2013-02-14 19:45:01 --> No URI present. Default controller set.
DEBUG - 2013-02-14 19:45:01 --> Output Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Security Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Input Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:45:01 --> Language Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Loader Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:45:01 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Session Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:45:01 --> A session cookie was not found.
DEBUG - 2013-02-14 19:45:01 --> Session routines successfully run
DEBUG - 2013-02-14 19:45:01 --> Model Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Model Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Controller Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Pagination Class Initialized
DEBUG - 2013-02-14 19:45:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-02-14 19:45:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-02-14 19:45:01 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2013-02-14 19:45:01 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2013-02-14 19:45:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-02-14 19:45:01 --> File loaded: application/views/user/home.php
DEBUG - 2013-02-14 19:45:01 --> Final output sent to browser
DEBUG - 2013-02-14 19:45:01 --> Total execution time: 0.4172
DEBUG - 2013-02-14 19:45:01 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:01 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:01 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Router Class Initialized
ERROR - 2013-02-14 19:45:01 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:45:01 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:01 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:01 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:01 --> Router Class Initialized
ERROR - 2013-02-14 19:45:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:45:04 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:04 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:04 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Router Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Output Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Security Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Input Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:45:04 --> Language Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Loader Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:45:04 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Session Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:45:04 --> A session cookie was not found.
DEBUG - 2013-02-14 19:45:04 --> Session routines successfully run
DEBUG - 2013-02-14 19:45:04 --> Model Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Model Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Controller Class Initialized
DEBUG - 2013-02-14 19:45:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-02-14 19:45:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-02-14 19:45:04 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2013-02-14 19:45:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-02-14 19:45:04 --> File loaded: application/views/user/article.php
DEBUG - 2013-02-14 19:45:04 --> Final output sent to browser
DEBUG - 2013-02-14 19:45:04 --> Total execution time: 0.3323
DEBUG - 2013-02-14 19:45:04 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:04 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:04 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:04 --> Router Class Initialized
ERROR - 2013-02-14 19:45:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:45:06 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:06 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:06 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:06 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:06 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:06 --> Router Class Initialized
DEBUG - 2013-02-14 19:45:06 --> Output Class Initialized
DEBUG - 2013-02-14 19:45:06 --> Security Class Initialized
DEBUG - 2013-02-14 19:45:06 --> Input Class Initialized
DEBUG - 2013-02-14 19:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:45:06 --> Language Class Initialized
DEBUG - 2013-02-14 19:45:07 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:07 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:07 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:07 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:07 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:07 --> Router Class Initialized
ERROR - 2013-02-14 19:45:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:45:10 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:10 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:10 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:10 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:10 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:10 --> Router Class Initialized
ERROR - 2013-02-14 19:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:45:14 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:14 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:14 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Router Class Initialized
DEBUG - 2013-02-14 19:45:14 --> No URI present. Default controller set.
DEBUG - 2013-02-14 19:45:14 --> Output Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Security Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Input Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:45:14 --> Language Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Loader Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:45:14 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Session Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:45:14 --> Session routines successfully run
DEBUG - 2013-02-14 19:45:14 --> Model Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Model Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Controller Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Pagination Class Initialized
DEBUG - 2013-02-14 19:45:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-02-14 19:45:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-02-14 19:45:14 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2013-02-14 19:45:14 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2013-02-14 19:45:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-02-14 19:45:14 --> File loaded: application/views/user/home.php
DEBUG - 2013-02-14 19:45:14 --> Final output sent to browser
DEBUG - 2013-02-14 19:45:14 --> Total execution time: 0.2797
DEBUG - 2013-02-14 19:45:14 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:14 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:14 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Router Class Initialized
ERROR - 2013-02-14 19:45:14 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:45:14 --> Config Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:45:14 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:45:14 --> URI Class Initialized
DEBUG - 2013-02-14 19:45:14 --> Router Class Initialized
ERROR - 2013-02-14 19:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:50:21 --> Config Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:50:21 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:50:21 --> URI Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Router Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Output Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Security Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Input Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:50:21 --> Language Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Config Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:50:21 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:50:21 --> URI Class Initialized
DEBUG - 2013-02-14 19:50:21 --> Router Class Initialized
ERROR - 2013-02-14 19:50:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:50:23 --> Config Class Initialized
DEBUG - 2013-02-14 19:50:23 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:50:23 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:50:23 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:50:23 --> URI Class Initialized
DEBUG - 2013-02-14 19:50:23 --> Router Class Initialized
ERROR - 2013-02-14 19:50:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:11 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:11 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:11 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:11 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:11 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:11 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:11 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:11 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:11 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:11 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:11 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:11 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:11 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:11 --> File loaded: application/views/admin/login.php
DEBUG - 2013-02-14 19:54:11 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:11 --> Total execution time: 0.1454
DEBUG - 2013-02-14 19:54:11 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:11 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:11 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:11 --> Router Class Initialized
ERROR - 2013-02-14 19:54:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:18 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:18 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:18 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:18 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:18 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:18 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:18 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:18 --> File loaded: application/views/admin/login.php
DEBUG - 2013-02-14 19:54:18 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:18 --> Total execution time: 0.2879
DEBUG - 2013-02-14 19:54:18 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:18 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:18 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:18 --> Router Class Initialized
ERROR - 2013-02-14 19:54:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:24 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:24 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:24 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:24 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:24 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:24 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:24 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:24 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:24 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:25 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:25 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:25 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:25 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Pagination Class Initialized
ERROR - 2013-02-14 19:54:25 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:25 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2013-02-14 19:54:25 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2013-02-14 19:54:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:25 --> File loaded: application/views/admin/home.php
DEBUG - 2013-02-14 19:54:25 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:25 --> Total execution time: 0.1891
DEBUG - 2013-02-14 19:54:25 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:25 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:25 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Router Class Initialized
ERROR - 2013-02-14 19:54:25 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:54:25 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:25 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:25 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:25 --> Router Class Initialized
ERROR - 2013-02-14 19:54:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:30 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:30 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:30 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:30 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:30 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:30 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:30 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Controller Class Initialized
ERROR - 2013-02-14 19:54:30 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:30 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-02-14 19:54:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:30 --> File loaded: application/views/admin/category.php
DEBUG - 2013-02-14 19:54:30 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:30 --> Total execution time: 0.3326
DEBUG - 2013-02-14 19:54:30 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:30 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:30 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:30 --> Router Class Initialized
ERROR - 2013-02-14 19:54:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:32 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:32 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:32 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:32 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:32 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:32 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:32 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Controller Class Initialized
ERROR - 2013-02-14 19:54:32 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:32 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-02-14 19:54:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:32 --> File loaded: application/views/admin/category.php
DEBUG - 2013-02-14 19:54:32 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:32 --> Total execution time: 0.3001
DEBUG - 2013-02-14 19:54:32 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:32 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:32 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:32 --> Router Class Initialized
ERROR - 2013-02-14 19:54:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:34 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:34 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:34 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:34 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:34 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:34 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:34 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Controller Class Initialized
ERROR - 2013-02-14 19:54:34 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:34 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-02-14 19:54:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:34 --> File loaded: application/views/admin/category.php
DEBUG - 2013-02-14 19:54:34 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:34 --> Total execution time: 0.3052
DEBUG - 2013-02-14 19:54:34 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:34 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:34 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Router Class Initialized
ERROR - 2013-02-14 19:54:34 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:54:34 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:34 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:34 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:34 --> Router Class Initialized
ERROR - 2013-02-14 19:54:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:35 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:35 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:35 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:35 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:35 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:35 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:35 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Controller Class Initialized
ERROR - 2013-02-14 19:54:35 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:35 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-02-14 19:54:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:35 --> File loaded: application/views/admin/category.php
DEBUG - 2013-02-14 19:54:35 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:35 --> Total execution time: 0.1970
DEBUG - 2013-02-14 19:54:35 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:35 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:35 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:35 --> Router Class Initialized
ERROR - 2013-02-14 19:54:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:38 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:38 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:38 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:38 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:38 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:38 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:38 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:38 --> Helper loaded: tinymce_helper
ERROR - 2013-02-14 19:54:38 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:38 --> File loaded: application/views/admin/page.php
DEBUG - 2013-02-14 19:54:38 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:38 --> Total execution time: 0.3328
DEBUG - 2013-02-14 19:54:39 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:39 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:39 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Router Class Initialized
ERROR - 2013-02-14 19:54:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:39 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:39 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:39 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Router Class Initialized
ERROR - 2013-02-14 19:54:39 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:54:39 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:39 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:39 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:39 --> Router Class Initialized
ERROR - 2013-02-14 19:54:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:47 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:47 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:47 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:47 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:47 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:47 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:47 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:47 --> Helper loaded: tinymce_helper
ERROR - 2013-02-14 19:54:47 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:47 --> File loaded: application/views/admin/page.php
DEBUG - 2013-02-14 19:54:47 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:47 --> Total execution time: 0.3950
DEBUG - 2013-02-14 19:54:48 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:48 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:48 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Router Class Initialized
ERROR - 2013-02-14 19:54:48 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:54:48 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:48 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:48 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Router Class Initialized
ERROR - 2013-02-14 19:54:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:48 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:48 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:48 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:48 --> Router Class Initialized
ERROR - 2013-02-14 19:54:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:50 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:50 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:50 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:50 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:50 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:50 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:50 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Helper loaded: tinymce_helper
ERROR - 2013-02-14 19:54:50 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-02-14 19:54:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-02-14 19:54:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-02-14 19:54:50 --> File loaded: application/views/admin/page.php
DEBUG - 2013-02-14 19:54:50 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:50 --> Total execution time: 0.3361
DEBUG - 2013-02-14 19:54:50 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:50 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:50 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:50 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:50 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:50 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:50 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:51 --> URI Class Initialized
ERROR - 2013-02-14 19:54:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:51 --> Router Class Initialized
ERROR - 2013-02-14 19:54:51 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:54:51 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:51 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:51 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:51 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:51 --> Router Class Initialized
ERROR - 2013-02-14 19:54:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:54:54 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:54 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:55 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Router Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Output Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Security Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Input Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:54:55 --> Language Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Loader Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:54:55 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Session Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:54:55 --> Session routines successfully run
DEBUG - 2013-02-14 19:54:55 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Model Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Controller Class Initialized
DEBUG - 2013-02-14 19:54:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-02-14 19:54:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-02-14 19:54:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-02-14 19:54:55 --> File loaded: application/views/user/page.php
DEBUG - 2013-02-14 19:54:55 --> Final output sent to browser
DEBUG - 2013-02-14 19:54:55 --> Total execution time: 0.3065
DEBUG - 2013-02-14 19:54:55 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:55 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Router Class Initialized
ERROR - 2013-02-14 19:54:55 --> 404 Page Not Found --> lessons
DEBUG - 2013-02-14 19:54:55 --> Config Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:54:55 --> URI Class Initialized
DEBUG - 2013-02-14 19:54:55 --> Router Class Initialized
ERROR - 2013-02-14 19:54:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:56:22 --> Config Class Initialized
DEBUG - 2013-02-14 19:56:22 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:56:22 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:56:22 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:56:22 --> URI Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Router Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Output Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Security Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Input Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:56:23 --> Language Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Loader Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:56:23 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Session Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:56:23 --> Session routines successfully run
DEBUG - 2013-02-14 19:56:23 --> Model Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Model Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Controller Class Initialized
DEBUG - 2013-02-14 19:56:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-02-14 19:56:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-02-14 19:56:23 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2013-02-14 19:56:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-02-14 19:56:23 --> File loaded: application/views/user/article.php
DEBUG - 2013-02-14 19:56:23 --> Final output sent to browser
DEBUG - 2013-02-14 19:56:23 --> Total execution time: 0.3026
DEBUG - 2013-02-14 19:56:23 --> Config Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:56:23 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:56:23 --> URI Class Initialized
DEBUG - 2013-02-14 19:56:23 --> Router Class Initialized
ERROR - 2013-02-14 19:56:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-02-14 19:56:35 --> Config Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:56:35 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:56:35 --> URI Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Router Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Output Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Security Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Input Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:56:35 --> Language Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Loader Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:56:35 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Session Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:56:35 --> Session routines successfully run
DEBUG - 2013-02-14 19:56:35 --> Model Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Model Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Controller Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Config Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:56:35 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:56:35 --> URI Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Router Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Output Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Security Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Input Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-02-14 19:56:35 --> Language Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Loader Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Helper loaded: url_helper
DEBUG - 2013-02-14 19:56:35 --> Database Driver Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Session Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Helper loaded: string_helper
DEBUG - 2013-02-14 19:56:35 --> Session routines successfully run
DEBUG - 2013-02-14 19:56:35 --> Model Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Model Class Initialized
DEBUG - 2013-02-14 19:56:35 --> Controller Class Initialized
DEBUG - 2013-02-14 19:56:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-02-14 19:56:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-02-14 19:56:35 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2013-02-14 19:56:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-02-14 19:56:35 --> File loaded: application/views/user/article.php
DEBUG - 2013-02-14 19:56:35 --> Final output sent to browser
DEBUG - 2013-02-14 19:56:35 --> Total execution time: 0.2300
DEBUG - 2013-02-14 19:56:36 --> Config Class Initialized
DEBUG - 2013-02-14 19:56:36 --> Hooks Class Initialized
DEBUG - 2013-02-14 19:56:36 --> Utf8 Class Initialized
DEBUG - 2013-02-14 19:56:36 --> UTF-8 Support Enabled
DEBUG - 2013-02-14 19:56:36 --> URI Class Initialized
DEBUG - 2013-02-14 19:56:36 --> Router Class Initialized
ERROR - 2013-02-14 19:56:36 --> 404 Page Not Found --> favicon.ico

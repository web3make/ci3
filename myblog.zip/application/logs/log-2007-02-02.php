<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-02-02 19:35:32 --> Config Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Hooks Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Utf8 Class Initialized
DEBUG - 2007-02-02 19:35:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-02 19:35:32 --> URI Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Router Class Initialized
DEBUG - 2007-02-02 19:35:32 --> No URI present. Default controller set.
DEBUG - 2007-02-02 19:35:32 --> Output Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Security Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Input Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-02 19:35:32 --> Language Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Loader Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Helper loaded: url_helper
DEBUG - 2007-02-02 19:35:32 --> Database Driver Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Session Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Helper loaded: string_helper
DEBUG - 2007-02-02 19:35:32 --> Session routines successfully run
DEBUG - 2007-02-02 19:35:32 --> Model Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Model Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Controller Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Pagination Class Initialized
DEBUG - 2007-02-02 19:35:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-02 19:35:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-02 19:35:32 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-02 19:35:32 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-02 19:35:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-02 19:35:32 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-02 19:35:32 --> Final output sent to browser
DEBUG - 2007-02-02 19:35:32 --> Total execution time: 0.2566
DEBUG - 2007-02-02 19:35:32 --> Config Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Hooks Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Utf8 Class Initialized
DEBUG - 2007-02-02 19:35:32 --> UTF-8 Support Enabled
DEBUG - 2007-02-02 19:35:32 --> URI Class Initialized
DEBUG - 2007-02-02 19:35:32 --> Router Class Initialized
ERROR - 2007-02-02 19:35:32 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-02 19:35:51 --> Config Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Hooks Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Utf8 Class Initialized
DEBUG - 2007-02-02 19:35:51 --> UTF-8 Support Enabled
DEBUG - 2007-02-02 19:35:51 --> URI Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Router Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Config Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Hooks Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Utf8 Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Output Class Initialized
DEBUG - 2007-02-02 19:35:51 --> UTF-8 Support Enabled
DEBUG - 2007-02-02 19:35:51 --> Security Class Initialized
DEBUG - 2007-02-02 19:35:51 --> URI Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Router Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Input Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-02 19:35:51 --> Language Class Initialized
ERROR - 2007-02-02 19:35:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-02 19:35:51 --> Loader Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Helper loaded: url_helper
DEBUG - 2007-02-02 19:35:51 --> Database Driver Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Session Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Helper loaded: string_helper
DEBUG - 2007-02-02 19:35:51 --> Session routines successfully run
DEBUG - 2007-02-02 19:35:51 --> Model Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Model Class Initialized
DEBUG - 2007-02-02 19:35:51 --> Controller Class Initialized
DEBUG - 2007-02-02 19:35:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-02 19:35:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-02 19:35:51 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-02-02 19:35:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-02 19:35:51 --> File loaded: application/views/user/article.php
DEBUG - 2007-02-02 19:35:51 --> Final output sent to browser
DEBUG - 2007-02-02 19:35:51 --> Total execution time: 0.2177
DEBUG - 2007-02-02 19:35:52 --> Config Class Initialized
DEBUG - 2007-02-02 19:35:52 --> Hooks Class Initialized
DEBUG - 2007-02-02 19:35:52 --> Utf8 Class Initialized
DEBUG - 2007-02-02 19:35:52 --> UTF-8 Support Enabled
DEBUG - 2007-02-02 19:35:52 --> URI Class Initialized
DEBUG - 2007-02-02 19:35:52 --> Router Class Initialized
ERROR - 2007-02-02 19:35:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-02 20:19:14 --> Config Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Hooks Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Utf8 Class Initialized
DEBUG - 2007-02-02 20:19:14 --> UTF-8 Support Enabled
DEBUG - 2007-02-02 20:19:14 --> URI Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Router Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Output Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Security Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Input Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-02 20:19:14 --> Language Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Loader Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Helper loaded: url_helper
DEBUG - 2007-02-02 20:19:14 --> Database Driver Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Session Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Helper loaded: string_helper
DEBUG - 2007-02-02 20:19:14 --> Session routines successfully run
DEBUG - 2007-02-02 20:19:14 --> Model Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Model Class Initialized
DEBUG - 2007-02-02 20:19:14 --> Controller Class Initialized
DEBUG - 2007-02-02 20:19:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-02 20:19:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-02 20:19:15 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-02-02 20:19:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-02 20:19:15 --> File loaded: application/views/user/article.php
DEBUG - 2007-02-02 20:19:15 --> Final output sent to browser
DEBUG - 2007-02-02 20:19:15 --> Total execution time: 0.1484
DEBUG - 2007-02-02 20:19:15 --> Config Class Initialized
DEBUG - 2007-02-02 20:19:15 --> Hooks Class Initialized
DEBUG - 2007-02-02 20:19:15 --> Utf8 Class Initialized
DEBUG - 2007-02-02 20:19:15 --> UTF-8 Support Enabled
DEBUG - 2007-02-02 20:19:15 --> URI Class Initialized
DEBUG - 2007-02-02 20:19:15 --> Router Class Initialized
ERROR - 2007-02-02 20:19:15 --> 404 Page Not Found --> favicon.ico

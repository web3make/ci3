<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-02-21 20:03:36 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:36 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Router Class Initialized
DEBUG - 2011-02-21 20:03:36 --> No URI present. Default controller set.
DEBUG - 2011-02-21 20:03:36 --> Output Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Security Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Input Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:03:36 --> Language Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Loader Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:03:36 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Session Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:03:36 --> A session cookie was not found.
DEBUG - 2011-02-21 20:03:36 --> Session routines successfully run
DEBUG - 2011-02-21 20:03:36 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Controller Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Pagination Class Initialized
DEBUG - 2011-02-21 20:03:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2011-02-21 20:03:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2011-02-21 20:03:36 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2011-02-21 20:03:36 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2011-02-21 20:03:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2011-02-21 20:03:36 --> File loaded: application/views/user/home.php
DEBUG - 2011-02-21 20:03:36 --> Final output sent to browser
DEBUG - 2011-02-21 20:03:36 --> Total execution time: 0.3317
DEBUG - 2011-02-21 20:03:36 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:36 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:36 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:37 --> Router Class Initialized
ERROR - 2011-02-21 20:03:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:03:37 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:37 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:37 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:37 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:37 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:37 --> Router Class Initialized
ERROR - 2011-02-21 20:03:37 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:03:42 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:42 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:42 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:42 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:42 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:42 --> Router Class Initialized
DEBUG - 2011-02-21 20:03:42 --> Output Class Initialized
DEBUG - 2011-02-21 20:03:42 --> Security Class Initialized
DEBUG - 2011-02-21 20:03:42 --> Input Class Initialized
DEBUG - 2011-02-21 20:03:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:03:42 --> Language Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Loader Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:03:43 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Session Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:03:43 --> A session cookie was not found.
DEBUG - 2011-02-21 20:03:43 --> Session routines successfully run
DEBUG - 2011-02-21 20:03:43 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Controller Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:43 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Router Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Output Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Security Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Input Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:03:43 --> Language Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Loader Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:03:43 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Session Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:03:43 --> Session routines successfully run
DEBUG - 2011-02-21 20:03:43 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Controller Class Initialized
DEBUG - 2011-02-21 20:03:43 --> File loaded: application/views/admin/login.php
DEBUG - 2011-02-21 20:03:43 --> Final output sent to browser
DEBUG - 2011-02-21 20:03:43 --> Total execution time: 0.1240
DEBUG - 2011-02-21 20:03:43 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:43 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:43 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:43 --> Router Class Initialized
ERROR - 2011-02-21 20:03:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:03:54 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:54 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Router Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Output Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Security Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Input Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:03:54 --> Language Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Loader Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:03:54 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Session Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:03:54 --> Session routines successfully run
DEBUG - 2011-02-21 20:03:54 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Controller Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:54 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Router Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Output Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Security Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Input Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:03:54 --> Language Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Loader Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:03:54 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Session Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:03:54 --> Session routines successfully run
DEBUG - 2011-02-21 20:03:54 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Model Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Controller Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Pagination Class Initialized
ERROR - 2011-02-21 20:03:54 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:03:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:03:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:03:54 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2011-02-21 20:03:54 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2011-02-21 20:03:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:03:54 --> File loaded: application/views/admin/home.php
DEBUG - 2011-02-21 20:03:54 --> Final output sent to browser
DEBUG - 2011-02-21 20:03:54 --> Total execution time: 0.1645
DEBUG - 2011-02-21 20:03:54 --> Config Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:03:54 --> URI Class Initialized
DEBUG - 2011-02-21 20:03:54 --> Router Class Initialized
ERROR - 2011-02-21 20:03:54 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:04:05 --> Config Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:04:05 --> URI Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Router Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Output Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Security Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Input Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:04:05 --> Language Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Loader Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:04:05 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Session Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:04:05 --> Session routines successfully run
DEBUG - 2011-02-21 20:04:05 --> Model Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Model Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Controller Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:04:05 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:04:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:04:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:04:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:04:05 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:04:05 --> Final output sent to browser
DEBUG - 2011-02-21 20:04:05 --> Total execution time: 0.1676
DEBUG - 2011-02-21 20:04:05 --> Config Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:04:05 --> URI Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Router Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Output Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Config Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Security Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:04:05 --> Input Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:04:05 --> URI Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Language Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Router Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Loader Class Initialized
ERROR - 2011-02-21 20:04:05 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:04:05 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:04:05 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Session Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:04:05 --> Session routines successfully run
DEBUG - 2011-02-21 20:04:05 --> Model Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Model Class Initialized
DEBUG - 2011-02-21 20:04:05 --> Controller Class Initialized
ERROR - 2011-02-21 20:04:05 --> 404 Page Not Found --> page/css
DEBUG - 2011-02-21 20:04:33 --> Config Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:04:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:04:33 --> URI Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Router Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Output Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Security Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Input Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:04:33 --> Language Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Loader Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Config Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:04:33 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:04:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:04:33 --> URI Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Router Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Database Driver Class Initialized
ERROR - 2011-02-21 20:04:33 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:04:33 --> Session Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:04:33 --> Session routines successfully run
DEBUG - 2011-02-21 20:04:33 --> Model Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Model Class Initialized
DEBUG - 2011-02-21 20:04:33 --> Controller Class Initialized
ERROR - 2011-02-21 20:04:33 --> 404 Page Not Found --> page/css
DEBUG - 2011-02-21 20:06:03 --> Config Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:06:03 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:06:03 --> URI Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Router Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Output Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Security Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Input Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:06:03 --> Language Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Loader Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:06:03 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Session Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:06:03 --> Session routines successfully run
DEBUG - 2011-02-21 20:06:03 --> Model Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Model Class Initialized
DEBUG - 2011-02-21 20:06:03 --> Controller Class Initialized
ERROR - 2011-02-21 20:06:03 --> 404 Page Not Found --> page/lists
DEBUG - 2011-02-21 20:06:33 --> Config Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:06:33 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:06:33 --> URI Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Router Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Output Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Security Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Input Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:06:33 --> Language Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Loader Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:06:33 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Session Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:06:33 --> Session routines successfully run
DEBUG - 2011-02-21 20:06:33 --> Model Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Model Class Initialized
DEBUG - 2011-02-21 20:06:33 --> Controller Class Initialized
ERROR - 2011-02-21 20:06:33 --> 404 Page Not Found --> page/lists
DEBUG - 2011-02-21 20:10:20 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:20 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Router Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Output Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Security Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Input Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:10:20 --> Language Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Loader Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:10:20 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Session Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:10:20 --> Session routines successfully run
DEBUG - 2011-02-21 20:10:20 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Controller Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:10:20 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:10:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:10:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:10:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:10:20 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:10:20 --> Final output sent to browser
DEBUG - 2011-02-21 20:10:20 --> Total execution time: 0.1579
DEBUG - 2011-02-21 20:10:20 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:20 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Router Class Initialized
ERROR - 2011-02-21 20:10:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:10:20 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:20 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:20 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:20 --> Router Class Initialized
ERROR - 2011-02-21 20:10:20 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:10:21 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:21 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:21 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Router Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Output Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Security Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Input Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:10:21 --> Language Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Loader Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:10:21 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Session Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:10:21 --> Session routines successfully run
DEBUG - 2011-02-21 20:10:21 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Controller Class Initialized
DEBUG - 2011-02-21 20:10:21 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:10:21 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:10:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:10:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:10:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:10:21 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:10:21 --> Final output sent to browser
DEBUG - 2011-02-21 20:10:21 --> Total execution time: 0.1598
DEBUG - 2011-02-21 20:10:22 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:22 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:22 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:22 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:22 --> Router Class Initialized
ERROR - 2011-02-21 20:10:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:10:22 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:22 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:22 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:22 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:22 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:22 --> Router Class Initialized
ERROR - 2011-02-21 20:10:22 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:10:23 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:23 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Router Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Output Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Security Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Input Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:10:23 --> Language Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Loader Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:10:23 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Session Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:10:23 --> Session routines successfully run
DEBUG - 2011-02-21 20:10:23 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Controller Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:10:23 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:10:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:10:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:10:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:10:23 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:10:23 --> Final output sent to browser
DEBUG - 2011-02-21 20:10:23 --> Total execution time: 0.1443
DEBUG - 2011-02-21 20:10:23 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:23 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Router Class Initialized
ERROR - 2011-02-21 20:10:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:10:23 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:23 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:23 --> Router Class Initialized
ERROR - 2011-02-21 20:10:23 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:10:24 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:24 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Router Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Output Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Security Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Input Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:10:24 --> Language Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Loader Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:10:24 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Session Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:10:24 --> Session routines successfully run
DEBUG - 2011-02-21 20:10:24 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Controller Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:10:24 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:10:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:10:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:10:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:10:24 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:10:24 --> Final output sent to browser
DEBUG - 2011-02-21 20:10:24 --> Total execution time: 0.1510
DEBUG - 2011-02-21 20:10:24 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:24 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Router Class Initialized
ERROR - 2011-02-21 20:10:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:10:24 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:24 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:24 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:24 --> Router Class Initialized
ERROR - 2011-02-21 20:10:24 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:10:25 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:25 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Router Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Output Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Security Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Input Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:10:25 --> Language Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Loader Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:10:25 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Session Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:10:25 --> Session routines successfully run
DEBUG - 2011-02-21 20:10:25 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Controller Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:10:25 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:10:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:10:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:10:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:10:25 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:10:25 --> Final output sent to browser
DEBUG - 2011-02-21 20:10:25 --> Total execution time: 0.1526
DEBUG - 2011-02-21 20:10:25 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:25 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Router Class Initialized
ERROR - 2011-02-21 20:10:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:10:25 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:25 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:25 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:25 --> Router Class Initialized
ERROR - 2011-02-21 20:10:25 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:10:26 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:26 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Router Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Output Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Security Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Input Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:10:26 --> Language Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Loader Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:10:26 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Session Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:10:26 --> Session routines successfully run
DEBUG - 2011-02-21 20:10:26 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Controller Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:10:26 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:10:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:10:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:10:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:10:26 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:10:26 --> Final output sent to browser
DEBUG - 2011-02-21 20:10:26 --> Total execution time: 0.1522
DEBUG - 2011-02-21 20:10:26 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:26 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Router Class Initialized
ERROR - 2011-02-21 20:10:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:10:26 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:26 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:26 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:26 --> Router Class Initialized
ERROR - 2011-02-21 20:10:26 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:10:27 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:27 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Router Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Output Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Security Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Input Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:10:27 --> Language Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Loader Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:10:27 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Session Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:10:27 --> Session routines successfully run
DEBUG - 2011-02-21 20:10:27 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Model Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Controller Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:10:27 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:10:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:10:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:10:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:10:27 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:10:27 --> Final output sent to browser
DEBUG - 2011-02-21 20:10:27 --> Total execution time: 0.1497
DEBUG - 2011-02-21 20:10:27 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:27 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Router Class Initialized
ERROR - 2011-02-21 20:10:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:10:27 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:27 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:27 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:27 --> Router Class Initialized
ERROR - 2011-02-21 20:10:27 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:10:36 --> Config Class Initialized
DEBUG - 2011-02-21 20:10:36 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:10:36 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:10:36 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:10:36 --> URI Class Initialized
DEBUG - 2011-02-21 20:10:36 --> Router Class Initialized
ERROR - 2011-02-21 20:10:36 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:13:10 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:10 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Router Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Output Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Security Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Input Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:13:10 --> Language Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Loader Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:13:10 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Session Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:13:10 --> Session routines successfully run
DEBUG - 2011-02-21 20:13:10 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Controller Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:13:10 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:13:10 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:13:10 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:13:10 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:13:10 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:13:10 --> Final output sent to browser
DEBUG - 2011-02-21 20:13:10 --> Total execution time: 0.1546
DEBUG - 2011-02-21 20:13:10 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:10 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Router Class Initialized
ERROR - 2011-02-21 20:13:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:13:10 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:10 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:10 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:10 --> Router Class Initialized
ERROR - 2011-02-21 20:13:10 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:13:11 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:11 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Router Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Output Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Security Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Input Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:13:11 --> Language Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Loader Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:13:11 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Session Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:13:11 --> Session routines successfully run
DEBUG - 2011-02-21 20:13:11 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Controller Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:13:11 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:13:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:13:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:13:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:13:11 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:13:11 --> Final output sent to browser
DEBUG - 2011-02-21 20:13:11 --> Total execution time: 0.1417
DEBUG - 2011-02-21 20:13:11 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:11 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Router Class Initialized
ERROR - 2011-02-21 20:13:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:13:11 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:11 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:11 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:11 --> Router Class Initialized
ERROR - 2011-02-21 20:13:11 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:13:12 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:12 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Router Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Output Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Security Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Input Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:13:12 --> Language Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Loader Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:13:12 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Session Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:13:12 --> Session routines successfully run
DEBUG - 2011-02-21 20:13:12 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Controller Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Helper loaded: tinymce_helper
ERROR - 2011-02-21 20:13:12 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2011-02-21 20:13:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2011-02-21 20:13:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2011-02-21 20:13:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2011-02-21 20:13:12 --> File loaded: application/views/admin/page.php
DEBUG - 2011-02-21 20:13:12 --> Final output sent to browser
DEBUG - 2011-02-21 20:13:12 --> Total execution time: 0.1493
DEBUG - 2011-02-21 20:13:12 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:12 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Router Class Initialized
ERROR - 2011-02-21 20:13:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-02-21 20:13:12 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:12 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:12 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:12 --> Router Class Initialized
ERROR - 2011-02-21 20:13:12 --> 404 Page Not Found --> lessons
DEBUG - 2011-02-21 20:13:23 --> Config Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Hooks Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Utf8 Class Initialized
DEBUG - 2011-02-21 20:13:23 --> UTF-8 Support Enabled
DEBUG - 2011-02-21 20:13:23 --> URI Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Router Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Output Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Security Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Input Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-02-21 20:13:23 --> Language Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Loader Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Helper loaded: url_helper
DEBUG - 2011-02-21 20:13:23 --> Database Driver Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Session Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Helper loaded: string_helper
DEBUG - 2011-02-21 20:13:23 --> Session routines successfully run
DEBUG - 2011-02-21 20:13:23 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Model Class Initialized
DEBUG - 2011-02-21 20:13:23 --> Controller Class Initialized
ERROR - 2011-02-21 20:13:23 --> 404 Page Not Found --> page/lists

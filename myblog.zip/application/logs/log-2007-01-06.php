<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-01-06 23:12:32 --> Config Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Hooks Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Utf8 Class Initialized
DEBUG - 2007-01-06 23:12:32 --> UTF-8 Support Enabled
DEBUG - 2007-01-06 23:12:32 --> URI Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Router Class Initialized
DEBUG - 2007-01-06 23:12:32 --> No URI present. Default controller set.
DEBUG - 2007-01-06 23:12:32 --> Output Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Security Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Input Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-06 23:12:32 --> Language Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Loader Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Helper loaded: url_helper
DEBUG - 2007-01-06 23:12:32 --> Database Driver Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Session Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Helper loaded: string_helper
DEBUG - 2007-01-06 23:12:32 --> A session cookie was not found.
DEBUG - 2007-01-06 23:12:32 --> Session routines successfully run
DEBUG - 2007-01-06 23:12:32 --> Model Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Model Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Controller Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Pagination Class Initialized
DEBUG - 2007-01-06 23:12:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-06 23:12:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-06 23:12:32 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-01-06 23:12:32 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-01-06 23:12:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-06 23:12:32 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-06 23:12:32 --> Final output sent to browser
DEBUG - 2007-01-06 23:12:32 --> Total execution time: 0.3554
DEBUG - 2007-01-06 23:12:32 --> Config Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Hooks Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Utf8 Class Initialized
DEBUG - 2007-01-06 23:12:32 --> UTF-8 Support Enabled
DEBUG - 2007-01-06 23:12:32 --> URI Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Router Class Initialized
ERROR - 2007-01-06 23:12:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-06 23:12:32 --> Config Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Hooks Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Utf8 Class Initialized
DEBUG - 2007-01-06 23:12:32 --> UTF-8 Support Enabled
DEBUG - 2007-01-06 23:12:32 --> URI Class Initialized
DEBUG - 2007-01-06 23:12:32 --> Router Class Initialized
ERROR - 2007-01-06 23:12:32 --> 404 Page Not Found --> lessons

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-02-11 14:25:21 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:21 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:21 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:21 --> No URI present. Default controller set.
DEBUG - 2007-02-11 14:25:21 --> Output Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Security Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Input Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 14:25:21 --> Language Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Loader Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Helper loaded: url_helper
DEBUG - 2007-02-11 14:25:21 --> Database Driver Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Session Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Helper loaded: string_helper
DEBUG - 2007-02-11 14:25:21 --> Session routines successfully run
DEBUG - 2007-02-11 14:25:21 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Controller Class Initialized
DEBUG - 2007-02-11 14:25:21 --> Pagination Class Initialized
DEBUG - 2007-02-11 14:25:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-11 14:25:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-11 14:25:22 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-11 14:25:22 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-11 14:25:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-11 14:25:22 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-11 14:25:22 --> Final output sent to browser
DEBUG - 2007-02-11 14:25:22 --> Total execution time: 0.3479
DEBUG - 2007-02-11 14:25:22 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:22 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:22 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:22 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:22 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:22 --> Router Class Initialized
ERROR - 2007-02-11 14:25:22 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-11 14:25:28 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:28 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Output Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Security Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Input Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 14:25:28 --> Language Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Loader Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Helper loaded: url_helper
DEBUG - 2007-02-11 14:25:28 --> Database Driver Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Session Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Helper loaded: string_helper
DEBUG - 2007-02-11 14:25:28 --> Session routines successfully run
DEBUG - 2007-02-11 14:25:28 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Controller Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:28 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Output Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Security Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Input Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 14:25:28 --> Language Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Loader Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Helper loaded: url_helper
DEBUG - 2007-02-11 14:25:28 --> Database Driver Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Session Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Helper loaded: string_helper
DEBUG - 2007-02-11 14:25:28 --> Session routines successfully run
DEBUG - 2007-02-11 14:25:28 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Controller Class Initialized
DEBUG - 2007-02-11 14:25:28 --> File loaded: application/views/admin/login.php
DEBUG - 2007-02-11 14:25:28 --> Final output sent to browser
DEBUG - 2007-02-11 14:25:28 --> Total execution time: 0.1316
DEBUG - 2007-02-11 14:25:28 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:28 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:28 --> Router Class Initialized
ERROR - 2007-02-11 14:25:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 14:25:39 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:39 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:39 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Output Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Security Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Input Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 14:25:39 --> Language Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Loader Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Helper loaded: url_helper
DEBUG - 2007-02-11 14:25:39 --> Database Driver Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Session Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Helper loaded: string_helper
DEBUG - 2007-02-11 14:25:39 --> Session routines successfully run
DEBUG - 2007-02-11 14:25:39 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Controller Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:39 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:39 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Output Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Security Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Input Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 14:25:39 --> Language Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Loader Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Helper loaded: url_helper
DEBUG - 2007-02-11 14:25:39 --> Database Driver Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Session Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Helper loaded: string_helper
DEBUG - 2007-02-11 14:25:39 --> Session routines successfully run
DEBUG - 2007-02-11 14:25:39 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Controller Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Pagination Class Initialized
ERROR - 2007-02-11 14:25:39 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-11 14:25:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-11 14:25:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-11 14:25:39 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-11 14:25:39 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-11 14:25:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-11 14:25:39 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-11 14:25:39 --> Final output sent to browser
DEBUG - 2007-02-11 14:25:39 --> Total execution time: 0.1803
DEBUG - 2007-02-11 14:25:39 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:39 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:39 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:39 --> Router Class Initialized
ERROR - 2007-02-11 14:25:39 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-11 14:25:44 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:44 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:44 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Output Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Security Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Input Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 14:25:44 --> Language Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Loader Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:44 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:44 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Helper loaded: url_helper
ERROR - 2007-02-11 14:25:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 14:25:44 --> Database Driver Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Session Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Helper loaded: string_helper
DEBUG - 2007-02-11 14:25:44 --> Session routines successfully run
DEBUG - 2007-02-11 14:25:44 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Controller Class Initialized
DEBUG - 2007-02-11 14:25:44 --> Helper loaded: tinymce_helper
ERROR - 2007-02-11 14:25:44 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-11 14:25:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-11 14:25:44 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-11 14:25:44 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-11 14:25:44 --> File loaded: application/views/admin/article.php
DEBUG - 2007-02-11 14:25:44 --> Final output sent to browser
DEBUG - 2007-02-11 14:25:44 --> Total execution time: 0.2557
DEBUG - 2007-02-11 14:25:45 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:45 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:45 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:45 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:45 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:45 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:45 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Router Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Output Class Initialized
ERROR - 2007-02-11 14:25:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 14:25:45 --> Security Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Input Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 14:25:45 --> Language Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Loader Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Helper loaded: url_helper
DEBUG - 2007-02-11 14:25:45 --> Config Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Hooks Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Utf8 Class Initialized
DEBUG - 2007-02-11 14:25:45 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 14:25:45 --> URI Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Database Driver Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Router Class Initialized
ERROR - 2007-02-11 14:25:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 14:25:45 --> Session Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Helper loaded: string_helper
DEBUG - 2007-02-11 14:25:45 --> Session routines successfully run
DEBUG - 2007-02-11 14:25:45 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Model Class Initialized
DEBUG - 2007-02-11 14:25:45 --> Controller Class Initialized
ERROR - 2007-02-11 14:25:45 --> 404 Page Not Found --> article/css
DEBUG - 2007-02-11 15:08:24 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:24 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:24 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Router Class Initialized
DEBUG - 2007-02-11 15:08:24 --> No URI present. Default controller set.
DEBUG - 2007-02-11 15:08:24 --> Output Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Security Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Input Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 15:08:24 --> Language Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Loader Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Helper loaded: url_helper
DEBUG - 2007-02-11 15:08:24 --> Database Driver Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Session Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Helper loaded: string_helper
DEBUG - 2007-02-11 15:08:24 --> Session routines successfully run
DEBUG - 2007-02-11 15:08:24 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Controller Class Initialized
DEBUG - 2007-02-11 15:08:24 --> Pagination Class Initialized
DEBUG - 2007-02-11 15:08:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-11 15:08:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-11 15:08:24 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-11 15:08:24 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-11 15:08:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-11 15:08:24 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-11 15:08:24 --> Final output sent to browser
DEBUG - 2007-02-11 15:08:24 --> Total execution time: 0.1766
DEBUG - 2007-02-11 15:08:25 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:25 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:25 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:25 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:25 --> Router Class Initialized
ERROR - 2007-02-11 15:08:25 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-11 15:08:29 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:29 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:29 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Router Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Output Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Security Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Input Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 15:08:29 --> Language Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Loader Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Helper loaded: url_helper
DEBUG - 2007-02-11 15:08:29 --> Database Driver Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Session Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Helper loaded: string_helper
DEBUG - 2007-02-11 15:08:29 --> Session routines successfully run
DEBUG - 2007-02-11 15:08:29 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Controller Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Pagination Class Initialized
ERROR - 2007-02-11 15:08:29 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-11 15:08:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-11 15:08:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-11 15:08:29 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2007-02-11 15:08:29 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2007-02-11 15:08:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-11 15:08:29 --> File loaded: application/views/admin/home.php
DEBUG - 2007-02-11 15:08:29 --> Final output sent to browser
DEBUG - 2007-02-11 15:08:29 --> Total execution time: 0.1890
DEBUG - 2007-02-11 15:08:29 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:29 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:29 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Router Class Initialized
ERROR - 2007-02-11 15:08:29 --> 404 Page Not Found --> lessons
DEBUG - 2007-02-11 15:08:29 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:29 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:29 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:29 --> Router Class Initialized
ERROR - 2007-02-11 15:08:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 15:08:36 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:36 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:36 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Router Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Output Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Security Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Input Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 15:08:36 --> Language Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Loader Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Helper loaded: url_helper
DEBUG - 2007-02-11 15:08:36 --> Database Driver Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Session Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Helper loaded: string_helper
DEBUG - 2007-02-11 15:08:36 --> Session routines successfully run
DEBUG - 2007-02-11 15:08:36 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Controller Class Initialized
DEBUG - 2007-02-11 15:08:36 --> Helper loaded: tinymce_helper
ERROR - 2007-02-11 15:08:36 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-02-11 15:08:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-02-11 15:08:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-02-11 15:08:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-02-11 15:08:36 --> File loaded: application/views/admin/article.php
DEBUG - 2007-02-11 15:08:36 --> Final output sent to browser
DEBUG - 2007-02-11 15:08:36 --> Total execution time: 0.1653
DEBUG - 2007-02-11 15:08:37 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:37 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:37 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Router Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Output Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Security Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Input Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 15:08:37 --> Language Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Loader Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Helper loaded: url_helper
DEBUG - 2007-02-11 15:08:37 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Database Driver Class Initialized
DEBUG - 2007-02-11 15:08:37 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:37 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Router Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Session Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Helper loaded: string_helper
DEBUG - 2007-02-11 15:08:37 --> Session routines successfully run
ERROR - 2007-02-11 15:08:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 15:08:37 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Controller Class Initialized
ERROR - 2007-02-11 15:08:37 --> 404 Page Not Found --> article/css
DEBUG - 2007-02-11 15:08:37 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:37 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:37 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:37 --> Router Class Initialized
ERROR - 2007-02-11 15:08:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 15:08:41 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:41 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:41 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:41 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:41 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:41 --> Router Class Initialized
ERROR - 2007-02-11 15:08:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 15:08:44 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:44 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:44 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Router Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Output Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Security Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Input Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-11 15:08:44 --> Language Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Loader Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Helper loaded: url_helper
DEBUG - 2007-02-11 15:08:44 --> Database Driver Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Session Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Helper loaded: string_helper
DEBUG - 2007-02-11 15:08:44 --> Session routines successfully run
DEBUG - 2007-02-11 15:08:44 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Model Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Controller Class Initialized
ERROR - 2007-02-11 15:08:44 --> 404 Page Not Found --> article/lists
DEBUG - 2007-02-11 15:08:44 --> Config Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:08:44 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:08:44 --> URI Class Initialized
DEBUG - 2007-02-11 15:08:44 --> Router Class Initialized
ERROR - 2007-02-11 15:08:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-11 15:09:07 --> Config Class Initialized
DEBUG - 2007-02-11 15:09:07 --> Hooks Class Initialized
DEBUG - 2007-02-11 15:09:07 --> Utf8 Class Initialized
DEBUG - 2007-02-11 15:09:07 --> UTF-8 Support Enabled
DEBUG - 2007-02-11 15:09:07 --> URI Class Initialized
DEBUG - 2007-02-11 15:09:07 --> Router Class Initialized
ERROR - 2007-02-11 15:09:07 --> 404 Page Not Found --> favicon.ico

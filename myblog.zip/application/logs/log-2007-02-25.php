<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-02-25 14:12:51 --> Config Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Hooks Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Utf8 Class Initialized
DEBUG - 2007-02-25 14:12:51 --> UTF-8 Support Enabled
DEBUG - 2007-02-25 14:12:51 --> URI Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Router Class Initialized
DEBUG - 2007-02-25 14:12:51 --> No URI present. Default controller set.
DEBUG - 2007-02-25 14:12:51 --> Output Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Security Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Input Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Global POST and COOKIE data sanitized
DEBUG - 2007-02-25 14:12:51 --> Language Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Loader Class Initialized
DEBUG - 2007-02-25 14:12:51 --> Helper loaded: url_helper
DEBUG - 2007-02-25 14:12:52 --> Database Driver Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Session Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Helper loaded: string_helper
DEBUG - 2007-02-25 14:12:52 --> A session cookie was not found.
DEBUG - 2007-02-25 14:12:52 --> Session routines successfully run
DEBUG - 2007-02-25 14:12:52 --> Model Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Model Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Controller Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Pagination Class Initialized
DEBUG - 2007-02-25 14:12:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-02-25 14:12:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-02-25 14:12:52 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2007-02-25 14:12:52 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2007-02-25 14:12:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-02-25 14:12:52 --> File loaded: application/views/user/home.php
DEBUG - 2007-02-25 14:12:52 --> Final output sent to browser
DEBUG - 2007-02-25 14:12:52 --> Total execution time: 0.3478
DEBUG - 2007-02-25 14:12:52 --> Config Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Hooks Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Utf8 Class Initialized
DEBUG - 2007-02-25 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2007-02-25 14:12:52 --> URI Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Router Class Initialized
ERROR - 2007-02-25 14:12:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-02-25 14:12:52 --> Config Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Hooks Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Utf8 Class Initialized
DEBUG - 2007-02-25 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2007-02-25 14:12:52 --> URI Class Initialized
DEBUG - 2007-02-25 14:12:52 --> Router Class Initialized
ERROR - 2007-02-25 14:12:52 --> 404 Page Not Found --> lessons

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-30 21:43:36 --> Config Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Hooks Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Utf8 Class Initialized
DEBUG - 2012-01-30 21:43:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 21:43:36 --> URI Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Router Class Initialized
DEBUG - 2012-01-30 21:43:36 --> No URI present. Default controller set.
DEBUG - 2012-01-30 21:43:36 --> Output Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Security Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Input Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 21:43:36 --> Language Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Loader Class Initialized
DEBUG - 2012-01-30 21:43:36 --> Helper loaded: url_helper
DEBUG - 2012-01-30 21:43:37 --> Database Driver Class Initialized
DEBUG - 2012-01-30 21:43:37 --> Session Class Initialized
DEBUG - 2012-01-30 21:43:37 --> Helper loaded: string_helper
DEBUG - 2012-01-30 21:43:37 --> A session cookie was not found.
DEBUG - 2012-01-30 21:43:37 --> Session routines successfully run
DEBUG - 2012-01-30 21:43:37 --> Cart Class Initialized
DEBUG - 2012-01-30 21:43:37 --> Model Class Initialized
DEBUG - 2012-01-30 21:43:37 --> Model Class Initialized
DEBUG - 2012-01-30 21:43:37 --> Controller Class Initialized
DEBUG - 2012-01-30 21:43:37 --> Pagination Class Initialized
DEBUG - 2012-01-30 21:43:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 21:43:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 21:43:37 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 21:43:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 21:43:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 21:43:37 --> Final output sent to browser
DEBUG - 2012-01-30 21:43:37 --> Total execution time: 1.1722
DEBUG - 2012-01-30 21:43:38 --> Config Class Initialized
DEBUG - 2012-01-30 21:43:38 --> Hooks Class Initialized
DEBUG - 2012-01-30 21:43:38 --> Utf8 Class Initialized
DEBUG - 2012-01-30 21:43:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 21:43:38 --> URI Class Initialized
DEBUG - 2012-01-30 21:43:38 --> Router Class Initialized
ERROR - 2012-01-30 21:43:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 21:43:41 --> Config Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Hooks Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Utf8 Class Initialized
DEBUG - 2012-01-30 21:43:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 21:43:41 --> URI Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Router Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Output Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Security Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Input Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 21:43:41 --> Language Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Loader Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Helper loaded: url_helper
DEBUG - 2012-01-30 21:43:41 --> Database Driver Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Session Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Helper loaded: string_helper
DEBUG - 2012-01-30 21:43:41 --> Session routines successfully run
DEBUG - 2012-01-30 21:43:41 --> Cart Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Model Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Model Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Controller Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Config Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Hooks Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Utf8 Class Initialized
DEBUG - 2012-01-30 21:43:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 21:43:41 --> URI Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Router Class Initialized
DEBUG - 2012-01-30 21:43:41 --> No URI present. Default controller set.
DEBUG - 2012-01-30 21:43:41 --> Output Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Security Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Input Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 21:43:41 --> Language Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Loader Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Helper loaded: url_helper
DEBUG - 2012-01-30 21:43:41 --> Database Driver Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Session Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Helper loaded: string_helper
DEBUG - 2012-01-30 21:43:41 --> Session routines successfully run
DEBUG - 2012-01-30 21:43:41 --> Cart Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Model Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Model Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Controller Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Pagination Class Initialized
DEBUG - 2012-01-30 21:43:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 21:43:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 21:43:41 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 21:43:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 21:43:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 21:43:41 --> Final output sent to browser
DEBUG - 2012-01-30 21:43:41 --> Total execution time: 0.1901
DEBUG - 2012-01-30 21:43:41 --> Config Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Hooks Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Utf8 Class Initialized
DEBUG - 2012-01-30 21:43:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 21:43:41 --> URI Class Initialized
DEBUG - 2012-01-30 21:43:41 --> Router Class Initialized
ERROR - 2012-01-30 21:43:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:07:27 --> Config Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:07:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:07:27 --> URI Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Router Class Initialized
DEBUG - 2012-01-30 22:07:27 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:07:27 --> Output Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Security Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Input Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:07:27 --> Language Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Loader Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:07:27 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Session Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:07:27 --> Session routines successfully run
DEBUG - 2012-01-30 22:07:27 --> Cart Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Model Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Model Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Controller Class Initialized
DEBUG - 2012-01-30 22:07:27 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:07:27 --> DB Transaction Failure
ERROR - 2012-01-30 22:07:27 --> Query error: Table 'codeigniter.fool.pages' doesn't exist
DEBUG - 2012-01-30 22:07:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-30 22:07:28 --> Config Class Initialized
DEBUG - 2012-01-30 22:07:28 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:07:28 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:07:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:07:28 --> URI Class Initialized
DEBUG - 2012-01-30 22:07:28 --> Router Class Initialized
ERROR - 2012-01-30 22:07:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:09:41 --> Config Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:09:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:09:41 --> URI Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Router Class Initialized
DEBUG - 2012-01-30 22:09:41 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:09:41 --> Output Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Security Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Input Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:09:41 --> Language Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Loader Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:09:41 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Session Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:09:41 --> Session routines successfully run
DEBUG - 2012-01-30 22:09:41 --> Cart Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Model Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Model Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Controller Class Initialized
DEBUG - 2012-01-30 22:09:41 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:09:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:09:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:09:41 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:09:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:09:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:09:41 --> Final output sent to browser
DEBUG - 2012-01-30 22:09:41 --> Total execution time: 0.5225
DEBUG - 2012-01-30 22:09:42 --> Config Class Initialized
DEBUG - 2012-01-30 22:09:42 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:09:42 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:09:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:09:42 --> URI Class Initialized
DEBUG - 2012-01-30 22:09:42 --> Router Class Initialized
ERROR - 2012-01-30 22:09:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:09:53 --> Config Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:09:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:09:53 --> URI Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Router Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Output Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Security Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Input Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:09:53 --> Language Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Loader Class Initialized
DEBUG - 2012-01-30 22:09:53 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:09:53 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Session Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:09:54 --> Session routines successfully run
DEBUG - 2012-01-30 22:09:54 --> Cart Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Model Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Model Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Controller Class Initialized
DEBUG - 2012-01-30 22:09:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:09:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:09:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:09:54 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 22:09:54 --> Final output sent to browser
DEBUG - 2012-01-30 22:09:54 --> Total execution time: 0.4778
DEBUG - 2012-01-30 22:09:54 --> Config Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:09:54 --> URI Class Initialized
DEBUG - 2012-01-30 22:09:54 --> Router Class Initialized
ERROR - 2012-01-30 22:09:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:09:58 --> Config Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:09:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:09:58 --> URI Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Router Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Output Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Security Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Input Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:09:58 --> Language Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Loader Class Initialized
DEBUG - 2012-01-30 22:09:58 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:09:59 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Session Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:09:59 --> Session routines successfully run
DEBUG - 2012-01-30 22:09:59 --> Cart Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Model Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Model Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Controller Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Config Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:09:59 --> URI Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Router Class Initialized
DEBUG - 2012-01-30 22:09:59 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:09:59 --> Output Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Security Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Input Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:09:59 --> Language Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Loader Class Initialized
DEBUG - 2012-01-30 22:09:59 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:00 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:00 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:00 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:00 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:00 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:00 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:00 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:00 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:00 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:00 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:10:00 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:00 --> Total execution time: 1.0023
DEBUG - 2012-01-30 22:10:01 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:01 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:01 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:01 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:01 --> Router Class Initialized
ERROR - 2012-01-30 22:10:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:12 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:12 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:12 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:12 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:12 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:12 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:12 --> File loaded: application/views/user/page.php
DEBUG - 2012-01-30 22:10:12 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:12 --> Total execution time: 0.4455
DEBUG - 2012-01-30 22:10:12 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:12 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:12 --> Router Class Initialized
ERROR - 2012-01-30 22:10:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:13 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:13 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:13 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:13 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:13 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:13 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:14 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:14 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:14 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:14 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:14 --> File loaded: application/views/user/page.php
DEBUG - 2012-01-30 22:10:14 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:14 --> Total execution time: 0.5117
DEBUG - 2012-01-30 22:10:14 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:14 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:14 --> Router Class Initialized
ERROR - 2012-01-30 22:10:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:15 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:15 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:15 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:15 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:15 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:15 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:15 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:15 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-30 22:10:15 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:15 --> Total execution time: 0.4681
DEBUG - 2012-01-30 22:10:16 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:16 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:16 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:16 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:16 --> Router Class Initialized
ERROR - 2012-01-30 22:10:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:17 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:17 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:17 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:17 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:17 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:18 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:18 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:18 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-30 22:10:18 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:18 --> Total execution time: 1.1461
DEBUG - 2012-01-30 22:10:18 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:18 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:18 --> Router Class Initialized
ERROR - 2012-01-30 22:10:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:19 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:19 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:20 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:20 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:20 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:20 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:20 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:20 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-30 22:10:20 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:20 --> Total execution time: 0.5040
DEBUG - 2012-01-30 22:10:20 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:20 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:20 --> Router Class Initialized
ERROR - 2012-01-30 22:10:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:35 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:35 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:35 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:35 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:35 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:35 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:35 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-30 22:10:35 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:35 --> Total execution time: 0.4816
DEBUG - 2012-01-30 22:10:35 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:35 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:36 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:36 --> Router Class Initialized
ERROR - 2012-01-30 22:10:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:37 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:37 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:37 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:37 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:37 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:37 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:37 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:37 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-30 22:10:37 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:37 --> Total execution time: 0.4724
DEBUG - 2012-01-30 22:10:38 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:38 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:38 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:38 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:38 --> Router Class Initialized
ERROR - 2012-01-30 22:10:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:39 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:39 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:39 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:39 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:39 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:39 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:39 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:39 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:10:39 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:39 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:39 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:39 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:40 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:40 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:40 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:10:40 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:40 --> Total execution time: 0.6469
DEBUG - 2012-01-30 22:10:40 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:40 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:41 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:41 --> Router Class Initialized
ERROR - 2012-01-30 22:10:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:42 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:42 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:42 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:42 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:42 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:42 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:42 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:42 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:10:42 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:42 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:42 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:42 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:42 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:42 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:42 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:10:42 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:42 --> Total execution time: 0.5091
DEBUG - 2012-01-30 22:10:43 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:43 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:43 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:43 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:43 --> Router Class Initialized
ERROR - 2012-01-30 22:10:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:44 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:44 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:44 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:44 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:44 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:44 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:44 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:44 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:10:44 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:44 --> Total execution time: 0.5774
DEBUG - 2012-01-30 22:10:45 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:45 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:45 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:45 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:45 --> Router Class Initialized
ERROR - 2012-01-30 22:10:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:47 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:47 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:47 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:47 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:47 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:47 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:47 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:47 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:47 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:10:47 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:47 --> Total execution time: 0.5375
DEBUG - 2012-01-30 22:10:48 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:48 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:48 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:48 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:48 --> Router Class Initialized
ERROR - 2012-01-30 22:10:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:49 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:49 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:49 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:49 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:49 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:50 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:50 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:50 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:50 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:10:50 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:50 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:50 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:50 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:50 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:50 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:50 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:10:51 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:51 --> Total execution time: 0.8706
DEBUG - 2012-01-30 22:10:51 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:51 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:51 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:51 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:51 --> Router Class Initialized
ERROR - 2012-01-30 22:10:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:53 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:53 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:53 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:53 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:53 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:53 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:53 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:53 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-30 22:10:53 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:53 --> Total execution time: 0.4344
DEBUG - 2012-01-30 22:10:54 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:54 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:54 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:54 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:54 --> Router Class Initialized
ERROR - 2012-01-30 22:10:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:55 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:55 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:55 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:55 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:55 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:55 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:55 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:56 --> File loaded: application/views/user/product.php
DEBUG - 2012-01-30 22:10:56 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:56 --> Total execution time: 0.8714
DEBUG - 2012-01-30 22:10:56 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:56 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:56 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:56 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:56 --> Router Class Initialized
ERROR - 2012-01-30 22:10:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:10:57 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:57 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Router Class Initialized
DEBUG - 2012-01-30 22:10:57 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:10:57 --> Output Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Security Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Input Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:10:57 --> Language Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Loader Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:10:57 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Session Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:10:57 --> Session routines successfully run
DEBUG - 2012-01-30 22:10:57 --> Cart Class Initialized
DEBUG - 2012-01-30 22:10:57 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:58 --> Model Class Initialized
DEBUG - 2012-01-30 22:10:58 --> Controller Class Initialized
DEBUG - 2012-01-30 22:10:58 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:10:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:10:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:10:58 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:10:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:10:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:10:58 --> Final output sent to browser
DEBUG - 2012-01-30 22:10:58 --> Total execution time: 0.4957
DEBUG - 2012-01-30 22:10:58 --> Config Class Initialized
DEBUG - 2012-01-30 22:10:58 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:10:58 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:10:58 --> URI Class Initialized
DEBUG - 2012-01-30 22:10:58 --> Router Class Initialized
ERROR - 2012-01-30 22:10:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:13:26 --> Config Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:13:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:13:26 --> URI Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Router Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Output Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Security Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Input Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:13:26 --> Language Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Loader Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:13:26 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Session Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:13:26 --> Session routines successfully run
DEBUG - 2012-01-30 22:13:26 --> Cart Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Model Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Model Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Controller Class Initialized
DEBUG - 2012-01-30 22:13:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:13:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:13:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:13:26 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 22:13:26 --> Final output sent to browser
DEBUG - 2012-01-30 22:13:26 --> Total execution time: 0.4336
DEBUG - 2012-01-30 22:13:26 --> Config Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:13:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:13:26 --> URI Class Initialized
DEBUG - 2012-01-30 22:13:26 --> Router Class Initialized
ERROR - 2012-01-30 22:13:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:13:30 --> Config Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:13:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:13:30 --> URI Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Router Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Output Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Security Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Input Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:13:30 --> Language Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Loader Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:13:30 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Session Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:13:30 --> Session routines successfully run
DEBUG - 2012-01-30 22:13:30 --> Cart Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Model Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Model Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Controller Class Initialized
DEBUG - 2012-01-30 22:13:30 --> Final output sent to browser
DEBUG - 2012-01-30 22:13:30 --> Total execution time: 0.4538
DEBUG - 2012-01-30 22:13:31 --> Config Class Initialized
DEBUG - 2012-01-30 22:13:31 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:13:31 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:13:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:13:31 --> URI Class Initialized
DEBUG - 2012-01-30 22:13:31 --> Router Class Initialized
ERROR - 2012-01-30 22:13:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:13:32 --> Config Class Initialized
DEBUG - 2012-01-30 22:13:32 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:13:32 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:13:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:13:32 --> URI Class Initialized
DEBUG - 2012-01-30 22:13:32 --> Router Class Initialized
ERROR - 2012-01-30 22:13:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:15:04 --> Config Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:15:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:15:04 --> URI Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Router Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Output Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Security Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Input Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:15:04 --> Language Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Loader Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:15:04 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Session Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:15:04 --> Session routines successfully run
DEBUG - 2012-01-30 22:15:04 --> Cart Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Model Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Model Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Controller Class Initialized
DEBUG - 2012-01-30 22:15:04 --> Final output sent to browser
DEBUG - 2012-01-30 22:15:04 --> Total execution time: 0.5529
DEBUG - 2012-01-30 22:15:05 --> Config Class Initialized
DEBUG - 2012-01-30 22:15:05 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:15:05 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:15:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:15:05 --> URI Class Initialized
DEBUG - 2012-01-30 22:15:05 --> Router Class Initialized
ERROR - 2012-01-30 22:15:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:15:07 --> Config Class Initialized
DEBUG - 2012-01-30 22:15:07 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:15:07 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:15:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:15:07 --> URI Class Initialized
DEBUG - 2012-01-30 22:15:07 --> Router Class Initialized
ERROR - 2012-01-30 22:15:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:19:53 --> Config Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:19:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:19:54 --> URI Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Router Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Output Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Security Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Input Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:19:54 --> Language Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Loader Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:19:54 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Session Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:19:54 --> Session routines successfully run
DEBUG - 2012-01-30 22:19:54 --> Cart Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Model Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Model Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Controller Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Final output sent to browser
DEBUG - 2012-01-30 22:19:54 --> Total execution time: 0.4893
DEBUG - 2012-01-30 22:19:54 --> Config Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:19:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:19:54 --> URI Class Initialized
DEBUG - 2012-01-30 22:19:54 --> Router Class Initialized
ERROR - 2012-01-30 22:19:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:21:10 --> Config Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:21:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:21:10 --> URI Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Router Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Output Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Security Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Input Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:21:10 --> Language Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Loader Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:21:10 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Session Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:21:10 --> Session routines successfully run
DEBUG - 2012-01-30 22:21:10 --> Cart Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Model Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Model Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Controller Class Initialized
DEBUG - 2012-01-30 22:21:10 --> Final output sent to browser
DEBUG - 2012-01-30 22:21:10 --> Total execution time: 0.4477
DEBUG - 2012-01-30 22:21:11 --> Config Class Initialized
DEBUG - 2012-01-30 22:21:11 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:21:11 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:21:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:21:11 --> URI Class Initialized
DEBUG - 2012-01-30 22:21:11 --> Router Class Initialized
ERROR - 2012-01-30 22:21:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:21:18 --> Config Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:21:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:21:18 --> URI Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Router Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Output Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Security Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Input Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:21:18 --> Language Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Loader Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:21:18 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Session Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:21:18 --> Session routines successfully run
DEBUG - 2012-01-30 22:21:18 --> Cart Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Model Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Model Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Controller Class Initialized
DEBUG - 2012-01-30 22:21:18 --> Final output sent to browser
DEBUG - 2012-01-30 22:21:18 --> Total execution time: 0.5188
DEBUG - 2012-01-30 22:21:19 --> Config Class Initialized
DEBUG - 2012-01-30 22:21:19 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:21:19 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:21:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:21:19 --> URI Class Initialized
DEBUG - 2012-01-30 22:21:19 --> Router Class Initialized
ERROR - 2012-01-30 22:21:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:23:40 --> Config Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:23:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:23:40 --> URI Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Router Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Output Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Security Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Input Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:23:40 --> Language Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Loader Class Initialized
DEBUG - 2012-01-30 22:23:40 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:23:40 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Session Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:23:41 --> Session routines successfully run
DEBUG - 2012-01-30 22:23:41 --> Cart Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Model Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Model Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Controller Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Final output sent to browser
DEBUG - 2012-01-30 22:23:41 --> Total execution time: 1.0474
DEBUG - 2012-01-30 22:23:41 --> Config Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:23:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:23:41 --> URI Class Initialized
DEBUG - 2012-01-30 22:23:41 --> Router Class Initialized
ERROR - 2012-01-30 22:23:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:24:29 --> Config Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:24:29 --> URI Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Router Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Output Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Security Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Input Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:24:29 --> Language Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Loader Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:24:29 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Session Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:24:29 --> Session routines successfully run
DEBUG - 2012-01-30 22:24:29 --> Cart Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Model Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Model Class Initialized
DEBUG - 2012-01-30 22:24:29 --> Controller Class Initialized
DEBUG - 2012-01-30 22:24:30 --> Config Class Initialized
DEBUG - 2012-01-30 22:24:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:24:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:24:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:24:30 --> URI Class Initialized
DEBUG - 2012-01-30 22:24:30 --> Router Class Initialized
ERROR - 2012-01-30 22:24:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:24:55 --> Config Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:24:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:24:55 --> URI Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Router Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Output Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Security Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Input Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:24:55 --> Language Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Loader Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:24:55 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Session Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:24:55 --> Session routines successfully run
DEBUG - 2012-01-30 22:24:55 --> Cart Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Model Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Model Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Controller Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Final output sent to browser
DEBUG - 2012-01-30 22:24:55 --> Total execution time: 0.3396
DEBUG - 2012-01-30 22:24:55 --> Config Class Initialized
DEBUG - 2012-01-30 22:24:55 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:24:56 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:24:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:24:56 --> URI Class Initialized
DEBUG - 2012-01-30 22:24:56 --> Router Class Initialized
ERROR - 2012-01-30 22:24:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:25:01 --> Config Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:25:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:25:01 --> URI Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Router Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Output Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Security Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Input Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:25:01 --> Language Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Loader Class Initialized
DEBUG - 2012-01-30 22:25:01 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:25:02 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Session Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:25:02 --> Session routines successfully run
DEBUG - 2012-01-30 22:25:02 --> Cart Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Model Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Model Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Controller Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Final output sent to browser
DEBUG - 2012-01-30 22:25:02 --> Total execution time: 0.6765
DEBUG - 2012-01-30 22:25:02 --> Config Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:25:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:25:02 --> URI Class Initialized
DEBUG - 2012-01-30 22:25:02 --> Router Class Initialized
ERROR - 2012-01-30 22:25:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:35:52 --> Config Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:35:52 --> URI Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Router Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Output Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Security Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Input Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:35:52 --> Language Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Loader Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:35:52 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:35:52 --> Session Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:35:53 --> Session routines successfully run
DEBUG - 2012-01-30 22:35:53 --> Cart Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Model Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Model Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Controller Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Final output sent to browser
DEBUG - 2012-01-30 22:35:53 --> Total execution time: 0.8875
DEBUG - 2012-01-30 22:35:53 --> Config Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:35:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:35:53 --> URI Class Initialized
DEBUG - 2012-01-30 22:35:53 --> Router Class Initialized
ERROR - 2012-01-30 22:35:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:37:30 --> Config Class Initialized
DEBUG - 2012-01-30 22:37:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:37:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:37:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:37:30 --> URI Class Initialized
DEBUG - 2012-01-30 22:37:30 --> Router Class Initialized
ERROR - 2012-01-30 22:37:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:37:33 --> Config Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:37:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:37:33 --> URI Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Router Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Output Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Security Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Input Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:37:33 --> Language Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Loader Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:37:33 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Session Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:37:33 --> Session routines successfully run
DEBUG - 2012-01-30 22:37:33 --> Cart Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Model Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Model Class Initialized
DEBUG - 2012-01-30 22:37:33 --> Controller Class Initialized
DEBUG - 2012-01-30 22:37:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:37:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:37:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:37:33 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 22:37:33 --> Final output sent to browser
DEBUG - 2012-01-30 22:37:33 --> Total execution time: 0.5856
DEBUG - 2012-01-30 22:37:37 --> Config Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:37:37 --> URI Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Router Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Output Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Security Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Input Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:37:37 --> Language Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Loader Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:37:37 --> Config Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:37:37 --> URI Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Session Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Router Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:37:37 --> Session routines successfully run
ERROR - 2012-01-30 22:37:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:37:37 --> Cart Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Model Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Model Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Controller Class Initialized
DEBUG - 2012-01-30 22:37:37 --> Final output sent to browser
DEBUG - 2012-01-30 22:37:37 --> Total execution time: 0.8856
DEBUG - 2012-01-30 22:37:38 --> Config Class Initialized
DEBUG - 2012-01-30 22:37:38 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:37:38 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:37:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:37:38 --> URI Class Initialized
DEBUG - 2012-01-30 22:37:38 --> Router Class Initialized
ERROR - 2012-01-30 22:37:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:38:01 --> Config Class Initialized
DEBUG - 2012-01-30 22:38:01 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:38:01 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:38:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:38:01 --> URI Class Initialized
DEBUG - 2012-01-30 22:38:01 --> Router Class Initialized
ERROR - 2012-01-30 22:38:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:48:54 --> Config Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:48:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:48:54 --> URI Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Router Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Output Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Security Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Input Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:48:54 --> Language Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Loader Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:48:54 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Session Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:48:54 --> Session routines successfully run
DEBUG - 2012-01-30 22:48:54 --> Cart Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Model Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Model Class Initialized
DEBUG - 2012-01-30 22:48:54 --> Controller Class Initialized
DEBUG - 2012-01-30 22:48:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:48:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:48:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:48:54 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 22:48:54 --> Final output sent to browser
DEBUG - 2012-01-30 22:48:54 --> Total execution time: 0.5076
DEBUG - 2012-01-30 22:48:55 --> Config Class Initialized
DEBUG - 2012-01-30 22:48:55 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:48:55 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:48:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:48:55 --> URI Class Initialized
DEBUG - 2012-01-30 22:48:55 --> Router Class Initialized
ERROR - 2012-01-30 22:48:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:49:00 --> Config Class Initialized
DEBUG - 2012-01-30 22:49:00 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:49:00 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:49:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:49:00 --> URI Class Initialized
DEBUG - 2012-01-30 22:49:00 --> Router Class Initialized
DEBUG - 2012-01-30 22:49:00 --> Output Class Initialized
DEBUG - 2012-01-30 22:49:00 --> Security Class Initialized
DEBUG - 2012-01-30 22:49:00 --> Input Class Initialized
DEBUG - 2012-01-30 22:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:49:01 --> Language Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Loader Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:49:01 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Session Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:49:01 --> Session routines successfully run
DEBUG - 2012-01-30 22:49:01 --> Cart Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Model Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Model Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Controller Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Config Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:49:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:49:01 --> URI Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Router Class Initialized
DEBUG - 2012-01-30 22:49:01 --> No URI present. Default controller set.
DEBUG - 2012-01-30 22:49:01 --> Output Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Security Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Input Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:49:01 --> Language Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Loader Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:49:01 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Session Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:49:01 --> Session routines successfully run
DEBUG - 2012-01-30 22:49:01 --> Cart Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Model Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Model Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Controller Class Initialized
DEBUG - 2012-01-30 22:49:01 --> Pagination Class Initialized
DEBUG - 2012-01-30 22:49:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:49:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:49:01 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 22:49:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:49:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 22:49:01 --> Final output sent to browser
DEBUG - 2012-01-30 22:49:01 --> Total execution time: 0.4857
DEBUG - 2012-01-30 22:49:05 --> Config Class Initialized
DEBUG - 2012-01-30 22:49:05 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:49:05 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:49:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:49:05 --> URI Class Initialized
DEBUG - 2012-01-30 22:49:05 --> Router Class Initialized
ERROR - 2012-01-30 22:49:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:49:15 --> Config Class Initialized
DEBUG - 2012-01-30 22:49:15 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:49:15 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:49:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:49:15 --> URI Class Initialized
DEBUG - 2012-01-30 22:49:15 --> Router Class Initialized
DEBUG - 2012-01-30 22:49:15 --> Output Class Initialized
DEBUG - 2012-01-30 22:49:15 --> Security Class Initialized
DEBUG - 2012-01-30 22:49:15 --> Input Class Initialized
DEBUG - 2012-01-30 22:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:49:16 --> Language Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Loader Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:49:16 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Session Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:49:16 --> Session routines successfully run
DEBUG - 2012-01-30 22:49:16 --> Cart Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Model Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Model Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Controller Class Initialized
DEBUG - 2012-01-30 22:49:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:49:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:49:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:49:16 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 22:49:16 --> Final output sent to browser
DEBUG - 2012-01-30 22:49:16 --> Total execution time: 0.4573
DEBUG - 2012-01-30 22:49:16 --> Config Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:49:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:49:16 --> URI Class Initialized
DEBUG - 2012-01-30 22:49:16 --> Router Class Initialized
ERROR - 2012-01-30 22:49:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:51:15 --> Config Class Initialized
DEBUG - 2012-01-30 22:51:15 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:51:15 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:51:15 --> URI Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Router Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Output Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Security Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Input Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:51:16 --> Language Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Loader Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:51:16 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Session Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:51:16 --> Session routines successfully run
DEBUG - 2012-01-30 22:51:16 --> Cart Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Model Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Model Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Controller Class Initialized
DEBUG - 2012-01-30 22:51:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:51:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:51:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:51:16 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 22:51:16 --> Final output sent to browser
DEBUG - 2012-01-30 22:51:16 --> Total execution time: 0.4998
DEBUG - 2012-01-30 22:51:16 --> Config Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:51:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:51:16 --> URI Class Initialized
DEBUG - 2012-01-30 22:51:16 --> Router Class Initialized
ERROR - 2012-01-30 22:51:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:51:19 --> Config Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:51:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:51:19 --> URI Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Router Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Output Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Security Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Input Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:51:19 --> Language Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Loader Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:51:19 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Session Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:51:19 --> Session routines successfully run
DEBUG - 2012-01-30 22:51:19 --> Cart Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Model Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Model Class Initialized
DEBUG - 2012-01-30 22:51:19 --> Controller Class Initialized
DEBUG - 2012-01-30 22:51:20 --> DB Transaction Failure
ERROR - 2012-01-30 22:51:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.fool`.`order_item`, CONSTRAINT `fk_products_has_orders_products1` FOREIGN KEY (`id_product`, `id_category`) REFERENCES `products` (`id_product`, `id_category`) ON DELETE CASCADE O)
DEBUG - 2012-01-30 22:51:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-30 22:51:20 --> Config Class Initialized
DEBUG - 2012-01-30 22:51:20 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:51:20 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:51:20 --> URI Class Initialized
DEBUG - 2012-01-30 22:51:20 --> Router Class Initialized
ERROR - 2012-01-30 22:51:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:52:28 --> Config Class Initialized
DEBUG - 2012-01-30 22:52:28 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:52:28 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:52:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:52:28 --> URI Class Initialized
DEBUG - 2012-01-30 22:52:28 --> Router Class Initialized
ERROR - 2012-01-30 22:52:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:52:30 --> Config Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:52:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:52:30 --> URI Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Router Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Output Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Security Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Input Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:52:30 --> Language Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Loader Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:52:30 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Session Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:52:30 --> Session routines successfully run
DEBUG - 2012-01-30 22:52:30 --> Cart Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Model Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Model Class Initialized
DEBUG - 2012-01-30 22:52:30 --> Controller Class Initialized
DEBUG - 2012-01-30 22:52:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 22:52:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 22:52:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 22:52:30 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 22:52:30 --> Final output sent to browser
DEBUG - 2012-01-30 22:52:30 --> Total execution time: 0.5203
DEBUG - 2012-01-30 22:52:31 --> Config Class Initialized
DEBUG - 2012-01-30 22:52:31 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:52:31 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:52:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:52:31 --> URI Class Initialized
DEBUG - 2012-01-30 22:52:31 --> Router Class Initialized
ERROR - 2012-01-30 22:52:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 22:52:34 --> Config Class Initialized
DEBUG - 2012-01-30 22:52:34 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:52:34 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:52:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:52:34 --> URI Class Initialized
DEBUG - 2012-01-30 22:52:34 --> Router Class Initialized
DEBUG - 2012-01-30 22:52:34 --> Output Class Initialized
DEBUG - 2012-01-30 22:52:34 --> Security Class Initialized
DEBUG - 2012-01-30 22:52:34 --> Input Class Initialized
DEBUG - 2012-01-30 22:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 22:52:35 --> Language Class Initialized
DEBUG - 2012-01-30 22:52:35 --> Loader Class Initialized
DEBUG - 2012-01-30 22:52:35 --> Helper loaded: url_helper
DEBUG - 2012-01-30 22:52:35 --> Database Driver Class Initialized
DEBUG - 2012-01-30 22:52:35 --> Session Class Initialized
DEBUG - 2012-01-30 22:52:35 --> Helper loaded: string_helper
DEBUG - 2012-01-30 22:52:35 --> Session routines successfully run
DEBUG - 2012-01-30 22:52:35 --> Cart Class Initialized
DEBUG - 2012-01-30 22:52:35 --> Model Class Initialized
DEBUG - 2012-01-30 22:52:35 --> Model Class Initialized
DEBUG - 2012-01-30 22:52:35 --> Controller Class Initialized
DEBUG - 2012-01-30 22:52:35 --> DB Transaction Failure
ERROR - 2012-01-30 22:52:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.fool`.`order_item`, CONSTRAINT `fk_products_has_orders_products1` FOREIGN KEY (`id_product`, `id_category`) REFERENCES `products` (`id_product`, `id_category`) ON DELETE CASCADE O)
DEBUG - 2012-01-30 22:52:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-30 22:52:36 --> Config Class Initialized
DEBUG - 2012-01-30 22:52:36 --> Hooks Class Initialized
DEBUG - 2012-01-30 22:52:36 --> Utf8 Class Initialized
DEBUG - 2012-01-30 22:52:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 22:52:36 --> URI Class Initialized
DEBUG - 2012-01-30 22:52:36 --> Router Class Initialized
ERROR - 2012-01-30 22:52:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:21:25 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:25 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:25 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:25 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:25 --> Router Class Initialized
ERROR - 2012-01-30 23:21:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:21:26 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:26 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Router Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Output Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Security Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Input Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:21:26 --> Language Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Loader Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:21:26 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Session Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:21:26 --> Session routines successfully run
DEBUG - 2012-01-30 23:21:26 --> Cart Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:26 --> Controller Class Initialized
DEBUG - 2012-01-30 23:21:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:21:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:21:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:21:26 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 23:21:26 --> Final output sent to browser
DEBUG - 2012-01-30 23:21:26 --> Total execution time: 0.3036
DEBUG - 2012-01-30 23:21:27 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:27 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:27 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:27 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:27 --> Router Class Initialized
ERROR - 2012-01-30 23:21:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:21:30 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:30 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Router Class Initialized
DEBUG - 2012-01-30 23:21:30 --> No URI present. Default controller set.
DEBUG - 2012-01-30 23:21:30 --> Output Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Security Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Input Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:21:30 --> Language Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Loader Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:21:30 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Session Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:21:30 --> Session routines successfully run
DEBUG - 2012-01-30 23:21:30 --> Cart Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Controller Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:21:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:21:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:21:30 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 23:21:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:21:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 23:21:30 --> Final output sent to browser
DEBUG - 2012-01-30 23:21:30 --> Total execution time: 0.1944
DEBUG - 2012-01-30 23:21:30 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:30 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:30 --> Router Class Initialized
ERROR - 2012-01-30 23:21:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:21:32 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:32 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Router Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Output Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Security Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Input Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:21:32 --> Language Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Loader Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:21:32 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Session Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:21:32 --> Session routines successfully run
DEBUG - 2012-01-30 23:21:32 --> Cart Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Controller Class Initialized
DEBUG - 2012-01-30 23:21:32 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:21:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:21:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:21:32 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 23:21:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:21:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 23:21:32 --> Final output sent to browser
DEBUG - 2012-01-30 23:21:32 --> Total execution time: 0.1925
DEBUG - 2012-01-30 23:21:33 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:33 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:33 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:33 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:33 --> Router Class Initialized
ERROR - 2012-01-30 23:21:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:21:34 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:34 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Router Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Output Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Security Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Input Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:21:34 --> Language Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Loader Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:21:34 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Session Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:21:34 --> Session routines successfully run
DEBUG - 2012-01-30 23:21:34 --> Cart Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:34 --> Controller Class Initialized
DEBUG - 2012-01-30 23:21:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:21:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:21:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:21:34 --> File loaded: application/views/user/order.php
DEBUG - 2012-01-30 23:21:34 --> Final output sent to browser
DEBUG - 2012-01-30 23:21:34 --> Total execution time: 0.1898
DEBUG - 2012-01-30 23:21:35 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:35 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:35 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:35 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:35 --> Router Class Initialized
ERROR - 2012-01-30 23:21:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:21:36 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:36 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Router Class Initialized
DEBUG - 2012-01-30 23:21:36 --> No URI present. Default controller set.
DEBUG - 2012-01-30 23:21:36 --> Output Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Security Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Input Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:21:36 --> Language Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Loader Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:21:36 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Session Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:21:36 --> Session routines successfully run
DEBUG - 2012-01-30 23:21:36 --> Cart Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Controller Class Initialized
DEBUG - 2012-01-30 23:21:36 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:21:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:21:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:21:36 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 23:21:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:21:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 23:21:36 --> Final output sent to browser
DEBUG - 2012-01-30 23:21:36 --> Total execution time: 0.2010
DEBUG - 2012-01-30 23:21:37 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:37 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:37 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:37 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:37 --> Router Class Initialized
ERROR - 2012-01-30 23:21:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:21:55 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:55 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Router Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Output Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Security Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Input Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:21:55 --> Language Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Loader Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:21:55 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Session Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:21:55 --> Session routines successfully run
DEBUG - 2012-01-30 23:21:55 --> Cart Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Model Class Initialized
DEBUG - 2012-01-30 23:21:55 --> Controller Class Initialized
DEBUG - 2012-01-30 23:21:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:21:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:21:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:21:55 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 23:21:55 --> Final output sent to browser
DEBUG - 2012-01-30 23:21:55 --> Total execution time: 0.2112
DEBUG - 2012-01-30 23:21:56 --> Config Class Initialized
DEBUG - 2012-01-30 23:21:56 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:21:56 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:21:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:21:56 --> URI Class Initialized
DEBUG - 2012-01-30 23:21:56 --> Router Class Initialized
ERROR - 2012-01-30 23:21:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:32:38 --> Config Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:32:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:32:38 --> URI Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Router Class Initialized
DEBUG - 2012-01-30 23:32:38 --> No URI present. Default controller set.
DEBUG - 2012-01-30 23:32:38 --> Output Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Security Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Input Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:32:38 --> Language Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Loader Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:32:38 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Session Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:32:38 --> Session routines successfully run
DEBUG - 2012-01-30 23:32:38 --> Cart Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Model Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Model Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Controller Class Initialized
DEBUG - 2012-01-30 23:32:38 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:32:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:32:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:32:38 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 23:32:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:32:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 23:32:38 --> Final output sent to browser
DEBUG - 2012-01-30 23:32:38 --> Total execution time: 0.5036
DEBUG - 2012-01-30 23:32:39 --> Config Class Initialized
DEBUG - 2012-01-30 23:32:39 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:32:39 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:32:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:32:39 --> URI Class Initialized
DEBUG - 2012-01-30 23:32:39 --> Router Class Initialized
ERROR - 2012-01-30 23:32:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:32:42 --> Config Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:32:42 --> URI Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Router Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Output Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Security Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Input Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:32:42 --> Language Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Loader Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:32:42 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Session Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:32:42 --> Session routines successfully run
DEBUG - 2012-01-30 23:32:42 --> Cart Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Model Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Model Class Initialized
DEBUG - 2012-01-30 23:32:42 --> Controller Class Initialized
DEBUG - 2012-01-30 23:32:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:32:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:32:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:32:43 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 23:32:43 --> Final output sent to browser
DEBUG - 2012-01-30 23:32:43 --> Total execution time: 0.4377
DEBUG - 2012-01-30 23:32:43 --> Config Class Initialized
DEBUG - 2012-01-30 23:32:43 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:32:43 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:32:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:32:43 --> URI Class Initialized
DEBUG - 2012-01-30 23:32:43 --> Router Class Initialized
ERROR - 2012-01-30 23:32:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:32:46 --> Config Class Initialized
DEBUG - 2012-01-30 23:32:46 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:32:46 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:32:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:32:46 --> URI Class Initialized
DEBUG - 2012-01-30 23:32:46 --> Router Class Initialized
DEBUG - 2012-01-30 23:32:46 --> Output Class Initialized
DEBUG - 2012-01-30 23:32:46 --> Security Class Initialized
DEBUG - 2012-01-30 23:32:46 --> Input Class Initialized
DEBUG - 2012-01-30 23:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:32:46 --> Language Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Loader Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:32:47 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Session Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:32:47 --> Session routines successfully run
DEBUG - 2012-01-30 23:32:47 --> Cart Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Model Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Model Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Controller Class Initialized
DEBUG - 2012-01-30 23:32:47 --> DB Transaction Failure
ERROR - 2012-01-30 23:32:47 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.fool`.`order_product`, CONSTRAINT `fk_products_has_orders_products1` FOREIGN KEY (`id_product`, `id_category`) REFERENCES `products` (`id_product`, `id_category`) ON DELETE CASCAD)
DEBUG - 2012-01-30 23:32:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2012-01-30 23:32:47 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.fool\www\application\controllers\user\cart.php:90) A:\home\codeigniter.fool\www\system\core\Common.php 442
DEBUG - 2012-01-30 23:32:47 --> Config Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:32:47 --> URI Class Initialized
DEBUG - 2012-01-30 23:32:47 --> Router Class Initialized
ERROR - 2012-01-30 23:32:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:37:07 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:07 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:07 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:07 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:07 --> Router Class Initialized
ERROR - 2012-01-30 23:37:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:37:10 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:10 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Router Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Output Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Security Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Input Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:37:10 --> Language Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Loader Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:37:10 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Session Class Initialized
DEBUG - 2012-01-30 23:37:10 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:37:10 --> Session routines successfully run
DEBUG - 2012-01-30 23:37:10 --> Cart Class Initialized
DEBUG - 2012-01-30 23:37:11 --> Model Class Initialized
DEBUG - 2012-01-30 23:37:11 --> Model Class Initialized
DEBUG - 2012-01-30 23:37:11 --> Controller Class Initialized
DEBUG - 2012-01-30 23:37:11 --> DB Transaction Failure
ERROR - 2012-01-30 23:37:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.fool`.`order_product`, CONSTRAINT `fk_products_has_orders_products1` FOREIGN KEY (`id_product`, `id_category`) REFERENCES `products` (`id_product`, `id_category`) ON DELETE CASCAD)
DEBUG - 2012-01-30 23:37:11 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-30 23:37:11 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:11 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:11 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:11 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:11 --> Router Class Initialized
ERROR - 2012-01-30 23:37:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:37:32 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:32 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:32 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:32 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:32 --> Router Class Initialized
ERROR - 2012-01-30 23:37:32 --> 404 Page Not Found --> cart
DEBUG - 2012-01-30 23:37:33 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:33 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:33 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:33 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:33 --> Router Class Initialized
ERROR - 2012-01-30 23:37:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:37:36 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:36 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Router Class Initialized
DEBUG - 2012-01-30 23:37:36 --> No URI present. Default controller set.
DEBUG - 2012-01-30 23:37:36 --> Output Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Security Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Input Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:37:36 --> Language Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Loader Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:37:36 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Session Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:37:36 --> Session routines successfully run
DEBUG - 2012-01-30 23:37:36 --> Cart Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Model Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Model Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Controller Class Initialized
DEBUG - 2012-01-30 23:37:36 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:37:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:37:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:37:36 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 23:37:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:37:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 23:37:37 --> Final output sent to browser
DEBUG - 2012-01-30 23:37:37 --> Total execution time: 0.5091
DEBUG - 2012-01-30 23:37:37 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:37 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:37 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:37 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:37 --> Router Class Initialized
ERROR - 2012-01-30 23:37:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:37:39 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:39 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Router Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Output Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Security Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Input Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:37:39 --> Language Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Loader Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:37:39 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Session Class Initialized
DEBUG - 2012-01-30 23:37:39 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:37:39 --> Session routines successfully run
DEBUG - 2012-01-30 23:37:39 --> Cart Class Initialized
DEBUG - 2012-01-30 23:37:40 --> Model Class Initialized
DEBUG - 2012-01-30 23:37:40 --> Model Class Initialized
DEBUG - 2012-01-30 23:37:40 --> Controller Class Initialized
DEBUG - 2012-01-30 23:37:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:37:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:37:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:37:40 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 23:37:40 --> Final output sent to browser
DEBUG - 2012-01-30 23:37:40 --> Total execution time: 0.4820
DEBUG - 2012-01-30 23:37:40 --> Config Class Initialized
DEBUG - 2012-01-30 23:37:40 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:37:40 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:37:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:37:40 --> URI Class Initialized
DEBUG - 2012-01-30 23:37:40 --> Router Class Initialized
ERROR - 2012-01-30 23:37:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:41:27 --> Config Class Initialized
DEBUG - 2012-01-30 23:41:27 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:41:27 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:41:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:41:27 --> URI Class Initialized
DEBUG - 2012-01-30 23:41:27 --> Router Class Initialized
ERROR - 2012-01-30 23:41:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:41:29 --> Config Class Initialized
DEBUG - 2012-01-30 23:41:29 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:41:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:41:30 --> URI Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Router Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Output Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Security Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Input Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:41:30 --> Language Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Loader Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:41:30 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Session Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:41:30 --> Session routines successfully run
DEBUG - 2012-01-30 23:41:30 --> Cart Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Controller Class Initialized
DEBUG - 2012-01-30 23:41:30 --> DB Transaction Failure
ERROR - 2012-01-30 23:41:30 --> Query error: Unknown column 'id_gategory' in 'field list'
DEBUG - 2012-01-30 23:41:30 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-30 23:41:30 --> Config Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:41:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:41:30 --> URI Class Initialized
DEBUG - 2012-01-30 23:41:30 --> Router Class Initialized
ERROR - 2012-01-30 23:41:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:41:50 --> Config Class Initialized
DEBUG - 2012-01-30 23:41:50 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:41:50 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:41:50 --> URI Class Initialized
DEBUG - 2012-01-30 23:41:50 --> Router Class Initialized
ERROR - 2012-01-30 23:41:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:41:53 --> Config Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:41:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:41:53 --> URI Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Router Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Output Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Security Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Input Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:41:53 --> Language Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Loader Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:41:53 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Session Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:41:53 --> Session routines successfully run
DEBUG - 2012-01-30 23:41:53 --> Cart Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Model Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Model Class Initialized
DEBUG - 2012-01-30 23:41:53 --> Controller Class Initialized
ERROR - 2012-01-30 23:41:54 --> Severity: 4096  --> Object of class stdClass could not be converted to string A:\home\codeigniter.fool\www\system\database\drivers\mysql\mysql_driver.php 552
DEBUG - 2012-01-30 23:41:54 --> DB Transaction Failure
ERROR - 2012-01-30 23:41:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ' 4, 4)' at line 1
DEBUG - 2012-01-30 23:41:54 --> Language file loaded: language/english/db_lang.php
ERROR - 2012-01-30 23:41:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.fool\www\system\core\Exceptions.php:185) A:\home\codeigniter.fool\www\system\core\Common.php 442
DEBUG - 2012-01-30 23:41:54 --> Config Class Initialized
DEBUG - 2012-01-30 23:41:54 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:41:54 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:41:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:41:54 --> URI Class Initialized
DEBUG - 2012-01-30 23:41:54 --> Router Class Initialized
ERROR - 2012-01-30 23:41:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:42:26 --> Config Class Initialized
DEBUG - 2012-01-30 23:42:26 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:42:26 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:42:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:42:26 --> URI Class Initialized
DEBUG - 2012-01-30 23:42:26 --> Router Class Initialized
ERROR - 2012-01-30 23:42:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:42:29 --> Config Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:42:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:42:29 --> URI Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Router Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Output Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Security Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Input Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:42:29 --> Language Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Loader Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:42:29 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Session Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:42:29 --> Session routines successfully run
DEBUG - 2012-01-30 23:42:29 --> Cart Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Model Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Model Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Controller Class Initialized
DEBUG - 2012-01-30 23:42:29 --> Final output sent to browser
DEBUG - 2012-01-30 23:42:29 --> Total execution time: 0.7165
DEBUG - 2012-01-30 23:42:30 --> Config Class Initialized
DEBUG - 2012-01-30 23:42:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:42:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:42:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:42:30 --> URI Class Initialized
DEBUG - 2012-01-30 23:42:30 --> Router Class Initialized
ERROR - 2012-01-30 23:42:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:44:50 --> Config Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:44:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:44:50 --> URI Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Router Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Output Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Security Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Input Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:44:50 --> Language Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Loader Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:44:50 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Session Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:44:50 --> Session routines successfully run
DEBUG - 2012-01-30 23:44:50 --> Cart Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Model Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Model Class Initialized
DEBUG - 2012-01-30 23:44:50 --> Controller Class Initialized
DEBUG - 2012-01-30 23:44:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:44:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:44:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:44:50 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 23:44:50 --> Final output sent to browser
DEBUG - 2012-01-30 23:44:50 --> Total execution time: 0.4690
DEBUG - 2012-01-30 23:44:51 --> Config Class Initialized
DEBUG - 2012-01-30 23:44:51 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:44:51 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:44:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:44:51 --> URI Class Initialized
DEBUG - 2012-01-30 23:44:51 --> Router Class Initialized
ERROR - 2012-01-30 23:44:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:22 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:22 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:22 --> No URI present. Default controller set.
DEBUG - 2012-01-30 23:46:22 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:22 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:22 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:22 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:22 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:22 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:46:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:46:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:46:23 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 23:46:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:46:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 23:46:23 --> Final output sent to browser
DEBUG - 2012-01-30 23:46:23 --> Total execution time: 0.4661
DEBUG - 2012-01-30 23:46:23 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:23 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:23 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:23 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:23 --> Router Class Initialized
ERROR - 2012-01-30 23:46:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:27 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:27 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:27 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:27 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:27 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:27 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:27 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:27 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:27 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:28 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:28 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:28 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:28 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-30 23:46:28 --> Final output sent to browser
DEBUG - 2012-01-30 23:46:28 --> Total execution time: 0.8294
DEBUG - 2012-01-30 23:46:28 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:28 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:29 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:29 --> Router Class Initialized
ERROR - 2012-01-30 23:46:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:29 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:29 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:29 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:29 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:29 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:29 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:29 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:30 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:30 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:30 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:30 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:30 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:30 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:30 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:30 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:30 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:30 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:46:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-30 23:46:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-30 23:46:30 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-30 23:46:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-30 23:46:30 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-30 23:46:30 --> Final output sent to browser
DEBUG - 2012-01-30 23:46:30 --> Total execution time: 0.5178
DEBUG - 2012-01-30 23:46:31 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:31 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:31 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:31 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:31 --> Router Class Initialized
ERROR - 2012-01-30 23:46:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:36 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:36 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:37 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:37 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:37 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:37 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:37 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:46:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:46:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:46:37 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-01-30 23:46:37 --> Final output sent to browser
DEBUG - 2012-01-30 23:46:37 --> Total execution time: 0.4345
DEBUG - 2012-01-30 23:46:37 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:37 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:37 --> Router Class Initialized
ERROR - 2012-01-30 23:46:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:45 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:45 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:45 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:45 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:45 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:45 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:45 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:46 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:46 --> No URI present. Default controller set.
DEBUG - 2012-01-30 23:46:46 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:46 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:46 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:46 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:46 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:46 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:46:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-30 23:46:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-30 23:46:46 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-01-30 23:46:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-30 23:46:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-30 23:46:46 --> Final output sent to browser
DEBUG - 2012-01-30 23:46:46 --> Total execution time: 0.5095
DEBUG - 2012-01-30 23:46:47 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:47 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:47 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:47 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:47 --> Router Class Initialized
ERROR - 2012-01-30 23:46:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:51 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:51 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:51 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:51 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:51 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:51 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:51 --> Pagination Class Initialized
DEBUG - 2012-01-30 23:46:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-30 23:46:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-30 23:46:51 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-01-30 23:46:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-30 23:46:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-30 23:46:51 --> Final output sent to browser
DEBUG - 2012-01-30 23:46:51 --> Total execution time: 0.5099
DEBUG - 2012-01-30 23:46:52 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:52 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:52 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:52 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:52 --> Router Class Initialized
ERROR - 2012-01-30 23:46:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:54 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:54 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Router Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Output Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Security Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Input Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-30 23:46:54 --> Language Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Loader Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Helper loaded: url_helper
DEBUG - 2012-01-30 23:46:54 --> Database Driver Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Session Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Helper loaded: string_helper
DEBUG - 2012-01-30 23:46:54 --> Session routines successfully run
DEBUG - 2012-01-30 23:46:54 --> Cart Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Model Class Initialized
DEBUG - 2012-01-30 23:46:54 --> Controller Class Initialized
DEBUG - 2012-01-30 23:46:54 --> DB Transaction Failure
ERROR - 2012-01-30 23:46:54 --> Query error: Unknown column 'o.name' in 'field list'
DEBUG - 2012-01-30 23:46:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-30 23:46:55 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:55 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:55 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:55 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:55 --> Router Class Initialized
ERROR - 2012-01-30 23:46:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-30 23:46:57 --> Config Class Initialized
DEBUG - 2012-01-30 23:46:57 --> Hooks Class Initialized
DEBUG - 2012-01-30 23:46:57 --> Utf8 Class Initialized
DEBUG - 2012-01-30 23:46:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-30 23:46:57 --> URI Class Initialized
DEBUG - 2012-01-30 23:46:57 --> Router Class Initialized
ERROR - 2012-01-30 23:46:57 --> 404 Page Not Found --> favicon.ico

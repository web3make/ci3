<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-02-01 21:09:52 --> Config Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:09:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:09:52 --> URI Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Router Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Output Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Security Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Input Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:09:52 --> Language Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Loader Class Initialized
DEBUG - 2012-02-01 21:09:52 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:09:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Session Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:09:53 --> A session cookie was not found.
DEBUG - 2012-02-01 21:09:53 --> Session routines successfully run
DEBUG - 2012-02-01 21:09:53 --> Cart Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Controller Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Config Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:09:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:09:53 --> URI Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Router Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Output Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Security Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Input Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:09:53 --> Language Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Loader Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:09:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Session Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:09:53 --> Session routines successfully run
DEBUG - 2012-02-01 21:09:53 --> Cart Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:09:53 --> Controller Class Initialized
DEBUG - 2012-02-01 21:09:53 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-01 21:09:53 --> Final output sent to browser
DEBUG - 2012-02-01 21:09:53 --> Total execution time: 0.1858
DEBUG - 2012-02-01 21:09:54 --> Config Class Initialized
DEBUG - 2012-02-01 21:09:54 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:09:54 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:09:54 --> URI Class Initialized
DEBUG - 2012-02-01 21:09:54 --> Router Class Initialized
ERROR - 2012-02-01 21:09:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 21:12:14 --> Config Class Initialized
DEBUG - 2012-02-01 21:12:14 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:12:14 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:12:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:12:15 --> URI Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Router Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Output Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Security Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Input Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:12:15 --> Language Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Loader Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:12:15 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Session Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:12:15 --> Session routines successfully run
DEBUG - 2012-02-01 21:12:15 --> Cart Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Model Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Model Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Controller Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Config Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:12:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:12:15 --> URI Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Router Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Output Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Security Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Input Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:12:15 --> Language Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Loader Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:12:15 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Session Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:12:15 --> Session routines successfully run
DEBUG - 2012-02-01 21:12:15 --> Cart Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Model Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Model Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Controller Class Initialized
DEBUG - 2012-02-01 21:12:15 --> Pagination Class Initialized
DEBUG - 2012-02-01 21:12:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:12:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:12:15 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 21:12:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:12:15 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 21:12:15 --> Final output sent to browser
DEBUG - 2012-02-01 21:12:15 --> Total execution time: 0.4177
DEBUG - 2012-02-01 21:12:16 --> Config Class Initialized
DEBUG - 2012-02-01 21:12:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:12:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:12:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:12:16 --> URI Class Initialized
DEBUG - 2012-02-01 21:12:16 --> Router Class Initialized
ERROR - 2012-02-01 21:12:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 21:12:22 --> Config Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:12:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:12:22 --> URI Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Router Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Output Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Security Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Input Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:12:22 --> Language Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Loader Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:12:22 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Session Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:12:22 --> Session routines successfully run
DEBUG - 2012-02-01 21:12:22 --> Cart Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Model Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Model Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Controller Class Initialized
DEBUG - 2012-02-01 21:12:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:12:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:12:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:12:22 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:12:22 --> Final output sent to browser
DEBUG - 2012-02-01 21:12:22 --> Total execution time: 0.2546
DEBUG - 2012-02-01 21:12:22 --> Config Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:12:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:12:22 --> URI Class Initialized
DEBUG - 2012-02-01 21:12:22 --> Router Class Initialized
ERROR - 2012-02-01 21:12:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 21:38:41 --> Config Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:38:41 --> URI Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Router Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Output Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Security Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Input Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:38:41 --> Language Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Loader Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:38:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Session Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:38:41 --> A session cookie was not found.
DEBUG - 2012-02-01 21:38:41 --> Session routines successfully run
DEBUG - 2012-02-01 21:38:41 --> Cart Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Controller Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Config Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:38:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:38:41 --> URI Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Router Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Output Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Security Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Input Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:38:42 --> Language Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Loader Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:38:42 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Session Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:38:42 --> Session routines successfully run
DEBUG - 2012-02-01 21:38:42 --> Cart Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:42 --> Controller Class Initialized
DEBUG - 2012-02-01 21:38:42 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-01 21:38:42 --> Final output sent to browser
DEBUG - 2012-02-01 21:38:42 --> Total execution time: 0.1891
DEBUG - 2012-02-01 21:38:47 --> Config Class Initialized
DEBUG - 2012-02-01 21:38:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:38:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:38:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:38:47 --> URI Class Initialized
DEBUG - 2012-02-01 21:38:47 --> Router Class Initialized
DEBUG - 2012-02-01 21:38:47 --> No URI present. Default controller set.
DEBUG - 2012-02-01 21:38:47 --> Output Class Initialized
DEBUG - 2012-02-01 21:38:47 --> Security Class Initialized
DEBUG - 2012-02-01 21:38:47 --> Input Class Initialized
DEBUG - 2012-02-01 21:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:38:47 --> Language Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Loader Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:38:48 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Session Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:38:48 --> Session routines successfully run
DEBUG - 2012-02-01 21:38:48 --> Cart Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Controller Class Initialized
DEBUG - 2012-02-01 21:38:48 --> Pagination Class Initialized
DEBUG - 2012-02-01 21:38:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 21:38:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 21:38:48 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 21:38:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 21:38:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 21:38:48 --> Final output sent to browser
DEBUG - 2012-02-01 21:38:48 --> Total execution time: 0.4773
DEBUG - 2012-02-01 21:38:51 --> Config Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:38:51 --> URI Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Router Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Output Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Security Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Input Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:38:51 --> Language Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Loader Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:38:51 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Session Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:38:51 --> Session routines successfully run
DEBUG - 2012-02-01 21:38:51 --> Cart Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Controller Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Config Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:38:51 --> URI Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Router Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Output Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Security Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Input Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:38:51 --> Language Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Loader Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:38:51 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Session Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:38:51 --> Session routines successfully run
DEBUG - 2012-02-01 21:38:51 --> Cart Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:51 --> Controller Class Initialized
DEBUG - 2012-02-01 21:38:52 --> Pagination Class Initialized
DEBUG - 2012-02-01 21:38:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:38:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:38:52 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 21:38:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:38:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 21:38:52 --> Final output sent to browser
DEBUG - 2012-02-01 21:38:52 --> Total execution time: 0.1934
DEBUG - 2012-02-01 21:38:53 --> Config Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:38:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:38:53 --> URI Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Router Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Output Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Security Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Input Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:38:53 --> Language Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Loader Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:38:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Session Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:38:53 --> Session routines successfully run
DEBUG - 2012-02-01 21:38:53 --> Cart Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:38:53 --> Controller Class Initialized
DEBUG - 2012-02-01 21:38:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:38:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:38:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:38:53 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:38:53 --> Final output sent to browser
DEBUG - 2012-02-01 21:38:53 --> Total execution time: 0.2058
DEBUG - 2012-02-01 21:46:28 --> Config Class Initialized
DEBUG - 2012-02-01 21:46:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:46:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:46:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:46:29 --> URI Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Router Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Output Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Security Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Input Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:46:29 --> Language Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Loader Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:46:29 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Session Class Initialized
DEBUG - 2012-02-01 21:46:29 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:46:29 --> Session routines successfully run
DEBUG - 2012-02-01 21:46:30 --> Cart Class Initialized
DEBUG - 2012-02-01 21:46:30 --> Model Class Initialized
DEBUG - 2012-02-01 21:46:30 --> Model Class Initialized
DEBUG - 2012-02-01 21:46:30 --> Controller Class Initialized
DEBUG - 2012-02-01 21:46:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:46:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:46:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:46:30 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:46:30 --> Final output sent to browser
DEBUG - 2012-02-01 21:46:30 --> Total execution time: 1.9285
DEBUG - 2012-02-01 21:46:31 --> Config Class Initialized
DEBUG - 2012-02-01 21:46:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:46:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:46:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:46:32 --> URI Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Router Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Output Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Security Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Input Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:46:32 --> Language Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Loader Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:46:32 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Session Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:46:32 --> Session routines successfully run
DEBUG - 2012-02-01 21:46:32 --> Cart Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Model Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Model Class Initialized
DEBUG - 2012-02-01 21:46:32 --> Controller Class Initialized
ERROR - 2012-02-01 21:46:32 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 21:47:46 --> Config Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:47:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:47:46 --> URI Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Router Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Output Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Security Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Input Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:47:46 --> Language Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Loader Class Initialized
DEBUG - 2012-02-01 21:47:46 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:47:47 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:47:47 --> Session Class Initialized
DEBUG - 2012-02-01 21:47:47 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:47:47 --> Session routines successfully run
DEBUG - 2012-02-01 21:47:47 --> Cart Class Initialized
DEBUG - 2012-02-01 21:47:47 --> Model Class Initialized
DEBUG - 2012-02-01 21:47:47 --> Model Class Initialized
DEBUG - 2012-02-01 21:47:47 --> Controller Class Initialized
DEBUG - 2012-02-01 21:47:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:47:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:47:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:47:47 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:47:47 --> Final output sent to browser
DEBUG - 2012-02-01 21:47:47 --> Total execution time: 0.5303
DEBUG - 2012-02-01 21:47:49 --> Config Class Initialized
DEBUG - 2012-02-01 21:47:49 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:47:49 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:47:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:47:49 --> URI Class Initialized
DEBUG - 2012-02-01 21:47:49 --> Router Class Initialized
DEBUG - 2012-02-01 21:47:49 --> Output Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Security Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Input Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:47:50 --> Language Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Loader Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:47:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Session Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:47:50 --> Session routines successfully run
DEBUG - 2012-02-01 21:47:50 --> Cart Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Model Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Model Class Initialized
DEBUG - 2012-02-01 21:47:50 --> Controller Class Initialized
ERROR - 2012-02-01 21:47:50 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 21:48:13 --> Config Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:48:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:48:13 --> URI Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Router Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Output Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Security Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Input Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:48:13 --> Language Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Loader Class Initialized
DEBUG - 2012-02-01 21:48:13 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:48:14 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:48:14 --> Session Class Initialized
DEBUG - 2012-02-01 21:48:14 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:48:14 --> Session routines successfully run
DEBUG - 2012-02-01 21:48:14 --> Cart Class Initialized
DEBUG - 2012-02-01 21:48:14 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:14 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:14 --> Controller Class Initialized
DEBUG - 2012-02-01 21:48:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:48:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:48:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:48:15 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:48:15 --> Final output sent to browser
DEBUG - 2012-02-01 21:48:15 --> Total execution time: 2.1776
DEBUG - 2012-02-01 21:48:18 --> Config Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:48:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:48:18 --> URI Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Router Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Output Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Security Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Input Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:48:18 --> Language Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Loader Class Initialized
DEBUG - 2012-02-01 21:48:18 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:48:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:48:19 --> Session Class Initialized
DEBUG - 2012-02-01 21:48:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:48:19 --> Session routines successfully run
DEBUG - 2012-02-01 21:48:19 --> Cart Class Initialized
DEBUG - 2012-02-01 21:48:19 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:19 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:19 --> Controller Class Initialized
ERROR - 2012-02-01 21:48:19 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 21:48:49 --> Config Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:48:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:48:49 --> URI Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Router Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Output Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Security Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Input Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:48:49 --> Language Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Loader Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:48:49 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Session Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:48:49 --> Session routines successfully run
DEBUG - 2012-02-01 21:48:49 --> Cart Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:49 --> Controller Class Initialized
DEBUG - 2012-02-01 21:48:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:48:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:48:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:48:49 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:48:50 --> Final output sent to browser
DEBUG - 2012-02-01 21:48:50 --> Total execution time: 0.5789
DEBUG - 2012-02-01 21:48:52 --> Config Class Initialized
DEBUG - 2012-02-01 21:48:52 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:48:52 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:48:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:48:52 --> URI Class Initialized
DEBUG - 2012-02-01 21:48:52 --> Router Class Initialized
DEBUG - 2012-02-01 21:48:52 --> Output Class Initialized
DEBUG - 2012-02-01 21:48:52 --> Security Class Initialized
DEBUG - 2012-02-01 21:48:52 --> Input Class Initialized
DEBUG - 2012-02-01 21:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:48:52 --> Language Class Initialized
DEBUG - 2012-02-01 21:48:53 --> Loader Class Initialized
DEBUG - 2012-02-01 21:48:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:48:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:48:53 --> Session Class Initialized
DEBUG - 2012-02-01 21:48:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:48:53 --> Session routines successfully run
DEBUG - 2012-02-01 21:48:53 --> Cart Class Initialized
DEBUG - 2012-02-01 21:48:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:53 --> Model Class Initialized
DEBUG - 2012-02-01 21:48:53 --> Controller Class Initialized
ERROR - 2012-02-01 21:48:53 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 21:52:08 --> Config Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:52:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:52:08 --> URI Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Router Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Output Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Security Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Input Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:52:08 --> Language Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Loader Class Initialized
DEBUG - 2012-02-01 21:52:08 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:52:08 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:52:09 --> Session Class Initialized
DEBUG - 2012-02-01 21:52:09 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:52:09 --> Session routines successfully run
DEBUG - 2012-02-01 21:52:09 --> Cart Class Initialized
DEBUG - 2012-02-01 21:52:09 --> Model Class Initialized
DEBUG - 2012-02-01 21:52:09 --> Model Class Initialized
DEBUG - 2012-02-01 21:52:09 --> Controller Class Initialized
DEBUG - 2012-02-01 21:52:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:52:09 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:52:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:52:09 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:52:09 --> Final output sent to browser
DEBUG - 2012-02-01 21:52:09 --> Total execution time: 1.2461
DEBUG - 2012-02-01 21:52:12 --> Config Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:52:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:52:12 --> URI Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Router Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Output Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Security Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Input Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:52:12 --> Language Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Loader Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:52:12 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Session Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:52:12 --> Session routines successfully run
DEBUG - 2012-02-01 21:52:12 --> Cart Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Model Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Model Class Initialized
DEBUG - 2012-02-01 21:52:12 --> Controller Class Initialized
ERROR - 2012-02-01 21:52:12 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 21:53:07 --> Config Class Initialized
DEBUG - 2012-02-01 21:53:07 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:53:07 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:53:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:53:07 --> URI Class Initialized
DEBUG - 2012-02-01 21:53:07 --> Router Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Output Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Security Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Input Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:53:08 --> Language Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Loader Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:53:08 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Session Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:53:08 --> Session routines successfully run
DEBUG - 2012-02-01 21:53:08 --> Cart Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Model Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Model Class Initialized
DEBUG - 2012-02-01 21:53:08 --> Controller Class Initialized
DEBUG - 2012-02-01 21:53:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:53:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:53:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:53:08 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:53:09 --> Final output sent to browser
DEBUG - 2012-02-01 21:53:09 --> Total execution time: 1.7249
DEBUG - 2012-02-01 21:53:12 --> Config Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:53:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:53:12 --> URI Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Router Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Output Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Security Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Input Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:53:12 --> Language Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Loader Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:53:12 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:53:12 --> Session Class Initialized
DEBUG - 2012-02-01 21:53:13 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:53:13 --> Session routines successfully run
DEBUG - 2012-02-01 21:53:13 --> Cart Class Initialized
DEBUG - 2012-02-01 21:53:13 --> Model Class Initialized
DEBUG - 2012-02-01 21:53:13 --> Model Class Initialized
DEBUG - 2012-02-01 21:53:13 --> Controller Class Initialized
ERROR - 2012-02-01 21:53:13 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 21:54:28 --> Config Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:54:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:54:28 --> URI Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Router Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Output Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Security Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Input Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:54:28 --> Language Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Loader Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:54:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Session Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:54:28 --> Session routines successfully run
DEBUG - 2012-02-01 21:54:28 --> Cart Class Initialized
DEBUG - 2012-02-01 21:54:28 --> Model Class Initialized
DEBUG - 2012-02-01 21:54:29 --> Model Class Initialized
DEBUG - 2012-02-01 21:54:29 --> Controller Class Initialized
DEBUG - 2012-02-01 21:54:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:54:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:54:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:54:29 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:54:29 --> Final output sent to browser
DEBUG - 2012-02-01 21:54:29 --> Total execution time: 1.1977
DEBUG - 2012-02-01 21:54:32 --> Config Class Initialized
DEBUG - 2012-02-01 21:54:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:54:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:54:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:54:32 --> URI Class Initialized
DEBUG - 2012-02-01 21:54:32 --> Router Class Initialized
DEBUG - 2012-02-01 21:54:32 --> Output Class Initialized
DEBUG - 2012-02-01 21:54:32 --> Security Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Input Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:54:33 --> Language Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Loader Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:54:33 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Session Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:54:33 --> Session routines successfully run
DEBUG - 2012-02-01 21:54:33 --> Cart Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Model Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Model Class Initialized
DEBUG - 2012-02-01 21:54:33 --> Controller Class Initialized
ERROR - 2012-02-01 21:54:33 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 21:56:35 --> Config Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:56:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:56:36 --> URI Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Router Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Output Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Security Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Input Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:56:36 --> Language Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Loader Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:56:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Session Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:56:36 --> Session routines successfully run
DEBUG - 2012-02-01 21:56:36 --> Cart Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Model Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Model Class Initialized
DEBUG - 2012-02-01 21:56:36 --> Controller Class Initialized
DEBUG - 2012-02-01 21:56:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 21:56:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 21:56:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 21:56:37 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 21:56:37 --> Final output sent to browser
DEBUG - 2012-02-01 21:56:37 --> Total execution time: 1.1094
DEBUG - 2012-02-01 21:56:40 --> Config Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 21:56:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 21:56:40 --> URI Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Router Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Output Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Security Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Input Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 21:56:40 --> Language Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Loader Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 21:56:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Session Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 21:56:40 --> Session routines successfully run
DEBUG - 2012-02-01 21:56:40 --> Cart Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Model Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Model Class Initialized
DEBUG - 2012-02-01 21:56:40 --> Controller Class Initialized
ERROR - 2012-02-01 21:56:40 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:05:38 --> Config Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:05:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:05:39 --> URI Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Router Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Output Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Security Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Input Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:05:39 --> Language Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Loader Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:05:39 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Session Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:05:39 --> Session routines successfully run
DEBUG - 2012-02-01 22:05:39 --> Cart Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Model Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Model Class Initialized
DEBUG - 2012-02-01 22:05:39 --> Controller Class Initialized
DEBUG - 2012-02-01 22:05:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:05:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:05:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:05:39 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:05:39 --> Final output sent to browser
DEBUG - 2012-02-01 22:05:39 --> Total execution time: 0.7800
DEBUG - 2012-02-01 22:05:42 --> Config Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:05:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:05:42 --> URI Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Router Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Output Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Security Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Input Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:05:42 --> Language Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Loader Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:05:42 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Session Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:05:42 --> Session routines successfully run
DEBUG - 2012-02-01 22:05:42 --> Cart Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Model Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Model Class Initialized
DEBUG - 2012-02-01 22:05:42 --> Controller Class Initialized
ERROR - 2012-02-01 22:05:43 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:08:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:08:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:08:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Router Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Output Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Security Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Input Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:08:35 --> Language Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Loader Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:08:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Session Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:08:35 --> Session routines successfully run
DEBUG - 2012-02-01 22:08:35 --> Cart Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:35 --> Controller Class Initialized
ERROR - 2012-02-01 22:08:35 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 22:08:47 --> Config Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:08:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:08:47 --> URI Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Router Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Output Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Security Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Input Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:08:47 --> Language Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Loader Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:08:47 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Session Class Initialized
DEBUG - 2012-02-01 22:08:47 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:08:48 --> Session routines successfully run
DEBUG - 2012-02-01 22:08:48 --> Cart Class Initialized
DEBUG - 2012-02-01 22:08:48 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:48 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:48 --> Controller Class Initialized
DEBUG - 2012-02-01 22:08:48 --> Config Class Initialized
DEBUG - 2012-02-01 22:08:48 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:08:48 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:08:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:08:48 --> URI Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Router Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Output Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Security Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Input Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:08:49 --> Language Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Loader Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:08:49 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Session Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:08:49 --> Session routines successfully run
DEBUG - 2012-02-01 22:08:49 --> Cart Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:49 --> Controller Class Initialized
DEBUG - 2012-02-01 22:08:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:08:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:08:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:08:49 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:08:49 --> Final output sent to browser
DEBUG - 2012-02-01 22:08:49 --> Total execution time: 0.4619
DEBUG - 2012-02-01 22:08:50 --> Config Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:08:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:08:50 --> URI Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Router Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Output Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Security Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Input Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:08:50 --> Language Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Loader Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:08:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Session Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:08:50 --> Session routines successfully run
DEBUG - 2012-02-01 22:08:50 --> Cart Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:50 --> Controller Class Initialized
ERROR - 2012-02-01 22:08:50 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:08:54 --> Config Class Initialized
DEBUG - 2012-02-01 22:08:54 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:08:54 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:08:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:08:54 --> URI Class Initialized
DEBUG - 2012-02-01 22:08:54 --> Router Class Initialized
DEBUG - 2012-02-01 22:08:54 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:08:54 --> Output Class Initialized
DEBUG - 2012-02-01 22:08:54 --> Security Class Initialized
DEBUG - 2012-02-01 22:08:54 --> Input Class Initialized
DEBUG - 2012-02-01 22:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:08:54 --> Language Class Initialized
DEBUG - 2012-02-01 22:08:54 --> Loader Class Initialized
DEBUG - 2012-02-01 22:08:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:08:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:08:55 --> Session Class Initialized
DEBUG - 2012-02-01 22:08:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:08:55 --> Session routines successfully run
DEBUG - 2012-02-01 22:08:55 --> Cart Class Initialized
DEBUG - 2012-02-01 22:08:55 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:55 --> Model Class Initialized
DEBUG - 2012-02-01 22:08:55 --> Controller Class Initialized
DEBUG - 2012-02-01 22:08:55 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:08:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:08:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:08:55 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:08:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:08:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:08:56 --> Final output sent to browser
DEBUG - 2012-02-01 22:08:56 --> Total execution time: 1.2713
DEBUG - 2012-02-01 22:09:43 --> Config Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:09:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:09:43 --> URI Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Router Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Output Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Security Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Input Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:09:43 --> Language Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Loader Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:09:43 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Session Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:09:43 --> Session routines successfully run
DEBUG - 2012-02-01 22:09:43 --> Cart Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Controller Class Initialized
DEBUG - 2012-02-01 22:09:43 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:09:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:09:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:09:43 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:09:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:09:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:09:44 --> Final output sent to browser
DEBUG - 2012-02-01 22:09:44 --> Total execution time: 0.4701
DEBUG - 2012-02-01 22:09:44 --> Config Class Initialized
DEBUG - 2012-02-01 22:09:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:09:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:09:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:09:44 --> URI Class Initialized
DEBUG - 2012-02-01 22:09:44 --> Router Class Initialized
ERROR - 2012-02-01 22:09:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:09:47 --> Config Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:09:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:09:47 --> URI Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Router Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Output Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Security Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Input Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:09:47 --> Language Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Loader Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:09:47 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Session Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:09:47 --> Session routines successfully run
DEBUG - 2012-02-01 22:09:47 --> Cart Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Controller Class Initialized
DEBUG - 2012-02-01 22:09:47 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:09:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:09:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:09:48 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:09:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:09:48 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 22:09:48 --> Final output sent to browser
DEBUG - 2012-02-01 22:09:48 --> Total execution time: 0.5007
DEBUG - 2012-02-01 22:09:48 --> Config Class Initialized
DEBUG - 2012-02-01 22:09:48 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:09:48 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:09:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:09:48 --> URI Class Initialized
DEBUG - 2012-02-01 22:09:48 --> Router Class Initialized
ERROR - 2012-02-01 22:09:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:09:50 --> Config Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:09:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:09:50 --> URI Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Router Class Initialized
DEBUG - 2012-02-01 22:09:50 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:09:50 --> Output Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Security Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Input Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:09:50 --> Language Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Loader Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:09:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Session Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:09:50 --> Session routines successfully run
DEBUG - 2012-02-01 22:09:50 --> Cart Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Controller Class Initialized
DEBUG - 2012-02-01 22:09:50 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:09:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:09:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:09:50 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:09:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:09:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:09:50 --> Final output sent to browser
DEBUG - 2012-02-01 22:09:50 --> Total execution time: 0.7185
DEBUG - 2012-02-01 22:09:51 --> Config Class Initialized
DEBUG - 2012-02-01 22:09:51 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:09:51 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:09:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:09:51 --> URI Class Initialized
DEBUG - 2012-02-01 22:09:51 --> Router Class Initialized
ERROR - 2012-02-01 22:09:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:09:59 --> Config Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:09:59 --> URI Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Router Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Output Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Security Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Input Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:09:59 --> Language Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Loader Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:09:59 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Session Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:09:59 --> Session routines successfully run
DEBUG - 2012-02-01 22:09:59 --> Cart Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:09:59 --> Controller Class Initialized
DEBUG - 2012-02-01 22:09:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:09:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:09:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:09:59 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:09:59 --> Final output sent to browser
DEBUG - 2012-02-01 22:09:59 --> Total execution time: 0.4931
DEBUG - 2012-02-01 22:10:00 --> Config Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Config Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:10:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:10:00 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:10:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:10:00 --> URI Class Initialized
DEBUG - 2012-02-01 22:10:00 --> URI Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Router Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Router Class Initialized
ERROR - 2012-02-01 22:10:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:10:00 --> Output Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Security Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Input Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:10:00 --> Language Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Loader Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Config Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:10:00 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:10:00 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:10:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:10:01 --> URI Class Initialized
DEBUG - 2012-02-01 22:10:01 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:10:01 --> Router Class Initialized
ERROR - 2012-02-01 22:10:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:10:01 --> Session Class Initialized
DEBUG - 2012-02-01 22:10:01 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:10:01 --> Session routines successfully run
DEBUG - 2012-02-01 22:10:01 --> Cart Class Initialized
DEBUG - 2012-02-01 22:10:01 --> Model Class Initialized
DEBUG - 2012-02-01 22:10:01 --> Model Class Initialized
DEBUG - 2012-02-01 22:10:01 --> Controller Class Initialized
ERROR - 2012-02-01 22:10:01 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:11:22 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:22 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Router Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Output Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Security Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Input Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:11:22 --> Language Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Loader Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:11:22 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Session Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:11:22 --> Session routines successfully run
DEBUG - 2012-02-01 22:11:22 --> Cart Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:22 --> Controller Class Initialized
DEBUG - 2012-02-01 22:11:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:11:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:11:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:11:22 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:11:22 --> Final output sent to browser
DEBUG - 2012-02-01 22:11:22 --> Total execution time: 0.3837
DEBUG - 2012-02-01 22:11:23 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:23 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:23 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Router Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Router Class Initialized
ERROR - 2012-02-01 22:11:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:11:23 --> Output Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Security Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Input Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:11:23 --> Language Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Loader Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:11:23 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:11:23 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Router Class Initialized
ERROR - 2012-02-01 22:11:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:11:23 --> Session Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:11:23 --> Session routines successfully run
DEBUG - 2012-02-01 22:11:23 --> Cart Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:23 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:24 --> Controller Class Initialized
ERROR - 2012-02-01 22:11:24 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:11:40 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:40 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Router Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Output Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Security Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Input Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:11:40 --> Language Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Loader Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:11:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Session Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:11:40 --> Session routines successfully run
DEBUG - 2012-02-01 22:11:40 --> Cart Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Controller Class Initialized
DEBUG - 2012-02-01 22:11:40 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:11:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:11:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:11:40 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:11:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:11:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:11:40 --> Final output sent to browser
DEBUG - 2012-02-01 22:11:40 --> Total execution time: 0.4519
DEBUG - 2012-02-01 22:11:41 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:41 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:41 --> Router Class Initialized
ERROR - 2012-02-01 22:11:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:11:42 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:42 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Router Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Output Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Security Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Input Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:11:42 --> Language Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Loader Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:11:42 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Session Class Initialized
DEBUG - 2012-02-01 22:11:42 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:11:43 --> Session routines successfully run
DEBUG - 2012-02-01 22:11:43 --> Cart Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Controller Class Initialized
DEBUG - 2012-02-01 22:11:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:11:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:11:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:11:43 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:11:43 --> Final output sent to browser
DEBUG - 2012-02-01 22:11:43 --> Total execution time: 0.4352
DEBUG - 2012-02-01 22:11:43 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:43 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:43 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Router Class Initialized
DEBUG - 2012-02-01 22:11:43 --> Router Class Initialized
ERROR - 2012-02-01 22:11:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:11:44 --> Output Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Security Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Input Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:11:44 --> Language Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Loader Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Config Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:11:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:11:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:11:44 --> URI Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Router Class Initialized
ERROR - 2012-02-01 22:11:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:11:44 --> Session Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:11:44 --> Session routines successfully run
DEBUG - 2012-02-01 22:11:44 --> Cart Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Model Class Initialized
DEBUG - 2012-02-01 22:11:44 --> Controller Class Initialized
ERROR - 2012-02-01 22:11:44 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:12:04 --> Config Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:12:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:12:04 --> URI Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Router Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Output Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Security Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Input Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:12:04 --> Language Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Loader Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:12:04 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Session Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:12:04 --> Session routines successfully run
DEBUG - 2012-02-01 22:12:04 --> Cart Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Model Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Model Class Initialized
DEBUG - 2012-02-01 22:12:04 --> Controller Class Initialized
DEBUG - 2012-02-01 22:12:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:12:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:12:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:12:04 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:12:04 --> Final output sent to browser
DEBUG - 2012-02-01 22:12:04 --> Total execution time: 0.4505
DEBUG - 2012-02-01 22:12:05 --> Config Class Initialized
DEBUG - 2012-02-01 22:12:05 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:12:05 --> Config Class Initialized
DEBUG - 2012-02-01 22:12:05 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:12:05 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:12:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:12:05 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:12:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:12:05 --> URI Class Initialized
DEBUG - 2012-02-01 22:12:05 --> URI Class Initialized
DEBUG - 2012-02-01 22:12:05 --> Router Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Router Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Output Class Initialized
ERROR - 2012-02-01 22:12:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:12:06 --> Security Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Input Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:12:06 --> Language Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Loader Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:12:06 --> Config Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:12:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:12:06 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:12:06 --> URI Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Router Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Session Class Initialized
ERROR - 2012-02-01 22:12:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:12:06 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:12:06 --> Session routines successfully run
DEBUG - 2012-02-01 22:12:06 --> Cart Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Model Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Model Class Initialized
DEBUG - 2012-02-01 22:12:06 --> Controller Class Initialized
ERROR - 2012-02-01 22:12:06 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:23:29 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:29 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Output Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Security Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Input Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:23:29 --> Language Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Loader Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:23:29 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Session Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:23:29 --> Session routines successfully run
DEBUG - 2012-02-01 22:23:29 --> Cart Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Controller Class Initialized
DEBUG - 2012-02-01 22:23:29 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:23:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:23:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:23:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:23:29 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:23:29 --> Final output sent to browser
DEBUG - 2012-02-01 22:23:29 --> Total execution time: 0.4461
DEBUG - 2012-02-01 22:23:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Router Class Initialized
ERROR - 2012-02-01 22:23:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:23:31 --> Output Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Security Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Input Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:23:31 --> Language Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Loader Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:23:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:31 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:23:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Session Class Initialized
ERROR - 2012-02-01 22:23:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:23:31 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:23:31 --> Session routines successfully run
DEBUG - 2012-02-01 22:23:31 --> Cart Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Controller Class Initialized
DEBUG - 2012-02-01 22:23:31 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:23:31 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:23:34 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:34 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Output Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Security Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Input Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:23:34 --> Language Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Loader Class Initialized
DEBUG - 2012-02-01 22:23:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:23:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Session Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:23:35 --> Session routines successfully run
DEBUG - 2012-02-01 22:23:35 --> Cart Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Controller Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:23:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Output Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Security Class Initialized
DEBUG - 2012-02-01 22:23:35 --> Input Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:23:36 --> Language Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Loader Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:23:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Session Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:23:36 --> Session routines successfully run
DEBUG - 2012-02-01 22:23:36 --> Cart Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Controller Class Initialized
DEBUG - 2012-02-01 22:23:36 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:23:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:23:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:23:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:23:36 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:23:36 --> Final output sent to browser
DEBUG - 2012-02-01 22:23:36 --> Total execution time: 0.8178
DEBUG - 2012-02-01 22:23:37 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:37 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:37 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:37 --> URI Class Initialized
ERROR - 2012-02-01 22:23:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:23:37 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Output Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Security Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Input Class Initialized
DEBUG - 2012-02-01 22:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:23:38 --> Language Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Loader Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:23:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:38 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Router Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Database Driver Class Initialized
ERROR - 2012-02-01 22:23:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:23:38 --> Session Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:23:38 --> Session routines successfully run
DEBUG - 2012-02-01 22:23:38 --> Cart Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Model Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Controller Class Initialized
DEBUG - 2012-02-01 22:23:38 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:23:38 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:23:47 --> Config Class Initialized
DEBUG - 2012-02-01 22:23:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:23:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:23:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:23:47 --> URI Class Initialized
DEBUG - 2012-02-01 22:23:47 --> Router Class Initialized
ERROR - 2012-02-01 22:23:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:25:33 --> Config Class Initialized
DEBUG - 2012-02-01 22:25:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:25:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:25:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:25:33 --> URI Class Initialized
DEBUG - 2012-02-01 22:25:33 --> Router Class Initialized
ERROR - 2012-02-01 22:25:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:25:43 --> Config Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:25:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:25:43 --> URI Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Router Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Output Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Security Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Input Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:25:43 --> Language Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Loader Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:25:43 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Session Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:25:43 --> Session routines successfully run
DEBUG - 2012-02-01 22:25:43 --> Cart Class Initialized
DEBUG - 2012-02-01 22:25:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:25:44 --> Model Class Initialized
DEBUG - 2012-02-01 22:25:44 --> Controller Class Initialized
DEBUG - 2012-02-01 22:25:44 --> Config Class Initialized
DEBUG - 2012-02-01 22:25:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:25:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:25:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:25:44 --> URI Class Initialized
DEBUG - 2012-02-01 22:25:44 --> Router Class Initialized
ERROR - 2012-02-01 22:25:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:26:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Router Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Router Class Initialized
ERROR - 2012-02-01 22:26:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:26:31 --> Output Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Security Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Input Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:26:31 --> Language Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Loader Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:26:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:32 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Router Class Initialized
ERROR - 2012-02-01 22:26:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:26:32 --> Session Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:26:32 --> Session routines successfully run
DEBUG - 2012-02-01 22:26:32 --> Cart Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Controller Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:26:32 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:26:32 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:32 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Router Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Output Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Security Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Input Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:26:32 --> Language Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Loader Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:26:32 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Session Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:26:32 --> Session routines successfully run
DEBUG - 2012-02-01 22:26:32 --> Cart Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Controller Class Initialized
DEBUG - 2012-02-01 22:26:32 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:26:33 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:33 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Router Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Output Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Security Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Input Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:26:33 --> Language Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Loader Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:26:33 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Session Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:26:33 --> Session routines successfully run
DEBUG - 2012-02-01 22:26:33 --> Cart Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Controller Class Initialized
DEBUG - 2012-02-01 22:26:33 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:26:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:26:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:26:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:26:34 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:26:34 --> Final output sent to browser
DEBUG - 2012-02-01 22:26:34 --> Total execution time: 1.0706
DEBUG - 2012-02-01 22:26:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:35 --> Router Class Initialized
DEBUG - 2012-02-01 22:26:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Router Class Initialized
ERROR - 2012-02-01 22:26:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:26:35 --> Output Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Security Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Input Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:26:35 --> Language Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Loader Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:26:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Router Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Database Driver Class Initialized
ERROR - 2012-02-01 22:26:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:26:35 --> Session Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:26:35 --> Session routines successfully run
DEBUG - 2012-02-01 22:26:35 --> Cart Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Controller Class Initialized
DEBUG - 2012-02-01 22:26:35 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:26:35 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:26:50 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:50 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Router Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Output Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Security Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Input Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:26:50 --> Language Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Loader Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:26:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Session Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:26:50 --> Session routines successfully run
DEBUG - 2012-02-01 22:26:50 --> Cart Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Controller Class Initialized
DEBUG - 2012-02-01 22:26:50 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:26:50 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:26:51 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:51 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:51 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:51 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:51 --> Router Class Initialized
ERROR - 2012-02-01 22:26:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:26:55 --> Config Class Initialized
DEBUG - 2012-02-01 22:26:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:26:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:26:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:26:55 --> URI Class Initialized
DEBUG - 2012-02-01 22:26:55 --> Router Class Initialized
ERROR - 2012-02-01 22:26:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:27:58 --> Config Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:27:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:27:58 --> URI Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Router Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Output Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Security Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Input Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:27:58 --> Language Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Loader Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:27:58 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Session Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:27:58 --> Session routines successfully run
DEBUG - 2012-02-01 22:27:58 --> Cart Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Controller Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:27:58 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 22:27:58 --> Config Class Initialized
DEBUG - 2012-02-01 22:27:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:27:59 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:27:59 --> URI Class Initialized
DEBUG - 2012-02-01 22:27:59 --> Router Class Initialized
ERROR - 2012-02-01 22:27:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:28:07 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:07 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:07 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:07 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:07 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:07 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:07 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:28:08 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:08 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:08 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:08 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:08 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:08 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:08 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:28:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:28:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:28:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:28:08 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:28:08 --> Final output sent to browser
DEBUG - 2012-02-01 22:28:08 --> Total execution time: 0.5214
DEBUG - 2012-02-01 22:28:09 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:09 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:09 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:09 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:09 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:09 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:09 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:10 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:10 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Router Class Initialized
ERROR - 2012-02-01 22:28:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:28:10 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:10 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:10 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:10 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Database Driver Class Initialized
ERROR - 2012-02-01 22:28:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:28:10 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:10 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:10 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:10 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:28:10 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:28:14 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:14 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:14 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:28:14 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:14 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:14 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:14 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:14 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:14 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:28:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:28:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:28:14 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:28:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:28:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:28:14 --> Final output sent to browser
DEBUG - 2012-02-01 22:28:14 --> Total execution time: 0.5205
DEBUG - 2012-02-01 22:28:18 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:18 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:18 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:18 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:18 --> Router Class Initialized
ERROR - 2012-02-01 22:28:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 22:28:27 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:27 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:27 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:27 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:27 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:27 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:28:28 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:28 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:28 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:28 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:28 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:28:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:28:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:28:28 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:28:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:28:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:28:28 --> Final output sent to browser
DEBUG - 2012-02-01 22:28:28 --> Total execution time: 0.5412
DEBUG - 2012-02-01 22:28:36 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:36 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:36 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:36 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:36 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:36 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:28:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:28:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:28:36 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:28:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:28:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:28:36 --> Final output sent to browser
DEBUG - 2012-02-01 22:28:36 --> Total execution time: 0.5266
DEBUG - 2012-02-01 22:28:38 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:38 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:38 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:38 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:38 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:28:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:28:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:28:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:28:39 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:28:39 --> Final output sent to browser
DEBUG - 2012-02-01 22:28:39 --> Total execution time: 0.5593
DEBUG - 2012-02-01 22:28:39 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:39 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:39 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:40 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:40 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:40 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:40 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:28:40 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:28:57 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:57 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:57 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:57 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:57 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:57 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:28:57 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:57 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:57 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:58 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:58 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:58 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:58 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:58 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:28:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:28:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:28:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:28:58 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:28:58 --> Final output sent to browser
DEBUG - 2012-02-01 22:28:58 --> Total execution time: 0.5116
DEBUG - 2012-02-01 22:28:59 --> Config Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:28:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:28:59 --> URI Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Router Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Output Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Security Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Input Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:28:59 --> Language Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Loader Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:28:59 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Session Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:28:59 --> Session routines successfully run
DEBUG - 2012-02-01 22:28:59 --> Cart Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Controller Class Initialized
DEBUG - 2012-02-01 22:28:59 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:28:59 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:29:01 --> Config Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:29:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:29:01 --> URI Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Router Class Initialized
DEBUG - 2012-02-01 22:29:01 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:29:01 --> Output Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Security Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Input Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:29:01 --> Language Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Loader Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:29:01 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Session Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:29:01 --> Session routines successfully run
DEBUG - 2012-02-01 22:29:01 --> Cart Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Model Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Model Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Controller Class Initialized
DEBUG - 2012-02-01 22:29:01 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:29:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:29:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:29:01 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:29:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:29:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:29:01 --> Final output sent to browser
DEBUG - 2012-02-01 22:29:01 --> Total execution time: 0.6216
DEBUG - 2012-02-01 22:38:14 --> Config Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:38:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:38:14 --> URI Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Router Class Initialized
DEBUG - 2012-02-01 22:38:14 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:38:14 --> Output Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Security Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Input Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:38:14 --> Language Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Loader Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:38:14 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Session Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:38:14 --> Session routines successfully run
DEBUG - 2012-02-01 22:38:14 --> Cart Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:38:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:38:15 --> Controller Class Initialized
DEBUG - 2012-02-01 22:38:15 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:38:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:38:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:38:15 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:38:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:38:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:38:15 --> Final output sent to browser
DEBUG - 2012-02-01 22:38:15 --> Total execution time: 0.5307
DEBUG - 2012-02-01 22:39:52 --> Config Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:39:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:39:52 --> URI Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Router Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Output Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Security Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Input Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:39:52 --> Language Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Loader Class Initialized
DEBUG - 2012-02-01 22:39:52 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:39:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:39:53 --> Session Class Initialized
DEBUG - 2012-02-01 22:39:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:39:53 --> Session routines successfully run
DEBUG - 2012-02-01 22:39:53 --> Cart Class Initialized
DEBUG - 2012-02-01 22:39:53 --> Model Class Initialized
DEBUG - 2012-02-01 22:39:53 --> Model Class Initialized
DEBUG - 2012-02-01 22:39:53 --> Controller Class Initialized
DEBUG - 2012-02-01 22:39:53 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:39:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:39:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:39:53 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:39:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:39:53 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:39:53 --> Final output sent to browser
DEBUG - 2012-02-01 22:39:53 --> Total execution time: 0.5095
DEBUG - 2012-02-01 22:39:55 --> Config Class Initialized
DEBUG - 2012-02-01 22:39:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:39:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:39:56 --> URI Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Router Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Output Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Security Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Input Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:39:56 --> Language Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Loader Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:39:56 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Session Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:39:56 --> Session routines successfully run
DEBUG - 2012-02-01 22:39:56 --> Cart Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Model Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Model Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Controller Class Initialized
DEBUG - 2012-02-01 22:39:56 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:39:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:39:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:39:56 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:39:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:39:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:39:57 --> Final output sent to browser
DEBUG - 2012-02-01 22:39:57 --> Total execution time: 1.1570
DEBUG - 2012-02-01 22:39:58 --> Config Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:39:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:39:58 --> URI Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Router Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Output Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Security Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Input Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:39:58 --> Language Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Loader Class Initialized
DEBUG - 2012-02-01 22:39:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:39:59 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:39:59 --> Session Class Initialized
DEBUG - 2012-02-01 22:39:59 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:39:59 --> Session routines successfully run
DEBUG - 2012-02-01 22:39:59 --> Cart Class Initialized
DEBUG - 2012-02-01 22:39:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:39:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:39:59 --> Controller Class Initialized
DEBUG - 2012-02-01 22:39:59 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:39:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:39:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:39:59 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:39:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:39:59 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 22:39:59 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:00 --> Total execution time: 0.5489
DEBUG - 2012-02-01 22:40:01 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:01 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:02 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:02 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:02 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:02 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:02 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:02 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:40:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:40:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:40:02 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:40:03 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:03 --> Total execution time: 1.1495
DEBUG - 2012-02-01 22:40:04 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:04 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:04 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:04 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:04 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:04 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:04 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:40:05 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:40:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:31 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:31 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:31 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:31 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:31 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:40:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:40:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:40:31 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:40:31 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:31 --> Total execution time: 0.5432
DEBUG - 2012-02-01 22:40:32 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:32 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:32 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:32 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:33 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:33 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:33 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:40:33 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:40:33 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:33 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:33 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:34 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:34 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:34 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:40:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:40:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:34 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:40:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:40:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:40:34 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:34 --> Total execution time: 0.5615
DEBUG - 2012-02-01 22:40:36 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:36 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:36 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:36 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:36 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:36 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:40:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:40:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:36 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:40:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:40:36 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 22:40:36 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:36 --> Total execution time: 0.5063
DEBUG - 2012-02-01 22:40:38 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:38 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:38 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:38 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:38 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:38 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:40:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:40:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:40:39 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:40:39 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:39 --> Total execution time: 1.0264
DEBUG - 2012-02-01 22:40:40 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:41 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:41 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:41 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:41 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:41 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:40:41 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:40:43 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:43 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:43 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:43 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:40:43 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:43 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:43 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:43 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:44 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:44 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:44 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:44 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:40:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:40:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:44 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:40:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:40:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:40:44 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:44 --> Total execution time: 0.9227
DEBUG - 2012-02-01 22:40:48 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:48 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:48 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:48 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:48 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:49 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:49 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:49 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:49 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:49 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:49 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:49 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:49 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:40:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:40:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:49 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:40:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:40:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:40:49 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:49 --> Total execution time: 1.2880
DEBUG - 2012-02-01 22:40:50 --> Config Class Initialized
DEBUG - 2012-02-01 22:40:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:40:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:40:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:40:50 --> URI Class Initialized
DEBUG - 2012-02-01 22:40:50 --> Router Class Initialized
DEBUG - 2012-02-01 22:40:50 --> Output Class Initialized
DEBUG - 2012-02-01 22:40:50 --> Security Class Initialized
DEBUG - 2012-02-01 22:40:50 --> Input Class Initialized
DEBUG - 2012-02-01 22:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:40:51 --> Language Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Loader Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:40:51 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Session Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:40:51 --> Session routines successfully run
DEBUG - 2012-02-01 22:40:51 --> Cart Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Model Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Controller Class Initialized
DEBUG - 2012-02-01 22:40:51 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:40:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:40:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:40:51 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:40:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:40:51 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 22:40:51 --> Final output sent to browser
DEBUG - 2012-02-01 22:40:51 --> Total execution time: 0.5143
DEBUG - 2012-02-01 22:41:29 --> Config Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:41:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:41:29 --> URI Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Router Class Initialized
DEBUG - 2012-02-01 22:41:29 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:41:29 --> Output Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Security Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Input Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:41:29 --> Language Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Loader Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:41:29 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Session Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:41:29 --> Session routines successfully run
DEBUG - 2012-02-01 22:41:29 --> Cart Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Controller Class Initialized
DEBUG - 2012-02-01 22:41:29 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:41:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:41:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:41:29 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:41:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:41:29 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:41:29 --> Final output sent to browser
DEBUG - 2012-02-01 22:41:29 --> Total execution time: 0.6244
DEBUG - 2012-02-01 22:41:53 --> Config Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:41:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:41:53 --> URI Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Router Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Output Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Security Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Input Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:41:53 --> Language Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Loader Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:41:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Session Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:41:53 --> Session routines successfully run
DEBUG - 2012-02-01 22:41:53 --> Cart Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Controller Class Initialized
DEBUG - 2012-02-01 22:41:53 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:41:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:41:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:41:53 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:41:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:41:53 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:41:54 --> Final output sent to browser
DEBUG - 2012-02-01 22:41:54 --> Total execution time: 0.5709
DEBUG - 2012-02-01 22:41:55 --> Config Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:41:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:41:55 --> URI Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Router Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Output Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Security Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Input Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:41:55 --> Language Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Loader Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:41:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Session Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:41:55 --> Session routines successfully run
DEBUG - 2012-02-01 22:41:55 --> Cart Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Controller Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:41:55 --> Config Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:41:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:41:55 --> URI Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Router Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Output Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Security Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Input Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:41:55 --> Language Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Loader Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:41:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:41:55 --> Session Class Initialized
DEBUG - 2012-02-01 22:41:56 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:41:56 --> Session routines successfully run
DEBUG - 2012-02-01 22:41:56 --> Cart Class Initialized
DEBUG - 2012-02-01 22:41:56 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:56 --> Model Class Initialized
DEBUG - 2012-02-01 22:41:56 --> Controller Class Initialized
DEBUG - 2012-02-01 22:41:56 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:41:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:41:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:41:56 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:41:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:41:56 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:41:56 --> Final output sent to browser
DEBUG - 2012-02-01 22:41:56 --> Total execution time: 0.5280
DEBUG - 2012-02-01 22:44:55 --> Config Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:44:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:44:55 --> URI Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Router Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Output Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Security Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Input Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:44:55 --> Language Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Loader Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:44:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Session Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:44:55 --> Session routines successfully run
DEBUG - 2012-02-01 22:44:55 --> Cart Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Model Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Model Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Controller Class Initialized
DEBUG - 2012-02-01 22:44:55 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:44:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:44:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:44:55 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:44:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:44:55 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 22:44:55 --> Final output sent to browser
DEBUG - 2012-02-01 22:44:55 --> Total execution time: 0.4954
DEBUG - 2012-02-01 22:45:01 --> Config Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:45:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:45:01 --> URI Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Router Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Output Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Security Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Input Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:45:01 --> Language Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Loader Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:45:01 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Session Class Initialized
DEBUG - 2012-02-01 22:45:01 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:45:01 --> Session routines successfully run
DEBUG - 2012-02-01 22:45:01 --> Cart Class Initialized
DEBUG - 2012-02-01 22:45:02 --> Model Class Initialized
DEBUG - 2012-02-01 22:45:02 --> Model Class Initialized
DEBUG - 2012-02-01 22:45:02 --> Controller Class Initialized
DEBUG - 2012-02-01 22:45:02 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:45:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:45:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:45:02 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:45:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:45:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:45:02 --> Final output sent to browser
DEBUG - 2012-02-01 22:45:02 --> Total execution time: 0.5743
DEBUG - 2012-02-01 22:45:05 --> Config Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:45:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:45:05 --> URI Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Router Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Output Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Security Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Input Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:45:05 --> Language Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Loader Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:45:05 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Session Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:45:05 --> Session routines successfully run
DEBUG - 2012-02-01 22:45:05 --> Cart Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Model Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Model Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Controller Class Initialized
DEBUG - 2012-02-01 22:45:05 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:45:06 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:45:06 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:45:06 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:45:06 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:45:06 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 22:45:06 --> Final output sent to browser
DEBUG - 2012-02-01 22:45:06 --> Total execution time: 0.5370
DEBUG - 2012-02-01 22:45:11 --> Config Class Initialized
DEBUG - 2012-02-01 22:45:11 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:45:11 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:45:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:45:11 --> URI Class Initialized
DEBUG - 2012-02-01 22:45:11 --> Router Class Initialized
DEBUG - 2012-02-01 22:45:11 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:45:11 --> Output Class Initialized
DEBUG - 2012-02-01 22:45:11 --> Security Class Initialized
DEBUG - 2012-02-01 22:45:11 --> Input Class Initialized
DEBUG - 2012-02-01 22:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:45:11 --> Language Class Initialized
DEBUG - 2012-02-01 22:45:11 --> Loader Class Initialized
DEBUG - 2012-02-01 22:45:12 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:45:12 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:45:12 --> Session Class Initialized
DEBUG - 2012-02-01 22:45:12 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:45:12 --> Session routines successfully run
DEBUG - 2012-02-01 22:45:12 --> Cart Class Initialized
DEBUG - 2012-02-01 22:45:12 --> Model Class Initialized
DEBUG - 2012-02-01 22:45:12 --> Model Class Initialized
DEBUG - 2012-02-01 22:45:12 --> Controller Class Initialized
DEBUG - 2012-02-01 22:45:12 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:45:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:45:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:45:12 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:45:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:45:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:45:12 --> Final output sent to browser
DEBUG - 2012-02-01 22:45:12 --> Total execution time: 1.3274
DEBUG - 2012-02-01 22:46:07 --> Config Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:46:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:46:07 --> URI Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Router Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Output Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Security Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Input Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:46:07 --> Language Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Loader Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:46:07 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Session Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:46:07 --> Session routines successfully run
DEBUG - 2012-02-01 22:46:07 --> Cart Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:07 --> Controller Class Initialized
DEBUG - 2012-02-01 22:46:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:46:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:46:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:46:07 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 22:46:08 --> Final output sent to browser
DEBUG - 2012-02-01 22:46:08 --> Total execution time: 0.4510
DEBUG - 2012-02-01 22:46:08 --> Config Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:46:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:46:08 --> URI Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Router Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Output Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Security Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Input Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:46:08 --> Language Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Loader Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:46:08 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Session Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:46:08 --> Session routines successfully run
DEBUG - 2012-02-01 22:46:08 --> Cart Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:08 --> Controller Class Initialized
ERROR - 2012-02-01 22:46:08 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:46:11 --> Config Class Initialized
DEBUG - 2012-02-01 22:46:11 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:46:11 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:46:11 --> URI Class Initialized
DEBUG - 2012-02-01 22:46:11 --> Router Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Output Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Security Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Input Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:46:12 --> Language Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Loader Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:46:12 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Session Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:46:12 --> Session routines successfully run
DEBUG - 2012-02-01 22:46:12 --> Cart Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:12 --> Controller Class Initialized
DEBUG - 2012-02-01 22:46:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:46:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:46:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:46:12 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 22:46:12 --> Final output sent to browser
DEBUG - 2012-02-01 22:46:12 --> Total execution time: 0.7036
DEBUG - 2012-02-01 22:46:13 --> Config Class Initialized
DEBUG - 2012-02-01 22:46:13 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:46:13 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:46:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:46:13 --> URI Class Initialized
DEBUG - 2012-02-01 22:46:13 --> Router Class Initialized
DEBUG - 2012-02-01 22:46:13 --> Output Class Initialized
DEBUG - 2012-02-01 22:46:13 --> Security Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Input Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:46:14 --> Language Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Loader Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:46:14 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Session Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:46:14 --> Session routines successfully run
DEBUG - 2012-02-01 22:46:14 --> Cart Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:46:14 --> Controller Class Initialized
ERROR - 2012-02-01 22:46:14 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:47:15 --> Config Class Initialized
DEBUG - 2012-02-01 22:47:15 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:47:15 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:47:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:47:15 --> URI Class Initialized
DEBUG - 2012-02-01 22:47:15 --> Router Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Output Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Security Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Input Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:47:16 --> Language Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Loader Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:47:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Session Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:47:16 --> Session routines successfully run
DEBUG - 2012-02-01 22:47:16 --> Cart Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Model Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Model Class Initialized
DEBUG - 2012-02-01 22:47:16 --> Controller Class Initialized
DEBUG - 2012-02-01 22:47:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:47:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:47:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:47:16 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 22:47:16 --> Final output sent to browser
DEBUG - 2012-02-01 22:47:16 --> Total execution time: 1.5715
DEBUG - 2012-02-01 22:47:17 --> Config Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:47:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:47:17 --> URI Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Router Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Output Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Security Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Input Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:47:17 --> Language Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Loader Class Initialized
DEBUG - 2012-02-01 22:47:17 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:47:18 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:47:18 --> Session Class Initialized
DEBUG - 2012-02-01 22:47:18 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:47:18 --> Session routines successfully run
DEBUG - 2012-02-01 22:47:18 --> Cart Class Initialized
DEBUG - 2012-02-01 22:47:18 --> Model Class Initialized
DEBUG - 2012-02-01 22:47:18 --> Model Class Initialized
DEBUG - 2012-02-01 22:47:18 --> Controller Class Initialized
ERROR - 2012-02-01 22:47:18 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:47:23 --> Config Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:47:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:47:23 --> URI Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Router Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Output Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Security Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Input Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:47:23 --> Language Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Loader Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:47:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Session Class Initialized
DEBUG - 2012-02-01 22:47:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:47:23 --> Session routines successfully run
DEBUG - 2012-02-01 22:47:23 --> Cart Class Initialized
DEBUG - 2012-02-01 22:47:24 --> Model Class Initialized
DEBUG - 2012-02-01 22:47:24 --> Model Class Initialized
DEBUG - 2012-02-01 22:47:24 --> Controller Class Initialized
DEBUG - 2012-02-01 22:47:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:47:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:47:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:47:24 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-02-01 22:47:24 --> Final output sent to browser
DEBUG - 2012-02-01 22:47:24 --> Total execution time: 0.4685
DEBUG - 2012-02-01 22:48:26 --> Config Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:48:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:48:26 --> URI Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Router Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Output Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Security Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Input Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:48:26 --> Language Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Loader Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:48:26 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Session Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:48:26 --> Session routines successfully run
DEBUG - 2012-02-01 22:48:26 --> Cart Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Model Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Model Class Initialized
DEBUG - 2012-02-01 22:48:26 --> Controller Class Initialized
ERROR - 2012-02-01 22:48:26 --> Severity: Notice  --> Undefined property: Category::$pagination A:\home\codeigniter.fool\www\application\controllers\admin\category.php 61
DEBUG - 2012-02-01 22:49:50 --> Config Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:49:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:49:50 --> URI Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Router Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Output Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Security Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Input Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:49:50 --> Language Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Loader Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:49:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Session Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:49:50 --> Session routines successfully run
DEBUG - 2012-02-01 22:49:50 --> Cart Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:49:50 --> Controller Class Initialized
DEBUG - 2012-02-01 22:49:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:49:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:49:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:49:50 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-02-01 22:49:50 --> Final output sent to browser
DEBUG - 2012-02-01 22:49:50 --> Total execution time: 0.5048
DEBUG - 2012-02-01 22:50:16 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:16 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:16 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:17 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:17 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:17 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:17 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:17 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:17 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:17 --> Controller Class Initialized
DEBUG - 2012-02-01 22:50:17 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:50:17 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:50:17 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:50:17 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-02-01 22:50:17 --> Final output sent to browser
DEBUG - 2012-02-01 22:50:17 --> Total execution time: 0.4540
DEBUG - 2012-02-01 22:50:22 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:22 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:22 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:22 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:22 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:22 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Controller Class Initialized
DEBUG - 2012-02-01 22:50:22 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:50:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:50:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:50:22 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:50:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:50:22 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:50:23 --> Final output sent to browser
DEBUG - 2012-02-01 22:50:23 --> Total execution time: 0.5409
DEBUG - 2012-02-01 22:50:24 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:24 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:24 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:24 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:24 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:24 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Controller Class Initialized
DEBUG - 2012-02-01 22:50:24 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:50:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:50:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:50:24 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:50:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:50:24 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 22:50:25 --> Final output sent to browser
DEBUG - 2012-02-01 22:50:25 --> Total execution time: 0.4856
DEBUG - 2012-02-01 22:50:26 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:26 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:26 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:26 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:26 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:26 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:26 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:26 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:26 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:27 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:27 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:27 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Controller Class Initialized
DEBUG - 2012-02-01 22:50:27 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 22:50:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:50:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:50:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:50:27 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 22:50:27 --> Final output sent to browser
DEBUG - 2012-02-01 22:50:27 --> Total execution time: 1.3266
DEBUG - 2012-02-01 22:50:28 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:28 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:28 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:29 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:29 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:29 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:29 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:29 --> Controller Class Initialized
DEBUG - 2012-02-01 22:50:29 --> Helper loaded: validate_helper
ERROR - 2012-02-01 22:50:29 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 22:50:30 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:30 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:30 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:30 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:30 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:30 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:30 --> Controller Class Initialized
DEBUG - 2012-02-01 22:50:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:50:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:50:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:50:30 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 22:50:30 --> Final output sent to browser
DEBUG - 2012-02-01 22:50:30 --> Total execution time: 0.4517
DEBUG - 2012-02-01 22:50:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:31 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:31 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:31 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:31 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:31 --> Controller Class Initialized
ERROR - 2012-02-01 22:50:31 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:50:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:36 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:36 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:36 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:36 --> Controller Class Initialized
ERROR - 2012-02-01 22:50:36 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:50:44 --> Config Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:50:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:50:44 --> URI Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Router Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Output Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Security Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Input Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:50:44 --> Language Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Loader Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:50:44 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Session Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:50:44 --> Session routines successfully run
DEBUG - 2012-02-01 22:50:44 --> Cart Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Model Class Initialized
DEBUG - 2012-02-01 22:50:44 --> Controller Class Initialized
ERROR - 2012-02-01 22:50:44 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:51:17 --> Config Class Initialized
DEBUG - 2012-02-01 22:51:17 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:51:17 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:51:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:51:18 --> URI Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Router Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Output Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Security Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Input Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:51:18 --> Language Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Loader Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:51:18 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Session Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:51:18 --> Session routines successfully run
DEBUG - 2012-02-01 22:51:18 --> Cart Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:18 --> Controller Class Initialized
ERROR - 2012-02-01 22:51:18 --> 404 Page Not Found --> page/lists
DEBUG - 2012-02-01 22:51:30 --> Config Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:51:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:51:30 --> URI Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Router Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Output Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Security Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Input Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:51:30 --> Language Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Loader Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:51:30 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Session Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:51:30 --> Session routines successfully run
DEBUG - 2012-02-01 22:51:30 --> Cart Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:30 --> Controller Class Initialized
ERROR - 2012-02-01 22:51:30 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:51:57 --> Config Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:51:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:51:57 --> URI Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Router Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Output Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Security Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Input Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:51:57 --> Language Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Loader Class Initialized
DEBUG - 2012-02-01 22:51:57 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:51:57 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Session Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:51:58 --> Session routines successfully run
DEBUG - 2012-02-01 22:51:58 --> Cart Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Controller Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Config Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:51:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:51:58 --> URI Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Router Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Output Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Security Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Input Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:51:58 --> Language Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Loader Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:51:58 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Session Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:51:58 --> Session routines successfully run
DEBUG - 2012-02-01 22:51:58 --> Cart Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:58 --> Controller Class Initialized
DEBUG - 2012-02-01 22:51:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:51:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:51:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:51:58 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 22:51:58 --> Final output sent to browser
DEBUG - 2012-02-01 22:51:58 --> Total execution time: 0.4416
DEBUG - 2012-02-01 22:51:59 --> Config Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:51:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:51:59 --> URI Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Router Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Output Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Security Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Input Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:51:59 --> Language Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Loader Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:51:59 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Session Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:51:59 --> Session routines successfully run
DEBUG - 2012-02-01 22:51:59 --> Cart Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:51:59 --> Controller Class Initialized
ERROR - 2012-02-01 22:51:59 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:52:03 --> Config Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:52:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:52:03 --> URI Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Router Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Output Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Security Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Input Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:52:03 --> Language Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Loader Class Initialized
DEBUG - 2012-02-01 22:52:03 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:52:04 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:52:04 --> Session Class Initialized
DEBUG - 2012-02-01 22:52:04 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:52:04 --> Session routines successfully run
DEBUG - 2012-02-01 22:52:04 --> Cart Class Initialized
DEBUG - 2012-02-01 22:52:04 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:04 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:04 --> Controller Class Initialized
DEBUG - 2012-02-01 22:52:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:52:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:52:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:52:04 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:52:04 --> Final output sent to browser
DEBUG - 2012-02-01 22:52:04 --> Total execution time: 0.9708
DEBUG - 2012-02-01 22:52:10 --> Config Class Initialized
DEBUG - 2012-02-01 22:52:10 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:52:10 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:52:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:52:10 --> URI Class Initialized
DEBUG - 2012-02-01 22:52:10 --> Router Class Initialized
DEBUG - 2012-02-01 22:52:10 --> Output Class Initialized
DEBUG - 2012-02-01 22:52:10 --> Security Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Input Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:52:11 --> Language Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Loader Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:52:11 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Session Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:52:11 --> Session routines successfully run
DEBUG - 2012-02-01 22:52:11 --> Cart Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:11 --> Controller Class Initialized
DEBUG - 2012-02-01 22:52:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:52:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:52:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:52:11 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:52:11 --> Final output sent to browser
DEBUG - 2012-02-01 22:52:11 --> Total execution time: 0.4250
DEBUG - 2012-02-01 22:52:12 --> Config Class Initialized
DEBUG - 2012-02-01 22:52:12 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:52:12 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:52:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:52:12 --> URI Class Initialized
DEBUG - 2012-02-01 22:52:12 --> Router Class Initialized
DEBUG - 2012-02-01 22:52:12 --> Output Class Initialized
DEBUG - 2012-02-01 22:52:12 --> Security Class Initialized
DEBUG - 2012-02-01 22:52:12 --> Input Class Initialized
DEBUG - 2012-02-01 22:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:52:13 --> Language Class Initialized
DEBUG - 2012-02-01 22:52:13 --> Loader Class Initialized
DEBUG - 2012-02-01 22:52:13 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:52:13 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:52:13 --> Session Class Initialized
DEBUG - 2012-02-01 22:52:13 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:52:13 --> Session routines successfully run
DEBUG - 2012-02-01 22:52:13 --> Cart Class Initialized
DEBUG - 2012-02-01 22:52:13 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:13 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:13 --> Controller Class Initialized
DEBUG - 2012-02-01 22:52:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:52:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:52:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:52:13 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:52:13 --> Final output sent to browser
DEBUG - 2012-02-01 22:52:13 --> Total execution time: 0.4286
DEBUG - 2012-02-01 22:52:16 --> Config Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:52:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:52:16 --> URI Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Router Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Output Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Security Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Input Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:52:16 --> Language Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Loader Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:52:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Session Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:52:16 --> Session routines successfully run
DEBUG - 2012-02-01 22:52:16 --> Cart Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Controller Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Config Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:52:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:52:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:52:16 --> URI Class Initialized
DEBUG - 2012-02-01 22:52:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:52:16 --> Router Class Initialized
DEBUG - 2012-02-01 22:52:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:52:16 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:52:16 --> Final output sent to browser
DEBUG - 2012-02-01 22:52:16 --> Total execution time: 0.8123
DEBUG - 2012-02-01 22:52:16 --> Output Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Security Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Input Class Initialized
DEBUG - 2012-02-01 22:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:52:16 --> Language Class Initialized
DEBUG - 2012-02-01 22:52:17 --> Loader Class Initialized
DEBUG - 2012-02-01 22:52:17 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:52:17 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:52:17 --> Session Class Initialized
DEBUG - 2012-02-01 22:52:17 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:52:17 --> Session routines successfully run
DEBUG - 2012-02-01 22:52:17 --> Cart Class Initialized
DEBUG - 2012-02-01 22:52:17 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:17 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:17 --> Controller Class Initialized
DEBUG - 2012-02-01 22:52:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:52:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:52:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:52:17 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:52:17 --> Final output sent to browser
DEBUG - 2012-02-01 22:52:17 --> Total execution time: 1.1841
DEBUG - 2012-02-01 22:52:18 --> Config Class Initialized
DEBUG - 2012-02-01 22:52:18 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:52:18 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:52:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:52:18 --> URI Class Initialized
DEBUG - 2012-02-01 22:52:18 --> Router Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Output Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Security Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Input Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:52:19 --> Language Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Loader Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:52:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Session Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:52:19 --> Session routines successfully run
DEBUG - 2012-02-01 22:52:19 --> Cart Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Model Class Initialized
DEBUG - 2012-02-01 22:52:19 --> Controller Class Initialized
DEBUG - 2012-02-01 22:52:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:52:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:52:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:52:19 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:52:19 --> Final output sent to browser
DEBUG - 2012-02-01 22:52:19 --> Total execution time: 0.5184
DEBUG - 2012-02-01 22:53:13 --> Config Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:53:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:53:13 --> URI Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Router Class Initialized
DEBUG - 2012-02-01 22:53:13 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:53:13 --> Output Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Security Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Input Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:53:13 --> Language Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Loader Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:53:13 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Session Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:53:13 --> Session routines successfully run
DEBUG - 2012-02-01 22:53:13 --> Cart Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Model Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Model Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Controller Class Initialized
DEBUG - 2012-02-01 22:53:13 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:53:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:53:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:53:14 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:53:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:53:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:53:14 --> Final output sent to browser
DEBUG - 2012-02-01 22:53:14 --> Total execution time: 0.4991
DEBUG - 2012-02-01 22:53:57 --> Config Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:53:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:53:57 --> URI Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Router Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Output Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Security Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Input Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:53:57 --> Language Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Loader Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:53:57 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:53:57 --> Session Class Initialized
DEBUG - 2012-02-01 22:53:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:53:58 --> Session routines successfully run
DEBUG - 2012-02-01 22:53:58 --> Cart Class Initialized
DEBUG - 2012-02-01 22:53:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:53:58 --> Model Class Initialized
DEBUG - 2012-02-01 22:53:58 --> Controller Class Initialized
DEBUG - 2012-02-01 22:53:58 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:53:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:53:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:53:58 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:53:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:53:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:53:58 --> Final output sent to browser
DEBUG - 2012-02-01 22:53:58 --> Total execution time: 0.6442
DEBUG - 2012-02-01 22:58:16 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:16 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:16 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:16 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:16 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:16 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:58:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:58:16 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 22:58:16 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:16 --> Total execution time: 0.4997
DEBUG - 2012-02-01 22:58:18 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:19 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:19 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:19 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:19 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:19 --> Controller Class Initialized
ERROR - 2012-02-01 22:58:19 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:58:20 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:20 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:20 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:20 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:20 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:20 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:20 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:58:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:58:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:20 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:58:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:58:20 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:58:21 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:21 --> Total execution time: 0.5139
DEBUG - 2012-02-01 22:58:23 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:23 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:23 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:23 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:23 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:23 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:24 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:24 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:58:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:58:24 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 22:58:24 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:24 --> Total execution time: 0.9556
DEBUG - 2012-02-01 22:58:25 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:25 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:25 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:25 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:25 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:25 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:25 --> Controller Class Initialized
ERROR - 2012-02-01 22:58:25 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 22:58:31 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:31 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:31 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:31 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:31 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:31 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:31 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:31 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:32 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:58:32 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:32 --> Total execution time: 0.9288
DEBUG - 2012-02-01 22:58:33 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:33 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:33 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:33 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:33 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:33 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:33 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:33 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:58:33 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:33 --> Total execution time: 0.5059
DEBUG - 2012-02-01 22:58:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:35 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:35 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:35 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:35 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:35 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 22:58:35 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:35 --> Total execution time: 0.5035
DEBUG - 2012-02-01 22:58:36 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:36 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:36 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:37 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:37 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:37 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:37 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:37 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:58:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:37 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:58:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 22:58:37 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:37 --> Total execution time: 1.1213
DEBUG - 2012-02-01 22:58:39 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:39 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:39 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:39 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:39 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:39 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:39 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:58:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:39 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:58:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:39 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 22:58:40 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:40 --> Total execution time: 0.5086
DEBUG - 2012-02-01 22:58:43 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:43 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:43 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:43 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:43 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:43 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:43 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:58:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:43 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:58:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 22:58:43 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:43 --> Total execution time: 0.6900
DEBUG - 2012-02-01 22:58:45 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:45 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:45 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:45 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:45 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:45 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:45 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:58:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:45 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:58:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:45 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 22:58:45 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:45 --> Total execution time: 0.4968
DEBUG - 2012-02-01 22:58:47 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:47 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:47 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:47 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:47 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:47 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:47 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:58:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:47 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:58:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:47 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 22:58:47 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:47 --> Total execution time: 0.5531
DEBUG - 2012-02-01 22:58:58 --> Config Class Initialized
DEBUG - 2012-02-01 22:58:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:58:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:58:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:58:58 --> URI Class Initialized
DEBUG - 2012-02-01 22:58:58 --> Router Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Output Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Security Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Input Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:58:59 --> Language Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Loader Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:58:59 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Session Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:58:59 --> Session routines successfully run
DEBUG - 2012-02-01 22:58:59 --> Cart Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Model Class Initialized
DEBUG - 2012-02-01 22:58:59 --> Controller Class Initialized
DEBUG - 2012-02-01 22:58:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:58:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:58:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:58:59 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-01 22:58:59 --> Final output sent to browser
DEBUG - 2012-02-01 22:58:59 --> Total execution time: 0.4423
DEBUG - 2012-02-01 22:59:00 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:00 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:00 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:00 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:01 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:01 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:01 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:01 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:01 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:01 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:01 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:01 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:01 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:01 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:01 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:01 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-01 22:59:01 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:01 --> Total execution time: 0.6978
DEBUG - 2012-02-01 22:59:04 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:04 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:04 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:04 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:04 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:05 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:05 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:05 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:05 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:05 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:05 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-01 22:59:05 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:05 --> Total execution time: 1.1881
DEBUG - 2012-02-01 22:59:12 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:12 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:12 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:12 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:12 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:12 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:12 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:12 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-01 22:59:12 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:12 --> Total execution time: 0.6196
DEBUG - 2012-02-01 22:59:14 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:14 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:14 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:14 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:14 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:14 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:14 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:14 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-01 22:59:14 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:14 --> Total execution time: 0.4428
DEBUG - 2012-02-01 22:59:19 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:19 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:19 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:19 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:19 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:19 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:19 --> XSS Filtering completed
DEBUG - 2012-02-01 22:59:19 --> XSS Filtering completed
DEBUG - 2012-02-01 22:59:19 --> XSS Filtering completed
DEBUG - 2012-02-01 22:59:21 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:21 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:21 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:21 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:59:21 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:21 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:21 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:21 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:21 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:21 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:59:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:21 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:59:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:59:21 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:21 --> Total execution time: 0.6080
DEBUG - 2012-02-01 22:59:23 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:23 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:23 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:23 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:23 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:23 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:59:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:59:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:23 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 22:59:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:59:23 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 22:59:23 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:23 --> Total execution time: 0.4962
DEBUG - 2012-02-01 22:59:25 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:25 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:25 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:25 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:25 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:25 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:26 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:26 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:26 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:26 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:26 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 22:59:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 22:59:26 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 22:59:26 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:26 --> Total execution time: 1.2809
DEBUG - 2012-02-01 22:59:34 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:34 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:34 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:34 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:34 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:34 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:34 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:59:34 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:34 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:34 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:34 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:34 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:59:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:34 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:59:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:59:35 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:35 --> Total execution time: 0.5417
DEBUG - 2012-02-01 22:59:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:35 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:35 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:35 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:35 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:35 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:59:35 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:35 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:35 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:36 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:36 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:36 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:36 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:59:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:36 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:59:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:59:36 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:36 --> Total execution time: 0.5571
DEBUG - 2012-02-01 22:59:37 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:37 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:37 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:37 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:37 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:37 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:37 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:38 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:59:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:38 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:59:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:59:38 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:38 --> Total execution time: 0.6817
DEBUG - 2012-02-01 22:59:39 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:39 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:39 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:39 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:39 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:40 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:40 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:40 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:41 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:41 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:41 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:41 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:41 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:41 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:42 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:42 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:42 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:42 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:42 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:42 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:43 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:59:43 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:43 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:43 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:43 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:43 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:43 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:59:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:43 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:59:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:59:43 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:43 --> Total execution time: 1.0074
DEBUG - 2012-02-01 22:59:45 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:45 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:45 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:45 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:45 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:45 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:45 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:46 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:46 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:46 --> File loaded: application/views/user/order_cart.php
DEBUG - 2012-02-01 22:59:46 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:46 --> Total execution time: 0.8793
DEBUG - 2012-02-01 22:59:50 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:50 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:50 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:50 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:50 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:50 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:51 --> Config Class Initialized
DEBUG - 2012-02-01 22:59:51 --> Hooks Class Initialized
DEBUG - 2012-02-01 22:59:51 --> Utf8 Class Initialized
DEBUG - 2012-02-01 22:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 22:59:51 --> URI Class Initialized
DEBUG - 2012-02-01 22:59:52 --> Router Class Initialized
DEBUG - 2012-02-01 22:59:52 --> No URI present. Default controller set.
DEBUG - 2012-02-01 22:59:52 --> Output Class Initialized
DEBUG - 2012-02-01 22:59:52 --> Security Class Initialized
DEBUG - 2012-02-01 22:59:52 --> Input Class Initialized
DEBUG - 2012-02-01 22:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 22:59:52 --> Language Class Initialized
DEBUG - 2012-02-01 22:59:52 --> Loader Class Initialized
DEBUG - 2012-02-01 22:59:52 --> Helper loaded: url_helper
DEBUG - 2012-02-01 22:59:52 --> Database Driver Class Initialized
DEBUG - 2012-02-01 22:59:53 --> Session Class Initialized
DEBUG - 2012-02-01 22:59:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 22:59:53 --> Session routines successfully run
DEBUG - 2012-02-01 22:59:53 --> Cart Class Initialized
DEBUG - 2012-02-01 22:59:53 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:53 --> Model Class Initialized
DEBUG - 2012-02-01 22:59:53 --> Controller Class Initialized
DEBUG - 2012-02-01 22:59:53 --> Pagination Class Initialized
DEBUG - 2012-02-01 22:59:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 22:59:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 22:59:53 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 22:59:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 22:59:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 22:59:53 --> Final output sent to browser
DEBUG - 2012-02-01 22:59:53 --> Total execution time: 2.6384
DEBUG - 2012-02-01 23:00:01 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:01 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:01 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:01 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:01 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:01 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:01 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:01 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:02 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:02 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:02 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:02 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:02 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:02 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:00:02 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:00:02 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:02 --> Total execution time: 0.8066
DEBUG - 2012-02-01 23:00:02 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:02 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:02 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:02 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:02 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:00:03 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:03 --> Total execution time: 0.8083
DEBUG - 2012-02-01 23:00:04 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:04 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:04 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:04 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:04 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:04 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:04 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:00:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:04 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:00:05 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:05 --> Total execution time: 0.6041
DEBUG - 2012-02-01 23:00:05 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:05 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:05 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:05 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:06 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:06 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:06 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:06 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:06 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:06 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:06 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:06 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:06 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:00:06 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:00:19 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:19 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:19 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:19 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:19 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:19 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:00:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:19 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:00:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:19 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:00:20 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:20 --> Total execution time: 0.5936
DEBUG - 2012-02-01 23:00:24 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:24 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:24 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:24 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:24 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:24 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:24 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:24 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:00:24 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:24 --> Total execution time: 0.4052
DEBUG - 2012-02-01 23:00:27 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:27 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:27 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:27 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:27 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:27 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:27 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:27 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:27 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:28 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:00:28 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:28 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:28 --> Total execution time: 1.0059
DEBUG - 2012-02-01 23:00:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:28 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:28 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:28 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:28 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:00:28 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:28 --> Total execution time: 0.9141
DEBUG - 2012-02-01 23:00:29 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:29 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:29 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:29 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:29 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:29 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:29 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:29 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:00:29 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:29 --> Total execution time: 0.4323
DEBUG - 2012-02-01 23:00:31 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:31 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:31 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:31 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:31 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:31 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:31 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:31 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:00:31 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:31 --> Total execution time: 0.5409
DEBUG - 2012-02-01 23:00:35 --> Config Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:00:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:00:35 --> URI Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Router Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Output Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Security Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Input Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:00:35 --> Language Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Loader Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:00:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Session Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:00:35 --> Session routines successfully run
DEBUG - 2012-02-01 23:00:35 --> Cart Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Controller Class Initialized
DEBUG - 2012-02-01 23:00:35 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:00:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:00:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:00:36 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:00:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:00:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:00:36 --> Final output sent to browser
DEBUG - 2012-02-01 23:00:36 --> Total execution time: 0.7890
DEBUG - 2012-02-01 23:05:11 --> Config Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:05:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:05:11 --> URI Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Router Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Output Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Security Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Input Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:05:11 --> Language Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Loader Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:05:11 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Session Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:05:11 --> Session routines successfully run
DEBUG - 2012-02-01 23:05:11 --> Cart Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Model Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Model Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Controller Class Initialized
DEBUG - 2012-02-01 23:05:11 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Config Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:05:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:05:24 --> URI Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Router Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Output Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Security Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Input Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:05:24 --> Language Class Initialized
DEBUG - 2012-02-01 23:05:24 --> Loader Class Initialized
DEBUG - 2012-02-01 23:05:25 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:05:25 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:05:25 --> Session Class Initialized
DEBUG - 2012-02-01 23:05:25 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:05:25 --> Session routines successfully run
DEBUG - 2012-02-01 23:05:25 --> Cart Class Initialized
DEBUG - 2012-02-01 23:05:25 --> Model Class Initialized
DEBUG - 2012-02-01 23:05:25 --> Model Class Initialized
DEBUG - 2012-02-01 23:05:25 --> Controller Class Initialized
DEBUG - 2012-02-01 23:05:25 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:05:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:05:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:05:25 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:05:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:05:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:05:25 --> Final output sent to browser
DEBUG - 2012-02-01 23:05:25 --> Total execution time: 1.7612
DEBUG - 2012-02-01 23:05:28 --> Config Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:05:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:05:28 --> URI Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Router Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Output Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Security Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Input Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:05:28 --> Language Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Loader Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:05:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Session Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:05:28 --> Session routines successfully run
DEBUG - 2012-02-01 23:05:28 --> Cart Class Initialized
DEBUG - 2012-02-01 23:05:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:05:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:05:29 --> Controller Class Initialized
DEBUG - 2012-02-01 23:05:29 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:05:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:05:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:05:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:05:29 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:05:29 --> Final output sent to browser
DEBUG - 2012-02-01 23:05:29 --> Total execution time: 0.9338
DEBUG - 2012-02-01 23:07:19 --> Config Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:07:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:07:19 --> URI Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Router Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Output Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Security Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Input Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:07:19 --> Language Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Loader Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:07:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Session Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:07:19 --> Session routines successfully run
DEBUG - 2012-02-01 23:07:19 --> Cart Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Controller Class Initialized
DEBUG - 2012-02-01 23:07:19 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:07:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:07:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:07:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:07:19 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:07:19 --> Final output sent to browser
DEBUG - 2012-02-01 23:07:19 --> Total execution time: 0.4872
DEBUG - 2012-02-01 23:07:25 --> Config Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:07:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:07:25 --> URI Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Router Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Output Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Security Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Input Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:07:25 --> Language Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Loader Class Initialized
DEBUG - 2012-02-01 23:07:25 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:07:25 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:07:26 --> Session Class Initialized
DEBUG - 2012-02-01 23:07:26 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:07:26 --> Session routines successfully run
DEBUG - 2012-02-01 23:07:26 --> Cart Class Initialized
DEBUG - 2012-02-01 23:07:26 --> Model Class Initialized
DEBUG - 2012-02-01 23:07:26 --> Model Class Initialized
DEBUG - 2012-02-01 23:07:26 --> Controller Class Initialized
DEBUG - 2012-02-01 23:07:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:07:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:07:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:07:26 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 23:07:26 --> Final output sent to browser
DEBUG - 2012-02-01 23:07:26 --> Total execution time: 0.4932
DEBUG - 2012-02-01 23:07:54 --> Config Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:07:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:07:54 --> URI Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Router Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Output Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Security Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Input Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:07:54 --> Language Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Loader Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:07:54 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Session Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:07:54 --> Session routines successfully run
DEBUG - 2012-02-01 23:07:54 --> Cart Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Model Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Model Class Initialized
DEBUG - 2012-02-01 23:07:54 --> Controller Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Config Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:08:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:08:27 --> URI Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Router Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Output Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Security Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Input Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:08:27 --> Language Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Loader Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:08:27 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Session Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:08:27 --> Session routines successfully run
DEBUG - 2012-02-01 23:08:27 --> Cart Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Controller Class Initialized
DEBUG - 2012-02-01 23:08:27 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:08:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:08:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:08:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:08:27 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 23:08:27 --> Final output sent to browser
DEBUG - 2012-02-01 23:08:27 --> Total execution time: 0.4269
DEBUG - 2012-02-01 23:08:28 --> Config Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:08:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:08:28 --> URI Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Router Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Output Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Security Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Input Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:08:28 --> Language Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Loader Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:08:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:08:28 --> Session Class Initialized
DEBUG - 2012-02-01 23:08:29 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:08:29 --> Session routines successfully run
DEBUG - 2012-02-01 23:08:29 --> Cart Class Initialized
DEBUG - 2012-02-01 23:08:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:29 --> Controller Class Initialized
ERROR - 2012-02-01 23:08:29 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 23:08:32 --> Config Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:08:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:08:32 --> URI Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Router Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Output Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Security Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Input Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:08:32 --> Language Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Loader Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:08:32 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Session Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:08:32 --> Session routines successfully run
DEBUG - 2012-02-01 23:08:32 --> Cart Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:32 --> Controller Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:08:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:08:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:08:33 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:08:33 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 23:08:33 --> Final output sent to browser
DEBUG - 2012-02-01 23:08:33 --> Total execution time: 0.5360
DEBUG - 2012-02-01 23:08:33 --> Config Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:08:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:08:33 --> URI Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Router Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Output Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Security Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Input Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:08:33 --> Language Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Loader Class Initialized
DEBUG - 2012-02-01 23:08:33 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:08:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:08:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:08:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Controller Class Initialized
ERROR - 2012-02-01 23:08:34 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 23:08:34 --> Config Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:08:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:08:34 --> URI Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Router Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Output Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Security Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Input Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:08:34 --> Language Class Initialized
DEBUG - 2012-02-01 23:08:34 --> Loader Class Initialized
DEBUG - 2012-02-01 23:08:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:08:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:08:35 --> Session Class Initialized
DEBUG - 2012-02-01 23:08:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:08:35 --> Session routines successfully run
DEBUG - 2012-02-01 23:08:35 --> Cart Class Initialized
DEBUG - 2012-02-01 23:08:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:35 --> Controller Class Initialized
DEBUG - 2012-02-01 23:08:35 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:08:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:08:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:08:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:08:35 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 23:08:35 --> Final output sent to browser
DEBUG - 2012-02-01 23:08:35 --> Total execution time: 1.0056
DEBUG - 2012-02-01 23:08:36 --> Config Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:08:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:08:36 --> URI Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Router Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Output Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Security Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Input Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:08:36 --> Language Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Loader Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:08:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Session Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:08:36 --> Session routines successfully run
DEBUG - 2012-02-01 23:08:36 --> Cart Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:36 --> Controller Class Initialized
ERROR - 2012-02-01 23:08:36 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 23:08:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:08:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:08:38 --> URI Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Router Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Output Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Security Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Input Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:08:38 --> Language Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Loader Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:08:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Session Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:08:38 --> Session routines successfully run
DEBUG - 2012-02-01 23:08:38 --> Cart Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:08:38 --> Controller Class Initialized
DEBUG - 2012-02-01 23:08:39 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:08:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:08:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:08:39 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:08:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:08:39 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:08:39 --> Final output sent to browser
DEBUG - 2012-02-01 23:08:39 --> Total execution time: 0.4940
DEBUG - 2012-02-01 23:09:36 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:36 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:37 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:37 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:37 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:37 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:37 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:09:37 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:09:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:37 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:09:37 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:37 --> Total execution time: 0.4525
DEBUG - 2012-02-01 23:09:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:38 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:38 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:38 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:38 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:38 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:09:38 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:09:39 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:39 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:39 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:40 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:40 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:40 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:40 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:09:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:40 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:09:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:09:40 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:40 --> Total execution time: 0.9149
DEBUG - 2012-02-01 23:09:42 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:42 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:42 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:42 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:42 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:42 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:42 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:09:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:42 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:09:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:09:42 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:42 --> Total execution time: 0.5114
DEBUG - 2012-02-01 23:09:44 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:44 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:44 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:44 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:44 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:44 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:44 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:09:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:44 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:44 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:09:44 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:44 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:09:44 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:44 --> Total execution time: 0.4725
DEBUG - 2012-02-01 23:09:47 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:47 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:47 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:47 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:47 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:48 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:48 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:48 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:48 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:48 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:48 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:48 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:09:48 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:09:48 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:09:48 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:48 --> Total execution time: 1.0113
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:48 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:09:48 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:48 --> Total execution time: 0.9635
DEBUG - 2012-02-01 23:09:50 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:50 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:50 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:51 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:51 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:51 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:51 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:51 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:51 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:09:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:51 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:09:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:51 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:09:51 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:51 --> Total execution time: 0.9966
DEBUG - 2012-02-01 23:09:54 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:54 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:54 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:54 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:54 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:54 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:54 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:09:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:54 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 23:09:55 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:55 --> Total execution time: 0.4601
DEBUG - 2012-02-01 23:09:55 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:55 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:55 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:55 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:55 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:56 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:56 --> Controller Class Initialized
ERROR - 2012-02-01 23:09:56 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 23:09:57 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:57 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:57 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:57 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:57 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:57 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Controller Class Initialized
DEBUG - 2012-02-01 23:09:57 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:09:57 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:09:57 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:09:57 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:09:57 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 23:09:57 --> Final output sent to browser
DEBUG - 2012-02-01 23:09:57 --> Total execution time: 0.4807
DEBUG - 2012-02-01 23:09:58 --> Config Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:09:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:09:58 --> URI Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Router Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Output Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Security Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Input Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:09:58 --> Language Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Loader Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:09:58 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Session Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:09:58 --> Session routines successfully run
DEBUG - 2012-02-01 23:09:58 --> Cart Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:09:58 --> Controller Class Initialized
ERROR - 2012-02-01 23:09:58 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 23:10:00 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:00 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:00 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:00 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:00 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:00 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:00 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:10:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:10:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:10:00 --> File loaded: application/views/admin/page.php
DEBUG - 2012-02-01 23:10:00 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:00 --> Total execution time: 0.3969
DEBUG - 2012-02-01 23:10:01 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:01 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:01 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:01 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:01 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:02 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:02 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:02 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:02 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:02 --> Controller Class Initialized
ERROR - 2012-02-01 23:10:02 --> 404 Page Not Found --> page/css
DEBUG - 2012-02-01 23:10:03 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:03 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:03 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:03 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:03 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:03 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:03 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:10:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:10:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:03 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:10:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:10:03 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:10:03 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:03 --> Total execution time: 0.6102
DEBUG - 2012-02-01 23:10:06 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:06 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:06 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:07 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:07 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:07 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:07 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:07 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:07 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:10:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:10:07 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:10:07 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:07 --> Total execution time: 1.0248
DEBUG - 2012-02-01 23:10:09 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:09 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:09 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:09 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:09 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:09 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:09 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:10:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:10:09 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:10:09 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:09 --> Total execution time: 0.5361
DEBUG - 2012-02-01 23:10:11 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:11 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:11 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:11 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:11 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:11 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:11 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:10:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:10:11 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:10:11 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:11 --> Total execution time: 0.4615
DEBUG - 2012-02-01 23:10:12 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:12 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:12 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:12 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:12 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:12 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:12 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:13 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:13 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:13 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:13 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:13 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:10:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:10:13 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:10:13 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:13 --> Total execution time: 0.5493
DEBUG - 2012-02-01 23:10:16 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:16 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:16 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:16 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:16 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:16 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:10:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:10:16 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:10:17 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:17 --> Total execution time: 0.4419
DEBUG - 2012-02-01 23:10:18 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:18 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:18 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:18 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:18 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:18 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:18 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:10:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:10:19 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:10:19 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:19 --> Total execution time: 0.8132
DEBUG - 2012-02-01 23:10:22 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:22 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:22 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:22 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:23 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:23 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:23 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:23 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:23 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:10:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:10:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:23 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:10:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:10:23 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:10:23 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:23 --> Total execution time: 0.5197
DEBUG - 2012-02-01 23:10:25 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:25 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:25 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:25 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:25 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:25 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:25 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:10:25 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:10:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:10:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:10:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:10:26 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:10:26 --> Final output sent to browser
DEBUG - 2012-02-01 23:10:26 --> Total execution time: 0.5777
DEBUG - 2012-02-01 23:10:27 --> Config Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:10:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:10:27 --> URI Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Router Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Output Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Security Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Input Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:10:27 --> Language Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Loader Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:10:27 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Session Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:10:27 --> Session routines successfully run
DEBUG - 2012-02-01 23:10:27 --> Cart Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Controller Class Initialized
DEBUG - 2012-02-01 23:10:27 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:10:27 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:11:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:11:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:11:38 --> URI Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Router Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Output Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Security Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Input Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:11:38 --> Language Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Loader Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:11:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Session Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:11:38 --> Session routines successfully run
DEBUG - 2012-02-01 23:11:38 --> Cart Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Controller Class Initialized
DEBUG - 2012-02-01 23:11:38 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:11:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:11:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:11:38 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:11:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:11:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:11:38 --> Final output sent to browser
DEBUG - 2012-02-01 23:11:38 --> Total execution time: 0.4806
DEBUG - 2012-02-01 23:11:39 --> Config Class Initialized
DEBUG - 2012-02-01 23:11:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:11:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:11:40 --> URI Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Router Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Output Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Security Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Input Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:11:40 --> Language Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Loader Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:11:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Session Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:11:40 --> Session routines successfully run
DEBUG - 2012-02-01 23:11:40 --> Cart Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Controller Class Initialized
DEBUG - 2012-02-01 23:11:40 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:11:40 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:11:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:11:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:11:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:11:40 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:11:40 --> Final output sent to browser
DEBUG - 2012-02-01 23:11:40 --> Total execution time: 0.5713
DEBUG - 2012-02-01 23:11:41 --> Config Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:11:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:11:41 --> URI Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Router Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Output Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Security Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Input Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:11:41 --> Language Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Loader Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:11:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Session Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:11:41 --> Session routines successfully run
DEBUG - 2012-02-01 23:11:41 --> Cart Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Controller Class Initialized
DEBUG - 2012-02-01 23:11:41 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:11:41 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:11:49 --> Config Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:11:49 --> URI Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Router Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Output Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Security Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Input Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:11:49 --> Language Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Loader Class Initialized
DEBUG - 2012-02-01 23:11:49 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:11:49 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:11:50 --> Session Class Initialized
DEBUG - 2012-02-01 23:11:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:11:50 --> Session routines successfully run
DEBUG - 2012-02-01 23:11:50 --> Cart Class Initialized
DEBUG - 2012-02-01 23:11:50 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:50 --> Model Class Initialized
DEBUG - 2012-02-01 23:11:50 --> Controller Class Initialized
DEBUG - 2012-02-01 23:11:50 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:11:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:11:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:11:50 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:11:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:11:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:11:50 --> Final output sent to browser
DEBUG - 2012-02-01 23:11:50 --> Total execution time: 0.5889
DEBUG - 2012-02-01 23:14:20 --> Config Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:14:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:14:20 --> URI Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Router Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Output Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Security Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Input Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:14:20 --> Language Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Loader Class Initialized
DEBUG - 2012-02-01 23:14:20 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:14:20 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Session Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:14:21 --> Session routines successfully run
DEBUG - 2012-02-01 23:14:21 --> Cart Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Controller Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Config Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:14:21 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:14:21 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:14:21 --> URI Class Initialized
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:14:21 --> Router Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Final output sent to browser
DEBUG - 2012-02-01 23:14:21 --> Total execution time: 0.7268
DEBUG - 2012-02-01 23:14:21 --> Output Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Security Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Input Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:14:21 --> Language Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Loader Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:14:21 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Session Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:14:21 --> Session routines successfully run
DEBUG - 2012-02-01 23:14:21 --> Cart Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Controller Class Initialized
DEBUG - 2012-02-01 23:14:21 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:14:21 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:14:21 --> Final output sent to browser
DEBUG - 2012-02-01 23:14:21 --> Total execution time: 0.7001
DEBUG - 2012-02-01 23:14:25 --> Config Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:14:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:14:25 --> URI Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Router Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Output Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Security Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Input Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:14:25 --> Language Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Loader Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:14:25 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Session Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:14:25 --> Session routines successfully run
DEBUG - 2012-02-01 23:14:25 --> Cart Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Controller Class Initialized
DEBUG - 2012-02-01 23:14:25 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:14:25 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:14:25 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:14:25 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:14:25 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:14:25 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:14:25 --> Final output sent to browser
DEBUG - 2012-02-01 23:14:25 --> Total execution time: 0.5849
DEBUG - 2012-02-01 23:14:26 --> Config Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:14:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:14:26 --> URI Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Router Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Output Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Security Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Input Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:14:26 --> Language Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Loader Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:14:26 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Session Class Initialized
DEBUG - 2012-02-01 23:14:26 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:14:26 --> Session routines successfully run
DEBUG - 2012-02-01 23:14:26 --> Cart Class Initialized
DEBUG - 2012-02-01 23:14:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:14:27 --> Controller Class Initialized
DEBUG - 2012-02-01 23:14:27 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:14:27 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:16:32 --> Config Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:16:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:16:32 --> URI Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Router Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Output Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Security Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Input Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:16:32 --> Language Class Initialized
DEBUG - 2012-02-01 23:16:32 --> Loader Class Initialized
DEBUG - 2012-02-01 23:16:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:16:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:16:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:16:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:16:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:16:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:16:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:16:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:16:34 --> Controller Class Initialized
DEBUG - 2012-02-01 23:16:34 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:16:34 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:16:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:16:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:16:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:16:34 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:16:34 --> Final output sent to browser
DEBUG - 2012-02-01 23:16:34 --> Total execution time: 2.4432
DEBUG - 2012-02-01 23:16:35 --> Config Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:16:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:16:35 --> URI Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Router Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Output Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Security Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Input Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:16:35 --> Language Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Loader Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:16:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Session Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:16:35 --> Session routines successfully run
DEBUG - 2012-02-01 23:16:35 --> Cart Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:16:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:16:36 --> Controller Class Initialized
DEBUG - 2012-02-01 23:16:36 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:16:36 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:17:10 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:10 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:10 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:10 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:10 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:11 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:11 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:11 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:11 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:11 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:11 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:11 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:17:11 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:17:22 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:22 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:22 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:22 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:22 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:22 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:22 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:17:23 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:23 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:23 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:23 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:23 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:23 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:17:23 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:17:23 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:17:23 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:17:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:17:23 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:17:23 --> Final output sent to browser
DEBUG - 2012-02-01 23:17:23 --> Total execution time: 0.5210
DEBUG - 2012-02-01 23:17:26 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:26 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:26 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:26 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:26 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:26 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:26 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:17:26 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:17:28 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:28 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:28 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:29 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:29 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:29 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:29 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:29 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:29 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:17:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:17:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:17:29 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:17:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:17:29 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:17:29 --> Final output sent to browser
DEBUG - 2012-02-01 23:17:29 --> Total execution time: 0.8850
DEBUG - 2012-02-01 23:17:35 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:35 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:35 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:35 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:36 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:36 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:36 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:36 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:17:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:17:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:17:36 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:17:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:17:36 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:17:36 --> Final output sent to browser
DEBUG - 2012-02-01 23:17:36 --> Total execution time: 1.0827
DEBUG - 2012-02-01 23:17:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:38 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:38 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:38 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:38 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:38 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:17:38 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:17:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:17:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:17:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:17:38 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:17:39 --> Final output sent to browser
DEBUG - 2012-02-01 23:17:39 --> Total execution time: 0.6475
DEBUG - 2012-02-01 23:17:40 --> Config Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:17:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:17:40 --> URI Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Router Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Output Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Security Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Input Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:17:40 --> Language Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Loader Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:17:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Session Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:17:40 --> Session routines successfully run
DEBUG - 2012-02-01 23:17:40 --> Cart Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Controller Class Initialized
DEBUG - 2012-02-01 23:17:40 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:17:40 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:18:18 --> Config Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:18:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:18:18 --> URI Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Router Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Output Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Security Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Input Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:18:18 --> Language Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Loader Class Initialized
DEBUG - 2012-02-01 23:18:18 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:18:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:18:19 --> Session Class Initialized
DEBUG - 2012-02-01 23:18:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:18:19 --> Session routines successfully run
DEBUG - 2012-02-01 23:18:19 --> Cart Class Initialized
DEBUG - 2012-02-01 23:18:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:19 --> Controller Class Initialized
DEBUG - 2012-02-01 23:18:19 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:18:19 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:18:27 --> Config Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:18:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:18:27 --> URI Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Router Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Output Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Security Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Input Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:18:27 --> Language Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Loader Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:18:27 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Session Class Initialized
DEBUG - 2012-02-01 23:18:27 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:18:27 --> Session routines successfully run
DEBUG - 2012-02-01 23:18:27 --> Cart Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Controller Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:18:28 --> Config Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:18:28 --> URI Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Router Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Output Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Security Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Input Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:18:28 --> Language Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Loader Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:18:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Session Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:18:28 --> Session routines successfully run
DEBUG - 2012-02-01 23:18:28 --> Cart Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Controller Class Initialized
DEBUG - 2012-02-01 23:18:28 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:18:28 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:18:28 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:18:28 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:18:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:18:29 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:18:29 --> Final output sent to browser
DEBUG - 2012-02-01 23:18:29 --> Total execution time: 0.7218
DEBUG - 2012-02-01 23:18:29 --> Config Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:18:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:18:29 --> URI Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Router Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Output Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Security Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Input Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:18:29 --> Language Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Loader Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:18:29 --> Config Class Initialized
DEBUG - 2012-02-01 23:18:29 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:18:30 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:18:30 --> URI Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Router Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Session Class Initialized
DEBUG - 2012-02-01 23:18:30 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:18:30 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:18:30 --> Session routines successfully run
DEBUG - 2012-02-01 23:18:30 --> Output Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Cart Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Security Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Input Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:18:30 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Controller Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Language Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:18:30 --> Loader Class Initialized
ERROR - 2012-02-01 23:18:30 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:18:30 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:18:30 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Session Class Initialized
DEBUG - 2012-02-01 23:18:30 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:18:30 --> Session routines successfully run
DEBUG - 2012-02-01 23:18:30 --> Cart Class Initialized
DEBUG - 2012-02-01 23:18:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:32 --> Controller Class Initialized
DEBUG - 2012-02-01 23:18:32 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:18:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:18:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:18:32 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:18:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:18:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:18:32 --> Final output sent to browser
DEBUG - 2012-02-01 23:18:32 --> Total execution time: 2.4813
DEBUG - 2012-02-01 23:18:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:18:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:18:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:18:40 --> URI Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Router Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Output Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Security Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Input Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:18:40 --> Language Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Loader Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:18:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Session Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:18:40 --> Session routines successfully run
DEBUG - 2012-02-01 23:18:40 --> Cart Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Controller Class Initialized
DEBUG - 2012-02-01 23:18:40 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:18:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:18:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:18:40 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:18:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:18:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:18:40 --> Final output sent to browser
DEBUG - 2012-02-01 23:18:40 --> Total execution time: 2.2244
DEBUG - 2012-02-01 23:18:46 --> Config Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:18:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:18:46 --> URI Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Router Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Output Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Security Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Input Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:18:46 --> Language Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Loader Class Initialized
DEBUG - 2012-02-01 23:18:46 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:18:47 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:18:47 --> Session Class Initialized
DEBUG - 2012-02-01 23:18:47 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:18:47 --> Session routines successfully run
DEBUG - 2012-02-01 23:18:47 --> Cart Class Initialized
DEBUG - 2012-02-01 23:18:47 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:47 --> Model Class Initialized
DEBUG - 2012-02-01 23:18:47 --> Controller Class Initialized
DEBUG - 2012-02-01 23:18:47 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:18:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:18:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:18:47 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:18:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:18:47 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:18:47 --> Final output sent to browser
DEBUG - 2012-02-01 23:18:47 --> Total execution time: 0.5244
DEBUG - 2012-02-01 23:23:58 --> Config Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:23:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:23:58 --> URI Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Router Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Output Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Security Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Input Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:23:58 --> Language Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Loader Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:23:58 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Session Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:23:58 --> Session routines successfully run
DEBUG - 2012-02-01 23:23:58 --> Cart Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:23:58 --> Controller Class Initialized
DEBUG - 2012-02-01 23:23:59 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:23:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:23:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:23:59 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:23:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:23:59 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:23:59 --> Final output sent to browser
DEBUG - 2012-02-01 23:23:59 --> Total execution time: 0.6012
DEBUG - 2012-02-01 23:24:02 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:02 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:02 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:02 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:02 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:02 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:02 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:24:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:24:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:24:02 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:24:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:24:02 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:24:02 --> Final output sent to browser
DEBUG - 2012-02-01 23:24:02 --> Total execution time: 0.5769
DEBUG - 2012-02-01 23:24:04 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:04 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:04 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:04 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:04 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:04 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:04 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:24:04 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:24:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:24:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:24:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:24:04 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:24:05 --> Final output sent to browser
DEBUG - 2012-02-01 23:24:05 --> Total execution time: 0.5485
DEBUG - 2012-02-01 23:24:05 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:05 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:05 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:05 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:05 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:05 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:05 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:24:05 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:24:37 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:37 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:37 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:37 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:37 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:37 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:37 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:24:37 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:24:48 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:48 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:48 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:48 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:48 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:48 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:48 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:24:49 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:49 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:49 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:49 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:49 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:49 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:49 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:24:49 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:24:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:24:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:24:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:24:49 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:24:49 --> Final output sent to browser
DEBUG - 2012-02-01 23:24:50 --> Total execution time: 0.5612
DEBUG - 2012-02-01 23:24:50 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:50 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:52 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:52 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:52 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:52 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:52 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:24:53 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:24:53 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:53 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:53 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:53 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:53 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:53 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:24:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:24:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:24:53 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:24:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:24:53 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:24:53 --> Final output sent to browser
DEBUG - 2012-02-01 23:24:53 --> Total execution time: 0.4729
DEBUG - 2012-02-01 23:24:57 --> Config Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:24:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:24:57 --> URI Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Router Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Output Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Security Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Input Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:24:57 --> Language Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Loader Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:24:57 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Session Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:24:57 --> Session routines successfully run
DEBUG - 2012-02-01 23:24:57 --> Cart Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Model Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Controller Class Initialized
DEBUG - 2012-02-01 23:24:57 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:24:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:24:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:24:57 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:24:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:24:57 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:24:57 --> Final output sent to browser
DEBUG - 2012-02-01 23:24:57 --> Total execution time: 0.5909
DEBUG - 2012-02-01 23:25:04 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:04 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:04 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:04 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:04 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:05 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:05 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:05 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:05 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:05 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:05 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:25:05 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:05 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:05 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:25:05 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:05 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:25:05 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:05 --> Total execution time: 0.5486
DEBUG - 2012-02-01 23:25:06 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:06 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:06 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:06 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:06 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:06 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:06 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:07 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:07 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:07 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:07 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:07 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:07 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:07 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:07 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:07 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:08 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:08 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:08 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:08 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:25:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:09 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:09 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:25:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:09 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:25:09 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:09 --> Total execution time: 2.3128
DEBUG - 2012-02-01 23:25:09 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:09 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:09 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:09 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:09 --> Router Class Initialized
ERROR - 2012-02-01 23:25:09 --> 404 Page Not Found --> admin/upload
DEBUG - 2012-02-01 23:25:13 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:13 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:13 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:13 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:13 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:13 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:13 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:25:13 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:25:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:14 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:25:14 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:14 --> Total execution time: 0.4744
DEBUG - 2012-02-01 23:25:16 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:16 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:16 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:16 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:16 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:16 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:25:16 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:25:20 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:20 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:20 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:20 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:20 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:20 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:20 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:25:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:20 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:25:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:20 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:25:20 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:20 --> Total execution time: 0.4859
DEBUG - 2012-02-01 23:25:22 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:22 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:22 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:22 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:22 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:22 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:22 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:25:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:22 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:25:23 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:23 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:25:23 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:23 --> Total execution time: 0.5481
DEBUG - 2012-02-01 23:25:23 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:23 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:23 --> Router Class Initialized
ERROR - 2012-02-01 23:25:23 --> 404 Page Not Found --> admin/upload
DEBUG - 2012-02-01 23:25:32 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:32 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:32 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:32 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:32 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:32 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:32 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:25:32 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:25:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:32 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:25:33 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:33 --> Total execution time: 0.5295
DEBUG - 2012-02-01 23:25:33 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:33 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:33 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:33 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:34 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:34 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:25:34 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:25:37 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:37 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:37 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:37 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:37 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:37 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:37 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:25:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:38 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:25:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:38 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:25:38 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:38 --> Total execution time: 0.7238
DEBUG - 2012-02-01 23:25:40 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:40 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Router Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Output Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Security Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Input Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:25:40 --> Language Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Loader Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:25:40 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Session Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:25:40 --> Session routines successfully run
DEBUG - 2012-02-01 23:25:40 --> Cart Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Model Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Controller Class Initialized
DEBUG - 2012-02-01 23:25:40 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:25:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:25:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:25:40 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:25:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:25:40 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:25:41 --> Final output sent to browser
DEBUG - 2012-02-01 23:25:41 --> Total execution time: 0.5583
DEBUG - 2012-02-01 23:25:41 --> Config Class Initialized
DEBUG - 2012-02-01 23:25:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:25:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:25:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:25:41 --> URI Class Initialized
DEBUG - 2012-02-01 23:25:41 --> Router Class Initialized
ERROR - 2012-02-01 23:25:41 --> 404 Page Not Found --> admin/upload
DEBUG - 2012-02-01 23:26:30 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:30 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Router Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Output Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Security Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Input Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:26:30 --> Language Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Loader Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:26:30 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Session Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:26:30 --> Session routines successfully run
DEBUG - 2012-02-01 23:26:30 --> Cart Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Controller Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:26:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:26:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:26:30 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:26:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:26:30 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:26:30 --> Final output sent to browser
DEBUG - 2012-02-01 23:26:30 --> Total execution time: 0.4745
DEBUG - 2012-02-01 23:26:30 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:30 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:30 --> Router Class Initialized
ERROR - 2012-02-01 23:26:30 --> 404 Page Not Found --> admin/upload
DEBUG - 2012-02-01 23:26:33 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:33 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Router Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Output Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Security Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Input Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:26:33 --> Language Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Loader Class Initialized
DEBUG - 2012-02-01 23:26:33 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:26:33 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:26:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:26:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Controller Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:26:34 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:34 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Router Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Output Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Security Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Input Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:26:34 --> Language Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Loader Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:26:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:26:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:26:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:34 --> Controller Class Initialized
DEBUG - 2012-02-01 23:26:35 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:26:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:26:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:26:35 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:26:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:26:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:26:35 --> Final output sent to browser
DEBUG - 2012-02-01 23:26:35 --> Total execution time: 0.7999
DEBUG - 2012-02-01 23:26:37 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:37 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Router Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Output Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Security Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Input Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:26:37 --> Language Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Loader Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:26:37 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Session Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:26:37 --> Session routines successfully run
DEBUG - 2012-02-01 23:26:37 --> Cart Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Controller Class Initialized
DEBUG - 2012-02-01 23:26:37 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:26:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:26:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:26:37 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:26:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:26:37 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:26:37 --> Final output sent to browser
DEBUG - 2012-02-01 23:26:37 --> Total execution time: 0.4657
DEBUG - 2012-02-01 23:26:39 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:39 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:39 --> Router Class Initialized
DEBUG - 2012-02-01 23:26:40 --> Output Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Security Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Input Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:26:41 --> Language Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Loader Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:26:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Session Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:26:41 --> Session routines successfully run
DEBUG - 2012-02-01 23:26:41 --> Cart Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Controller Class Initialized
DEBUG - 2012-02-01 23:26:41 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:26:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:26:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:26:41 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:26:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:26:41 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:26:41 --> Final output sent to browser
DEBUG - 2012-02-01 23:26:41 --> Total execution time: 2.2275
DEBUG - 2012-02-01 23:26:44 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:44 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Router Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Output Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Security Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Input Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:26:45 --> Language Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Loader Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:26:45 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Session Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:26:45 --> Session routines successfully run
DEBUG - 2012-02-01 23:26:45 --> Cart Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Controller Class Initialized
DEBUG - 2012-02-01 23:26:45 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:26:45 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:26:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:26:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:26:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:26:45 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:26:45 --> Final output sent to browser
DEBUG - 2012-02-01 23:26:46 --> Total execution time: 0.5053
DEBUG - 2012-02-01 23:26:46 --> Config Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:26:46 --> URI Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Router Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Output Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Security Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Input Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:26:46 --> Language Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Loader Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:26:46 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Session Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:26:46 --> Session routines successfully run
DEBUG - 2012-02-01 23:26:46 --> Cart Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Model Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Controller Class Initialized
DEBUG - 2012-02-01 23:26:46 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:26:46 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:27:06 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:06 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:06 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:06 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:06 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:06 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:06 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:27:06 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:27:15 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:15 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:15 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:15 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:15 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:15 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:15 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:27:16 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:16 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:16 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:16 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:16 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:16 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:27:16 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:27:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:27:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:27:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:27:16 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:27:16 --> Final output sent to browser
DEBUG - 2012-02-01 23:27:16 --> Total execution time: 0.4792
DEBUG - 2012-02-01 23:27:17 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:17 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:17 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:17 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:17 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:17 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:17 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:27:17 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:27:24 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:24 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:24 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:24 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:24 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:24 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:24 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:27:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:27:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:27:24 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:27:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:27:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:27:24 --> Final output sent to browser
DEBUG - 2012-02-01 23:27:24 --> Total execution time: 0.4737
DEBUG - 2012-02-01 23:27:29 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:29 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:29 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:29 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:29 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:29 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:29 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:27:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:27:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:27:30 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:27:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:27:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:27:30 --> Final output sent to browser
DEBUG - 2012-02-01 23:27:30 --> Total execution time: 0.6476
DEBUG - 2012-02-01 23:27:33 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:33 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:33 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:33 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:33 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:33 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:33 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:27:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:27:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:27:33 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-01 23:27:33 --> Final output sent to browser
DEBUG - 2012-02-01 23:27:33 --> Total execution time: 0.4431
DEBUG - 2012-02-01 23:27:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:38 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:38 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:39 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:39 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:39 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:39 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:39 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:39 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:27:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:27:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:27:39 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:27:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:27:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:27:39 --> Final output sent to browser
DEBUG - 2012-02-01 23:27:39 --> Total execution time: 0.4788
DEBUG - 2012-02-01 23:27:41 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:41 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Router Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Output Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Security Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Input Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:27:41 --> Language Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Loader Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:27:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Session Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:27:41 --> Session routines successfully run
DEBUG - 2012-02-01 23:27:41 --> Cart Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Controller Class Initialized
DEBUG - 2012-02-01 23:27:41 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:27:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:27:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:27:41 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:27:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:27:41 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:27:41 --> Final output sent to browser
DEBUG - 2012-02-01 23:27:41 --> Total execution time: 0.5699
DEBUG - 2012-02-01 23:27:42 --> Config Class Initialized
DEBUG - 2012-02-01 23:27:42 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:27:42 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:27:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:27:42 --> URI Class Initialized
DEBUG - 2012-02-01 23:27:42 --> Router Class Initialized
ERROR - 2012-02-01 23:27:42 --> 404 Page Not Found --> admin/upload
DEBUG - 2012-02-01 23:28:55 --> Config Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:28:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:28:55 --> URI Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Router Class Initialized
DEBUG - 2012-02-01 23:28:55 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:28:55 --> Output Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Security Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Input Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:28:55 --> Language Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Loader Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:28:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Session Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:28:55 --> Session routines successfully run
DEBUG - 2012-02-01 23:28:55 --> Cart Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Controller Class Initialized
DEBUG - 2012-02-01 23:28:55 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:28:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:28:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:28:55 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:28:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:28:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:28:55 --> Final output sent to browser
DEBUG - 2012-02-01 23:28:55 --> Total execution time: 0.5278
DEBUG - 2012-02-01 23:28:58 --> Config Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:28:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:28:58 --> URI Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Router Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Output Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Security Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Input Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:28:58 --> Language Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Loader Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:28:58 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Session Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:28:58 --> Session routines successfully run
DEBUG - 2012-02-01 23:28:58 --> Cart Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Controller Class Initialized
DEBUG - 2012-02-01 23:28:58 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:28:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:28:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:28:58 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:28:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:28:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:28:58 --> Final output sent to browser
DEBUG - 2012-02-01 23:28:58 --> Total execution time: 0.5571
DEBUG - 2012-02-01 23:29:02 --> Config Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:29:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:29:02 --> URI Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Router Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Output Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Security Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Input Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:29:02 --> Language Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Loader Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:29:02 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Session Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:29:02 --> Session routines successfully run
DEBUG - 2012-02-01 23:29:02 --> Cart Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Controller Class Initialized
DEBUG - 2012-02-01 23:29:02 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:29:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:29:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:29:02 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:29:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:29:02 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:29:02 --> Final output sent to browser
DEBUG - 2012-02-01 23:29:02 --> Total execution time: 0.5317
DEBUG - 2012-02-01 23:29:05 --> Config Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:29:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:29:05 --> URI Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Router Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Output Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Security Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Input Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:29:05 --> Language Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Loader Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:29:05 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Session Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:29:05 --> Session routines successfully run
DEBUG - 2012-02-01 23:29:05 --> Cart Class Initialized
DEBUG - 2012-02-01 23:29:05 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:06 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:06 --> Controller Class Initialized
DEBUG - 2012-02-01 23:29:06 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:29:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:29:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:29:06 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:29:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:29:06 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:29:06 --> Final output sent to browser
DEBUG - 2012-02-01 23:29:06 --> Total execution time: 0.4868
DEBUG - 2012-02-01 23:29:50 --> Config Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:29:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:29:50 --> URI Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Router Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Output Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Security Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Input Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:29:50 --> Language Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Loader Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:29:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Session Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:29:50 --> Session routines successfully run
DEBUG - 2012-02-01 23:29:50 --> Cart Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Controller Class Initialized
DEBUG - 2012-02-01 23:29:50 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:29:50 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:29:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:29:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:29:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:29:50 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:29:50 --> Final output sent to browser
DEBUG - 2012-02-01 23:29:50 --> Total execution time: 0.4666
DEBUG - 2012-02-01 23:29:51 --> Config Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:29:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:29:51 --> URI Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Router Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Output Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Security Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Input Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:29:51 --> Language Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Loader Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:29:51 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Session Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:29:51 --> Session routines successfully run
DEBUG - 2012-02-01 23:29:51 --> Cart Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Controller Class Initialized
DEBUG - 2012-02-01 23:29:51 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:29:51 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:29:54 --> Config Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:29:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:29:54 --> URI Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Router Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Output Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Security Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Input Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:29:54 --> Language Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Loader Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:29:54 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:29:54 --> Session Class Initialized
DEBUG - 2012-02-01 23:29:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:29:55 --> Session routines successfully run
DEBUG - 2012-02-01 23:29:55 --> Cart Class Initialized
DEBUG - 2012-02-01 23:29:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:29:55 --> Controller Class Initialized
DEBUG - 2012-02-01 23:29:55 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:29:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:29:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:29:55 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:29:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:29:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:29:55 --> Final output sent to browser
DEBUG - 2012-02-01 23:29:55 --> Total execution time: 0.8795
DEBUG - 2012-02-01 23:30:00 --> Config Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:30:00 --> URI Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Router Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Output Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Security Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Input Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:30:00 --> Language Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Loader Class Initialized
DEBUG - 2012-02-01 23:30:00 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:30:01 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:30:01 --> Session Class Initialized
DEBUG - 2012-02-01 23:30:01 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:30:01 --> Session routines successfully run
DEBUG - 2012-02-01 23:30:01 --> Cart Class Initialized
DEBUG - 2012-02-01 23:30:01 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:01 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:01 --> Controller Class Initialized
DEBUG - 2012-02-01 23:30:01 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:30:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:30:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:30:01 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:30:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:30:01 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:30:01 --> Final output sent to browser
DEBUG - 2012-02-01 23:30:01 --> Total execution time: 0.7771
DEBUG - 2012-02-01 23:30:03 --> Config Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:30:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:30:03 --> URI Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Router Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Output Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Security Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Input Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:30:03 --> Language Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Loader Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:30:03 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Session Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:30:03 --> Session routines successfully run
DEBUG - 2012-02-01 23:30:03 --> Cart Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Controller Class Initialized
DEBUG - 2012-02-01 23:30:03 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:30:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:30:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:30:04 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:30:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:30:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:30:04 --> Final output sent to browser
DEBUG - 2012-02-01 23:30:04 --> Total execution time: 0.5967
DEBUG - 2012-02-01 23:30:10 --> Config Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:30:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:30:10 --> URI Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Router Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Output Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Security Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Input Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:30:10 --> Language Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Loader Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:30:10 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Session Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:30:10 --> Session routines successfully run
DEBUG - 2012-02-01 23:30:10 --> Cart Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Controller Class Initialized
DEBUG - 2012-02-01 23:30:10 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:30:10 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:30:10 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:30:10 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:30:10 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:30:10 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:30:10 --> Final output sent to browser
DEBUG - 2012-02-01 23:30:10 --> Total execution time: 0.4614
DEBUG - 2012-02-01 23:30:12 --> Config Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:30:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:30:12 --> URI Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Router Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Output Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Security Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Input Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:30:12 --> Language Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Loader Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:30:12 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:30:12 --> Session Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:30:13 --> Session routines successfully run
DEBUG - 2012-02-01 23:30:13 --> Cart Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Model Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Controller Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:30:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:30:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:30:13 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:30:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:30:13 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:30:13 --> Final output sent to browser
DEBUG - 2012-02-01 23:30:13 --> Total execution time: 0.5480
DEBUG - 2012-02-01 23:30:13 --> Config Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:30:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:30:13 --> URI Class Initialized
DEBUG - 2012-02-01 23:30:13 --> Router Class Initialized
ERROR - 2012-02-01 23:30:13 --> 404 Page Not Found --> admin/upload
DEBUG - 2012-02-01 23:31:40 --> Config Class Initialized
DEBUG - 2012-02-01 23:31:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:31:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:31:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:31:40 --> URI Class Initialized
DEBUG - 2012-02-01 23:31:40 --> Router Class Initialized
ERROR - 2012-02-01 23:31:40 --> 404 Page Not Found --> admin/upload
DEBUG - 2012-02-01 23:33:16 --> Config Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:33:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:33:17 --> URI Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Router Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Output Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Security Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Input Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:33:17 --> Language Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Loader Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:33:17 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Session Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:33:17 --> Session routines successfully run
DEBUG - 2012-02-01 23:33:17 --> Cart Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Model Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Model Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Controller Class Initialized
DEBUG - 2012-02-01 23:33:17 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:33:17 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:33:17 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:33:17 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:33:17 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:33:17 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:33:17 --> Final output sent to browser
DEBUG - 2012-02-01 23:33:17 --> Total execution time: 2.5562
DEBUG - 2012-02-01 23:33:19 --> Config Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:33:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:33:19 --> URI Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Router Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Output Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Security Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Input Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:33:19 --> Language Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Loader Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:33:19 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Session Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:33:19 --> Session routines successfully run
DEBUG - 2012-02-01 23:33:19 --> Cart Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Model Class Initialized
DEBUG - 2012-02-01 23:33:19 --> Controller Class Initialized
DEBUG - 2012-02-01 23:33:20 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:33:20 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:34:09 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:09 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:09 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:09 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:09 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:09 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:09 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:34:09 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:34:17 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:17 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:17 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:17 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:17 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:17 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:17 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:17 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:17 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:18 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:18 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:18 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:34:18 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:18 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:18 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:18 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:18 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:18 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:18 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:34:18 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:34:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:34:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:34:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:34:18 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:34:19 --> Final output sent to browser
DEBUG - 2012-02-01 23:34:19 --> Total execution time: 0.5181
DEBUG - 2012-02-01 23:34:22 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:22 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:22 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:22 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:22 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:22 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:22 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:23 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:34:23 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:34:26 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:26 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:26 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:26 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:26 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:27 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:27 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:27 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:27 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:27 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:34:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:34:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:34:27 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:34:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:34:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:34:27 --> Final output sent to browser
DEBUG - 2012-02-01 23:34:27 --> Total execution time: 0.5356
DEBUG - 2012-02-01 23:34:32 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:32 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:32 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:32 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:32 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:32 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:32 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:34:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:34:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:34:32 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:34:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:34:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:34:32 --> Final output sent to browser
DEBUG - 2012-02-01 23:34:32 --> Total execution time: 0.5089
DEBUG - 2012-02-01 23:34:36 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:36 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:36 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:37 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:39 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:39 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:39 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:39 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:39 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:34:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:34:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:34:39 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:34:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:34:39 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:34:39 --> Final output sent to browser
DEBUG - 2012-02-01 23:34:39 --> Total execution time: 3.0622
DEBUG - 2012-02-01 23:34:48 --> Config Class Initialized
DEBUG - 2012-02-01 23:34:48 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:34:48 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:34:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:34:48 --> URI Class Initialized
DEBUG - 2012-02-01 23:34:48 --> Router Class Initialized
DEBUG - 2012-02-01 23:34:48 --> Output Class Initialized
DEBUG - 2012-02-01 23:34:48 --> Security Class Initialized
DEBUG - 2012-02-01 23:34:49 --> Input Class Initialized
DEBUG - 2012-02-01 23:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:34:51 --> Language Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Loader Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:34:51 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Session Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:34:51 --> Session routines successfully run
DEBUG - 2012-02-01 23:34:51 --> Cart Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Controller Class Initialized
DEBUG - 2012-02-01 23:34:51 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:34:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:34:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:34:51 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:34:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:34:51 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:34:51 --> Final output sent to browser
DEBUG - 2012-02-01 23:34:51 --> Total execution time: 2.8455
DEBUG - 2012-02-01 23:35:10 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:10 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:10 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:10 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:10 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:10 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:10 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:35:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:35:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:10 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:35:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:35:10 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:35:10 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:10 --> Total execution time: 0.5306
DEBUG - 2012-02-01 23:35:14 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:14 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:14 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:14 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:14 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:14 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:14 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:15 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:35:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:35:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:15 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:35:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:35:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:35:15 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:15 --> Total execution time: 0.9778
DEBUG - 2012-02-01 23:35:28 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:28 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:28 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:28 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:28 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:28 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:35:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:35:28 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-01 23:35:28 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:28 --> Total execution time: 0.4209
DEBUG - 2012-02-01 23:35:34 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:34 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:34 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:35 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:35 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:35:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:35:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:35 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:35:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:35:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:35:35 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:35 --> Total execution time: 0.8551
DEBUG - 2012-02-01 23:35:41 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:42 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:42 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:42 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:42 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:42 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:42 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:35:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:35:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:42 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:35:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:35:42 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:35:43 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:43 --> Total execution time: 1.0900
DEBUG - 2012-02-01 23:35:44 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:44 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:44 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:44 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:35:44 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:44 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:45 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:45 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:45 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:45 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:45 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:35:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:35:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:45 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:35:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:35:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:35:45 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:45 --> Total execution time: 0.5188
DEBUG - 2012-02-01 23:35:49 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:49 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:49 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:49 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:49 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:50 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:50 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:50 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:50 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:50 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:35:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:35:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:50 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:35:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:35:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:35:50 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:50 --> Total execution time: 1.0350
DEBUG - 2012-02-01 23:35:52 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:52 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:52 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:52 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:52 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:52 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:52 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:35:52 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:35:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:35:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:35:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:35:52 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:35:52 --> Final output sent to browser
DEBUG - 2012-02-01 23:35:53 --> Total execution time: 0.5180
DEBUG - 2012-02-01 23:35:53 --> Config Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:35:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:35:53 --> URI Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Router Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Output Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Security Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Input Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:35:53 --> Language Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Loader Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:35:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Session Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:35:53 --> Session routines successfully run
DEBUG - 2012-02-01 23:35:53 --> Cart Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Controller Class Initialized
DEBUG - 2012-02-01 23:35:53 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:35:53 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:37:02 --> Config Class Initialized
DEBUG - 2012-02-01 23:37:02 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:37:02 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:37:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:37:02 --> URI Class Initialized
DEBUG - 2012-02-01 23:37:02 --> Router Class Initialized
DEBUG - 2012-02-01 23:37:02 --> Output Class Initialized
DEBUG - 2012-02-01 23:37:02 --> Security Class Initialized
DEBUG - 2012-02-01 23:37:02 --> Input Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:37:03 --> Language Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Loader Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:37:03 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Session Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:37:03 --> Session routines successfully run
DEBUG - 2012-02-01 23:37:03 --> Cart Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Controller Class Initialized
DEBUG - 2012-02-01 23:37:03 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:37:03 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:37:13 --> Config Class Initialized
DEBUG - 2012-02-01 23:37:13 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:37:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:37:14 --> URI Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Router Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Output Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Security Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Input Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:37:14 --> Language Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Loader Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:37:14 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Session Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:37:14 --> Session routines successfully run
DEBUG - 2012-02-01 23:37:14 --> Cart Class Initialized
DEBUG - 2012-02-01 23:37:14 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Controller Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:37:15 --> Config Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:37:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:37:15 --> URI Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Router Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Output Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Security Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Input Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:37:15 --> Language Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Loader Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:37:15 --> Config Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:37:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:37:15 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:37:15 --> URI Class Initialized
DEBUG - 2012-02-01 23:37:15 --> Router Class Initialized
DEBUG - 2012-02-01 23:37:15 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:37:15 --> Session Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Output Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:37:16 --> Session routines successfully run
DEBUG - 2012-02-01 23:37:16 --> Cart Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Security Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Input Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:37:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Language Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Controller Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:37:16 --> Loader Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:37:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:37:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:37:16 --> Final output sent to browser
DEBUG - 2012-02-01 23:37:16 --> Total execution time: 1.0571
DEBUG - 2012-02-01 23:37:16 --> Session Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:37:16 --> Session routines successfully run
DEBUG - 2012-02-01 23:37:16 --> Cart Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Controller Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Config Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:37:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:37:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:37:16 --> URI Class Initialized
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:37:16 --> Router Class Initialized
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:37:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:37:17 --> Output Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Final output sent to browser
DEBUG - 2012-02-01 23:37:17 --> Total execution time: 1.2445
DEBUG - 2012-02-01 23:37:17 --> Security Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Input Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:37:17 --> Language Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Loader Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:37:17 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Session Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:37:17 --> Session routines successfully run
DEBUG - 2012-02-01 23:37:17 --> Cart Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Controller Class Initialized
DEBUG - 2012-02-01 23:37:17 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:37:17 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:37:23 --> Config Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:37:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:37:23 --> URI Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Router Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Output Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Security Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Input Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:37:23 --> Language Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Loader Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:37:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Session Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:37:23 --> Session routines successfully run
DEBUG - 2012-02-01 23:37:23 --> Cart Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:37:23 --> Controller Class Initialized
DEBUG - 2012-02-01 23:37:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:37:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:37:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:37:23 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-01 23:37:24 --> Final output sent to browser
DEBUG - 2012-02-01 23:37:24 --> Total execution time: 0.5308
DEBUG - 2012-02-01 23:38:51 --> Config Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:38:51 --> URI Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Router Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Output Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Security Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Input Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:38:51 --> Language Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Loader Class Initialized
DEBUG - 2012-02-01 23:38:51 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:38:52 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:38:52 --> Session Class Initialized
DEBUG - 2012-02-01 23:38:52 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:38:52 --> Session routines successfully run
DEBUG - 2012-02-01 23:38:52 --> Cart Class Initialized
DEBUG - 2012-02-01 23:38:52 --> Model Class Initialized
DEBUG - 2012-02-01 23:38:52 --> Model Class Initialized
DEBUG - 2012-02-01 23:38:52 --> Controller Class Initialized
DEBUG - 2012-02-01 23:38:52 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:38:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:38:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:38:52 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:38:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:38:52 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:38:52 --> Final output sent to browser
DEBUG - 2012-02-01 23:38:52 --> Total execution time: 0.4924
DEBUG - 2012-02-01 23:38:53 --> Config Class Initialized
DEBUG - 2012-02-01 23:38:53 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:38:53 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:38:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:38:54 --> URI Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Router Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Output Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Security Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Input Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:38:54 --> Language Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Loader Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:38:54 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Session Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:38:54 --> Session routines successfully run
DEBUG - 2012-02-01 23:38:54 --> Cart Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Model Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Model Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Controller Class Initialized
DEBUG - 2012-02-01 23:38:54 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:38:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:38:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:38:54 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:38:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:38:54 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:38:54 --> Final output sent to browser
DEBUG - 2012-02-01 23:38:54 --> Total execution time: 0.5406
DEBUG - 2012-02-01 23:38:55 --> Config Class Initialized
DEBUG - 2012-02-01 23:38:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:38:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:38:55 --> URI Class Initialized
DEBUG - 2012-02-01 23:38:55 --> Router Class Initialized
DEBUG - 2012-02-01 23:38:55 --> Output Class Initialized
DEBUG - 2012-02-01 23:38:55 --> Security Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Input Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:38:56 --> Language Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Loader Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:38:56 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Session Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:38:56 --> Session routines successfully run
DEBUG - 2012-02-01 23:38:56 --> Cart Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Model Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Model Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Controller Class Initialized
DEBUG - 2012-02-01 23:38:56 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:38:56 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:38:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:38:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:38:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:38:56 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:38:56 --> Final output sent to browser
DEBUG - 2012-02-01 23:38:56 --> Total execution time: 0.5321
DEBUG - 2012-02-01 23:38:57 --> Config Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:38:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:38:57 --> URI Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Router Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Output Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Security Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Input Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:38:57 --> Language Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Loader Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:38:57 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Session Class Initialized
DEBUG - 2012-02-01 23:38:57 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:38:57 --> Session routines successfully run
DEBUG - 2012-02-01 23:38:58 --> Cart Class Initialized
DEBUG - 2012-02-01 23:38:59 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:00 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:00 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:00 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:39:00 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:39:35 --> Config Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:39:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:39:35 --> URI Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Router Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Output Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Security Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Input Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:39:35 --> Language Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Loader Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:39:35 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Session Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:39:35 --> Session routines successfully run
DEBUG - 2012-02-01 23:39:35 --> Cart Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:35 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:39:35 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:39:43 --> Config Class Initialized
DEBUG - 2012-02-01 23:39:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:39:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:39:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:39:43 --> URI Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Router Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Output Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Security Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Input Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:39:44 --> Language Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Loader Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:39:44 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Session Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:39:44 --> Session routines successfully run
DEBUG - 2012-02-01 23:39:44 --> Cart Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:44 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:39:47 --> Config Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:39:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:39:47 --> URI Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Router Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Output Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Security Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Input Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:39:47 --> Language Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Loader Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:39:47 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Session Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:39:47 --> Session routines successfully run
DEBUG - 2012-02-01 23:39:47 --> Cart Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:47 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:39:48 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:39:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:39:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:39:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:39:48 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:39:48 --> Final output sent to browser
DEBUG - 2012-02-01 23:39:48 --> Total execution time: 0.5066
DEBUG - 2012-02-01 23:39:48 --> Config Class Initialized
DEBUG - 2012-02-01 23:39:48 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:39:48 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:39:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:39:48 --> URI Class Initialized
DEBUG - 2012-02-01 23:39:48 --> Router Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Output Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Security Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Input Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:39:49 --> Language Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Loader Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:39:49 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Session Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:39:49 --> Session routines successfully run
DEBUG - 2012-02-01 23:39:49 --> Cart Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:49 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:39:49 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:39:50 --> Config Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:39:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:39:50 --> URI Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Router Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Output Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Security Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Input Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:39:50 --> Language Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Loader Class Initialized
DEBUG - 2012-02-01 23:39:50 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:39:51 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:39:51 --> Session Class Initialized
DEBUG - 2012-02-01 23:39:51 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:39:51 --> Session routines successfully run
DEBUG - 2012-02-01 23:39:51 --> Cart Class Initialized
DEBUG - 2012-02-01 23:39:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:51 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:51 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:51 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:39:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:39:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:39:51 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:39:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:39:51 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-01 23:39:51 --> Final output sent to browser
DEBUG - 2012-02-01 23:39:51 --> Total execution time: 0.5862
DEBUG - 2012-02-01 23:39:55 --> Config Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:39:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:39:55 --> URI Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Router Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Output Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Security Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Input Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:39:55 --> Language Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Loader Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:39:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Session Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:39:55 --> Session routines successfully run
DEBUG - 2012-02-01 23:39:55 --> Cart Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:55 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:39:56 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:39:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:39:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:39:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:39:56 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:39:56 --> Final output sent to browser
DEBUG - 2012-02-01 23:39:56 --> Total execution time: 0.7665
DEBUG - 2012-02-01 23:39:57 --> Config Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:39:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:39:57 --> URI Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Router Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Output Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Security Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Input Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:39:57 --> Language Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Loader Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:39:57 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Session Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:39:57 --> Session routines successfully run
DEBUG - 2012-02-01 23:39:57 --> Cart Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Model Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Controller Class Initialized
DEBUG - 2012-02-01 23:39:57 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:39:57 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:40:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:40:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:40:38 --> URI Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Router Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Output Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Security Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Input Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:40:38 --> Language Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Loader Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:40:38 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Session Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:40:38 --> Session routines successfully run
DEBUG - 2012-02-01 23:40:38 --> Cart Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Controller Class Initialized
DEBUG - 2012-02-01 23:40:38 --> Helper loaded: validate_helper
ERROR - 2012-02-01 23:40:38 --> 404 Page Not Found --> product/lists
DEBUG - 2012-02-01 23:40:47 --> Config Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:40:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:40:47 --> URI Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Router Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Output Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Security Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Input Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:40:47 --> Language Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Loader Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:40:47 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Session Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:40:47 --> Session routines successfully run
DEBUG - 2012-02-01 23:40:47 --> Cart Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Controller Class Initialized
DEBUG - 2012-02-01 23:40:47 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:40:48 --> Config Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:40:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:40:48 --> URI Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Router Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Output Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Security Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Input Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:40:48 --> Language Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Loader Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:40:48 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Session Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:40:48 --> Session routines successfully run
DEBUG - 2012-02-01 23:40:48 --> Cart Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Controller Class Initialized
DEBUG - 2012-02-01 23:40:48 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:40:48 --> Helper loaded: tinymce_helper
DEBUG - 2012-02-01 23:40:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:40:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:40:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:40:48 --> File loaded: application/views/admin/product.php
DEBUG - 2012-02-01 23:40:48 --> Final output sent to browser
DEBUG - 2012-02-01 23:40:48 --> Total execution time: 0.4765
DEBUG - 2012-02-01 23:40:52 --> Config Class Initialized
DEBUG - 2012-02-01 23:40:52 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:40:52 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:40:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:40:52 --> URI Class Initialized
DEBUG - 2012-02-01 23:40:52 --> Router Class Initialized
DEBUG - 2012-02-01 23:40:52 --> Config Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Output Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Security Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:40:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:40:53 --> Input Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:40:53 --> URI Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Language Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Router Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Loader Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Output Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:40:53 --> Security Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Input Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:40:53 --> Language Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Loader Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:40:53 --> Session Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:40:53 --> Session routines successfully run
DEBUG - 2012-02-01 23:40:53 --> Cart Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Controller Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Helper loaded: validate_helper
DEBUG - 2012-02-01 23:40:53 --> Session Class Initialized
ERROR - 2012-02-01 23:40:53 --> 404 Page Not Found --> product/css
DEBUG - 2012-02-01 23:40:53 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:40:53 --> Session routines successfully run
DEBUG - 2012-02-01 23:40:53 --> Cart Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Controller Class Initialized
DEBUG - 2012-02-01 23:40:53 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:40:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:40:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:40:54 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:40:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:40:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:40:54 --> Final output sent to browser
DEBUG - 2012-02-01 23:40:54 --> Total execution time: 1.2650
DEBUG - 2012-02-01 23:40:55 --> Config Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:40:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:40:55 --> URI Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Router Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Output Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Security Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Input Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:40:55 --> Language Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Loader Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:40:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Session Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:40:55 --> Session routines successfully run
DEBUG - 2012-02-01 23:40:55 --> Cart Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Controller Class Initialized
DEBUG - 2012-02-01 23:40:55 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:40:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:40:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:40:55 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:40:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:40:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:40:55 --> Final output sent to browser
DEBUG - 2012-02-01 23:40:55 --> Total execution time: 0.5446
DEBUG - 2012-02-01 23:41:02 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:02 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:02 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:41:02 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:02 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:02 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:02 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:02 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:02 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:02 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:02 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:02 --> Total execution time: 0.5001
DEBUG - 2012-02-01 23:41:08 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:09 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:09 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:09 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:09 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:09 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:09 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:09 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:09 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:09 --> Total execution time: 0.5617
DEBUG - 2012-02-01 23:41:14 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:14 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:14 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:14 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:15 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:15 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:15 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:15 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:15 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:15 --> Total execution time: 0.8514
DEBUG - 2012-02-01 23:41:15 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:15 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:15 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:16 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:16 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:16 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:16 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:16 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:16 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:16 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:16 --> Total execution time: 0.6678
DEBUG - 2012-02-01 23:41:18 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:18 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:18 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:18 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:18 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:18 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:18 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:18 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:18 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:18 --> Total execution time: 0.5029
DEBUG - 2012-02-01 23:41:22 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:22 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:22 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:23 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:23 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:23 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:23 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:23 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:23 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:23 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:23 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:23 --> Total execution time: 0.8870
DEBUG - 2012-02-01 23:41:25 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:25 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:25 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:25 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:25 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:25 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:25 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:25 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:26 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:26 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:26 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:26 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:26 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:26 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:26 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:26 --> Total execution time: 0.5286
DEBUG - 2012-02-01 23:41:30 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:30 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:31 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:31 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:31 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:31 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:31 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:31 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:31 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:31 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:31 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:31 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:31 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:31 --> Total execution time: 1.0238
DEBUG - 2012-02-01 23:41:34 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:34 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:34 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:34 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:34 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:34 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:34 --> Total execution time: 0.5468
DEBUG - 2012-02-01 23:41:39 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:39 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:39 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:39 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:39 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:39 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:39 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:39 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:39 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:39 --> Total execution time: 0.8597
DEBUG - 2012-02-01 23:41:41 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:41 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:41 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:41 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:41 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:41 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:42 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:42 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:42 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:42 --> Total execution time: 0.5790
DEBUG - 2012-02-01 23:41:55 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:55 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:55 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:41:55 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:55 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:55 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:55 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:55 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:55 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:41:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:55 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:41:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:41:55 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:55 --> Total execution time: 0.4501
DEBUG - 2012-02-01 23:41:56 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:56 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:56 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:56 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:56 --> Router Class Initialized
ERROR - 2012-02-01 23:41:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:41:57 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:57 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:57 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:57 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:57 --> Router Class Initialized
DEBUG - 2012-02-01 23:41:57 --> Output Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Security Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Input Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:41:58 --> Language Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Loader Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:41:58 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Session Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:41:58 --> Session routines successfully run
DEBUG - 2012-02-01 23:41:58 --> Cart Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Model Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Controller Class Initialized
DEBUG - 2012-02-01 23:41:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:41:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:41:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:41:58 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:41:58 --> Final output sent to browser
DEBUG - 2012-02-01 23:41:58 --> Total execution time: 0.4720
DEBUG - 2012-02-01 23:41:58 --> Config Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:41:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:41:58 --> URI Class Initialized
DEBUG - 2012-02-01 23:41:58 --> Router Class Initialized
ERROR - 2012-02-01 23:41:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:00 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:00 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:00 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:00 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:03 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:03 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:03 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:03 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:42:03 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:03 --> Total execution time: 3.1520
DEBUG - 2012-02-01 23:42:03 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:03 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:03 --> Router Class Initialized
ERROR - 2012-02-01 23:42:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:04 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:04 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:04 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:04 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:04 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:04 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:04 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:05 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:42:05 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:05 --> Total execution time: 0.4973
DEBUG - 2012-02-01 23:42:05 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:05 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:05 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:05 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:05 --> Router Class Initialized
ERROR - 2012-02-01 23:42:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:06 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:06 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:06 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:06 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:06 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:06 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:06 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:06 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-01 23:42:06 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:06 --> Total execution time: 0.4841
DEBUG - 2012-02-01 23:42:07 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:07 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:07 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:07 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:07 --> Router Class Initialized
ERROR - 2012-02-01 23:42:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:08 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:08 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:08 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:42:08 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:08 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:08 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:08 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:08 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:42:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:08 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:42:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:42:08 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:08 --> Total execution time: 0.4497
DEBUG - 2012-02-01 23:42:08 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:08 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:08 --> Router Class Initialized
ERROR - 2012-02-01 23:42:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:10 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:10 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:10 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:10 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:10 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:10 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:10 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:10 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-01 23:42:11 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:11 --> Total execution time: 0.5870
DEBUG - 2012-02-01 23:42:11 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:11 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:11 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:11 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:11 --> Router Class Initialized
ERROR - 2012-02-01 23:42:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:15 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:15 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:15 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:15 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:15 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:15 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:15 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:42:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:16 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:42:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-01 23:42:16 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:16 --> Total execution time: 0.6824
DEBUG - 2012-02-01 23:42:16 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:16 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:16 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:16 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:16 --> Router Class Initialized
ERROR - 2012-02-01 23:42:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:20 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:20 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:20 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:20 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:20 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:20 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:20 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:20 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-01 23:42:20 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:20 --> Total execution time: 0.3594
DEBUG - 2012-02-01 23:42:21 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:21 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:21 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:21 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:21 --> Router Class Initialized
ERROR - 2012-02-01 23:42:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:27 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:27 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:27 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:27 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:27 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:27 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:27 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:27 --> XSS Filtering completed
DEBUG - 2012-02-01 23:42:27 --> XSS Filtering completed
DEBUG - 2012-02-01 23:42:27 --> XSS Filtering completed
DEBUG - 2012-02-01 23:42:28 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:28 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:28 --> No URI present. Default controller set.
DEBUG - 2012-02-01 23:42:28 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:28 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:28 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:28 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:28 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:28 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:42:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:42:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:28 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-01 23:42:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:42:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-01 23:42:28 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:28 --> Total execution time: 0.4803
DEBUG - 2012-02-01 23:42:29 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:29 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:29 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:29 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:29 --> Router Class Initialized
ERROR - 2012-02-01 23:42:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:31 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:31 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:31 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:31 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:31 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:32 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:32 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:42:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:42:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:32 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:42:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:42:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:42:32 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:32 --> Total execution time: 0.5259
DEBUG - 2012-02-01 23:42:32 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:32 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:32 --> Router Class Initialized
ERROR - 2012-02-01 23:42:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:34 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:34 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:34 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:34 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:34 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:34 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:42:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:42:34 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:42:34 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:34 --> Total execution time: 0.4350
DEBUG - 2012-02-01 23:42:34 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:34 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:34 --> Router Class Initialized
ERROR - 2012-02-01 23:42:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:35 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:35 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:35 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:36 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:36 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:36 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:36 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:36 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:36 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:36 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:37 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:37 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:37 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:42:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:42:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:37 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:42:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:42:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:42:37 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:37 --> Total execution time: 0.4795
DEBUG - 2012-02-01 23:42:37 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:37 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:37 --> Router Class Initialized
ERROR - 2012-02-01 23:42:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:38 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:38 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:38 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:38 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:39 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:39 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:39 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:42:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:42:39 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:42:39 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:39 --> Total execution time: 0.4546
DEBUG - 2012-02-01 23:42:39 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:39 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:39 --> Router Class Initialized
ERROR - 2012-02-01 23:42:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:40 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:40 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:40 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:40 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:40 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:40 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:41 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:41 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:41 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:41 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:41 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:41 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:42 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:42 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:42 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:42 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:42:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:42:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:42 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:42:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:42:42 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:42:42 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:42 --> Total execution time: 0.5485
DEBUG - 2012-02-01 23:42:43 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:43 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Router Class Initialized
ERROR - 2012-02-01 23:42:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:43 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:43 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:43 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:43 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:44 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:44 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:44 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:42:44 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:44 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:42:44 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-01 23:42:44 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:44 --> Total execution time: 0.5365
DEBUG - 2012-02-01 23:42:44 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:44 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:44 --> Router Class Initialized
ERROR - 2012-02-01 23:42:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:42:45 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:45 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:45 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:45 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:45 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:45 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:45 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:46 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Router Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Output Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Security Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Input Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:42:46 --> Language Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Loader Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:42:46 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Session Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:42:46 --> Session routines successfully run
DEBUG - 2012-02-01 23:42:46 --> Cart Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Model Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Controller Class Initialized
DEBUG - 2012-02-01 23:42:46 --> Pagination Class Initialized
DEBUG - 2012-02-01 23:42:46 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-01 23:42:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-01 23:42:47 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-01 23:42:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-01 23:42:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-01 23:42:47 --> Final output sent to browser
DEBUG - 2012-02-01 23:42:47 --> Total execution time: 0.4785
DEBUG - 2012-02-01 23:42:47 --> Config Class Initialized
DEBUG - 2012-02-01 23:42:47 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:42:47 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:42:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:42:47 --> URI Class Initialized
DEBUG - 2012-02-01 23:42:47 --> Router Class Initialized
ERROR - 2012-02-01 23:42:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-01 23:54:56 --> Config Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Hooks Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Utf8 Class Initialized
DEBUG - 2012-02-01 23:54:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-01 23:54:56 --> URI Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Router Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Output Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Security Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Input Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-01 23:54:56 --> Language Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Loader Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Helper loaded: url_helper
DEBUG - 2012-02-01 23:54:56 --> Database Driver Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Session Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Helper loaded: string_helper
DEBUG - 2012-02-01 23:54:56 --> Session routines successfully run
DEBUG - 2012-02-01 23:54:56 --> Cart Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Model Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Model Class Initialized
DEBUG - 2012-02-01 23:54:56 --> Controller Class Initialized
DEBUG - 2012-02-01 23:54:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-01 23:54:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-01 23:54:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-01 23:54:56 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-01 23:54:56 --> Final output sent to browser
DEBUG - 2012-02-01 23:54:56 --> Total execution time: 0.4883

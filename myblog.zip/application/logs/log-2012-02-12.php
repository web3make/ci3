<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-02-12 22:12:27 --> Config Class Initialized
DEBUG - 2012-02-12 22:12:27 --> Hooks Class Initialized
DEBUG - 2012-02-12 22:12:27 --> Utf8 Class Initialized
DEBUG - 2012-02-12 22:12:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-12 22:12:27 --> URI Class Initialized
DEBUG - 2012-02-12 22:12:27 --> Router Class Initialized
DEBUG - 2012-02-12 22:12:27 --> No URI present. Default controller set.
DEBUG - 2012-02-12 22:12:27 --> Output Class Initialized
DEBUG - 2012-02-12 22:12:28 --> Security Class Initialized
DEBUG - 2012-02-12 22:12:28 --> Input Class Initialized
DEBUG - 2012-02-12 22:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-12 22:12:28 --> Language Class Initialized
DEBUG - 2012-02-12 22:12:28 --> Loader Class Initialized
DEBUG - 2012-02-12 22:12:28 --> Helper loaded: url_helper
DEBUG - 2012-02-12 22:12:28 --> Database Driver Class Initialized
ERROR - 2012-02-12 22:12:28 --> Unable to select database: blog
DEBUG - 2012-02-12 22:12:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-02-12 22:12:28 --> Config Class Initialized
DEBUG - 2012-02-12 22:12:29 --> Hooks Class Initialized
DEBUG - 2012-02-12 22:12:29 --> Utf8 Class Initialized
DEBUG - 2012-02-12 22:12:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-12 22:12:29 --> URI Class Initialized
DEBUG - 2012-02-12 22:12:29 --> Router Class Initialized
ERROR - 2012-02-12 22:12:29 --> 404 Page Not Found --> favicon.ico

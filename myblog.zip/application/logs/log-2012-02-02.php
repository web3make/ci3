<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-02-02 00:00:24 --> Config Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:00:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:00:24 --> URI Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Router Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Output Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Security Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Input Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:00:24 --> Language Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Loader Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:00:24 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:00:24 --> Session Class Initialized
DEBUG - 2012-02-02 00:00:25 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:00:25 --> Session routines successfully run
DEBUG - 2012-02-02 00:00:25 --> Cart Class Initialized
DEBUG - 2012-02-02 00:00:25 --> Model Class Initialized
DEBUG - 2012-02-02 00:00:25 --> Model Class Initialized
DEBUG - 2012-02-02 00:00:25 --> Controller Class Initialized
DEBUG - 2012-02-02 00:00:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:00:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:00:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:00:25 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:00:25 --> Final output sent to browser
DEBUG - 2012-02-02 00:00:25 --> Total execution time: 0.9739
DEBUG - 2012-02-02 00:00:25 --> Config Class Initialized
DEBUG - 2012-02-02 00:00:25 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:00:25 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:00:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:00:25 --> URI Class Initialized
DEBUG - 2012-02-02 00:00:25 --> Router Class Initialized
ERROR - 2012-02-02 00:00:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 00:00:28 --> Config Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:00:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:00:28 --> URI Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Router Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Output Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Security Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Input Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:00:28 --> Language Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Loader Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:00:28 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Session Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:00:28 --> Session routines successfully run
DEBUG - 2012-02-02 00:00:28 --> Cart Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Model Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Model Class Initialized
DEBUG - 2012-02-02 00:00:28 --> Controller Class Initialized
DEBUG - 2012-02-02 00:00:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:00:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:00:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:00:28 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:00:28 --> Final output sent to browser
DEBUG - 2012-02-02 00:00:29 --> Total execution time: 0.4506
DEBUG - 2012-02-02 00:00:29 --> Config Class Initialized
DEBUG - 2012-02-02 00:00:29 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:00:29 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:00:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:00:29 --> URI Class Initialized
DEBUG - 2012-02-02 00:00:29 --> Router Class Initialized
ERROR - 2012-02-02 00:00:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 00:02:23 --> Config Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:02:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:02:23 --> URI Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Router Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Output Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Security Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Input Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:02:23 --> Language Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Loader Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:02:23 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Session Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:02:23 --> Session routines successfully run
DEBUG - 2012-02-02 00:02:23 --> Cart Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Model Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Model Class Initialized
DEBUG - 2012-02-02 00:02:23 --> Controller Class Initialized
DEBUG - 2012-02-02 00:02:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:02:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:02:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:02:23 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:02:23 --> Final output sent to browser
DEBUG - 2012-02-02 00:02:23 --> Total execution time: 0.3819
DEBUG - 2012-02-02 00:02:24 --> Config Class Initialized
DEBUG - 2012-02-02 00:02:24 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:02:24 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:02:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:02:24 --> URI Class Initialized
DEBUG - 2012-02-02 00:02:24 --> Router Class Initialized
ERROR - 2012-02-02 00:02:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 00:02:32 --> Config Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:02:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:02:32 --> URI Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Router Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Output Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Security Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Input Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:02:32 --> Language Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Loader Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:02:32 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Session Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:02:32 --> Session routines successfully run
DEBUG - 2012-02-02 00:02:32 --> Cart Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Model Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Model Class Initialized
DEBUG - 2012-02-02 00:02:32 --> Controller Class Initialized
DEBUG - 2012-02-02 00:02:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:02:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:02:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:02:32 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:02:32 --> Final output sent to browser
DEBUG - 2012-02-02 00:02:32 --> Total execution time: 0.4336
DEBUG - 2012-02-02 00:02:48 --> Config Class Initialized
DEBUG - 2012-02-02 00:02:48 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:02:48 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:02:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:02:48 --> URI Class Initialized
DEBUG - 2012-02-02 00:02:48 --> Router Class Initialized
ERROR - 2012-02-02 00:02:48 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 00:02:50 --> Config Class Initialized
DEBUG - 2012-02-02 00:02:50 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:02:50 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:02:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:02:50 --> URI Class Initialized
DEBUG - 2012-02-02 00:02:50 --> Router Class Initialized
ERROR - 2012-02-02 00:02:50 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 00:04:26 --> Config Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:04:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:04:26 --> URI Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Router Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Output Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Security Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Input Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:04:26 --> Language Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Loader Class Initialized
DEBUG - 2012-02-02 00:04:26 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:04:27 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:04:27 --> Session Class Initialized
DEBUG - 2012-02-02 00:04:27 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:04:27 --> Session routines successfully run
DEBUG - 2012-02-02 00:04:27 --> Cart Class Initialized
DEBUG - 2012-02-02 00:04:27 --> Model Class Initialized
DEBUG - 2012-02-02 00:04:27 --> Model Class Initialized
DEBUG - 2012-02-02 00:04:27 --> Controller Class Initialized
DEBUG - 2012-02-02 00:04:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:04:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:04:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:04:27 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:04:27 --> Final output sent to browser
DEBUG - 2012-02-02 00:04:27 --> Total execution time: 0.4862
DEBUG - 2012-02-02 00:04:34 --> Config Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:04:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:04:34 --> URI Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Router Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Output Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Security Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Input Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:04:34 --> Language Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Loader Class Initialized
DEBUG - 2012-02-02 00:04:34 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:04:35 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:04:35 --> Session Class Initialized
DEBUG - 2012-02-02 00:04:35 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:04:35 --> Session routines successfully run
DEBUG - 2012-02-02 00:04:35 --> Cart Class Initialized
DEBUG - 2012-02-02 00:04:35 --> Model Class Initialized
DEBUG - 2012-02-02 00:04:35 --> Model Class Initialized
DEBUG - 2012-02-02 00:04:35 --> Controller Class Initialized
DEBUG - 2012-02-02 00:04:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:04:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:04:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:04:35 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:04:35 --> Final output sent to browser
DEBUG - 2012-02-02 00:04:35 --> Total execution time: 1.1788
DEBUG - 2012-02-02 00:05:33 --> Config Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:05:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:05:33 --> URI Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Router Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Output Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Security Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Input Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:05:33 --> Language Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Loader Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:05:33 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Session Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:05:33 --> Session routines successfully run
DEBUG - 2012-02-02 00:05:33 --> Cart Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Model Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Model Class Initialized
DEBUG - 2012-02-02 00:05:33 --> Controller Class Initialized
DEBUG - 2012-02-02 00:05:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:05:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:05:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:05:33 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:05:33 --> Final output sent to browser
DEBUG - 2012-02-02 00:05:33 --> Total execution time: 0.4810
DEBUG - 2012-02-02 00:05:50 --> Config Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:05:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:05:50 --> URI Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Router Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Output Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Security Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Input Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:05:50 --> Language Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Loader Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:05:50 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Session Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:05:50 --> Session routines successfully run
DEBUG - 2012-02-02 00:05:50 --> Cart Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Model Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Model Class Initialized
DEBUG - 2012-02-02 00:05:50 --> Controller Class Initialized
DEBUG - 2012-02-02 00:05:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:05:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:05:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:05:51 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:05:51 --> Final output sent to browser
DEBUG - 2012-02-02 00:05:51 --> Total execution time: 0.5590
DEBUG - 2012-02-02 00:05:54 --> Config Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:05:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:05:54 --> URI Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Router Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Output Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Security Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Input Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:05:54 --> Language Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Loader Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:05:54 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Session Class Initialized
DEBUG - 2012-02-02 00:05:54 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:05:55 --> Session routines successfully run
DEBUG - 2012-02-02 00:05:55 --> Cart Class Initialized
DEBUG - 2012-02-02 00:05:55 --> Model Class Initialized
DEBUG - 2012-02-02 00:05:55 --> Model Class Initialized
DEBUG - 2012-02-02 00:05:55 --> Controller Class Initialized
DEBUG - 2012-02-02 00:05:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:05:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:05:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:05:55 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:05:55 --> Final output sent to browser
DEBUG - 2012-02-02 00:05:55 --> Total execution time: 1.0903
DEBUG - 2012-02-02 00:11:36 --> Config Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:11:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:11:36 --> URI Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Router Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Output Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Security Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Input Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:11:36 --> Language Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Loader Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:11:36 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Session Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:11:36 --> Session routines successfully run
DEBUG - 2012-02-02 00:11:36 --> Cart Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Model Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Model Class Initialized
DEBUG - 2012-02-02 00:11:36 --> Controller Class Initialized
DEBUG - 2012-02-02 00:11:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:11:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:11:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:11:37 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:11:37 --> Final output sent to browser
DEBUG - 2012-02-02 00:11:37 --> Total execution time: 0.7080
DEBUG - 2012-02-02 00:11:57 --> Config Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:11:58 --> URI Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Router Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Output Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Security Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Input Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:11:58 --> Language Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Loader Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:11:58 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Session Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:11:58 --> Session routines successfully run
DEBUG - 2012-02-02 00:11:58 --> Cart Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Model Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Model Class Initialized
DEBUG - 2012-02-02 00:11:58 --> Controller Class Initialized
DEBUG - 2012-02-02 00:11:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:11:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:11:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:11:59 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:11:59 --> Final output sent to browser
DEBUG - 2012-02-02 00:11:59 --> Total execution time: 4.7384
DEBUG - 2012-02-02 00:16:12 --> Config Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:16:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:16:12 --> URI Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Router Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Output Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Security Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Input Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:16:12 --> Language Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Loader Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:16:12 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Session Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:16:12 --> Session routines successfully run
DEBUG - 2012-02-02 00:16:12 --> Cart Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:12 --> Controller Class Initialized
DEBUG - 2012-02-02 00:16:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:16:12 --> File loaded: application/views/user/blocks/sidebar.php
ERROR - 2012-02-02 00:16:12 --> Severity: Notice  --> Undefined variable: _SESSION A:\home\codeigniter.fool\www\application\views\user\order.php 44
DEBUG - 2012-02-02 00:16:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:16:13 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:16:13 --> Final output sent to browser
DEBUG - 2012-02-02 00:16:13 --> Total execution time: 0.5785
DEBUG - 2012-02-02 00:16:20 --> Config Class Initialized
DEBUG - 2012-02-02 00:16:20 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:16:20 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:16:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:16:20 --> URI Class Initialized
DEBUG - 2012-02-02 00:16:20 --> Router Class Initialized
DEBUG - 2012-02-02 00:16:20 --> Output Class Initialized
DEBUG - 2012-02-02 00:16:20 --> Security Class Initialized
DEBUG - 2012-02-02 00:16:20 --> Input Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:16:21 --> Language Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Loader Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:16:21 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Session Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:16:21 --> Session routines successfully run
DEBUG - 2012-02-02 00:16:21 --> Cart Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Controller Class Initialized
DEBUG - 2012-02-02 00:16:21 --> XSS Filtering completed
DEBUG - 2012-02-02 00:16:21 --> XSS Filtering completed
DEBUG - 2012-02-02 00:16:21 --> XSS Filtering completed
DEBUG - 2012-02-02 00:16:21 --> Config Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:16:21 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:16:21 --> URI Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Router Class Initialized
DEBUG - 2012-02-02 00:16:21 --> No URI present. Default controller set.
DEBUG - 2012-02-02 00:16:21 --> Output Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Security Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Input Class Initialized
DEBUG - 2012-02-02 00:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:16:21 --> Language Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Loader Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:16:22 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Session Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:16:22 --> Session routines successfully run
DEBUG - 2012-02-02 00:16:22 --> Cart Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Controller Class Initialized
DEBUG - 2012-02-02 00:16:22 --> Pagination Class Initialized
DEBUG - 2012-02-02 00:16:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:16:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:16:22 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 00:16:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:16:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 00:16:22 --> Final output sent to browser
DEBUG - 2012-02-02 00:16:22 --> Total execution time: 0.5599
DEBUG - 2012-02-02 00:16:42 --> Config Class Initialized
DEBUG - 2012-02-02 00:16:42 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:16:42 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:16:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:16:42 --> URI Class Initialized
DEBUG - 2012-02-02 00:16:43 --> Router Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Output Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Security Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Input Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:16:45 --> Language Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Loader Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:16:45 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Session Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:16:45 --> Session routines successfully run
DEBUG - 2012-02-02 00:16:45 --> Cart Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:45 --> Controller Class Initialized
DEBUG - 2012-02-02 00:16:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:16:45 --> File loaded: application/views/user/blocks/sidebar.php
ERROR - 2012-02-02 00:16:45 --> Severity: Notice  --> Undefined variable: _SESSION A:\home\codeigniter.fool\www\application\views\user\order.php 44
DEBUG - 2012-02-02 00:16:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:16:45 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:16:45 --> Final output sent to browser
DEBUG - 2012-02-02 00:16:45 --> Total execution time: 3.1764
DEBUG - 2012-02-02 00:16:50 --> Config Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:16:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:16:50 --> URI Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Router Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Output Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Security Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Input Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:16:50 --> Language Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Loader Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:16:50 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Session Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:16:50 --> Session routines successfully run
DEBUG - 2012-02-02 00:16:50 --> Cart Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:50 --> Controller Class Initialized
DEBUG - 2012-02-02 00:16:50 --> XSS Filtering completed
DEBUG - 2012-02-02 00:16:50 --> XSS Filtering completed
DEBUG - 2012-02-02 00:16:50 --> XSS Filtering completed
DEBUG - 2012-02-02 00:16:51 --> Config Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:16:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:16:51 --> URI Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Router Class Initialized
DEBUG - 2012-02-02 00:16:51 --> No URI present. Default controller set.
DEBUG - 2012-02-02 00:16:51 --> Output Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Security Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Input Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:16:51 --> Language Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Loader Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:16:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Session Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:16:51 --> Session routines successfully run
DEBUG - 2012-02-02 00:16:51 --> Cart Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Controller Class Initialized
DEBUG - 2012-02-02 00:16:51 --> Pagination Class Initialized
DEBUG - 2012-02-02 00:16:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:16:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:16:51 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 00:16:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:16:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 00:16:51 --> Final output sent to browser
DEBUG - 2012-02-02 00:16:51 --> Total execution time: 0.4805
DEBUG - 2012-02-02 00:16:53 --> Config Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:16:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:16:53 --> URI Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Router Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Output Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Security Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Input Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:16:53 --> Language Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Loader Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:16:53 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Session Class Initialized
DEBUG - 2012-02-02 00:16:53 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:16:54 --> Session routines successfully run
DEBUG - 2012-02-02 00:16:54 --> Cart Class Initialized
DEBUG - 2012-02-02 00:16:54 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:54 --> Model Class Initialized
DEBUG - 2012-02-02 00:16:54 --> Controller Class Initialized
DEBUG - 2012-02-02 00:16:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:16:54 --> File loaded: application/views/user/blocks/sidebar.php
ERROR - 2012-02-02 00:16:54 --> Severity: Notice  --> Undefined variable: _SESSION A:\home\codeigniter.fool\www\application\views\user\order.php 44
DEBUG - 2012-02-02 00:16:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:16:54 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:16:54 --> Final output sent to browser
DEBUG - 2012-02-02 00:16:54 --> Total execution time: 0.4611
DEBUG - 2012-02-02 00:17:36 --> Config Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:17:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:17:36 --> URI Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Router Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Output Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Security Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Input Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:17:36 --> Language Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Loader Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:17:36 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Session Class Initialized
DEBUG - 2012-02-02 00:17:36 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:17:36 --> Session routines successfully run
DEBUG - 2012-02-02 00:17:37 --> Cart Class Initialized
DEBUG - 2012-02-02 00:17:37 --> Model Class Initialized
DEBUG - 2012-02-02 00:17:37 --> Model Class Initialized
DEBUG - 2012-02-02 00:17:37 --> Controller Class Initialized
DEBUG - 2012-02-02 00:17:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:17:37 --> File loaded: application/views/user/blocks/sidebar.php
ERROR - 2012-02-02 00:17:37 --> Severity: Notice  --> Undefined variable: _SESSION A:\home\codeigniter.fool\www\application\views\user\order.php 44
DEBUG - 2012-02-02 00:17:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:17:37 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:17:37 --> Final output sent to browser
DEBUG - 2012-02-02 00:17:37 --> Total execution time: 0.5245
DEBUG - 2012-02-02 00:19:06 --> Config Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:19:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:19:06 --> URI Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Router Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Output Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Security Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Input Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:19:06 --> Language Class Initialized
DEBUG - 2012-02-02 00:19:06 --> Loader Class Initialized
DEBUG - 2012-02-02 00:19:07 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:19:07 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:19:07 --> Session Class Initialized
DEBUG - 2012-02-02 00:19:07 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:19:07 --> Session routines successfully run
DEBUG - 2012-02-02 00:19:07 --> Cart Class Initialized
DEBUG - 2012-02-02 00:19:07 --> Model Class Initialized
DEBUG - 2012-02-02 00:19:07 --> Model Class Initialized
DEBUG - 2012-02-02 00:19:07 --> Controller Class Initialized
DEBUG - 2012-02-02 00:19:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:19:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:19:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:19:07 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:19:07 --> Final output sent to browser
DEBUG - 2012-02-02 00:19:07 --> Total execution time: 1.5238
DEBUG - 2012-02-02 00:19:18 --> Config Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:19:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:19:18 --> URI Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Router Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Output Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Security Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Input Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:19:18 --> Language Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Loader Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:19:18 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Session Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:19:18 --> Session routines successfully run
DEBUG - 2012-02-02 00:19:18 --> Cart Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Model Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Model Class Initialized
DEBUG - 2012-02-02 00:19:18 --> Controller Class Initialized
DEBUG - 2012-02-02 00:19:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:19:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:19:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:19:18 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:19:19 --> Final output sent to browser
DEBUG - 2012-02-02 00:19:19 --> Total execution time: 0.5808
DEBUG - 2012-02-02 00:19:50 --> Config Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:19:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:19:50 --> URI Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Router Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Output Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Security Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Input Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:19:50 --> Language Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Loader Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:19:50 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Session Class Initialized
DEBUG - 2012-02-02 00:19:50 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:19:51 --> Session routines successfully run
DEBUG - 2012-02-02 00:19:51 --> Cart Class Initialized
DEBUG - 2012-02-02 00:19:51 --> Model Class Initialized
DEBUG - 2012-02-02 00:19:51 --> Model Class Initialized
DEBUG - 2012-02-02 00:19:51 --> Controller Class Initialized
DEBUG - 2012-02-02 00:19:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:19:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:19:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:19:51 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:19:51 --> Final output sent to browser
DEBUG - 2012-02-02 00:19:51 --> Total execution time: 0.5663
DEBUG - 2012-02-02 00:20:51 --> Config Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:20:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:20:51 --> URI Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Router Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Output Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Security Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Input Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:20:51 --> Language Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Loader Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:20:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Session Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:20:51 --> Session routines successfully run
DEBUG - 2012-02-02 00:20:51 --> Cart Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Model Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Model Class Initialized
DEBUG - 2012-02-02 00:20:51 --> Controller Class Initialized
DEBUG - 2012-02-02 00:20:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:20:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:20:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:20:51 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:20:51 --> Final output sent to browser
DEBUG - 2012-02-02 00:20:51 --> Total execution time: 0.5443
DEBUG - 2012-02-02 00:21:47 --> Config Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:21:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:21:47 --> URI Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Router Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Output Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Security Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Input Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:21:47 --> Language Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Loader Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:21:47 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Session Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:21:47 --> Session routines successfully run
DEBUG - 2012-02-02 00:21:47 --> Cart Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Model Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Model Class Initialized
DEBUG - 2012-02-02 00:21:47 --> Controller Class Initialized
DEBUG - 2012-02-02 00:21:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:21:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:21:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:21:47 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 00:21:48 --> Final output sent to browser
DEBUG - 2012-02-02 00:21:48 --> Total execution time: 0.4836
DEBUG - 2012-02-02 00:23:37 --> Config Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Hooks Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Utf8 Class Initialized
DEBUG - 2012-02-02 00:23:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 00:23:37 --> URI Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Router Class Initialized
DEBUG - 2012-02-02 00:23:37 --> No URI present. Default controller set.
DEBUG - 2012-02-02 00:23:37 --> Output Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Security Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Input Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 00:23:37 --> Language Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Loader Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Helper loaded: url_helper
DEBUG - 2012-02-02 00:23:37 --> Database Driver Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Session Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Helper loaded: string_helper
DEBUG - 2012-02-02 00:23:37 --> Session routines successfully run
DEBUG - 2012-02-02 00:23:37 --> Cart Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Model Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Model Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Controller Class Initialized
DEBUG - 2012-02-02 00:23:37 --> Pagination Class Initialized
DEBUG - 2012-02-02 00:23:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 00:23:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 00:23:37 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 00:23:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 00:23:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 00:23:37 --> Final output sent to browser
DEBUG - 2012-02-02 00:23:37 --> Total execution time: 0.2432
DEBUG - 2012-02-02 21:31:02 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:02 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:02 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Router Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Router Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Output Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Output Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Security Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Security Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Input Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Input Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 21:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 21:31:02 --> Language Class Initialized
DEBUG - 2012-02-02 21:31:02 --> Language Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Loader Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Loader Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Helper loaded: url_helper
DEBUG - 2012-02-02 21:31:03 --> Helper loaded: url_helper
DEBUG - 2012-02-02 21:31:03 --> Database Driver Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Database Driver Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Session Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Session Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Helper loaded: string_helper
DEBUG - 2012-02-02 21:31:03 --> Helper loaded: string_helper
DEBUG - 2012-02-02 21:31:03 --> A session cookie was not found.
DEBUG - 2012-02-02 21:31:03 --> A session cookie was not found.
DEBUG - 2012-02-02 21:31:03 --> Session routines successfully run
DEBUG - 2012-02-02 21:31:03 --> Session routines successfully run
DEBUG - 2012-02-02 21:31:03 --> Cart Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Cart Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Controller Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Controller Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:03 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Router Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Output Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Security Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Input Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 21:31:03 --> Language Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Loader Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Helper loaded: url_helper
DEBUG - 2012-02-02 21:31:03 --> Database Driver Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Session Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Helper loaded: string_helper
DEBUG - 2012-02-02 21:31:03 --> Session routines successfully run
DEBUG - 2012-02-02 21:31:03 --> Cart Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:03 --> Controller Class Initialized
DEBUG - 2012-02-02 21:31:04 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-02 21:31:04 --> Final output sent to browser
DEBUG - 2012-02-02 21:31:04 --> Total execution time: 0.3745
DEBUG - 2012-02-02 21:31:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 21:31:04 --> File loaded: application/views/user/blocks/sidebar.php
ERROR - 2012-02-02 21:31:05 --> Severity: Notice  --> Undefined index: code A:\home\codeigniter.fool\www\application\views\user\order.php 45
DEBUG - 2012-02-02 21:31:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 21:31:05 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 21:31:05 --> Final output sent to browser
DEBUG - 2012-02-02 21:31:05 --> Total execution time: 3.1371
DEBUG - 2012-02-02 21:31:05 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:05 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:05 --> Router Class Initialized
ERROR - 2012-02-02 21:31:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 21:31:05 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:05 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:05 --> Router Class Initialized
ERROR - 2012-02-02 21:31:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 21:31:11 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:11 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Router Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Output Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Security Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Input Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 21:31:11 --> Language Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Loader Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Helper loaded: url_helper
DEBUG - 2012-02-02 21:31:11 --> Database Driver Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Session Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Helper loaded: string_helper
DEBUG - 2012-02-02 21:31:11 --> Session routines successfully run
DEBUG - 2012-02-02 21:31:11 --> Cart Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:11 --> Controller Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:12 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Router Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Output Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Security Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Input Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 21:31:12 --> Language Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Loader Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Helper loaded: url_helper
DEBUG - 2012-02-02 21:31:12 --> Database Driver Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Session Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Helper loaded: string_helper
DEBUG - 2012-02-02 21:31:12 --> Session routines successfully run
DEBUG - 2012-02-02 21:31:12 --> Cart Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Model Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Controller Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Pagination Class Initialized
DEBUG - 2012-02-02 21:31:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 21:31:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 21:31:12 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 21:31:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 21:31:12 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 21:31:12 --> Final output sent to browser
DEBUG - 2012-02-02 21:31:12 --> Total execution time: 0.4931
DEBUG - 2012-02-02 21:31:12 --> Config Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Hooks Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Utf8 Class Initialized
DEBUG - 2012-02-02 21:31:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 21:31:12 --> URI Class Initialized
DEBUG - 2012-02-02 21:31:12 --> Router Class Initialized
ERROR - 2012-02-02 21:31:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:25:24 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:24 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:25 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:25 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:25 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:25 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:25 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:25 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 22:25:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 22:25:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 22:25:26 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 22:25:26 --> Final output sent to browser
DEBUG - 2012-02-02 22:25:26 --> Total execution time: 1.4741
DEBUG - 2012-02-02 22:25:26 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:26 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:26 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:26 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:26 --> Router Class Initialized
ERROR - 2012-02-02 22:25:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:25:27 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:27 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:27 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:27 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:27 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:27 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:27 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:27 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:27 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:28 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:28 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:28 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:28 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:28 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:28 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:28 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:28 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:28 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:28 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:29 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:29 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:29 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:29 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:29 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Pagination Class Initialized
DEBUG - 2012-02-02 22:25:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 22:25:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 22:25:29 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 22:25:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 22:25:29 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 22:25:29 --> Final output sent to browser
DEBUG - 2012-02-02 22:25:29 --> Total execution time: 0.3228
DEBUG - 2012-02-02 22:25:29 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:29 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:29 --> Router Class Initialized
ERROR - 2012-02-02 22:25:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:25:30 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:30 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:30 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:30 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:31 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:31 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:31 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:31 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:31 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 22:25:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 22:25:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 22:25:31 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 22:25:31 --> Final output sent to browser
DEBUG - 2012-02-02 22:25:31 --> Total execution time: 0.4797
DEBUG - 2012-02-02 22:25:32 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:32 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:32 --> Router Class Initialized
ERROR - 2012-02-02 22:25:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:25:32 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:33 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:33 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:33 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:33 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:33 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:33 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:34 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:34 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:35 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:35 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:35 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:35 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:35 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:35 --> Pagination Class Initialized
DEBUG - 2012-02-02 22:25:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 22:25:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 22:25:35 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 22:25:35 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 22:25:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 22:25:35 --> Final output sent to browser
DEBUG - 2012-02-02 22:25:35 --> Total execution time: 0.6716
DEBUG - 2012-02-02 22:25:36 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:36 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:36 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:36 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:36 --> Router Class Initialized
ERROR - 2012-02-02 22:25:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:25:41 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:41 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:41 --> No URI present. Default controller set.
DEBUG - 2012-02-02 22:25:41 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:41 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:41 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:41 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:41 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:41 --> Pagination Class Initialized
DEBUG - 2012-02-02 22:25:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:25:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:25:41 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 22:25:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:25:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 22:25:41 --> Final output sent to browser
DEBUG - 2012-02-02 22:25:41 --> Total execution time: 0.7931
DEBUG - 2012-02-02 22:25:43 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:43 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:43 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:43 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:43 --> Router Class Initialized
ERROR - 2012-02-02 22:25:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:25:52 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:52 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:53 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:53 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:53 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:53 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:53 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:53 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:25:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:25:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:25:53 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-02 22:25:53 --> Final output sent to browser
DEBUG - 2012-02-02 22:25:53 --> Total execution time: 0.8215
DEBUG - 2012-02-02 22:25:54 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:54 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:54 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:54 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:54 --> Router Class Initialized
ERROR - 2012-02-02 22:25:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:25:55 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:55 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Router Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Output Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Security Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Input Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:25:55 --> Language Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Loader Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:25:55 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Session Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:25:55 --> Session routines successfully run
DEBUG - 2012-02-02 22:25:55 --> Cart Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:55 --> Model Class Initialized
DEBUG - 2012-02-02 22:25:56 --> Controller Class Initialized
DEBUG - 2012-02-02 22:25:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:25:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:25:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:25:56 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:25:56 --> Final output sent to browser
DEBUG - 2012-02-02 22:25:56 --> Total execution time: 0.8211
DEBUG - 2012-02-02 22:25:56 --> Config Class Initialized
DEBUG - 2012-02-02 22:25:56 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:25:56 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:25:56 --> URI Class Initialized
DEBUG - 2012-02-02 22:25:56 --> Router Class Initialized
ERROR - 2012-02-02 22:25:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 22:26:06 --> Config Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:26:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:26:06 --> URI Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Router Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Output Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Security Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Input Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:26:06 --> Language Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Loader Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:26:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Session Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:26:06 --> A session cookie was not found.
DEBUG - 2012-02-02 22:26:06 --> Session routines successfully run
DEBUG - 2012-02-02 22:26:06 --> Cart Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Model Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Model Class Initialized
DEBUG - 2012-02-02 22:26:06 --> Controller Class Initialized
DEBUG - 2012-02-02 22:26:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:26:06 --> File loaded: application/views/user/blocks/sidebar.php
ERROR - 2012-02-02 22:26:06 --> Severity: Notice  --> Undefined index: code A:\home\codeigniter.fool\www\application\views\user\order.php 45
DEBUG - 2012-02-02 22:26:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:26:06 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:26:06 --> Final output sent to browser
DEBUG - 2012-02-02 22:26:06 --> Total execution time: 0.8145
DEBUG - 2012-02-02 22:27:51 --> Config Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:27:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:27:51 --> URI Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Router Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Output Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Security Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Input Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:27:51 --> Language Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Loader Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:27:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Session Class Initialized
DEBUG - 2012-02-02 22:27:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:27:52 --> Session routines successfully run
DEBUG - 2012-02-02 22:27:52 --> Cart Class Initialized
DEBUG - 2012-02-02 22:27:52 --> Model Class Initialized
DEBUG - 2012-02-02 22:27:52 --> Model Class Initialized
DEBUG - 2012-02-02 22:27:52 --> Controller Class Initialized
DEBUG - 2012-02-02 22:27:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:27:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:27:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:27:52 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:27:52 --> Final output sent to browser
DEBUG - 2012-02-02 22:27:52 --> Total execution time: 0.4972
DEBUG - 2012-02-02 22:28:09 --> Config Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:28:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:28:09 --> URI Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Router Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Output Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Security Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Input Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:28:09 --> Language Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Loader Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:28:09 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Session Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:28:09 --> Session routines successfully run
DEBUG - 2012-02-02 22:28:09 --> Cart Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Model Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Model Class Initialized
DEBUG - 2012-02-02 22:28:09 --> Controller Class Initialized
DEBUG - 2012-02-02 22:28:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:28:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:28:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:28:09 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:28:09 --> Final output sent to browser
DEBUG - 2012-02-02 22:28:09 --> Total execution time: 0.5250
DEBUG - 2012-02-02 22:31:03 --> Config Class Initialized
DEBUG - 2012-02-02 22:31:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:31:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:31:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:31:03 --> URI Class Initialized
DEBUG - 2012-02-02 22:31:03 --> Router Class Initialized
DEBUG - 2012-02-02 22:31:03 --> Output Class Initialized
DEBUG - 2012-02-02 22:31:03 --> Security Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Input Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:31:04 --> Language Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Loader Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:31:04 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Session Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:31:04 --> Session routines successfully run
DEBUG - 2012-02-02 22:31:04 --> Cart Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Model Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Model Class Initialized
DEBUG - 2012-02-02 22:31:04 --> Controller Class Initialized
DEBUG - 2012-02-02 22:31:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:31:04 --> File loaded: application/views/user/blocks/sidebar.php
ERROR - 2012-02-02 22:31:04 --> Severity: Warning  --> file_get_contents(/additions/captcha.php) [<a href='function.file-get-contents'>function.file-get-contents</a>]: failed to open stream: No such file or directory A:\home\codeigniter.fool\www\application\views\user\order.php 45
DEBUG - 2012-02-02 22:31:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:31:04 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:31:04 --> Final output sent to browser
DEBUG - 2012-02-02 22:31:04 --> Total execution time: 0.5396
DEBUG - 2012-02-02 22:32:03 --> Config Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:32:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:32:03 --> URI Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Router Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Output Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Security Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Input Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:32:03 --> Language Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Loader Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:32:03 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Session Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:32:03 --> Session routines successfully run
DEBUG - 2012-02-02 22:32:03 --> Cart Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:03 --> Controller Class Initialized
DEBUG - 2012-02-02 22:32:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:32:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:32:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:32:03 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:32:03 --> Final output sent to browser
DEBUG - 2012-02-02 22:32:04 --> Total execution time: 0.6668
DEBUG - 2012-02-02 22:32:13 --> Config Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:32:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:32:13 --> URI Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Router Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Output Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Security Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Input Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:32:13 --> Language Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Loader Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:32:13 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Session Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:32:13 --> Session routines successfully run
DEBUG - 2012-02-02 22:32:13 --> Cart Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:13 --> Controller Class Initialized
DEBUG - 2012-02-02 22:32:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:32:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:32:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:32:13 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:32:14 --> Final output sent to browser
DEBUG - 2012-02-02 22:32:14 --> Total execution time: 0.7689
DEBUG - 2012-02-02 22:32:23 --> Config Class Initialized
DEBUG - 2012-02-02 22:32:23 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:32:23 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:32:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:32:24 --> URI Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Router Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Output Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Security Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Input Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:32:24 --> Language Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Loader Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:32:24 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Session Class Initialized
DEBUG - 2012-02-02 22:32:24 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:32:24 --> Session routines successfully run
DEBUG - 2012-02-02 22:32:25 --> Cart Class Initialized
DEBUG - 2012-02-02 22:32:27 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:27 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:27 --> Controller Class Initialized
DEBUG - 2012-02-02 22:32:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:32:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:32:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:32:27 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:32:27 --> Final output sent to browser
DEBUG - 2012-02-02 22:32:27 --> Total execution time: 3.3985
DEBUG - 2012-02-02 22:32:38 --> Config Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:32:38 --> URI Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Router Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Output Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Security Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Input Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:32:38 --> Language Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Loader Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:32:38 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Session Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:32:38 --> Session routines successfully run
DEBUG - 2012-02-02 22:32:38 --> Cart Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Model Class Initialized
DEBUG - 2012-02-02 22:32:38 --> Controller Class Initialized
DEBUG - 2012-02-02 22:32:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:32:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:32:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:32:38 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:32:38 --> Final output sent to browser
DEBUG - 2012-02-02 22:32:38 --> Total execution time: 0.6537
DEBUG - 2012-02-02 22:34:05 --> Config Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:34:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:34:05 --> URI Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Router Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Output Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Security Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Input Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:34:05 --> Language Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Loader Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:34:05 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Session Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:34:05 --> Session routines successfully run
DEBUG - 2012-02-02 22:34:05 --> Cart Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:05 --> Controller Class Initialized
DEBUG - 2012-02-02 22:34:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:34:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:34:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:34:06 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:34:06 --> Final output sent to browser
DEBUG - 2012-02-02 22:34:06 --> Total execution time: 0.5493
DEBUG - 2012-02-02 22:34:19 --> Config Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:34:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:34:19 --> URI Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Router Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Output Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Security Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Input Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:34:19 --> Language Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Loader Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:34:19 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Session Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:34:19 --> Session routines successfully run
DEBUG - 2012-02-02 22:34:19 --> Cart Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:19 --> Controller Class Initialized
DEBUG - 2012-02-02 22:34:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:34:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:34:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:34:19 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:34:19 --> Final output sent to browser
DEBUG - 2012-02-02 22:34:19 --> Total execution time: 0.5451
DEBUG - 2012-02-02 22:34:29 --> Config Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:34:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:34:29 --> URI Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Router Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Output Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Security Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Input Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:34:29 --> Language Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Loader Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:34:29 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Session Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:34:29 --> Session routines successfully run
DEBUG - 2012-02-02 22:34:29 --> Cart Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:29 --> Controller Class Initialized
DEBUG - 2012-02-02 22:34:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:34:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:34:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:34:29 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:34:29 --> Final output sent to browser
DEBUG - 2012-02-02 22:34:29 --> Total execution time: 0.6439
DEBUG - 2012-02-02 22:34:58 --> Config Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:34:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:34:58 --> URI Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Router Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Output Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Security Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Input Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:34:58 --> Language Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Loader Class Initialized
DEBUG - 2012-02-02 22:34:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:34:59 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:34:59 --> Session Class Initialized
DEBUG - 2012-02-02 22:34:59 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:34:59 --> Session routines successfully run
DEBUG - 2012-02-02 22:34:59 --> Cart Class Initialized
DEBUG - 2012-02-02 22:34:59 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:59 --> Model Class Initialized
DEBUG - 2012-02-02 22:34:59 --> Controller Class Initialized
DEBUG - 2012-02-02 22:34:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:34:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:34:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:34:59 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:34:59 --> Final output sent to browser
DEBUG - 2012-02-02 22:34:59 --> Total execution time: 0.5477
DEBUG - 2012-02-02 22:35:13 --> Config Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:35:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:35:13 --> URI Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Router Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Output Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Security Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Input Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:35:13 --> Language Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Loader Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:35:13 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Session Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:35:13 --> Session routines successfully run
DEBUG - 2012-02-02 22:35:13 --> Cart Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Model Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Model Class Initialized
DEBUG - 2012-02-02 22:35:13 --> Controller Class Initialized
DEBUG - 2012-02-02 22:35:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:35:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:35:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:35:14 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:35:14 --> Final output sent to browser
DEBUG - 2012-02-02 22:35:14 --> Total execution time: 0.5897
DEBUG - 2012-02-02 22:35:24 --> Config Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:35:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:35:24 --> URI Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Router Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Output Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Security Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Input Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:35:24 --> Language Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Loader Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:35:24 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Session Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:35:24 --> Session routines successfully run
DEBUG - 2012-02-02 22:35:24 --> Cart Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Model Class Initialized
DEBUG - 2012-02-02 22:35:24 --> Model Class Initialized
DEBUG - 2012-02-02 22:35:25 --> Controller Class Initialized
DEBUG - 2012-02-02 22:35:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:35:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:35:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:35:25 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:35:25 --> Final output sent to browser
DEBUG - 2012-02-02 22:35:25 --> Total execution time: 0.6997
DEBUG - 2012-02-02 22:36:51 --> Config Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:36:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:36:51 --> URI Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Router Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Output Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Security Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Input Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:36:51 --> Language Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Loader Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:36:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Session Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:36:51 --> Session routines successfully run
DEBUG - 2012-02-02 22:36:51 --> Cart Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Model Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Model Class Initialized
DEBUG - 2012-02-02 22:36:51 --> Controller Class Initialized
DEBUG - 2012-02-02 22:36:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:36:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:36:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:36:52 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:36:53 --> Final output sent to browser
DEBUG - 2012-02-02 22:36:53 --> Total execution time: 1.6011
DEBUG - 2012-02-02 22:37:06 --> Config Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:37:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:37:06 --> URI Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Router Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Output Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Security Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Input Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:37:06 --> Language Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Loader Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:37:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Session Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:37:06 --> Session routines successfully run
DEBUG - 2012-02-02 22:37:06 --> Cart Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Model Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Model Class Initialized
DEBUG - 2012-02-02 22:37:06 --> Controller Class Initialized
DEBUG - 2012-02-02 22:37:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:37:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:37:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:37:07 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:37:08 --> Final output sent to browser
DEBUG - 2012-02-02 22:37:08 --> Total execution time: 1.7513
DEBUG - 2012-02-02 22:38:13 --> Config Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:38:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:38:13 --> URI Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Router Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Output Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Security Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Input Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:38:13 --> Language Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Loader Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:38:13 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Session Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:38:13 --> Session routines successfully run
DEBUG - 2012-02-02 22:38:13 --> Cart Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Model Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Model Class Initialized
DEBUG - 2012-02-02 22:38:13 --> Controller Class Initialized
DEBUG - 2012-02-02 22:38:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:38:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:38:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:38:13 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:38:13 --> Final output sent to browser
DEBUG - 2012-02-02 22:38:13 --> Total execution time: 0.4875
DEBUG - 2012-02-02 22:38:20 --> Config Class Initialized
DEBUG - 2012-02-02 22:38:20 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:38:20 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:38:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:38:20 --> URI Class Initialized
DEBUG - 2012-02-02 22:38:20 --> Router Class Initialized
DEBUG - 2012-02-02 22:38:20 --> Output Class Initialized
DEBUG - 2012-02-02 22:38:20 --> Security Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Input Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:38:21 --> Language Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Loader Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:38:21 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Session Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:38:21 --> Session routines successfully run
DEBUG - 2012-02-02 22:38:21 --> Cart Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Model Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Model Class Initialized
DEBUG - 2012-02-02 22:38:21 --> Controller Class Initialized
DEBUG - 2012-02-02 22:38:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:38:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:38:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:38:21 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:38:21 --> Final output sent to browser
DEBUG - 2012-02-02 22:38:21 --> Total execution time: 0.8907
DEBUG - 2012-02-02 22:39:39 --> Config Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:39:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:39:39 --> URI Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Router Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Output Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Security Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Input Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:39:39 --> Language Class Initialized
DEBUG - 2012-02-02 22:39:39 --> Loader Class Initialized
DEBUG - 2012-02-02 22:39:40 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:39:40 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:39:40 --> Session Class Initialized
DEBUG - 2012-02-02 22:39:40 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:39:40 --> Session routines successfully run
DEBUG - 2012-02-02 22:39:40 --> Cart Class Initialized
DEBUG - 2012-02-02 22:39:40 --> Model Class Initialized
DEBUG - 2012-02-02 22:39:40 --> Model Class Initialized
DEBUG - 2012-02-02 22:39:40 --> Controller Class Initialized
DEBUG - 2012-02-02 22:39:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:39:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:39:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:39:40 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:39:40 --> Final output sent to browser
DEBUG - 2012-02-02 22:39:40 --> Total execution time: 0.5233
DEBUG - 2012-02-02 22:40:21 --> Config Class Initialized
DEBUG - 2012-02-02 22:40:21 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:40:21 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:40:21 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:40:21 --> URI Class Initialized
DEBUG - 2012-02-02 22:40:21 --> Router Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Output Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Security Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Input Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:40:22 --> Language Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Loader Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:40:22 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Session Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:40:22 --> Session routines successfully run
DEBUG - 2012-02-02 22:40:22 --> Cart Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Model Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Model Class Initialized
DEBUG - 2012-02-02 22:40:22 --> Controller Class Initialized
DEBUG - 2012-02-02 22:40:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:40:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:40:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:40:22 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:40:22 --> Final output sent to browser
DEBUG - 2012-02-02 22:40:22 --> Total execution time: 0.5961
DEBUG - 2012-02-02 22:40:48 --> Config Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:40:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:40:48 --> URI Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Router Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Output Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Security Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Input Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:40:48 --> Language Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Loader Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:40:48 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Session Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:40:48 --> Session routines successfully run
DEBUG - 2012-02-02 22:40:48 --> Cart Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Model Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Model Class Initialized
DEBUG - 2012-02-02 22:40:48 --> Controller Class Initialized
DEBUG - 2012-02-02 22:40:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:40:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:40:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:40:48 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:40:48 --> Final output sent to browser
DEBUG - 2012-02-02 22:40:48 --> Total execution time: 0.5491
DEBUG - 2012-02-02 22:47:59 --> Config Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:47:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:47:59 --> URI Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Router Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Output Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Security Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Input Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:47:59 --> Language Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Loader Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:47:59 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Session Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:47:59 --> Session routines successfully run
DEBUG - 2012-02-02 22:47:59 --> Cart Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Model Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Model Class Initialized
DEBUG - 2012-02-02 22:47:59 --> Controller Class Initialized
DEBUG - 2012-02-02 22:47:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:47:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:47:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:47:59 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:47:59 --> Final output sent to browser
DEBUG - 2012-02-02 22:47:59 --> Total execution time: 0.5605
DEBUG - 2012-02-02 22:48:07 --> Config Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:48:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:48:07 --> URI Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Router Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Output Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Security Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Input Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:48:07 --> Language Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Loader Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:48:07 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:48:07 --> Session Class Initialized
DEBUG - 2012-02-02 22:48:08 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:48:08 --> Session routines successfully run
DEBUG - 2012-02-02 22:48:08 --> Cart Class Initialized
DEBUG - 2012-02-02 22:48:08 --> Model Class Initialized
DEBUG - 2012-02-02 22:48:08 --> Model Class Initialized
DEBUG - 2012-02-02 22:48:08 --> Controller Class Initialized
DEBUG - 2012-02-02 22:48:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:48:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:48:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:48:08 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:48:08 --> Final output sent to browser
DEBUG - 2012-02-02 22:48:08 --> Total execution time: 0.5935
DEBUG - 2012-02-02 22:48:15 --> Config Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:48:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:48:15 --> URI Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Router Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Output Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Security Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Input Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:48:15 --> Language Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Loader Class Initialized
DEBUG - 2012-02-02 22:48:15 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:48:15 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:48:16 --> Session Class Initialized
DEBUG - 2012-02-02 22:48:16 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:48:16 --> Session routines successfully run
DEBUG - 2012-02-02 22:48:16 --> Cart Class Initialized
DEBUG - 2012-02-02 22:48:16 --> Model Class Initialized
DEBUG - 2012-02-02 22:48:16 --> Model Class Initialized
DEBUG - 2012-02-02 22:48:16 --> Controller Class Initialized
DEBUG - 2012-02-02 22:48:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:48:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:48:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:48:16 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:48:16 --> Final output sent to browser
DEBUG - 2012-02-02 22:48:16 --> Total execution time: 0.9610
DEBUG - 2012-02-02 22:52:00 --> Config Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:52:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:52:00 --> URI Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Router Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Output Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Security Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Input Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:52:00 --> Language Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Loader Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:52:00 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Session Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:52:00 --> Session routines successfully run
DEBUG - 2012-02-02 22:52:00 --> Cart Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Model Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Model Class Initialized
DEBUG - 2012-02-02 22:52:00 --> Controller Class Initialized
DEBUG - 2012-02-02 22:52:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:52:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:52:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:52:00 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:52:00 --> Final output sent to browser
DEBUG - 2012-02-02 22:52:01 --> Total execution time: 0.6966
DEBUG - 2012-02-02 22:59:57 --> Config Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Hooks Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Utf8 Class Initialized
DEBUG - 2012-02-02 22:59:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 22:59:57 --> URI Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Router Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Output Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Security Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Input Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 22:59:57 --> Language Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Loader Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Helper loaded: url_helper
DEBUG - 2012-02-02 22:59:57 --> Database Driver Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Session Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Helper loaded: string_helper
DEBUG - 2012-02-02 22:59:57 --> Session routines successfully run
DEBUG - 2012-02-02 22:59:57 --> Cart Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Model Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Model Class Initialized
DEBUG - 2012-02-02 22:59:57 --> Controller Class Initialized
DEBUG - 2012-02-02 22:59:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 22:59:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 22:59:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 22:59:57 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 22:59:57 --> Final output sent to browser
DEBUG - 2012-02-02 22:59:57 --> Total execution time: 0.5704
DEBUG - 2012-02-02 23:00:34 --> Config Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:00:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:00:34 --> URI Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Router Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Output Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Security Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Input Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:00:34 --> Language Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Loader Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:00:34 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Session Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:00:34 --> Session routines successfully run
DEBUG - 2012-02-02 23:00:34 --> Cart Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Model Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Model Class Initialized
DEBUG - 2012-02-02 23:00:34 --> Controller Class Initialized
DEBUG - 2012-02-02 23:00:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:00:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:00:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:00:34 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:00:34 --> Final output sent to browser
DEBUG - 2012-02-02 23:00:34 --> Total execution time: 0.6139
DEBUG - 2012-02-02 23:01:06 --> Config Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:01:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:01:06 --> URI Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Router Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Output Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Security Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Input Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:01:06 --> Language Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Loader Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:01:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Session Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:01:06 --> Session routines successfully run
DEBUG - 2012-02-02 23:01:06 --> Cart Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:01:06 --> Controller Class Initialized
DEBUG - 2012-02-02 23:01:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:01:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:01:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:01:06 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:01:07 --> Final output sent to browser
DEBUG - 2012-02-02 23:01:07 --> Total execution time: 0.8846
DEBUG - 2012-02-02 23:02:01 --> Config Class Initialized
DEBUG - 2012-02-02 23:02:01 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:02:01 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:02:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:02:01 --> URI Class Initialized
DEBUG - 2012-02-02 23:02:01 --> Router Class Initialized
ERROR - 2012-02-02 23:02:01 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 23:02:22 --> Config Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:02:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:02:22 --> URI Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Router Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Output Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Security Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Input Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:02:22 --> Language Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Loader Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:02:22 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Session Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:02:22 --> Session routines successfully run
DEBUG - 2012-02-02 23:02:22 --> Cart Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Model Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Model Class Initialized
DEBUG - 2012-02-02 23:02:22 --> Controller Class Initialized
DEBUG - 2012-02-02 23:02:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:02:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:02:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:02:23 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:02:23 --> Final output sent to browser
DEBUG - 2012-02-02 23:02:23 --> Total execution time: 0.5502
DEBUG - 2012-02-02 23:02:23 --> Config Class Initialized
DEBUG - 2012-02-02 23:02:23 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:02:23 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:02:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:02:24 --> URI Class Initialized
DEBUG - 2012-02-02 23:02:24 --> Router Class Initialized
ERROR - 2012-02-02 23:02:24 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 23:02:26 --> Config Class Initialized
DEBUG - 2012-02-02 23:02:26 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:02:26 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:02:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:02:26 --> URI Class Initialized
DEBUG - 2012-02-02 23:02:26 --> Router Class Initialized
ERROR - 2012-02-02 23:02:26 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 23:02:55 --> Config Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:02:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:02:55 --> URI Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Router Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Output Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Security Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Input Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:02:55 --> Language Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Loader Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:02:55 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Session Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:02:55 --> Session routines successfully run
DEBUG - 2012-02-02 23:02:55 --> Cart Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Model Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Model Class Initialized
DEBUG - 2012-02-02 23:02:55 --> Controller Class Initialized
DEBUG - 2012-02-02 23:02:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:02:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:02:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:02:55 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:02:55 --> Final output sent to browser
DEBUG - 2012-02-02 23:02:55 --> Total execution time: 0.5364
DEBUG - 2012-02-02 23:02:56 --> Config Class Initialized
DEBUG - 2012-02-02 23:02:56 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:02:56 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:02:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:02:56 --> URI Class Initialized
DEBUG - 2012-02-02 23:02:56 --> Router Class Initialized
ERROR - 2012-02-02 23:02:56 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 23:03:00 --> Config Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:03:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:03:00 --> URI Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Router Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Output Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Security Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Input Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:03:00 --> Language Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Loader Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:03:00 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Session Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:03:00 --> Session routines successfully run
DEBUG - 2012-02-02 23:03:00 --> Cart Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Controller Class Initialized
DEBUG - 2012-02-02 23:03:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:03:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:03:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:03:00 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:03:00 --> Final output sent to browser
DEBUG - 2012-02-02 23:03:00 --> Total execution time: 0.5619
DEBUG - 2012-02-02 23:03:00 --> Config Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:03:00 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:03:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:03:01 --> URI Class Initialized
DEBUG - 2012-02-02 23:03:01 --> Router Class Initialized
ERROR - 2012-02-02 23:03:01 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 23:03:03 --> Config Class Initialized
DEBUG - 2012-02-02 23:03:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:03:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:03:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:03:03 --> URI Class Initialized
DEBUG - 2012-02-02 23:03:03 --> Router Class Initialized
ERROR - 2012-02-02 23:03:03 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 23:03:05 --> Config Class Initialized
DEBUG - 2012-02-02 23:03:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:03:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:03:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:03:05 --> URI Class Initialized
DEBUG - 2012-02-02 23:03:05 --> Router Class Initialized
ERROR - 2012-02-02 23:03:05 --> 404 Page Not Found --> order
DEBUG - 2012-02-02 23:03:29 --> Config Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:03:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:03:29 --> URI Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Router Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Output Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Security Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Input Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:03:29 --> Language Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Loader Class Initialized
DEBUG - 2012-02-02 23:03:29 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:03:29 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:03:30 --> Session Class Initialized
DEBUG - 2012-02-02 23:03:30 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:03:30 --> Session routines successfully run
DEBUG - 2012-02-02 23:03:30 --> Cart Class Initialized
DEBUG - 2012-02-02 23:03:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:03:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:03:30 --> Controller Class Initialized
DEBUG - 2012-02-02 23:03:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:03:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:03:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:03:30 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:03:30 --> Final output sent to browser
DEBUG - 2012-02-02 23:03:30 --> Total execution time: 0.5721
DEBUG - 2012-02-02 23:03:49 --> Config Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:03:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:03:49 --> URI Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Router Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Output Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Security Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Input Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:03:49 --> Language Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Loader Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:03:49 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Session Class Initialized
DEBUG - 2012-02-02 23:03:49 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:03:49 --> Session routines successfully run
DEBUG - 2012-02-02 23:03:49 --> Cart Class Initialized
DEBUG - 2012-02-02 23:03:50 --> Model Class Initialized
DEBUG - 2012-02-02 23:03:50 --> Model Class Initialized
DEBUG - 2012-02-02 23:03:50 --> Controller Class Initialized
DEBUG - 2012-02-02 23:03:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:03:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:03:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:03:50 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:03:50 --> Final output sent to browser
DEBUG - 2012-02-02 23:03:50 --> Total execution time: 0.5420
DEBUG - 2012-02-02 23:05:17 --> Config Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:05:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:05:17 --> URI Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Router Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Output Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Security Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Input Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:05:17 --> Language Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Loader Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:05:17 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Session Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:05:17 --> Session routines successfully run
DEBUG - 2012-02-02 23:05:17 --> Cart Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Model Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Model Class Initialized
DEBUG - 2012-02-02 23:05:17 --> Controller Class Initialized
DEBUG - 2012-02-02 23:05:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:05:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:05:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:05:17 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:05:17 --> Final output sent to browser
DEBUG - 2012-02-02 23:05:17 --> Total execution time: 0.4702
DEBUG - 2012-02-02 23:05:51 --> Config Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:05:51 --> URI Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Router Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Output Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Security Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Input Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:05:51 --> Language Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Loader Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:05:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Session Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:05:51 --> Session routines successfully run
DEBUG - 2012-02-02 23:05:51 --> Cart Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Model Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Model Class Initialized
DEBUG - 2012-02-02 23:05:51 --> Controller Class Initialized
DEBUG - 2012-02-02 23:05:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:05:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:05:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:05:51 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:05:51 --> Final output sent to browser
DEBUG - 2012-02-02 23:05:51 --> Total execution time: 0.5310
DEBUG - 2012-02-02 23:05:56 --> Config Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:05:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:05:56 --> URI Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Router Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Output Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Security Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Input Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:05:56 --> Language Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Loader Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:05:56 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Session Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:05:56 --> Session routines successfully run
DEBUG - 2012-02-02 23:05:56 --> Cart Class Initialized
DEBUG - 2012-02-02 23:05:56 --> Model Class Initialized
DEBUG - 2012-02-02 23:05:57 --> Model Class Initialized
DEBUG - 2012-02-02 23:05:57 --> Controller Class Initialized
DEBUG - 2012-02-02 23:05:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:05:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:05:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:05:57 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:05:57 --> Final output sent to browser
DEBUG - 2012-02-02 23:05:57 --> Total execution time: 0.5306
DEBUG - 2012-02-02 23:06:31 --> Config Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:06:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:06:31 --> URI Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Router Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Output Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Security Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Input Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:06:31 --> Language Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Loader Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:06:31 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Session Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:06:31 --> Session routines successfully run
DEBUG - 2012-02-02 23:06:31 --> Cart Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:31 --> Controller Class Initialized
DEBUG - 2012-02-02 23:06:31 --> XSS Filtering completed
DEBUG - 2012-02-02 23:06:31 --> XSS Filtering completed
DEBUG - 2012-02-02 23:06:31 --> XSS Filtering completed
DEBUG - 2012-02-02 23:06:32 --> Config Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:06:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:06:32 --> URI Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Router Class Initialized
DEBUG - 2012-02-02 23:06:32 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:06:32 --> Output Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Security Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Input Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:06:32 --> Language Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Loader Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:06:32 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Session Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:06:32 --> Session routines successfully run
DEBUG - 2012-02-02 23:06:32 --> Cart Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:32 --> Controller Class Initialized
DEBUG - 2012-02-02 23:06:33 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:06:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:06:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:06:33 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:06:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:06:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:06:33 --> Final output sent to browser
DEBUG - 2012-02-02 23:06:33 --> Total execution time: 0.6336
DEBUG - 2012-02-02 23:06:46 --> Config Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:06:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:06:46 --> URI Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Router Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Output Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Security Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Input Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:06:46 --> Language Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Loader Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:06:46 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Session Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:06:46 --> Session routines successfully run
DEBUG - 2012-02-02 23:06:46 --> Cart Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:46 --> Controller Class Initialized
DEBUG - 2012-02-02 23:06:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:06:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:06:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:06:46 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:06:46 --> Final output sent to browser
DEBUG - 2012-02-02 23:06:46 --> Total execution time: 0.5525
DEBUG - 2012-02-02 23:06:50 --> Config Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:06:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:06:50 --> URI Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Router Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Output Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Security Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Input Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:06:50 --> Language Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Loader Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:06:50 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Session Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:06:50 --> Session routines successfully run
DEBUG - 2012-02-02 23:06:50 --> Cart Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:50 --> Controller Class Initialized
DEBUG - 2012-02-02 23:06:50 --> XSS Filtering completed
DEBUG - 2012-02-02 23:06:50 --> XSS Filtering completed
DEBUG - 2012-02-02 23:06:50 --> XSS Filtering completed
DEBUG - 2012-02-02 23:06:51 --> Config Class Initialized
DEBUG - 2012-02-02 23:06:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:06:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:06:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:06:52 --> URI Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Router Class Initialized
DEBUG - 2012-02-02 23:06:52 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:06:52 --> Output Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Security Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Input Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:06:52 --> Language Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Loader Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:06:52 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Session Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:06:52 --> Session routines successfully run
DEBUG - 2012-02-02 23:06:52 --> Cart Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Controller Class Initialized
DEBUG - 2012-02-02 23:06:52 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:06:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:06:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:06:52 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:06:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:06:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:06:52 --> Final output sent to browser
DEBUG - 2012-02-02 23:06:52 --> Total execution time: 0.7819
DEBUG - 2012-02-02 23:07:15 --> Config Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:07:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:07:15 --> URI Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Router Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Output Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Security Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Input Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:07:15 --> Language Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Loader Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:07:15 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Session Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:07:15 --> Session routines successfully run
DEBUG - 2012-02-02 23:07:15 --> Cart Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Model Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Model Class Initialized
DEBUG - 2012-02-02 23:07:15 --> Controller Class Initialized
DEBUG - 2012-02-02 23:07:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:07:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:07:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:07:15 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:07:15 --> Final output sent to browser
DEBUG - 2012-02-02 23:07:15 --> Total execution time: 0.5065
DEBUG - 2012-02-02 23:08:27 --> Config Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:08:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:08:27 --> URI Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Router Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Output Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Security Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Input Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:08:27 --> Language Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Loader Class Initialized
DEBUG - 2012-02-02 23:08:27 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:08:27 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:08:28 --> Session Class Initialized
DEBUG - 2012-02-02 23:08:28 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:08:28 --> Session routines successfully run
DEBUG - 2012-02-02 23:08:28 --> Cart Class Initialized
DEBUG - 2012-02-02 23:08:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:08:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:08:28 --> Controller Class Initialized
DEBUG - 2012-02-02 23:08:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:08:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:08:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:08:28 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:08:28 --> Final output sent to browser
DEBUG - 2012-02-02 23:08:28 --> Total execution time: 1.0377
DEBUG - 2012-02-02 23:09:20 --> Config Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:09:20 --> URI Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Router Class Initialized
DEBUG - 2012-02-02 23:09:20 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:09:20 --> Output Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Security Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Input Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:09:20 --> Language Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Loader Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:09:20 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Session Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:09:20 --> Session routines successfully run
DEBUG - 2012-02-02 23:09:20 --> Cart Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Model Class Initialized
DEBUG - 2012-02-02 23:09:20 --> Model Class Initialized
DEBUG - 2012-02-02 23:09:21 --> Controller Class Initialized
DEBUG - 2012-02-02 23:09:21 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:09:21 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:09:21 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:09:21 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:09:21 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:09:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:09:21 --> Final output sent to browser
DEBUG - 2012-02-02 23:09:21 --> Total execution time: 0.7108
DEBUG - 2012-02-02 23:09:29 --> Config Class Initialized
DEBUG - 2012-02-02 23:09:29 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:09:29 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:09:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:09:29 --> URI Class Initialized
DEBUG - 2012-02-02 23:09:29 --> Router Class Initialized
DEBUG - 2012-02-02 23:09:29 --> Output Class Initialized
DEBUG - 2012-02-02 23:09:29 --> Security Class Initialized
DEBUG - 2012-02-02 23:09:29 --> Input Class Initialized
DEBUG - 2012-02-02 23:09:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:09:30 --> Language Class Initialized
DEBUG - 2012-02-02 23:09:30 --> Loader Class Initialized
DEBUG - 2012-02-02 23:09:30 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:09:30 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:09:30 --> Session Class Initialized
DEBUG - 2012-02-02 23:09:30 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:09:30 --> Session routines successfully run
DEBUG - 2012-02-02 23:09:30 --> Cart Class Initialized
DEBUG - 2012-02-02 23:09:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:09:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:09:30 --> Controller Class Initialized
DEBUG - 2012-02-02 23:09:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:09:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:09:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:09:30 --> File loaded: application/views/user/product.php
DEBUG - 2012-02-02 23:09:30 --> Final output sent to browser
DEBUG - 2012-02-02 23:09:30 --> Total execution time: 0.7512
DEBUG - 2012-02-02 23:09:32 --> Config Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:09:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:09:32 --> URI Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Router Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Output Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Security Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Input Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:09:32 --> Language Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Loader Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:09:32 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Session Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:09:32 --> Session routines successfully run
DEBUG - 2012-02-02 23:09:32 --> Cart Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:09:32 --> Controller Class Initialized
DEBUG - 2012-02-02 23:09:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:09:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:09:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:09:32 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:09:33 --> Final output sent to browser
DEBUG - 2012-02-02 23:09:33 --> Total execution time: 0.5449
DEBUG - 2012-02-02 23:10:31 --> Config Class Initialized
DEBUG - 2012-02-02 23:10:31 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:10:31 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:10:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:10:31 --> URI Class Initialized
DEBUG - 2012-02-02 23:10:31 --> Router Class Initialized
DEBUG - 2012-02-02 23:10:31 --> Output Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Security Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Input Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:10:32 --> Language Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Loader Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:10:32 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Session Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:10:32 --> Session routines successfully run
DEBUG - 2012-02-02 23:10:32 --> Cart Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:32 --> Controller Class Initialized
DEBUG - 2012-02-02 23:10:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:10:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:10:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:10:32 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:10:32 --> Final output sent to browser
DEBUG - 2012-02-02 23:10:32 --> Total execution time: 0.5748
DEBUG - 2012-02-02 23:10:38 --> Config Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:10:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:10:38 --> URI Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Router Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Output Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Security Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Input Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:10:38 --> Language Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Loader Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:10:38 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Session Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:10:38 --> Session routines successfully run
DEBUG - 2012-02-02 23:10:38 --> Cart Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:38 --> Controller Class Initialized
DEBUG - 2012-02-02 23:10:38 --> XSS Filtering completed
DEBUG - 2012-02-02 23:10:38 --> XSS Filtering completed
DEBUG - 2012-02-02 23:10:38 --> XSS Filtering completed
DEBUG - 2012-02-02 23:10:39 --> Config Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:10:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:10:39 --> URI Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Router Class Initialized
DEBUG - 2012-02-02 23:10:39 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:10:39 --> Output Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Security Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Input Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:10:39 --> Language Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Loader Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:10:39 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Session Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:10:39 --> Session routines successfully run
DEBUG - 2012-02-02 23:10:39 --> Cart Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Controller Class Initialized
DEBUG - 2012-02-02 23:10:39 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:10:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:10:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:10:39 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:10:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:10:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:10:39 --> Final output sent to browser
DEBUG - 2012-02-02 23:10:39 --> Total execution time: 0.5325
DEBUG - 2012-02-02 23:10:45 --> Config Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:10:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:10:45 --> URI Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Router Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Output Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Security Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Input Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:10:45 --> Language Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Loader Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:10:45 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Session Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:10:45 --> Session routines successfully run
DEBUG - 2012-02-02 23:10:45 --> Cart Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:10:45 --> Controller Class Initialized
DEBUG - 2012-02-02 23:10:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:10:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:10:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:10:45 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:10:45 --> Final output sent to browser
DEBUG - 2012-02-02 23:10:46 --> Total execution time: 0.5410
DEBUG - 2012-02-02 23:12:14 --> Config Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:12:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:12:14 --> URI Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Router Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Output Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Security Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Input Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:12:14 --> Language Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Loader Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:12:14 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Session Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:12:14 --> Session routines successfully run
DEBUG - 2012-02-02 23:12:14 --> Cart Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:12:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:12:15 --> Controller Class Initialized
DEBUG - 2012-02-02 23:12:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:12:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:12:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:12:15 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:12:15 --> Final output sent to browser
DEBUG - 2012-02-02 23:12:15 --> Total execution time: 0.4891
DEBUG - 2012-02-02 23:13:27 --> Config Class Initialized
DEBUG - 2012-02-02 23:13:27 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:13:27 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:13:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:13:28 --> URI Class Initialized
DEBUG - 2012-02-02 23:13:28 --> Router Class Initialized
DEBUG - 2012-02-02 23:13:28 --> Output Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Security Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Input Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:13:29 --> Language Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Loader Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:13:29 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Session Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:13:29 --> Session routines successfully run
DEBUG - 2012-02-02 23:13:29 --> Cart Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Model Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Model Class Initialized
DEBUG - 2012-02-02 23:13:29 --> Controller Class Initialized
DEBUG - 2012-02-02 23:13:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:13:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:13:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:13:29 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:13:29 --> Final output sent to browser
DEBUG - 2012-02-02 23:13:29 --> Total execution time: 1.6911
DEBUG - 2012-02-02 23:14:10 --> Config Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:14:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:14:10 --> URI Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Router Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Output Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Security Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Input Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:14:10 --> Language Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Loader Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:14:10 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Session Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:14:10 --> Session routines successfully run
DEBUG - 2012-02-02 23:14:10 --> Cart Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:10 --> Controller Class Initialized
DEBUG - 2012-02-02 23:14:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:14:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:14:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:14:10 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:14:10 --> Final output sent to browser
DEBUG - 2012-02-02 23:14:10 --> Total execution time: 0.5015
DEBUG - 2012-02-02 23:14:29 --> Config Class Initialized
DEBUG - 2012-02-02 23:14:29 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:14:29 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:14:29 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:14:29 --> URI Class Initialized
DEBUG - 2012-02-02 23:14:29 --> Router Class Initialized
DEBUG - 2012-02-02 23:14:29 --> Output Class Initialized
DEBUG - 2012-02-02 23:14:29 --> Security Class Initialized
DEBUG - 2012-02-02 23:14:29 --> Input Class Initialized
DEBUG - 2012-02-02 23:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:14:30 --> Language Class Initialized
DEBUG - 2012-02-02 23:14:30 --> Loader Class Initialized
DEBUG - 2012-02-02 23:14:30 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:14:30 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:14:30 --> Session Class Initialized
DEBUG - 2012-02-02 23:14:30 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:14:30 --> Session routines successfully run
DEBUG - 2012-02-02 23:14:30 --> Cart Class Initialized
DEBUG - 2012-02-02 23:14:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:30 --> Controller Class Initialized
DEBUG - 2012-02-02 23:14:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:14:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:14:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:14:30 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:14:30 --> Final output sent to browser
DEBUG - 2012-02-02 23:14:30 --> Total execution time: 0.5771
DEBUG - 2012-02-02 23:14:32 --> Config Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:14:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:14:32 --> URI Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Router Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Output Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Security Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Input Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:14:32 --> Language Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Loader Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:14:32 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Session Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:14:32 --> Session routines successfully run
DEBUG - 2012-02-02 23:14:32 --> Cart Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:32 --> Controller Class Initialized
DEBUG - 2012-02-02 23:14:33 --> XSS Filtering completed
DEBUG - 2012-02-02 23:14:33 --> XSS Filtering completed
DEBUG - 2012-02-02 23:14:33 --> XSS Filtering completed
DEBUG - 2012-02-02 23:14:33 --> Config Class Initialized
DEBUG - 2012-02-02 23:14:33 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:14:33 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:14:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:14:33 --> URI Class Initialized
DEBUG - 2012-02-02 23:14:33 --> Router Class Initialized
DEBUG - 2012-02-02 23:14:33 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:14:33 --> Output Class Initialized
DEBUG - 2012-02-02 23:14:33 --> Security Class Initialized
DEBUG - 2012-02-02 23:14:33 --> Input Class Initialized
DEBUG - 2012-02-02 23:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:14:33 --> Language Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Loader Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:14:34 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Session Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:14:34 --> Session routines successfully run
DEBUG - 2012-02-02 23:14:34 --> Cart Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Model Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Controller Class Initialized
DEBUG - 2012-02-02 23:14:34 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:14:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:14:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:14:34 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:14:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:14:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:14:34 --> Final output sent to browser
DEBUG - 2012-02-02 23:14:34 --> Total execution time: 0.8418
DEBUG - 2012-02-02 23:15:22 --> Config Class Initialized
DEBUG - 2012-02-02 23:15:22 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:15:22 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:15:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:15:23 --> URI Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Router Class Initialized
DEBUG - 2012-02-02 23:15:23 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:15:23 --> Output Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Security Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Input Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:15:23 --> Language Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Loader Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:15:23 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Session Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:15:23 --> Session routines successfully run
DEBUG - 2012-02-02 23:15:23 --> Cart Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Controller Class Initialized
DEBUG - 2012-02-02 23:15:23 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:15:23 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:15:23 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:15:23 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:15:23 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:15:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:15:23 --> Final output sent to browser
DEBUG - 2012-02-02 23:15:23 --> Total execution time: 0.6104
DEBUG - 2012-02-02 23:15:27 --> Config Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:15:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:15:27 --> URI Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Router Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Output Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Security Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Input Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:15:27 --> Language Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Loader Class Initialized
DEBUG - 2012-02-02 23:15:27 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:15:28 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:15:28 --> Session Class Initialized
DEBUG - 2012-02-02 23:15:28 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:15:28 --> Session routines successfully run
DEBUG - 2012-02-02 23:15:28 --> Cart Class Initialized
DEBUG - 2012-02-02 23:15:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:28 --> Controller Class Initialized
DEBUG - 2012-02-02 23:15:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:15:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:15:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:15:28 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:15:28 --> Final output sent to browser
DEBUG - 2012-02-02 23:15:28 --> Total execution time: 0.5644
DEBUG - 2012-02-02 23:15:40 --> Config Class Initialized
DEBUG - 2012-02-02 23:15:40 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:15:40 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:15:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:15:41 --> URI Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Router Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Output Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Security Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Input Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:15:41 --> Language Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Loader Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:15:41 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Session Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:15:41 --> Session routines successfully run
DEBUG - 2012-02-02 23:15:41 --> Cart Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:41 --> Controller Class Initialized
DEBUG - 2012-02-02 23:15:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:15:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:15:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:15:41 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:15:41 --> Final output sent to browser
DEBUG - 2012-02-02 23:15:41 --> Total execution time: 0.6279
DEBUG - 2012-02-02 23:15:58 --> Config Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:15:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:15:58 --> URI Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Router Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Output Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Security Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Input Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:15:58 --> Language Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Loader Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:15:58 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Session Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:15:58 --> Session routines successfully run
DEBUG - 2012-02-02 23:15:58 --> Cart Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:15:58 --> Controller Class Initialized
DEBUG - 2012-02-02 23:15:58 --> XSS Filtering completed
DEBUG - 2012-02-02 23:15:58 --> XSS Filtering completed
DEBUG - 2012-02-02 23:15:58 --> XSS Filtering completed
DEBUG - 2012-02-02 23:15:59 --> Config Class Initialized
DEBUG - 2012-02-02 23:15:59 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:15:59 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:15:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:15:59 --> URI Class Initialized
DEBUG - 2012-02-02 23:15:59 --> Router Class Initialized
DEBUG - 2012-02-02 23:16:00 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:16:00 --> Output Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Security Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Input Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:16:00 --> Language Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Loader Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:16:00 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Session Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:16:00 --> Session routines successfully run
DEBUG - 2012-02-02 23:16:00 --> Cart Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Controller Class Initialized
DEBUG - 2012-02-02 23:16:00 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:16:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:16:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:16:00 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:16:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:16:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:16:00 --> Final output sent to browser
DEBUG - 2012-02-02 23:16:00 --> Total execution time: 0.5772
DEBUG - 2012-02-02 23:16:59 --> Config Class Initialized
DEBUG - 2012-02-02 23:16:59 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:16:59 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:16:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:16:59 --> URI Class Initialized
DEBUG - 2012-02-02 23:16:59 --> Router Class Initialized
DEBUG - 2012-02-02 23:16:59 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:17:00 --> Output Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Security Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Input Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:17:00 --> Language Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Loader Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:17:00 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Session Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:17:00 --> Session routines successfully run
DEBUG - 2012-02-02 23:17:00 --> Cart Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Controller Class Initialized
DEBUG - 2012-02-02 23:17:00 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:17:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:17:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:17:00 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:17:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:17:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:17:00 --> Final output sent to browser
DEBUG - 2012-02-02 23:17:00 --> Total execution time: 1.1052
DEBUG - 2012-02-02 23:17:03 --> Config Class Initialized
DEBUG - 2012-02-02 23:17:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:17:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:17:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:17:03 --> URI Class Initialized
DEBUG - 2012-02-02 23:17:03 --> Router Class Initialized
DEBUG - 2012-02-02 23:17:03 --> Output Class Initialized
DEBUG - 2012-02-02 23:17:03 --> Security Class Initialized
DEBUG - 2012-02-02 23:17:03 --> Input Class Initialized
DEBUG - 2012-02-02 23:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:17:03 --> Language Class Initialized
DEBUG - 2012-02-02 23:17:04 --> Loader Class Initialized
DEBUG - 2012-02-02 23:17:04 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:17:04 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:17:04 --> Session Class Initialized
DEBUG - 2012-02-02 23:17:04 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:17:04 --> Session routines successfully run
DEBUG - 2012-02-02 23:17:04 --> Cart Class Initialized
DEBUG - 2012-02-02 23:17:04 --> Model Class Initialized
DEBUG - 2012-02-02 23:17:04 --> Model Class Initialized
DEBUG - 2012-02-02 23:17:04 --> Controller Class Initialized
DEBUG - 2012-02-02 23:17:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:17:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:17:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:17:04 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:17:04 --> Final output sent to browser
DEBUG - 2012-02-02 23:17:04 --> Total execution time: 0.5206
DEBUG - 2012-02-02 23:19:37 --> Config Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:19:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:19:37 --> URI Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Router Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Output Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Security Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Input Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:19:37 --> Language Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Loader Class Initialized
DEBUG - 2012-02-02 23:19:37 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:19:38 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:19:38 --> Session Class Initialized
DEBUG - 2012-02-02 23:19:38 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:19:38 --> Session routines successfully run
DEBUG - 2012-02-02 23:19:38 --> Cart Class Initialized
DEBUG - 2012-02-02 23:19:38 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:38 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:38 --> Controller Class Initialized
DEBUG - 2012-02-02 23:19:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:19:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:19:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:19:38 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:19:38 --> Final output sent to browser
DEBUG - 2012-02-02 23:19:38 --> Total execution time: 0.7857
DEBUG - 2012-02-02 23:19:42 --> Config Class Initialized
DEBUG - 2012-02-02 23:19:42 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:19:42 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:19:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:19:42 --> URI Class Initialized
DEBUG - 2012-02-02 23:19:42 --> Router Class Initialized
DEBUG - 2012-02-02 23:19:42 --> Output Class Initialized
DEBUG - 2012-02-02 23:19:42 --> Security Class Initialized
DEBUG - 2012-02-02 23:19:42 --> Input Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:19:43 --> Language Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Loader Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:19:43 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Session Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:19:43 --> Session routines successfully run
DEBUG - 2012-02-02 23:19:43 --> Cart Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:43 --> Controller Class Initialized
DEBUG - 2012-02-02 23:19:43 --> XSS Filtering completed
DEBUG - 2012-02-02 23:19:43 --> XSS Filtering completed
DEBUG - 2012-02-02 23:19:43 --> XSS Filtering completed
DEBUG - 2012-02-02 23:19:44 --> Config Class Initialized
DEBUG - 2012-02-02 23:19:44 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:19:44 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:19:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:19:44 --> URI Class Initialized
DEBUG - 2012-02-02 23:19:44 --> Router Class Initialized
DEBUG - 2012-02-02 23:19:44 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:19:44 --> Output Class Initialized
DEBUG - 2012-02-02 23:19:44 --> Security Class Initialized
DEBUG - 2012-02-02 23:19:44 --> Input Class Initialized
DEBUG - 2012-02-02 23:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:19:44 --> Language Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Loader Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:19:45 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Session Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:19:45 --> Session routines successfully run
DEBUG - 2012-02-02 23:19:45 --> Cart Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Controller Class Initialized
DEBUG - 2012-02-02 23:19:45 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:19:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:19:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:19:45 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:19:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:19:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:19:45 --> Final output sent to browser
DEBUG - 2012-02-02 23:19:45 --> Total execution time: 1.0133
DEBUG - 2012-02-02 23:19:47 --> Config Class Initialized
DEBUG - 2012-02-02 23:19:47 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:19:47 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:19:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:19:47 --> URI Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Router Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Output Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Security Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Input Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:19:48 --> Language Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Loader Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:19:48 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Session Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:19:48 --> Session routines successfully run
DEBUG - 2012-02-02 23:19:48 --> Cart Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:48 --> Controller Class Initialized
DEBUG - 2012-02-02 23:19:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:19:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:19:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:19:48 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:19:48 --> Final output sent to browser
DEBUG - 2012-02-02 23:19:48 --> Total execution time: 1.0936
DEBUG - 2012-02-02 23:19:52 --> Config Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:19:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:19:52 --> URI Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Router Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Output Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Security Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Input Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:19:52 --> Language Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Loader Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:19:52 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Session Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:19:52 --> Session routines successfully run
DEBUG - 2012-02-02 23:19:52 --> Cart Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:52 --> Controller Class Initialized
DEBUG - 2012-02-02 23:19:52 --> XSS Filtering completed
DEBUG - 2012-02-02 23:19:52 --> XSS Filtering completed
DEBUG - 2012-02-02 23:19:52 --> XSS Filtering completed
DEBUG - 2012-02-02 23:19:53 --> Config Class Initialized
DEBUG - 2012-02-02 23:19:53 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:19:53 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:19:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:19:53 --> URI Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Router Class Initialized
DEBUG - 2012-02-02 23:19:54 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:19:54 --> Output Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Security Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Input Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:19:54 --> Language Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Loader Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:19:54 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Session Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:19:54 --> Session routines successfully run
DEBUG - 2012-02-02 23:19:54 --> Cart Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Model Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Controller Class Initialized
DEBUG - 2012-02-02 23:19:54 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:19:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:19:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:19:54 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:19:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:19:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:19:55 --> Final output sent to browser
DEBUG - 2012-02-02 23:19:55 --> Total execution time: 1.3322
DEBUG - 2012-02-02 23:20:52 --> Config Class Initialized
DEBUG - 2012-02-02 23:20:52 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:20:52 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:20:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:20:52 --> URI Class Initialized
DEBUG - 2012-02-02 23:20:52 --> Router Class Initialized
DEBUG - 2012-02-02 23:20:52 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:20:52 --> Output Class Initialized
DEBUG - 2012-02-02 23:20:52 --> Security Class Initialized
DEBUG - 2012-02-02 23:20:52 --> Input Class Initialized
DEBUG - 2012-02-02 23:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:20:52 --> Language Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Loader Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:20:53 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Session Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:20:53 --> Session routines successfully run
DEBUG - 2012-02-02 23:20:53 --> Cart Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Model Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Model Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Controller Class Initialized
DEBUG - 2012-02-02 23:20:53 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:20:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:20:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:20:53 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:20:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:20:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:20:53 --> Final output sent to browser
DEBUG - 2012-02-02 23:20:53 --> Total execution time: 0.5953
DEBUG - 2012-02-02 23:20:56 --> Config Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:20:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:20:56 --> URI Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Router Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Output Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Security Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Input Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:20:56 --> Language Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Loader Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:20:56 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Session Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:20:56 --> Session routines successfully run
DEBUG - 2012-02-02 23:20:56 --> Cart Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Model Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Model Class Initialized
DEBUG - 2012-02-02 23:20:56 --> Controller Class Initialized
DEBUG - 2012-02-02 23:20:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:20:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:20:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:20:56 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:20:56 --> Final output sent to browser
DEBUG - 2012-02-02 23:20:57 --> Total execution time: 0.5448
DEBUG - 2012-02-02 23:20:58 --> Config Class Initialized
DEBUG - 2012-02-02 23:20:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:20:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:20:59 --> URI Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Router Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Output Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Security Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Input Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:20:59 --> Language Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Loader Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:20:59 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Session Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:20:59 --> Session routines successfully run
DEBUG - 2012-02-02 23:20:59 --> Cart Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Model Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Model Class Initialized
DEBUG - 2012-02-02 23:20:59 --> Controller Class Initialized
DEBUG - 2012-02-02 23:20:59 --> XSS Filtering completed
DEBUG - 2012-02-02 23:20:59 --> XSS Filtering completed
DEBUG - 2012-02-02 23:20:59 --> XSS Filtering completed
DEBUG - 2012-02-02 23:21:00 --> Config Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:21:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:21:00 --> URI Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Router Class Initialized
DEBUG - 2012-02-02 23:21:00 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:21:00 --> Output Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Security Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Input Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:21:00 --> Language Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Loader Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:21:00 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Session Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:21:00 --> Session routines successfully run
DEBUG - 2012-02-02 23:21:00 --> Cart Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Controller Class Initialized
DEBUG - 2012-02-02 23:21:00 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:21:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:21:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:21:00 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:21:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:21:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:21:00 --> Final output sent to browser
DEBUG - 2012-02-02 23:21:00 --> Total execution time: 0.6869
DEBUG - 2012-02-02 23:22:05 --> Config Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:22:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:22:05 --> URI Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Router Class Initialized
DEBUG - 2012-02-02 23:22:05 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:22:05 --> Output Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Security Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Input Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:22:05 --> Language Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Loader Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:22:05 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Session Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:22:05 --> Session routines successfully run
DEBUG - 2012-02-02 23:22:05 --> Cart Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Model Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Model Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Controller Class Initialized
DEBUG - 2012-02-02 23:22:05 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:22:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:22:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:22:05 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:22:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:22:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:22:06 --> Final output sent to browser
DEBUG - 2012-02-02 23:22:06 --> Total execution time: 0.6055
DEBUG - 2012-02-02 23:22:37 --> Config Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:22:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:22:37 --> URI Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Router Class Initialized
DEBUG - 2012-02-02 23:22:37 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:22:37 --> Output Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Security Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Input Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:22:37 --> Language Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Loader Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:22:37 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Session Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:22:37 --> Session routines successfully run
DEBUG - 2012-02-02 23:22:37 --> Cart Class Initialized
DEBUG - 2012-02-02 23:22:37 --> Model Class Initialized
DEBUG - 2012-02-02 23:22:38 --> Model Class Initialized
DEBUG - 2012-02-02 23:22:38 --> Controller Class Initialized
DEBUG - 2012-02-02 23:22:38 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:22:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:22:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:22:39 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:22:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:22:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:22:39 --> Final output sent to browser
DEBUG - 2012-02-02 23:22:39 --> Total execution time: 1.8055
DEBUG - 2012-02-02 23:22:41 --> Config Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:22:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:22:41 --> URI Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Router Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Output Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Security Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Input Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:22:41 --> Language Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Loader Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:22:41 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Session Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:22:41 --> Session routines successfully run
DEBUG - 2012-02-02 23:22:41 --> Cart Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:22:41 --> Controller Class Initialized
DEBUG - 2012-02-02 23:22:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:22:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:22:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:22:44 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:22:44 --> Final output sent to browser
DEBUG - 2012-02-02 23:22:44 --> Total execution time: 3.4578
DEBUG - 2012-02-02 23:23:39 --> Config Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:23:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:23:39 --> URI Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Router Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Output Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Security Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Input Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:23:39 --> Language Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Loader Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:23:39 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Session Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:23:39 --> Session routines successfully run
DEBUG - 2012-02-02 23:23:39 --> Cart Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:23:39 --> Controller Class Initialized
DEBUG - 2012-02-02 23:23:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:23:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:23:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:23:39 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:23:39 --> Final output sent to browser
DEBUG - 2012-02-02 23:23:39 --> Total execution time: 0.4988
DEBUG - 2012-02-02 23:25:15 --> Config Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:25:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:25:15 --> URI Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Router Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Output Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Security Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Input Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:25:15 --> Language Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Loader Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:25:15 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Session Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:25:15 --> Session routines successfully run
DEBUG - 2012-02-02 23:25:15 --> Cart Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Model Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Model Class Initialized
DEBUG - 2012-02-02 23:25:15 --> Controller Class Initialized
DEBUG - 2012-02-02 23:25:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:25:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:25:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:25:15 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:25:15 --> Final output sent to browser
DEBUG - 2012-02-02 23:25:15 --> Total execution time: 0.5212
DEBUG - 2012-02-02 23:26:09 --> Config Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:26:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:26:09 --> URI Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Router Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Output Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Security Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Input Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:26:09 --> Language Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Loader Class Initialized
DEBUG - 2012-02-02 23:26:09 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:26:10 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:26:10 --> Session Class Initialized
DEBUG - 2012-02-02 23:26:10 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:26:10 --> Session routines successfully run
DEBUG - 2012-02-02 23:26:10 --> Cart Class Initialized
DEBUG - 2012-02-02 23:26:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:26:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:26:10 --> Controller Class Initialized
DEBUG - 2012-02-02 23:26:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:26:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:26:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:26:10 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:26:10 --> Final output sent to browser
DEBUG - 2012-02-02 23:26:10 --> Total execution time: 0.5178
DEBUG - 2012-02-02 23:26:16 --> Config Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:26:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:26:16 --> URI Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Router Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Output Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Security Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Input Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:26:16 --> Language Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Loader Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:26:16 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Session Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:26:16 --> Session routines successfully run
DEBUG - 2012-02-02 23:26:16 --> Cart Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:26:16 --> Controller Class Initialized
DEBUG - 2012-02-02 23:26:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:26:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:26:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:26:16 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:26:16 --> Final output sent to browser
DEBUG - 2012-02-02 23:26:16 --> Total execution time: 0.5187
DEBUG - 2012-02-02 23:27:06 --> Config Class Initialized
DEBUG - 2012-02-02 23:27:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:27:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:27:06 --> URI Class Initialized
DEBUG - 2012-02-02 23:27:06 --> Router Class Initialized
DEBUG - 2012-02-02 23:27:06 --> Output Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Security Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Input Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:27:07 --> Language Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Loader Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:27:07 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Session Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:27:07 --> Session routines successfully run
DEBUG - 2012-02-02 23:27:07 --> Cart Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Model Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Model Class Initialized
DEBUG - 2012-02-02 23:27:07 --> Controller Class Initialized
DEBUG - 2012-02-02 23:27:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:27:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:27:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:27:07 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:27:07 --> Final output sent to browser
DEBUG - 2012-02-02 23:27:07 --> Total execution time: 1.7190
DEBUG - 2012-02-02 23:28:16 --> Config Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:28:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:28:16 --> URI Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Router Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Output Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Security Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Input Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:28:16 --> Language Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Loader Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:28:16 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Session Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:28:16 --> Session routines successfully run
DEBUG - 2012-02-02 23:28:16 --> Cart Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:28:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:28:17 --> Controller Class Initialized
DEBUG - 2012-02-02 23:28:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:28:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:28:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:28:17 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:28:17 --> Final output sent to browser
DEBUG - 2012-02-02 23:28:17 --> Total execution time: 0.5181
DEBUG - 2012-02-02 23:28:34 --> Config Class Initialized
DEBUG - 2012-02-02 23:28:34 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:28:34 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:28:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:28:34 --> URI Class Initialized
DEBUG - 2012-02-02 23:28:34 --> Router Class Initialized
DEBUG - 2012-02-02 23:28:34 --> Output Class Initialized
DEBUG - 2012-02-02 23:28:34 --> Security Class Initialized
DEBUG - 2012-02-02 23:28:34 --> Input Class Initialized
DEBUG - 2012-02-02 23:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:28:35 --> Language Class Initialized
DEBUG - 2012-02-02 23:28:35 --> Loader Class Initialized
DEBUG - 2012-02-02 23:28:35 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:28:35 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:28:35 --> Session Class Initialized
DEBUG - 2012-02-02 23:28:35 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:28:35 --> Session routines successfully run
DEBUG - 2012-02-02 23:28:35 --> Cart Class Initialized
DEBUG - 2012-02-02 23:28:35 --> Model Class Initialized
DEBUG - 2012-02-02 23:28:35 --> Model Class Initialized
DEBUG - 2012-02-02 23:28:35 --> Controller Class Initialized
DEBUG - 2012-02-02 23:28:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:28:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:28:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:28:35 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:28:35 --> Final output sent to browser
DEBUG - 2012-02-02 23:28:35 --> Total execution time: 0.5981
DEBUG - 2012-02-02 23:29:14 --> Config Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:29:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:29:14 --> URI Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Router Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Output Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Security Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Input Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:29:14 --> Language Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Loader Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:29:14 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Session Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:29:14 --> Session routines successfully run
DEBUG - 2012-02-02 23:29:14 --> Cart Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:29:14 --> Controller Class Initialized
DEBUG - 2012-02-02 23:29:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:29:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:29:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:29:14 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:29:14 --> Final output sent to browser
DEBUG - 2012-02-02 23:29:14 --> Total execution time: 0.4916
DEBUG - 2012-02-02 23:30:06 --> Config Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:30:06 --> URI Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Router Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Output Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Security Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Input Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:30:06 --> Language Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Loader Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:30:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Session Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:30:06 --> Session routines successfully run
DEBUG - 2012-02-02 23:30:06 --> Cart Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:30:06 --> Controller Class Initialized
DEBUG - 2012-02-02 23:30:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:30:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:30:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:30:06 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:30:06 --> Final output sent to browser
DEBUG - 2012-02-02 23:30:06 --> Total execution time: 0.5959
DEBUG - 2012-02-02 23:30:48 --> Config Class Initialized
DEBUG - 2012-02-02 23:30:48 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:30:48 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:30:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:30:48 --> URI Class Initialized
DEBUG - 2012-02-02 23:30:48 --> Router Class Initialized
DEBUG - 2012-02-02 23:30:48 --> Output Class Initialized
DEBUG - 2012-02-02 23:30:48 --> Security Class Initialized
DEBUG - 2012-02-02 23:30:48 --> Input Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:30:49 --> Language Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Loader Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:30:49 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Session Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:30:49 --> Session routines successfully run
DEBUG - 2012-02-02 23:30:49 --> Cart Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:30:49 --> Controller Class Initialized
DEBUG - 2012-02-02 23:30:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:30:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:30:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:30:49 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:30:49 --> Final output sent to browser
DEBUG - 2012-02-02 23:30:49 --> Total execution time: 0.4993
DEBUG - 2012-02-02 23:31:08 --> Config Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:31:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:31:08 --> URI Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Router Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Output Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Security Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Input Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:31:08 --> Language Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Loader Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:31:08 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:31:08 --> Session Class Initialized
DEBUG - 2012-02-02 23:31:09 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:31:09 --> Session routines successfully run
DEBUG - 2012-02-02 23:31:09 --> Cart Class Initialized
DEBUG - 2012-02-02 23:31:09 --> Model Class Initialized
DEBUG - 2012-02-02 23:31:09 --> Model Class Initialized
DEBUG - 2012-02-02 23:31:09 --> Controller Class Initialized
DEBUG - 2012-02-02 23:31:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:31:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:31:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:31:09 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:31:09 --> Final output sent to browser
DEBUG - 2012-02-02 23:31:09 --> Total execution time: 0.4444
DEBUG - 2012-02-02 23:31:33 --> Config Class Initialized
DEBUG - 2012-02-02 23:31:33 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:31:33 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:31:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:31:33 --> URI Class Initialized
DEBUG - 2012-02-02 23:31:33 --> Router Class Initialized
DEBUG - 2012-02-02 23:31:33 --> Output Class Initialized
DEBUG - 2012-02-02 23:31:33 --> Security Class Initialized
DEBUG - 2012-02-02 23:31:33 --> Input Class Initialized
DEBUG - 2012-02-02 23:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:31:34 --> Language Class Initialized
DEBUG - 2012-02-02 23:31:34 --> Loader Class Initialized
DEBUG - 2012-02-02 23:31:34 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:31:34 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:31:34 --> Session Class Initialized
DEBUG - 2012-02-02 23:31:34 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:31:34 --> Session routines successfully run
DEBUG - 2012-02-02 23:31:34 --> Cart Class Initialized
DEBUG - 2012-02-02 23:31:34 --> Model Class Initialized
DEBUG - 2012-02-02 23:31:34 --> Model Class Initialized
DEBUG - 2012-02-02 23:31:34 --> Controller Class Initialized
DEBUG - 2012-02-02 23:31:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:31:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:31:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:31:34 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:31:34 --> Final output sent to browser
DEBUG - 2012-02-02 23:31:34 --> Total execution time: 0.5445
DEBUG - 2012-02-02 23:32:52 --> Config Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:32:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:32:52 --> URI Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Router Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Output Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Security Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Input Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:32:52 --> Language Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Loader Class Initialized
DEBUG - 2012-02-02 23:32:52 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:32:53 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:32:53 --> Session Class Initialized
DEBUG - 2012-02-02 23:32:53 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:32:53 --> Session routines successfully run
DEBUG - 2012-02-02 23:32:53 --> Cart Class Initialized
DEBUG - 2012-02-02 23:32:53 --> Model Class Initialized
DEBUG - 2012-02-02 23:32:53 --> Model Class Initialized
DEBUG - 2012-02-02 23:32:53 --> Controller Class Initialized
DEBUG - 2012-02-02 23:32:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:32:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:32:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:32:53 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:32:53 --> Final output sent to browser
DEBUG - 2012-02-02 23:32:53 --> Total execution time: 0.5984
DEBUG - 2012-02-02 23:32:56 --> Config Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:32:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:32:56 --> URI Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Router Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Output Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Security Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Input Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:32:56 --> Language Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Loader Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:32:56 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Session Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:32:56 --> Session routines successfully run
DEBUG - 2012-02-02 23:32:56 --> Cart Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Model Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Model Class Initialized
DEBUG - 2012-02-02 23:32:56 --> Controller Class Initialized
DEBUG - 2012-02-02 23:32:56 --> XSS Filtering completed
DEBUG - 2012-02-02 23:32:56 --> XSS Filtering completed
DEBUG - 2012-02-02 23:32:56 --> XSS Filtering completed
DEBUG - 2012-02-02 23:32:57 --> Config Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:32:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:32:57 --> URI Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Router Class Initialized
DEBUG - 2012-02-02 23:32:57 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:32:57 --> Output Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Security Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Input Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:32:57 --> Language Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Loader Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:32:57 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Session Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:32:57 --> Session routines successfully run
DEBUG - 2012-02-02 23:32:57 --> Cart Class Initialized
DEBUG - 2012-02-02 23:32:57 --> Model Class Initialized
DEBUG - 2012-02-02 23:32:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:32:58 --> Controller Class Initialized
DEBUG - 2012-02-02 23:32:58 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:32:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:32:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:32:58 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:32:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:32:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:32:58 --> Final output sent to browser
DEBUG - 2012-02-02 23:32:58 --> Total execution time: 1.2428
DEBUG - 2012-02-02 23:33:13 --> Config Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:33:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:33:13 --> URI Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Router Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Output Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Security Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Input Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:33:13 --> Language Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Loader Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:33:13 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Session Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:33:13 --> Session routines successfully run
DEBUG - 2012-02-02 23:33:13 --> Cart Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:33:13 --> Controller Class Initialized
DEBUG - 2012-02-02 23:33:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:33:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:33:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:33:13 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:33:13 --> Final output sent to browser
DEBUG - 2012-02-02 23:33:14 --> Total execution time: 0.6137
DEBUG - 2012-02-02 23:33:17 --> Config Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:33:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:33:17 --> URI Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Router Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Output Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Security Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Input Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:33:17 --> Language Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Loader Class Initialized
DEBUG - 2012-02-02 23:33:17 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:33:17 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:33:18 --> Session Class Initialized
DEBUG - 2012-02-02 23:33:18 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:33:18 --> Session routines successfully run
DEBUG - 2012-02-02 23:33:18 --> Cart Class Initialized
DEBUG - 2012-02-02 23:33:18 --> Model Class Initialized
DEBUG - 2012-02-02 23:33:18 --> Model Class Initialized
DEBUG - 2012-02-02 23:33:18 --> Controller Class Initialized
DEBUG - 2012-02-02 23:33:18 --> XSS Filtering completed
DEBUG - 2012-02-02 23:33:18 --> XSS Filtering completed
DEBUG - 2012-02-02 23:33:18 --> XSS Filtering completed
DEBUG - 2012-02-02 23:33:19 --> Config Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:33:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:33:19 --> URI Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Router Class Initialized
DEBUG - 2012-02-02 23:33:19 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:33:19 --> Output Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Security Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Input Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:33:19 --> Language Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Loader Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:33:19 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Session Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:33:19 --> Session routines successfully run
DEBUG - 2012-02-02 23:33:19 --> Cart Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Model Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Model Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Controller Class Initialized
DEBUG - 2012-02-02 23:33:19 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:33:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:33:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:33:19 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:33:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:33:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:33:19 --> Final output sent to browser
DEBUG - 2012-02-02 23:33:19 --> Total execution time: 0.8523
DEBUG - 2012-02-02 23:34:06 --> Config Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:34:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:34:06 --> URI Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Router Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Output Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Security Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Input Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:34:06 --> Language Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Loader Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:34:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Session Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:34:06 --> Session routines successfully run
DEBUG - 2012-02-02 23:34:06 --> Cart Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:06 --> Controller Class Initialized
DEBUG - 2012-02-02 23:34:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:34:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:34:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:34:06 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:34:06 --> Final output sent to browser
DEBUG - 2012-02-02 23:34:07 --> Total execution time: 0.5218
DEBUG - 2012-02-02 23:34:12 --> Config Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:34:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:34:13 --> URI Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Router Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Output Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Security Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Input Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:34:13 --> Language Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Loader Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:34:13 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Session Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:34:13 --> Session routines successfully run
DEBUG - 2012-02-02 23:34:13 --> Cart Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:13 --> Controller Class Initialized
DEBUG - 2012-02-02 23:34:13 --> XSS Filtering completed
DEBUG - 2012-02-02 23:34:13 --> XSS Filtering completed
DEBUG - 2012-02-02 23:34:13 --> XSS Filtering completed
DEBUG - 2012-02-02 23:34:14 --> Config Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:34:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:34:14 --> URI Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Router Class Initialized
DEBUG - 2012-02-02 23:34:14 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:34:14 --> Output Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Security Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Input Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:34:14 --> Language Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Loader Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:34:14 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Session Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:34:14 --> Session routines successfully run
DEBUG - 2012-02-02 23:34:14 --> Cart Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Controller Class Initialized
DEBUG - 2012-02-02 23:34:14 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:34:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:34:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:34:14 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:34:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:34:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:34:14 --> Final output sent to browser
DEBUG - 2012-02-02 23:34:14 --> Total execution time: 0.5739
DEBUG - 2012-02-02 23:34:16 --> Config Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:34:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:34:16 --> URI Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Router Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Output Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Security Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Input Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:34:16 --> Language Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Loader Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:34:16 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Session Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:34:16 --> Session routines successfully run
DEBUG - 2012-02-02 23:34:16 --> Cart Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:16 --> Controller Class Initialized
DEBUG - 2012-02-02 23:34:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:34:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:34:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:34:16 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:34:16 --> Final output sent to browser
DEBUG - 2012-02-02 23:34:17 --> Total execution time: 0.5336
DEBUG - 2012-02-02 23:34:43 --> Config Class Initialized
DEBUG - 2012-02-02 23:34:43 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:34:43 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:34:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:34:43 --> URI Class Initialized
DEBUG - 2012-02-02 23:34:43 --> Router Class Initialized
DEBUG - 2012-02-02 23:34:43 --> Output Class Initialized
DEBUG - 2012-02-02 23:34:43 --> Security Class Initialized
DEBUG - 2012-02-02 23:34:44 --> Input Class Initialized
DEBUG - 2012-02-02 23:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:34:44 --> Language Class Initialized
DEBUG - 2012-02-02 23:34:44 --> Loader Class Initialized
DEBUG - 2012-02-02 23:34:45 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:34:45 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:34:45 --> Session Class Initialized
DEBUG - 2012-02-02 23:34:45 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:34:45 --> Session routines successfully run
DEBUG - 2012-02-02 23:34:45 --> Cart Class Initialized
DEBUG - 2012-02-02 23:34:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:34:45 --> Controller Class Initialized
DEBUG - 2012-02-02 23:34:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:34:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:34:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:34:45 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:34:45 --> Final output sent to browser
DEBUG - 2012-02-02 23:34:45 --> Total execution time: 1.9175
DEBUG - 2012-02-02 23:35:02 --> Config Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:35:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:35:02 --> URI Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Router Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Output Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Security Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Input Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:35:02 --> Language Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Loader Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:35:02 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Session Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:35:02 --> Session routines successfully run
DEBUG - 2012-02-02 23:35:02 --> Cart Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:02 --> Controller Class Initialized
DEBUG - 2012-02-02 23:35:02 --> XSS Filtering completed
DEBUG - 2012-02-02 23:35:02 --> XSS Filtering completed
DEBUG - 2012-02-02 23:35:02 --> XSS Filtering completed
DEBUG - 2012-02-02 23:35:03 --> Config Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:35:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:35:03 --> URI Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Router Class Initialized
DEBUG - 2012-02-02 23:35:03 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:35:03 --> Output Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Security Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Input Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:35:03 --> Language Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Loader Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:35:03 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Session Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:35:03 --> Session routines successfully run
DEBUG - 2012-02-02 23:35:03 --> Cart Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Controller Class Initialized
DEBUG - 2012-02-02 23:35:03 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:35:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:35:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:35:03 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:35:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:35:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:35:03 --> Final output sent to browser
DEBUG - 2012-02-02 23:35:03 --> Total execution time: 0.5292
DEBUG - 2012-02-02 23:35:05 --> Config Class Initialized
DEBUG - 2012-02-02 23:35:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:35:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:35:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:35:05 --> URI Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Router Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Output Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Security Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Input Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:35:06 --> Language Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Loader Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:35:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Session Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:35:06 --> Session routines successfully run
DEBUG - 2012-02-02 23:35:06 --> Cart Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:06 --> Controller Class Initialized
DEBUG - 2012-02-02 23:35:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:35:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:35:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:35:06 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:35:06 --> Final output sent to browser
DEBUG - 2012-02-02 23:35:06 --> Total execution time: 0.5284
DEBUG - 2012-02-02 23:35:08 --> Config Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:35:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:35:08 --> URI Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Router Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Output Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Security Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Input Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:35:08 --> Language Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Loader Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:35:08 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Session Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:35:08 --> Session routines successfully run
DEBUG - 2012-02-02 23:35:08 --> Cart Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:08 --> Controller Class Initialized
DEBUG - 2012-02-02 23:35:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:35:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:35:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:35:08 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:35:08 --> Final output sent to browser
DEBUG - 2012-02-02 23:35:08 --> Total execution time: 0.4936
DEBUG - 2012-02-02 23:35:25 --> Config Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:35:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:35:25 --> URI Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Router Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Output Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Security Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Input Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:35:25 --> Language Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Loader Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:35:25 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Session Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:35:25 --> Session routines successfully run
DEBUG - 2012-02-02 23:35:25 --> Cart Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:25 --> Controller Class Initialized
DEBUG - 2012-02-02 23:35:25 --> XSS Filtering completed
DEBUG - 2012-02-02 23:35:25 --> XSS Filtering completed
DEBUG - 2012-02-02 23:35:25 --> XSS Filtering completed
DEBUG - 2012-02-02 23:35:26 --> Config Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:35:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:35:26 --> URI Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Router Class Initialized
DEBUG - 2012-02-02 23:35:26 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:35:26 --> Output Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Security Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Input Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:35:26 --> Language Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Loader Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:35:26 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Session Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:35:26 --> Session routines successfully run
DEBUG - 2012-02-02 23:35:26 --> Cart Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Controller Class Initialized
DEBUG - 2012-02-02 23:35:26 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:35:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:35:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:35:26 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:35:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:35:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:35:26 --> Final output sent to browser
DEBUG - 2012-02-02 23:35:26 --> Total execution time: 0.5755
DEBUG - 2012-02-02 23:35:28 --> Config Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:35:28 --> URI Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Router Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Output Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Security Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Input Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:35:28 --> Language Class Initialized
DEBUG - 2012-02-02 23:35:28 --> Loader Class Initialized
DEBUG - 2012-02-02 23:35:29 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:35:29 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:35:29 --> Session Class Initialized
DEBUG - 2012-02-02 23:35:29 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:35:29 --> Session routines successfully run
DEBUG - 2012-02-02 23:35:29 --> Cart Class Initialized
DEBUG - 2012-02-02 23:35:29 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:29 --> Model Class Initialized
DEBUG - 2012-02-02 23:35:29 --> Controller Class Initialized
DEBUG - 2012-02-02 23:35:29 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:35:29 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:35:29 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:35:29 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:35:29 --> Final output sent to browser
DEBUG - 2012-02-02 23:35:29 --> Total execution time: 0.5385
DEBUG - 2012-02-02 23:36:22 --> Config Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:36:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:36:22 --> URI Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Router Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Output Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Security Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Input Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:36:22 --> Language Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Loader Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:36:22 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Session Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:36:22 --> Session routines successfully run
DEBUG - 2012-02-02 23:36:22 --> Cart Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Model Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Model Class Initialized
DEBUG - 2012-02-02 23:36:22 --> Controller Class Initialized
DEBUG - 2012-02-02 23:36:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:36:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:36:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:36:22 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:36:22 --> Final output sent to browser
DEBUG - 2012-02-02 23:36:22 --> Total execution time: 0.5687
DEBUG - 2012-02-02 23:39:24 --> Config Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:39:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:39:24 --> URI Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Router Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Output Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Security Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Input Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:39:24 --> Language Class Initialized
DEBUG - 2012-02-02 23:39:24 --> Loader Class Initialized
DEBUG - 2012-02-02 23:39:25 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:39:25 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:39:25 --> Session Class Initialized
DEBUG - 2012-02-02 23:39:25 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:39:25 --> Session routines successfully run
DEBUG - 2012-02-02 23:39:25 --> Cart Class Initialized
DEBUG - 2012-02-02 23:39:25 --> Model Class Initialized
DEBUG - 2012-02-02 23:39:25 --> Model Class Initialized
DEBUG - 2012-02-02 23:39:25 --> Controller Class Initialized
DEBUG - 2012-02-02 23:39:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:39:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:39:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:39:25 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:39:25 --> Final output sent to browser
DEBUG - 2012-02-02 23:39:25 --> Total execution time: 1.2378
DEBUG - 2012-02-02 23:44:58 --> Config Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:44:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:44:58 --> URI Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Router Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Output Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Security Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Input Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:44:58 --> Language Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Loader Class Initialized
DEBUG - 2012-02-02 23:44:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:44:58 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:44:59 --> Session Class Initialized
DEBUG - 2012-02-02 23:44:59 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:44:59 --> Session routines successfully run
DEBUG - 2012-02-02 23:44:59 --> Cart Class Initialized
DEBUG - 2012-02-02 23:44:59 --> Model Class Initialized
DEBUG - 2012-02-02 23:44:59 --> Model Class Initialized
DEBUG - 2012-02-02 23:44:59 --> Controller Class Initialized
DEBUG - 2012-02-02 23:44:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:44:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:44:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:44:59 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:44:59 --> Final output sent to browser
DEBUG - 2012-02-02 23:44:59 --> Total execution time: 0.5541
DEBUG - 2012-02-02 23:46:40 --> Config Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:46:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:46:40 --> URI Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Router Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Output Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Security Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Input Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:46:40 --> Language Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Loader Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:46:40 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Session Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:46:40 --> Session routines successfully run
DEBUG - 2012-02-02 23:46:40 --> Cart Class Initialized
DEBUG - 2012-02-02 23:46:40 --> Model Class Initialized
DEBUG - 2012-02-02 23:46:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:46:41 --> Controller Class Initialized
DEBUG - 2012-02-02 23:46:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:46:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:46:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:46:41 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:46:41 --> Final output sent to browser
DEBUG - 2012-02-02 23:46:41 --> Total execution time: 1.1226
DEBUG - 2012-02-02 23:46:43 --> Config Class Initialized
DEBUG - 2012-02-02 23:46:43 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:46:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:46:44 --> URI Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Router Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Output Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Security Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Input Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:46:44 --> Language Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Loader Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:46:44 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Session Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:46:44 --> Session routines successfully run
DEBUG - 2012-02-02 23:46:44 --> Cart Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Model Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Model Class Initialized
DEBUG - 2012-02-02 23:46:44 --> Controller Class Initialized
DEBUG - 2012-02-02 23:46:44 --> XSS Filtering completed
DEBUG - 2012-02-02 23:46:44 --> XSS Filtering completed
DEBUG - 2012-02-02 23:46:44 --> XSS Filtering completed
DEBUG - 2012-02-02 23:46:45 --> Config Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:46:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:46:45 --> URI Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Router Class Initialized
DEBUG - 2012-02-02 23:46:45 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:46:45 --> Output Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Security Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Input Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:46:45 --> Language Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Loader Class Initialized
DEBUG - 2012-02-02 23:46:45 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:46:45 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:46:46 --> Session Class Initialized
DEBUG - 2012-02-02 23:46:46 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:46:46 --> Session routines successfully run
DEBUG - 2012-02-02 23:46:46 --> Cart Class Initialized
DEBUG - 2012-02-02 23:46:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:46:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:46:46 --> Controller Class Initialized
DEBUG - 2012-02-02 23:46:46 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:46:46 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:46:46 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:46:46 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:46:46 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:46:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:46:46 --> Final output sent to browser
DEBUG - 2012-02-02 23:46:46 --> Total execution time: 1.3370
DEBUG - 2012-02-02 23:47:58 --> Config Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:47:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:47:58 --> URI Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Router Class Initialized
DEBUG - 2012-02-02 23:47:58 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:47:58 --> Output Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Security Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Input Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:47:58 --> Language Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Loader Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:47:58 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Session Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:47:58 --> Session routines successfully run
DEBUG - 2012-02-02 23:47:58 --> Cart Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Controller Class Initialized
DEBUG - 2012-02-02 23:47:58 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:47:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:47:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:47:58 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:47:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:47:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:47:58 --> Final output sent to browser
DEBUG - 2012-02-02 23:47:58 --> Total execution time: 0.5907
DEBUG - 2012-02-02 23:48:01 --> Config Class Initialized
DEBUG - 2012-02-02 23:48:01 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:48:01 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:48:01 --> URI Class Initialized
DEBUG - 2012-02-02 23:48:01 --> Router Class Initialized
DEBUG - 2012-02-02 23:48:01 --> Output Class Initialized
DEBUG - 2012-02-02 23:48:01 --> Security Class Initialized
DEBUG - 2012-02-02 23:48:01 --> Input Class Initialized
DEBUG - 2012-02-02 23:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:48:01 --> Language Class Initialized
DEBUG - 2012-02-02 23:48:02 --> Loader Class Initialized
DEBUG - 2012-02-02 23:48:02 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:48:02 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:48:02 --> Session Class Initialized
DEBUG - 2012-02-02 23:48:02 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:48:02 --> Session routines successfully run
DEBUG - 2012-02-02 23:48:02 --> Cart Class Initialized
DEBUG - 2012-02-02 23:48:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:48:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:48:02 --> Controller Class Initialized
DEBUG - 2012-02-02 23:48:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:48:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:48:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:48:02 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:48:02 --> Final output sent to browser
DEBUG - 2012-02-02 23:48:02 --> Total execution time: 0.5387
DEBUG - 2012-02-02 23:48:47 --> Config Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:48:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:48:47 --> URI Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Router Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Output Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Security Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Input Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:48:47 --> Language Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Loader Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:48:47 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Session Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:48:47 --> Session routines successfully run
DEBUG - 2012-02-02 23:48:47 --> Cart Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Model Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Model Class Initialized
DEBUG - 2012-02-02 23:48:47 --> Controller Class Initialized
DEBUG - 2012-02-02 23:48:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:48:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:48:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:48:47 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:48:48 --> Final output sent to browser
DEBUG - 2012-02-02 23:48:48 --> Total execution time: 0.4532
DEBUG - 2012-02-02 23:49:05 --> Config Class Initialized
DEBUG - 2012-02-02 23:49:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:49:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:49:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:49:06 --> URI Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Router Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Output Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Security Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Input Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:49:06 --> Language Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Loader Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:49:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Session Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:49:06 --> Session routines successfully run
DEBUG - 2012-02-02 23:49:06 --> Cart Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:49:06 --> Controller Class Initialized
DEBUG - 2012-02-02 23:49:06 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:49:06 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:49:06 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:49:06 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:49:06 --> Final output sent to browser
DEBUG - 2012-02-02 23:49:06 --> Total execution time: 0.6098
DEBUG - 2012-02-02 23:49:08 --> Config Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:49:08 --> URI Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Router Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Output Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Security Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Input Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:49:08 --> Language Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Loader Class Initialized
DEBUG - 2012-02-02 23:49:08 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:49:09 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:49:09 --> Session Class Initialized
DEBUG - 2012-02-02 23:49:09 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:49:09 --> Session routines successfully run
DEBUG - 2012-02-02 23:49:09 --> Cart Class Initialized
DEBUG - 2012-02-02 23:49:09 --> Model Class Initialized
DEBUG - 2012-02-02 23:49:09 --> Model Class Initialized
DEBUG - 2012-02-02 23:49:09 --> Controller Class Initialized
DEBUG - 2012-02-02 23:49:09 --> XSS Filtering completed
DEBUG - 2012-02-02 23:49:09 --> XSS Filtering completed
DEBUG - 2012-02-02 23:49:09 --> XSS Filtering completed
DEBUG - 2012-02-02 23:49:10 --> Config Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:49:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:49:10 --> URI Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Router Class Initialized
DEBUG - 2012-02-02 23:49:10 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:49:10 --> Output Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Security Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Input Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:49:10 --> Language Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Loader Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:49:10 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Session Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:49:10 --> Session routines successfully run
DEBUG - 2012-02-02 23:49:10 --> Cart Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Controller Class Initialized
DEBUG - 2012-02-02 23:49:10 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:49:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:49:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:49:10 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:49:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:49:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:49:10 --> Final output sent to browser
DEBUG - 2012-02-02 23:49:10 --> Total execution time: 0.8130
DEBUG - 2012-02-02 23:51:49 --> Config Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:51:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:51:49 --> URI Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Router Class Initialized
DEBUG - 2012-02-02 23:51:49 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:51:49 --> Output Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Security Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Input Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:51:49 --> Language Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Loader Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:51:49 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Session Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:51:49 --> Session routines successfully run
DEBUG - 2012-02-02 23:51:49 --> Cart Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Controller Class Initialized
DEBUG - 2012-02-02 23:51:49 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:51:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:51:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:51:49 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:51:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:51:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:51:49 --> Final output sent to browser
DEBUG - 2012-02-02 23:51:49 --> Total execution time: 0.5309
DEBUG - 2012-02-02 23:51:51 --> Config Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:51:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:51:51 --> URI Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Router Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Output Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Security Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Input Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:51:51 --> Language Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Loader Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:51:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Session Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:51:51 --> Session routines successfully run
DEBUG - 2012-02-02 23:51:51 --> Cart Class Initialized
DEBUG - 2012-02-02 23:51:51 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:52 --> Controller Class Initialized
DEBUG - 2012-02-02 23:51:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:51:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:51:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:51:52 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:51:52 --> Final output sent to browser
DEBUG - 2012-02-02 23:51:52 --> Total execution time: 0.8370
DEBUG - 2012-02-02 23:51:57 --> Config Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:51:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:51:57 --> URI Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Router Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Output Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Security Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Input Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:51:57 --> Language Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Loader Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:51:57 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Session Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:51:57 --> Session routines successfully run
DEBUG - 2012-02-02 23:51:57 --> Cart Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:57 --> Controller Class Initialized
DEBUG - 2012-02-02 23:51:57 --> XSS Filtering completed
DEBUG - 2012-02-02 23:51:57 --> XSS Filtering completed
DEBUG - 2012-02-02 23:51:57 --> XSS Filtering completed
DEBUG - 2012-02-02 23:51:58 --> Config Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:51:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:51:58 --> URI Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Router Class Initialized
DEBUG - 2012-02-02 23:51:58 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:51:58 --> Output Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Security Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Input Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:51:58 --> Language Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Loader Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:51:58 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Session Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:51:58 --> Session routines successfully run
DEBUG - 2012-02-02 23:51:58 --> Cart Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Controller Class Initialized
DEBUG - 2012-02-02 23:51:58 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:51:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:51:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:51:58 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:51:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:51:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:51:58 --> Final output sent to browser
DEBUG - 2012-02-02 23:51:58 --> Total execution time: 0.5895
DEBUG - 2012-02-02 23:54:04 --> Config Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:54:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:54:04 --> URI Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Router Class Initialized
DEBUG - 2012-02-02 23:54:04 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:54:04 --> Output Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Security Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Input Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:54:04 --> Language Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Loader Class Initialized
DEBUG - 2012-02-02 23:54:04 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:54:05 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:54:05 --> Session Class Initialized
DEBUG - 2012-02-02 23:54:05 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:54:05 --> Session routines successfully run
DEBUG - 2012-02-02 23:54:05 --> Cart Class Initialized
DEBUG - 2012-02-02 23:54:05 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:05 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:05 --> Controller Class Initialized
DEBUG - 2012-02-02 23:54:05 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:54:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:54:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:54:05 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:54:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:54:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:54:05 --> Final output sent to browser
DEBUG - 2012-02-02 23:54:05 --> Total execution time: 1.0120
DEBUG - 2012-02-02 23:54:07 --> Config Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:54:07 --> URI Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Router Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Output Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Security Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Input Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:54:07 --> Language Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Loader Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:54:07 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Session Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:54:07 --> Session routines successfully run
DEBUG - 2012-02-02 23:54:07 --> Cart Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:07 --> Controller Class Initialized
DEBUG - 2012-02-02 23:54:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:54:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:54:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:54:07 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:54:08 --> Final output sent to browser
DEBUG - 2012-02-02 23:54:08 --> Total execution time: 0.6330
DEBUG - 2012-02-02 23:54:13 --> Config Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:54:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:54:13 --> URI Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Router Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Output Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Security Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Input Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:54:13 --> Language Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Loader Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:54:13 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Session Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:54:13 --> Session routines successfully run
DEBUG - 2012-02-02 23:54:13 --> Cart Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:13 --> Controller Class Initialized
DEBUG - 2012-02-02 23:54:13 --> XSS Filtering completed
DEBUG - 2012-02-02 23:54:13 --> XSS Filtering completed
DEBUG - 2012-02-02 23:54:13 --> XSS Filtering completed
DEBUG - 2012-02-02 23:54:14 --> Config Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:54:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:54:14 --> URI Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Router Class Initialized
DEBUG - 2012-02-02 23:54:14 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:54:14 --> Output Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Security Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Input Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:54:14 --> Language Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Loader Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:54:14 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Session Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:54:14 --> Session routines successfully run
DEBUG - 2012-02-02 23:54:14 --> Cart Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Controller Class Initialized
DEBUG - 2012-02-02 23:54:14 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:54:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:54:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:54:15 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:54:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:54:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:54:15 --> Final output sent to browser
DEBUG - 2012-02-02 23:54:15 --> Total execution time: 0.5730
DEBUG - 2012-02-02 23:54:59 --> Config Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:54:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:54:59 --> URI Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Router Class Initialized
DEBUG - 2012-02-02 23:54:59 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:54:59 --> Output Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Security Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Input Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:54:59 --> Language Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Loader Class Initialized
DEBUG - 2012-02-02 23:54:59 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:54:59 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:55:00 --> Session Class Initialized
DEBUG - 2012-02-02 23:55:00 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:55:00 --> Session routines successfully run
DEBUG - 2012-02-02 23:55:00 --> Cart Class Initialized
DEBUG - 2012-02-02 23:55:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:55:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:55:00 --> Controller Class Initialized
DEBUG - 2012-02-02 23:55:00 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:55:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:55:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:55:00 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:55:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:55:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:55:00 --> Final output sent to browser
DEBUG - 2012-02-02 23:55:00 --> Total execution time: 0.4783
DEBUG - 2012-02-02 23:55:01 --> Config Class Initialized
DEBUG - 2012-02-02 23:55:01 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:55:01 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:55:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:55:01 --> URI Class Initialized
DEBUG - 2012-02-02 23:55:01 --> Router Class Initialized
ERROR - 2012-02-02 23:55:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 23:55:02 --> Config Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:55:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:55:02 --> URI Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Router Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Output Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Security Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Input Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:55:02 --> Language Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Loader Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:55:02 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Session Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:55:02 --> Session routines successfully run
DEBUG - 2012-02-02 23:55:02 --> Cart Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:55:02 --> Controller Class Initialized
DEBUG - 2012-02-02 23:55:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:55:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:55:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:55:02 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:55:02 --> Final output sent to browser
DEBUG - 2012-02-02 23:55:03 --> Total execution time: 0.5424
DEBUG - 2012-02-02 23:55:03 --> Config Class Initialized
DEBUG - 2012-02-02 23:55:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:55:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:55:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:55:03 --> URI Class Initialized
DEBUG - 2012-02-02 23:55:03 --> Router Class Initialized
ERROR - 2012-02-02 23:55:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-02 23:55:36 --> Config Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:55:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:55:36 --> URI Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Router Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Output Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Security Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Input Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:55:36 --> Language Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Loader Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:55:36 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Session Class Initialized
DEBUG - 2012-02-02 23:55:36 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:55:36 --> Session routines successfully run
DEBUG - 2012-02-02 23:55:37 --> Cart Class Initialized
DEBUG - 2012-02-02 23:55:37 --> Model Class Initialized
DEBUG - 2012-02-02 23:55:37 --> Model Class Initialized
DEBUG - 2012-02-02 23:55:37 --> Controller Class Initialized
DEBUG - 2012-02-02 23:55:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:55:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:55:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:55:37 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:55:37 --> Final output sent to browser
DEBUG - 2012-02-02 23:55:37 --> Total execution time: 0.7546
DEBUG - 2012-02-02 23:56:09 --> Config Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:56:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:56:09 --> URI Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Router Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Output Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Security Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Input Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:56:09 --> Language Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Loader Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:56:09 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Session Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:56:09 --> Session routines successfully run
DEBUG - 2012-02-02 23:56:09 --> Cart Class Initialized
DEBUG - 2012-02-02 23:56:09 --> Model Class Initialized
DEBUG - 2012-02-02 23:56:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:56:10 --> Controller Class Initialized
DEBUG - 2012-02-02 23:56:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:56:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:56:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:56:10 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:56:10 --> Final output sent to browser
DEBUG - 2012-02-02 23:56:10 --> Total execution time: 0.5967
DEBUG - 2012-02-02 23:57:15 --> Config Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:57:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:57:15 --> URI Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Router Class Initialized
DEBUG - 2012-02-02 23:57:15 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:57:15 --> Output Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Security Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Input Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:57:15 --> Language Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Loader Class Initialized
DEBUG - 2012-02-02 23:57:15 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:57:16 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:57:16 --> Session Class Initialized
DEBUG - 2012-02-02 23:57:16 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:57:16 --> Session routines successfully run
DEBUG - 2012-02-02 23:57:16 --> Cart Class Initialized
DEBUG - 2012-02-02 23:57:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:16 --> Controller Class Initialized
DEBUG - 2012-02-02 23:57:16 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:57:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:57:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:57:16 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:57:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:57:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:57:16 --> Final output sent to browser
DEBUG - 2012-02-02 23:57:16 --> Total execution time: 0.8379
DEBUG - 2012-02-02 23:57:20 --> Config Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:57:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:57:20 --> URI Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Router Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Output Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Security Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Input Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:57:20 --> Language Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Loader Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:57:20 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Session Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:57:20 --> Session routines successfully run
DEBUG - 2012-02-02 23:57:20 --> Cart Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:20 --> Controller Class Initialized
DEBUG - 2012-02-02 23:57:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:57:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:57:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:57:20 --> File loaded: application/views/user/order.php
DEBUG - 2012-02-02 23:57:21 --> Final output sent to browser
DEBUG - 2012-02-02 23:57:21 --> Total execution time: 0.7008
DEBUG - 2012-02-02 23:57:45 --> Config Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:57:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:57:45 --> URI Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Router Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Output Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Security Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Input Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:57:45 --> Language Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Loader Class Initialized
DEBUG - 2012-02-02 23:57:45 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:57:45 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:57:46 --> Session Class Initialized
DEBUG - 2012-02-02 23:57:46 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:57:46 --> Session routines successfully run
DEBUG - 2012-02-02 23:57:46 --> Cart Class Initialized
DEBUG - 2012-02-02 23:57:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:46 --> Controller Class Initialized
DEBUG - 2012-02-02 23:57:46 --> XSS Filtering completed
DEBUG - 2012-02-02 23:57:46 --> XSS Filtering completed
DEBUG - 2012-02-02 23:57:46 --> XSS Filtering completed
DEBUG - 2012-02-02 23:57:46 --> Config Class Initialized
DEBUG - 2012-02-02 23:57:46 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:57:46 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:57:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:57:47 --> URI Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Router Class Initialized
DEBUG - 2012-02-02 23:57:47 --> No URI present. Default controller set.
DEBUG - 2012-02-02 23:57:47 --> Output Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Security Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Input Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:57:47 --> Language Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Loader Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:57:47 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Session Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:57:47 --> Session routines successfully run
DEBUG - 2012-02-02 23:57:47 --> Cart Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Model Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Controller Class Initialized
DEBUG - 2012-02-02 23:57:47 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:57:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-02 23:57:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-02 23:57:47 --> File loaded: application/views/user/blocks/products.php
DEBUG - 2012-02-02 23:57:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-02 23:57:47 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-02 23:57:47 --> Final output sent to browser
DEBUG - 2012-02-02 23:57:47 --> Total execution time: 0.6865
DEBUG - 2012-02-02 23:58:27 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:27 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:27 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:27 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:27 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:28 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:28 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:28 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:28 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:28 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:28 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:28 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:28 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:28 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-02 23:58:28 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:28 --> Total execution time: 0.7077
DEBUG - 2012-02-02 23:58:32 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:32 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:32 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:32 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:32 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:32 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:33 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:33 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:33 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:33 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:33 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:33 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:58:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:33 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:58:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:34 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:58:34 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:34 --> Total execution time: 1.3373
DEBUG - 2012-02-02 23:58:36 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:36 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:36 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:36 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:36 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:36 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:36 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:36 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:58:36 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:36 --> Total execution time: 0.4997
DEBUG - 2012-02-02 23:58:37 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:37 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:37 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:38 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:38 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:38 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:38 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:38 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:38 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:39 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:39 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:39 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:39 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:39 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:39 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:58:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:40 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:58:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:58:40 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:40 --> Total execution time: 0.4811
DEBUG - 2012-02-02 23:58:41 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:41 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:41 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:41 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:41 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:41 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:41 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:41 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:58:41 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:41 --> Total execution time: 0.5601
DEBUG - 2012-02-02 23:58:42 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:42 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:42 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:42 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:42 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:42 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:42 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:42 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:42 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:43 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:43 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:43 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:43 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:43 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:43 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:43 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:43 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:43 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:43 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:44 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:44 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:44 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:44 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:44 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:44 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:58:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:44 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:44 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:58:44 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:58:45 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:45 --> Total execution time: 0.6453
DEBUG - 2012-02-02 23:58:46 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:46 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:46 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:46 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:46 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:46 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:46 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:46 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:46 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:46 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:46 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:58:46 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:46 --> Total execution time: 0.5330
DEBUG - 2012-02-02 23:58:48 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:48 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:48 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:48 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:48 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:48 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:48 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:49 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:49 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:49 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:49 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:49 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:50 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:50 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:58:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:50 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:58:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:58:50 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:50 --> Total execution time: 0.5334
DEBUG - 2012-02-02 23:58:50 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:50 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:51 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:51 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:51 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:51 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:51 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:51 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:58:51 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:51 --> Total execution time: 0.4852
DEBUG - 2012-02-02 23:58:52 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:52 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:52 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:52 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:52 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:52 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:53 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:53 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:53 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:53 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:53 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:53 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:54 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:54 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:54 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:54 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:54 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:58:54 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:54 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:54 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:58:54 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:54 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:58:54 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:54 --> Total execution time: 1.0739
DEBUG - 2012-02-02 23:58:55 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:55 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:55 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:55 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:55 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:55 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:55 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:56 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:58:56 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:56 --> Total execution time: 0.5315
DEBUG - 2012-02-02 23:58:56 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:57 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:57 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:57 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:57 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:57 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:57 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:57 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:58 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:58:58 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Session Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:58:58 --> Session routines successfully run
DEBUG - 2012-02-02 23:58:58 --> Cart Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Model Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Controller Class Initialized
DEBUG - 2012-02-02 23:58:58 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:58:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:58:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:58:58 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:58:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:58:58 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:58:58 --> Final output sent to browser
DEBUG - 2012-02-02 23:58:58 --> Total execution time: 0.4719
DEBUG - 2012-02-02 23:58:59 --> Config Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:58:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:58:59 --> URI Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Router Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Output Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Security Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Input Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:58:59 --> Language Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Loader Class Initialized
DEBUG - 2012-02-02 23:58:59 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:00 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:00 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:00 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:00 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:00 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:00 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:00 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:00 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:00 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:00 --> Total execution time: 0.8018
DEBUG - 2012-02-02 23:59:01 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:01 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:01 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:01 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:01 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:01 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:01 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:02 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:02 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:02 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:02 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:02 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:02 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:02 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:02 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:02 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:02 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:02 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:02 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:02 --> Total execution time: 0.4879
DEBUG - 2012-02-02 23:59:03 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:03 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:03 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:03 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:03 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:04 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:04 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:04 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:04 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:04 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:04 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:04 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:04 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:04 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:04 --> Total execution time: 0.5779
DEBUG - 2012-02-02 23:59:05 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:05 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:05 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:05 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:05 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:05 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:05 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:06 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:06 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:06 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:06 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:06 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:06 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:06 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:06 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:06 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:06 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:06 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:06 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:06 --> Total execution time: 0.4841
DEBUG - 2012-02-02 23:59:07 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:07 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:07 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:07 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:07 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:07 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:07 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:07 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:07 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:07 --> Total execution time: 0.5467
DEBUG - 2012-02-02 23:59:08 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:08 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:08 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:08 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:09 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:09 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:09 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:09 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:09 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:10 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:10 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:10 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:10 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:10 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:10 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:10 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:10 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:10 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:10 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:10 --> Total execution time: 0.5606
DEBUG - 2012-02-02 23:59:11 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:11 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:11 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:11 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:11 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:11 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:11 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:12 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:12 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:12 --> Total execution time: 0.5657
DEBUG - 2012-02-02 23:59:13 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:13 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:13 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:13 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:13 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:13 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:13 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:14 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:14 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:14 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:14 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:14 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:14 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:14 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:14 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:14 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:14 --> Total execution time: 0.6814
DEBUG - 2012-02-02 23:59:15 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:15 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:15 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:15 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:16 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:16 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:16 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:16 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:16 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:16 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:16 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:16 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:16 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:16 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:16 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:16 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:16 --> Total execution time: 0.9733
DEBUG - 2012-02-02 23:59:17 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:17 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:17 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:17 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:17 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:17 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:17 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:18 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:18 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:18 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:18 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:18 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:18 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:18 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:18 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:18 --> Total execution time: 0.4954
DEBUG - 2012-02-02 23:59:19 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:19 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:19 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:19 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:19 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:20 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:20 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:20 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:20 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:20 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:20 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:20 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:20 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:20 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:20 --> Total execution time: 0.5473
DEBUG - 2012-02-02 23:59:21 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:21 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:21 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:21 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:21 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:21 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:21 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:22 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:22 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:22 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:22 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:22 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:22 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:22 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:22 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:22 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:22 --> Total execution time: 0.5509
DEBUG - 2012-02-02 23:59:24 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:24 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:24 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:24 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:24 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:24 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:24 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:24 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:24 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:24 --> Total execution time: 0.5582
DEBUG - 2012-02-02 23:59:25 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:25 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:25 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:25 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:25 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:25 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:25 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:26 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:26 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:26 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:26 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:27 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:27 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:27 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:27 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:27 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:27 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:27 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:27 --> Total execution time: 1.1093
DEBUG - 2012-02-02 23:59:28 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:28 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:28 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:28 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:28 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:28 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:28 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:29 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:29 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:29 --> Total execution time: 0.4826
DEBUG - 2012-02-02 23:59:30 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:30 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:30 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:30 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:30 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:30 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:30 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:31 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:31 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:31 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:31 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:31 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:31 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:31 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:31 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:31 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:31 --> Total execution time: 0.4769
DEBUG - 2012-02-02 23:59:32 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:32 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:32 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:32 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:33 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:33 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:33 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:33 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:33 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:33 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:33 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:33 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:33 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:33 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:33 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:33 --> Total execution time: 0.8705
DEBUG - 2012-02-02 23:59:34 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:34 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:34 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:34 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:34 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:34 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:34 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:35 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:35 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:35 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:35 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:35 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:35 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:35 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:35 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:36 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:36 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:36 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:36 --> Total execution time: 0.5393
DEBUG - 2012-02-02 23:59:36 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:36 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:36 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:37 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:37 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:37 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:37 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:37 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:37 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:37 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:37 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:37 --> Total execution time: 0.9163
DEBUG - 2012-02-02 23:59:38 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:38 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:38 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:38 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:38 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:39 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:39 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:39 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:39 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:39 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:39 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:40 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:40 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:40 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:40 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:40 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:40 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:40 --> Total execution time: 0.4555
DEBUG - 2012-02-02 23:59:40 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:40 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:41 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:41 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:41 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:41 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:41 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:41 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:41 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:41 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:41 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:41 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:41 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:41 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:41 --> Total execution time: 0.4880
DEBUG - 2012-02-02 23:59:42 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:42 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:42 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:42 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:42 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:43 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:43 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:43 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:43 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:43 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:43 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:44 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:44 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:44 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:44 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:44 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:44 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:44 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:44 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:44 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:44 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:44 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:44 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:44 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:44 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:44 --> Total execution time: 0.5992
DEBUG - 2012-02-02 23:59:44 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:45 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:45 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:45 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:45 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:45 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:45 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:45 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:45 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:45 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:45 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:45 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:45 --> Total execution time: 0.5376
DEBUG - 2012-02-02 23:59:46 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:46 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:46 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:46 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:46 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:46 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:46 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:47 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:47 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:47 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:47 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:47 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:47 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:47 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:48 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:48 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:48 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:48 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:48 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:48 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:48 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:48 --> Total execution time: 1.0564
DEBUG - 2012-02-02 23:59:49 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:49 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:49 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:49 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:49 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:49 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:49 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:50 --> File loaded: application/views/admin/order.php
DEBUG - 2012-02-02 23:59:50 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:50 --> Total execution time: 0.5815
DEBUG - 2012-02-02 23:59:51 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:51 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:51 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:51 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:51 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:51 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:51 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:52 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:52 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:52 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:52 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:52 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:52 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:52 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:52 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:52 --> Total execution time: 0.4547
DEBUG - 2012-02-02 23:59:55 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:55 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:55 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:55 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:55 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:55 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:55 --> Helper loaded: validate_helper
DEBUG - 2012-02-02 23:59:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:55 --> File loaded: application/views/admin/product_create.php
DEBUG - 2012-02-02 23:59:55 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:55 --> Total execution time: 0.4799
DEBUG - 2012-02-02 23:59:58 --> Config Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Hooks Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Utf8 Class Initialized
DEBUG - 2012-02-02 23:59:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-02 23:59:58 --> URI Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Router Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Output Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Security Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Input Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-02 23:59:58 --> Language Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Loader Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Helper loaded: url_helper
DEBUG - 2012-02-02 23:59:58 --> Database Driver Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Session Class Initialized
DEBUG - 2012-02-02 23:59:58 --> Helper loaded: string_helper
DEBUG - 2012-02-02 23:59:59 --> Session routines successfully run
DEBUG - 2012-02-02 23:59:59 --> Cart Class Initialized
DEBUG - 2012-02-02 23:59:59 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:59 --> Model Class Initialized
DEBUG - 2012-02-02 23:59:59 --> Controller Class Initialized
DEBUG - 2012-02-02 23:59:59 --> Pagination Class Initialized
DEBUG - 2012-02-02 23:59:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-02 23:59:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-02 23:59:59 --> File loaded: application/views//admin/blocks/products.php
DEBUG - 2012-02-02 23:59:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-02 23:59:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-02 23:59:59 --> Final output sent to browser
DEBUG - 2012-02-02 23:59:59 --> Total execution time: 0.5633

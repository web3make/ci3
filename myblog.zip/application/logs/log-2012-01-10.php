<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-10 00:03:02 --> Config Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:03:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:03:02 --> URI Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Router Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Output Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Security Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Input Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:03:02 --> Language Class Initialized
DEBUG - 2012-01-10 00:03:02 --> Loader Class Initialized
DEBUG - 2012-01-10 00:03:03 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:03:03 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:03:03 --> Session Class Initialized
DEBUG - 2012-01-10 00:03:03 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:03:03 --> Session routines successfully run
DEBUG - 2012-01-10 00:03:03 --> Controller Class Initialized
DEBUG - 2012-01-10 00:03:03 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:03:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:03:03 --> Final output sent to browser
DEBUG - 2012-01-10 00:03:03 --> Total execution time: 0.5654
DEBUG - 2012-01-10 00:03:06 --> Config Class Initialized
DEBUG - 2012-01-10 00:03:06 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:03:06 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:03:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:03:06 --> URI Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Router Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Output Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Security Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Input Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:03:07 --> Language Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Loader Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:03:07 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Session Class Initialized
DEBUG - 2012-01-10 00:03:07 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:03:07 --> Session routines successfully run
DEBUG - 2012-01-10 00:03:07 --> Controller Class Initialized
DEBUG - 2012-01-10 00:03:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:03:07 --> Final output sent to browser
DEBUG - 2012-01-10 00:03:07 --> Total execution time: 0.6138
DEBUG - 2012-01-10 00:03:08 --> Config Class Initialized
DEBUG - 2012-01-10 00:03:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:03:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:03:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:03:08 --> URI Class Initialized
DEBUG - 2012-01-10 00:03:08 --> Router Class Initialized
DEBUG - 2012-01-10 00:03:08 --> Output Class Initialized
DEBUG - 2012-01-10 00:03:08 --> Security Class Initialized
DEBUG - 2012-01-10 00:03:08 --> Input Class Initialized
DEBUG - 2012-01-10 00:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:03:09 --> Language Class Initialized
DEBUG - 2012-01-10 00:03:09 --> Loader Class Initialized
DEBUG - 2012-01-10 00:03:09 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:03:09 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:03:09 --> Session Class Initialized
DEBUG - 2012-01-10 00:03:09 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:03:09 --> Session routines successfully run
DEBUG - 2012-01-10 00:03:09 --> Controller Class Initialized
DEBUG - 2012-01-10 00:03:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:03:09 --> Final output sent to browser
DEBUG - 2012-01-10 00:03:09 --> Total execution time: 0.9095
DEBUG - 2012-01-10 00:03:37 --> Config Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:03:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:03:37 --> URI Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Router Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Output Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Security Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Input Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:03:37 --> Language Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Loader Class Initialized
DEBUG - 2012-01-10 00:03:37 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:03:38 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:03:38 --> Session Class Initialized
DEBUG - 2012-01-10 00:03:38 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:03:38 --> Session routines successfully run
DEBUG - 2012-01-10 00:03:38 --> Controller Class Initialized
ERROR - 2012-01-10 00:03:38 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\category.php 28
ERROR - 2012-01-10 00:03:38 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\category.php 28
DEBUG - 2012-01-10 00:03:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:03:38 --> Final output sent to browser
DEBUG - 2012-01-10 00:03:38 --> Total execution time: 0.4461
DEBUG - 2012-01-10 00:04:08 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:08 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:08 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:08 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:09 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:09 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:04:09 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:09 --> Total execution time: 0.3891
DEBUG - 2012-01-10 00:04:13 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:13 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:13 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:13 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:13 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:13 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:13 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:13 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:14 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:14 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:14 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:14 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:14 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:14 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:14 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:14 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:14 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:04:14 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:14 --> Total execution time: 0.4659
DEBUG - 2012-01-10 00:04:15 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:15 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:15 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:15 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:15 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:15 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:15 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:04:15 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:15 --> Total execution time: 0.4118
DEBUG - 2012-01-10 00:04:17 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:17 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:17 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:17 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:17 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:17 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:17 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:04:17 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:17 --> Total execution time: 0.4464
DEBUG - 2012-01-10 00:04:19 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:19 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:19 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:19 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:19 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:19 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:19 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:04:19 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:19 --> Total execution time: 1.0246
DEBUG - 2012-01-10 00:04:21 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:21 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:21 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:22 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:22 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:04:22 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:22 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:22 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:22 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:22 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:22 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:04:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:04:22 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:22 --> Total execution time: 0.5502
DEBUG - 2012-01-10 00:04:23 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:23 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:23 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:23 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:24 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:24 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:24 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:24 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:24 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:04:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:04:24 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:24 --> Total execution time: 0.9730
DEBUG - 2012-01-10 00:04:26 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:27 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:27 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:27 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:27 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:27 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:27 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:04:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:04:27 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:27 --> Total execution time: 0.5421
DEBUG - 2012-01-10 00:04:38 --> Config Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:04:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:04:38 --> URI Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Router Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Output Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Security Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Input Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:04:38 --> Language Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Loader Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:04:38 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Session Class Initialized
DEBUG - 2012-01-10 00:04:38 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:04:38 --> Session routines successfully run
DEBUG - 2012-01-10 00:04:38 --> Controller Class Initialized
DEBUG - 2012-01-10 00:04:38 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:04:38 --> Final output sent to browser
DEBUG - 2012-01-10 00:04:38 --> Total execution time: 0.4634
DEBUG - 2012-01-10 00:05:22 --> Config Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:05:22 --> URI Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Router Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Output Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Security Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Input Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:05:22 --> Language Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Loader Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:05:22 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Session Class Initialized
DEBUG - 2012-01-10 00:05:22 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:05:22 --> Session routines successfully run
DEBUG - 2012-01-10 00:05:23 --> Controller Class Initialized
DEBUG - 2012-01-10 00:05:23 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:05:23 --> Final output sent to browser
DEBUG - 2012-01-10 00:05:23 --> Total execution time: 1.0073
DEBUG - 2012-01-10 00:05:52 --> Config Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:05:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:05:52 --> URI Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Router Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Output Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Security Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Input Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:05:52 --> Language Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Loader Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:05:52 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Session Class Initialized
DEBUG - 2012-01-10 00:05:52 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:05:52 --> Session routines successfully run
DEBUG - 2012-01-10 00:05:52 --> Controller Class Initialized
DEBUG - 2012-01-10 00:05:52 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:05:52 --> Final output sent to browser
DEBUG - 2012-01-10 00:05:52 --> Total execution time: 0.4761
DEBUG - 2012-01-10 00:06:18 --> Config Class Initialized
DEBUG - 2012-01-10 00:06:18 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:06:18 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:06:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:06:18 --> URI Class Initialized
DEBUG - 2012-01-10 00:06:18 --> Router Class Initialized
DEBUG - 2012-01-10 00:06:19 --> Output Class Initialized
DEBUG - 2012-01-10 00:06:19 --> Security Class Initialized
DEBUG - 2012-01-10 00:06:19 --> Input Class Initialized
DEBUG - 2012-01-10 00:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:06:19 --> Language Class Initialized
DEBUG - 2012-01-10 00:06:19 --> Loader Class Initialized
DEBUG - 2012-01-10 00:06:19 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:06:20 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:06:20 --> Session Class Initialized
DEBUG - 2012-01-10 00:06:20 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:06:20 --> Session routines successfully run
DEBUG - 2012-01-10 00:06:20 --> Controller Class Initialized
DEBUG - 2012-01-10 00:06:20 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:06:20 --> Final output sent to browser
DEBUG - 2012-01-10 00:06:20 --> Total execution time: 1.5647
DEBUG - 2012-01-10 00:06:24 --> Config Class Initialized
DEBUG - 2012-01-10 00:06:24 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:06:24 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:06:24 --> URI Class Initialized
DEBUG - 2012-01-10 00:06:24 --> Router Class Initialized
DEBUG - 2012-01-10 00:06:24 --> Output Class Initialized
DEBUG - 2012-01-10 00:06:24 --> Security Class Initialized
DEBUG - 2012-01-10 00:06:25 --> Input Class Initialized
DEBUG - 2012-01-10 00:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:06:25 --> Language Class Initialized
DEBUG - 2012-01-10 00:06:25 --> Loader Class Initialized
DEBUG - 2012-01-10 00:06:25 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:06:25 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:06:25 --> Session Class Initialized
DEBUG - 2012-01-10 00:06:25 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:06:25 --> Session routines successfully run
DEBUG - 2012-01-10 00:06:25 --> Controller Class Initialized
DEBUG - 2012-01-10 00:06:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:06:25 --> Final output sent to browser
DEBUG - 2012-01-10 00:06:25 --> Total execution time: 0.4394
DEBUG - 2012-01-10 00:06:27 --> Config Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:06:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:06:27 --> URI Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Router Class Initialized
DEBUG - 2012-01-10 00:06:27 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:06:27 --> Output Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Security Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Input Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:06:27 --> Language Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Loader Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:06:27 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Session Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:06:27 --> Session routines successfully run
DEBUG - 2012-01-10 00:06:27 --> Controller Class Initialized
DEBUG - 2012-01-10 00:06:27 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:06:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:06:27 --> Final output sent to browser
DEBUG - 2012-01-10 00:06:27 --> Total execution time: 0.4574
DEBUG - 2012-01-10 00:06:29 --> Config Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:06:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:06:29 --> URI Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Router Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Output Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Security Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Input Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:06:29 --> Language Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Loader Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:06:29 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Session Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:06:29 --> Session routines successfully run
DEBUG - 2012-01-10 00:06:29 --> Controller Class Initialized
DEBUG - 2012-01-10 00:06:29 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:06:29 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:06:29 --> Final output sent to browser
DEBUG - 2012-01-10 00:06:29 --> Total execution time: 0.4691
DEBUG - 2012-01-10 00:06:31 --> Config Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:06:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:06:31 --> URI Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Router Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Output Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Security Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Input Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:06:31 --> Language Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Loader Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:06:31 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Session Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:06:31 --> Session routines successfully run
DEBUG - 2012-01-10 00:06:31 --> Controller Class Initialized
DEBUG - 2012-01-10 00:06:31 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:06:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:06:31 --> Final output sent to browser
DEBUG - 2012-01-10 00:06:31 --> Total execution time: 0.4887
DEBUG - 2012-01-10 00:06:38 --> Config Class Initialized
DEBUG - 2012-01-10 00:06:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:06:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:06:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:06:39 --> URI Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Router Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Output Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Security Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Input Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:06:39 --> Language Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Loader Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:06:39 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Session Class Initialized
DEBUG - 2012-01-10 00:06:39 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:06:39 --> Session routines successfully run
DEBUG - 2012-01-10 00:06:39 --> Controller Class Initialized
DEBUG - 2012-01-10 00:06:39 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 00:06:39 --> Final output sent to browser
DEBUG - 2012-01-10 00:06:39 --> Total execution time: 0.5151
DEBUG - 2012-01-10 00:17:42 --> Config Class Initialized
DEBUG - 2012-01-10 00:17:42 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:17:42 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:17:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:17:42 --> URI Class Initialized
DEBUG - 2012-01-10 00:17:42 --> Router Class Initialized
DEBUG - 2012-01-10 00:17:42 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:17:42 --> Output Class Initialized
DEBUG - 2012-01-10 00:17:42 --> Security Class Initialized
DEBUG - 2012-01-10 00:17:42 --> Input Class Initialized
DEBUG - 2012-01-10 00:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:17:43 --> Language Class Initialized
DEBUG - 2012-01-10 00:17:43 --> Loader Class Initialized
DEBUG - 2012-01-10 00:17:43 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:17:43 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:17:43 --> Session Class Initialized
DEBUG - 2012-01-10 00:17:43 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:17:43 --> Session routines successfully run
DEBUG - 2012-01-10 00:17:43 --> Controller Class Initialized
DEBUG - 2012-01-10 00:17:43 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:17:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:18:01 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:01 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:01 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:18:01 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:01 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:01 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:01 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:01 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:18:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:18:01 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:01 --> Total execution time: 0.1875
DEBUG - 2012-01-10 00:18:01 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:02 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:02 --> Router Class Initialized
ERROR - 2012-01-10 00:18:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:06 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:06 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:06 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:06 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:06 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:06 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:06 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:06 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:18:06 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:06 --> Total execution time: 0.3868
DEBUG - 2012-01-10 00:18:07 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:07 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:07 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:07 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:07 --> Router Class Initialized
ERROR - 2012-01-10 00:18:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:08 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:08 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:08 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:08 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:08 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:08 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:18:08 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:08 --> Total execution time: 0.4591
DEBUG - 2012-01-10 00:18:08 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:09 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:09 --> Router Class Initialized
ERROR - 2012-01-10 00:18:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:11 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:11 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:11 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:11 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:11 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:11 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:18:11 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:11 --> Total execution time: 0.1336
DEBUG - 2012-01-10 00:18:11 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:11 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:11 --> Router Class Initialized
ERROR - 2012-01-10 00:18:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:14 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:14 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:14 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:14 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:14 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:14 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:14 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:18:14 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:14 --> Total execution time: 0.1813
DEBUG - 2012-01-10 00:18:14 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:14 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:14 --> Router Class Initialized
ERROR - 2012-01-10 00:18:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:15 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:15 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:15 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:15 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:15 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:15 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:18:15 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:15 --> Total execution time: 0.1300
DEBUG - 2012-01-10 00:18:15 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:15 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:15 --> Router Class Initialized
ERROR - 2012-01-10 00:18:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:16 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:16 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:16 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:18:16 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:16 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:16 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:16 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:16 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:16 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:18:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:18:16 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:16 --> Total execution time: 0.2067
DEBUG - 2012-01-10 00:18:17 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:17 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:17 --> Router Class Initialized
ERROR - 2012-01-10 00:18:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:18 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:18 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:18 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:18 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:18 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:18 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:18 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:18:18 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:18 --> Total execution time: 0.1673
DEBUG - 2012-01-10 00:18:18 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:18 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:18 --> Router Class Initialized
ERROR - 2012-01-10 00:18:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:19 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:19 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:19 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:18:19 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:19 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:19 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:19 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:19 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:19 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:18:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:18:19 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:19 --> Total execution time: 0.1481
DEBUG - 2012-01-10 00:18:20 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:20 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Router Class Initialized
ERROR - 2012-01-10 00:18:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:20 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:20 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:20 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:20 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:20 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:20 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:20 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:20 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:18:20 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:20 --> Total execution time: 0.1283
DEBUG - 2012-01-10 00:18:21 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:21 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:21 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:21 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:21 --> Router Class Initialized
ERROR - 2012-01-10 00:18:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:22 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:22 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:22 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:18:22 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:22 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:22 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:22 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:22 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:18:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:18:22 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:22 --> Total execution time: 0.1853
DEBUG - 2012-01-10 00:18:22 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:22 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:22 --> Router Class Initialized
ERROR - 2012-01-10 00:18:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:23 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:23 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:23 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:24 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:24 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:24 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:24 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:18:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:18:24 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:24 --> Total execution time: 0.1846
DEBUG - 2012-01-10 00:18:24 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:24 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:24 --> Router Class Initialized
ERROR - 2012-01-10 00:18:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:18:25 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:25 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Router Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Output Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Security Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Input Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:18:25 --> Language Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Loader Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:18:25 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Session Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:18:25 --> Session routines successfully run
DEBUG - 2012-01-10 00:18:25 --> Controller Class Initialized
DEBUG - 2012-01-10 00:18:25 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:18:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:18:25 --> Final output sent to browser
DEBUG - 2012-01-10 00:18:25 --> Total execution time: 0.1875
DEBUG - 2012-01-10 00:18:25 --> Config Class Initialized
DEBUG - 2012-01-10 00:18:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:18:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:18:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:18:26 --> URI Class Initialized
DEBUG - 2012-01-10 00:18:26 --> Router Class Initialized
ERROR - 2012-01-10 00:18:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:34 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:34 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:34 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:34 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:34 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:34 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:34 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:20:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:20:34 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:34 --> Total execution time: 0.1761
DEBUG - 2012-01-10 00:20:35 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:35 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:35 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:35 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:35 --> Router Class Initialized
ERROR - 2012-01-10 00:20:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:36 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:36 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:36 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:20:36 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:36 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:36 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:36 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:36 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:36 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:20:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:20:37 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:37 --> Total execution time: 0.1633
DEBUG - 2012-01-10 00:20:37 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:37 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:37 --> Router Class Initialized
ERROR - 2012-01-10 00:20:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:38 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:38 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:38 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:38 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:38 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:38 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:20:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:20:38 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:38 --> Total execution time: 0.1792
DEBUG - 2012-01-10 00:20:38 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:38 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:38 --> Router Class Initialized
ERROR - 2012-01-10 00:20:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:39 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:39 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:39 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:39 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:39 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:39 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:39 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:20:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:20:39 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:39 --> Total execution time: 0.1799
DEBUG - 2012-01-10 00:20:40 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:40 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:40 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:40 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:40 --> Router Class Initialized
ERROR - 2012-01-10 00:20:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:41 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:41 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:41 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:41 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:41 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:41 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:20:41 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:41 --> Total execution time: 0.1629
DEBUG - 2012-01-10 00:20:41 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:41 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:41 --> Router Class Initialized
ERROR - 2012-01-10 00:20:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:42 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:42 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:42 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:42 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:42 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:42 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:42 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:20:42 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:42 --> Total execution time: 0.1573
DEBUG - 2012-01-10 00:20:42 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:42 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:42 --> Router Class Initialized
ERROR - 2012-01-10 00:20:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:43 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:43 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:43 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:43 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:43 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:43 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:43 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:20:43 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:43 --> Total execution time: 0.1531
DEBUG - 2012-01-10 00:20:44 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:44 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:44 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:44 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:44 --> Router Class Initialized
ERROR - 2012-01-10 00:20:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:20:45 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:45 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Router Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Output Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Security Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Input Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:20:45 --> Language Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Loader Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:20:45 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Session Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:20:45 --> Session routines successfully run
DEBUG - 2012-01-10 00:20:45 --> Controller Class Initialized
DEBUG - 2012-01-10 00:20:45 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:20:45 --> Final output sent to browser
DEBUG - 2012-01-10 00:20:45 --> Total execution time: 0.1390
DEBUG - 2012-01-10 00:20:45 --> Config Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:20:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:20:45 --> URI Class Initialized
DEBUG - 2012-01-10 00:20:45 --> Router Class Initialized
ERROR - 2012-01-10 00:20:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:12 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:12 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:12 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:22:12 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:12 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:12 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:12 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:12 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:22:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:22:12 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:12 --> Total execution time: 0.1997
DEBUG - 2012-01-10 00:22:12 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:12 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:12 --> Router Class Initialized
ERROR - 2012-01-10 00:22:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:14 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:14 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:14 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:14 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:14 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:14 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:14 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:22:14 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:14 --> Total execution time: 0.1614
DEBUG - 2012-01-10 00:22:14 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:14 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:14 --> Router Class Initialized
ERROR - 2012-01-10 00:22:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:15 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:15 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:15 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:15 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:15 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:15 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:15 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:22:15 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:15 --> Total execution time: 0.1611
DEBUG - 2012-01-10 00:22:16 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:16 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:16 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:16 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:16 --> Router Class Initialized
ERROR - 2012-01-10 00:22:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:16 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:17 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:17 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:17 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:17 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:17 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:22:17 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:17 --> Total execution time: 0.1842
DEBUG - 2012-01-10 00:22:17 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:17 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:17 --> Router Class Initialized
ERROR - 2012-01-10 00:22:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:19 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:19 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:19 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:19 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:19 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:19 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:22:19 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:19 --> Total execution time: 0.1616
DEBUG - 2012-01-10 00:22:19 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:19 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:19 --> Router Class Initialized
ERROR - 2012-01-10 00:22:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:20 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:20 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:20 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:20 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:20 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:20 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:20 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:22:20 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:20 --> Total execution time: 0.1561
DEBUG - 2012-01-10 00:22:21 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:21 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:21 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:21 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:21 --> Router Class Initialized
ERROR - 2012-01-10 00:22:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:25 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:25 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:25 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:25 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:25 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:25 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:25 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:25 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 00:22:25 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:25 --> Total execution time: 0.1228
DEBUG - 2012-01-10 00:22:26 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:26 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:26 --> Router Class Initialized
ERROR - 2012-01-10 00:22:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:29 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:29 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:29 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:22:29 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:29 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:29 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:29 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:29 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:22:29 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:22:29 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:29 --> Total execution time: 0.1528
DEBUG - 2012-01-10 00:22:29 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:29 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:29 --> Router Class Initialized
ERROR - 2012-01-10 00:22:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:31 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:31 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:31 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:31 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:31 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:31 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:22:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:22:31 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:31 --> Total execution time: 0.1455
DEBUG - 2012-01-10 00:22:31 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:32 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Router Class Initialized
ERROR - 2012-01-10 00:22:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:32 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:32 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:32 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:32 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:32 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:32 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:22:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:22:32 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:32 --> Total execution time: 0.1858
DEBUG - 2012-01-10 00:22:33 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:33 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:33 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:33 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:33 --> Router Class Initialized
ERROR - 2012-01-10 00:22:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:34 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:34 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:34 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:22:34 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:34 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:34 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:34 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:34 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:22:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:22:34 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:34 --> Total execution time: 0.1660
DEBUG - 2012-01-10 00:22:34 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:34 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:34 --> Router Class Initialized
ERROR - 2012-01-10 00:22:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:35 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:35 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:35 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:35 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:35 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:35 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:22:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:22:35 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:35 --> Total execution time: 0.1801
DEBUG - 2012-01-10 00:22:35 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:35 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:35 --> Router Class Initialized
ERROR - 2012-01-10 00:22:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:36 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:36 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:36 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:36 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:37 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:37 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:37 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:37 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:22:37 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:37 --> Total execution time: 0.1868
DEBUG - 2012-01-10 00:22:37 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:37 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:37 --> Router Class Initialized
ERROR - 2012-01-10 00:22:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:22:38 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:38 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Router Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Output Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Security Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Input Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:22:38 --> Language Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Loader Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:22:38 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Session Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:22:38 --> Session routines successfully run
DEBUG - 2012-01-10 00:22:38 --> Controller Class Initialized
DEBUG - 2012-01-10 00:22:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:22:38 --> Final output sent to browser
DEBUG - 2012-01-10 00:22:38 --> Total execution time: 0.1666
DEBUG - 2012-01-10 00:22:38 --> Config Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:22:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:22:38 --> URI Class Initialized
DEBUG - 2012-01-10 00:22:38 --> Router Class Initialized
ERROR - 2012-01-10 00:22:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:05 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:05 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:05 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:05 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:05 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:05 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:05 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:05 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:05 --> Total execution time: 0.1516
DEBUG - 2012-01-10 00:24:05 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:05 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:05 --> Router Class Initialized
ERROR - 2012-01-10 00:24:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:06 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:06 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:06 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:06 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:06 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:06 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:06 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:06 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:06 --> Total execution time: 0.1505
DEBUG - 2012-01-10 00:24:06 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:06 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:06 --> Router Class Initialized
ERROR - 2012-01-10 00:24:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:08 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:08 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:08 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:08 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:08 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:08 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:08 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:08 --> Total execution time: 0.1369
DEBUG - 2012-01-10 00:24:09 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:09 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Router Class Initialized
ERROR - 2012-01-10 00:24:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:09 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:09 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:09 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:09 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:09 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:09 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:09 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:09 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:09 --> Total execution time: 0.1332
DEBUG - 2012-01-10 00:24:10 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:10 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Router Class Initialized
ERROR - 2012-01-10 00:24:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:10 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:10 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:10 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:11 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:11 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:11 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:11 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:11 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:11 --> Total execution time: 0.1444
DEBUG - 2012-01-10 00:24:11 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:11 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:11 --> Router Class Initialized
ERROR - 2012-01-10 00:24:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:13 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:13 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:13 --> No URI present. Default controller set.
DEBUG - 2012-01-10 00:24:13 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:13 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:13 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:13 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:13 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:24:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:24:13 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:13 --> Total execution time: 0.1570
DEBUG - 2012-01-10 00:24:13 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:13 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:13 --> Router Class Initialized
ERROR - 2012-01-10 00:24:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:15 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:15 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:15 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:15 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:15 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:15 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:15 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:24:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:24:15 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:15 --> Total execution time: 0.1770
DEBUG - 2012-01-10 00:24:16 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:16 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Router Class Initialized
ERROR - 2012-01-10 00:24:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:16 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:16 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:16 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:16 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:16 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:16 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:16 --> Pagination Class Initialized
DEBUG - 2012-01-10 00:24:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 00:24:16 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:16 --> Total execution time: 0.1587
DEBUG - 2012-01-10 00:24:17 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:17 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:17 --> Router Class Initialized
ERROR - 2012-01-10 00:24:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:21 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:21 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:21 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:21 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:21 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:21 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:21 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:21 --> Total execution time: 0.1304
DEBUG - 2012-01-10 00:24:21 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:21 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:21 --> Router Class Initialized
ERROR - 2012-01-10 00:24:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:23 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:23 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:23 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:23 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:23 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:23 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:23 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:23 --> Total execution time: 0.1442
DEBUG - 2012-01-10 00:24:23 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:23 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:23 --> Router Class Initialized
ERROR - 2012-01-10 00:24:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:24 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:24 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:24 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:24 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:24 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:24 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:24 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:24 --> Total execution time: 0.1411
DEBUG - 2012-01-10 00:24:24 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:24 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:24 --> Router Class Initialized
ERROR - 2012-01-10 00:24:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:25 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:25 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:25 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:25 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:25 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:25 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:25 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 00:24:25 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:25 --> Total execution time: 0.1286
DEBUG - 2012-01-10 00:24:26 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:26 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:26 --> Router Class Initialized
ERROR - 2012-01-10 00:24:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 00:24:27 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:27 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Router Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Output Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Security Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Input Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 00:24:27 --> Language Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Loader Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Helper loaded: url_helper
DEBUG - 2012-01-10 00:24:27 --> Database Driver Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Session Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Helper loaded: string_helper
DEBUG - 2012-01-10 00:24:27 --> Session routines successfully run
DEBUG - 2012-01-10 00:24:27 --> Controller Class Initialized
DEBUG - 2012-01-10 00:24:27 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 00:24:27 --> Final output sent to browser
DEBUG - 2012-01-10 00:24:27 --> Total execution time: 0.1328
DEBUG - 2012-01-10 00:24:27 --> Config Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Hooks Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Utf8 Class Initialized
DEBUG - 2012-01-10 00:24:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 00:24:27 --> URI Class Initialized
DEBUG - 2012-01-10 00:24:27 --> Router Class Initialized
ERROR - 2012-01-10 00:24:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:02:11 --> Config Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:02:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:02:11 --> URI Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Router Class Initialized
DEBUG - 2012-01-10 22:02:11 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:02:11 --> Output Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Security Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Input Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:02:11 --> Language Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Loader Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:02:11 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Session Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:02:11 --> A session cookie was not found.
DEBUG - 2012-01-10 22:02:11 --> Session routines successfully run
DEBUG - 2012-01-10 22:02:11 --> Controller Class Initialized
DEBUG - 2012-01-10 22:02:11 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:02:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:02:11 --> Final output sent to browser
DEBUG - 2012-01-10 22:02:11 --> Total execution time: 0.1420
DEBUG - 2012-01-10 22:02:12 --> Config Class Initialized
DEBUG - 2012-01-10 22:02:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:02:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:02:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:02:12 --> URI Class Initialized
DEBUG - 2012-01-10 22:02:12 --> Router Class Initialized
ERROR - 2012-01-10 22:02:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:07 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:07 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:07 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:07 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:07 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:07 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:07 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:08 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:08 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:08 --> Total execution time: 0.1834
DEBUG - 2012-01-10 22:03:08 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:08 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:08 --> Router Class Initialized
ERROR - 2012-01-10 22:03:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:09 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:09 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:09 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:09 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:09 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:09 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:09 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:09 --> Total execution time: 0.2183
DEBUG - 2012-01-10 22:03:09 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:09 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:09 --> Router Class Initialized
ERROR - 2012-01-10 22:03:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:11 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:11 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:11 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:11 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:11 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:11 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:11 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:11 --> Total execution time: 0.1595
DEBUG - 2012-01-10 22:03:11 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:11 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:11 --> Router Class Initialized
ERROR - 2012-01-10 22:03:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:12 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:12 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:12 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:03:12 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:12 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:12 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:12 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:12 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:12 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:12 --> Total execution time: 0.1563
DEBUG - 2012-01-10 22:03:12 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:12 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:12 --> Router Class Initialized
ERROR - 2012-01-10 22:03:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:28 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:28 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:28 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:28 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:28 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:28 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:28 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:28 --> Total execution time: 0.1587
DEBUG - 2012-01-10 22:03:28 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:28 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:28 --> Router Class Initialized
ERROR - 2012-01-10 22:03:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:29 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:29 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:29 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:29 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:29 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:29 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:29 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:29 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:29 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:29 --> Total execution time: 0.1796
DEBUG - 2012-01-10 22:03:30 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:30 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Router Class Initialized
ERROR - 2012-01-10 22:03:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:30 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:30 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:30 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:30 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:30 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:30 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:03:30 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:30 --> Total execution time: 0.1338
DEBUG - 2012-01-10 22:03:30 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:30 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:30 --> Router Class Initialized
ERROR - 2012-01-10 22:03:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:31 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:31 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:31 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:32 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:32 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:32 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:03:32 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:32 --> Total execution time: 0.1432
DEBUG - 2012-01-10 22:03:32 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:32 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:32 --> Router Class Initialized
ERROR - 2012-01-10 22:03:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:33 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:33 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:33 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:33 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:33 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:33 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:03:33 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:33 --> Total execution time: 0.1407
DEBUG - 2012-01-10 22:03:33 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:33 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:33 --> Router Class Initialized
ERROR - 2012-01-10 22:03:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:34 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:34 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:34 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:34 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:34 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:34 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:03:34 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:34 --> Total execution time: 0.1328
DEBUG - 2012-01-10 22:03:34 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:34 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:34 --> Router Class Initialized
ERROR - 2012-01-10 22:03:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:35 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:35 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:35 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:35 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:35 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:35 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:03:35 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:35 --> Total execution time: 0.1526
DEBUG - 2012-01-10 22:03:35 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:35 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:35 --> Router Class Initialized
ERROR - 2012-01-10 22:03:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:37 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:37 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:37 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:03:37 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:37 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:37 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:37 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:37 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:37 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:37 --> Total execution time: 0.1405
DEBUG - 2012-01-10 22:03:37 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:37 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:37 --> Router Class Initialized
ERROR - 2012-01-10 22:03:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:38 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:38 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:38 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:38 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:38 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:38 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:38 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:38 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:03:38 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:38 --> Total execution time: 0.1779
DEBUG - 2012-01-10 22:03:39 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:39 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:39 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:39 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:39 --> Router Class Initialized
ERROR - 2012-01-10 22:03:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:41 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:41 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:41 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:03:41 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:41 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:41 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:41 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:41 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:41 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:41 --> Total execution time: 0.1381
DEBUG - 2012-01-10 22:03:41 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:41 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:41 --> Router Class Initialized
ERROR - 2012-01-10 22:03:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:45 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:45 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:45 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:45 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:45 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:45 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:45 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:45 --> Total execution time: 0.1416
DEBUG - 2012-01-10 22:03:45 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:45 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:45 --> Router Class Initialized
ERROR - 2012-01-10 22:03:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:03:46 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:46 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Router Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Output Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Security Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Input Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:03:46 --> Language Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Loader Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:03:46 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Session Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:03:46 --> Session routines successfully run
DEBUG - 2012-01-10 22:03:46 --> Controller Class Initialized
DEBUG - 2012-01-10 22:03:46 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:03:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:03:46 --> Final output sent to browser
DEBUG - 2012-01-10 22:03:46 --> Total execution time: 0.2005
DEBUG - 2012-01-10 22:03:47 --> Config Class Initialized
DEBUG - 2012-01-10 22:03:47 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:03:47 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:03:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:03:47 --> URI Class Initialized
DEBUG - 2012-01-10 22:03:47 --> Router Class Initialized
ERROR - 2012-01-10 22:03:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:04:18 --> Config Class Initialized
DEBUG - 2012-01-10 22:04:18 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:04:18 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:04:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:04:18 --> URI Class Initialized
DEBUG - 2012-01-10 22:04:18 --> Router Class Initialized
DEBUG - 2012-01-10 22:04:18 --> Output Class Initialized
DEBUG - 2012-01-10 22:04:18 --> Security Class Initialized
DEBUG - 2012-01-10 22:04:18 --> Input Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:04:19 --> Language Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Loader Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:04:19 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Session Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:04:19 --> Session routines successfully run
DEBUG - 2012-01-10 22:04:19 --> Controller Class Initialized
DEBUG - 2012-01-10 22:04:19 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 22:04:19 --> Final output sent to browser
DEBUG - 2012-01-10 22:04:19 --> Total execution time: 0.3651
DEBUG - 2012-01-10 22:04:19 --> Config Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:04:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:04:19 --> URI Class Initialized
DEBUG - 2012-01-10 22:04:19 --> Router Class Initialized
ERROR - 2012-01-10 22:04:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:10:56 --> Config Class Initialized
DEBUG - 2012-01-10 22:10:56 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:10:56 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:10:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:10:56 --> URI Class Initialized
DEBUG - 2012-01-10 22:10:56 --> Router Class Initialized
DEBUG - 2012-01-10 22:10:57 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:10:57 --> Output Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Security Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Input Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:10:57 --> Language Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Loader Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:10:57 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Session Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:10:57 --> Session routines successfully run
DEBUG - 2012-01-10 22:10:57 --> Controller Class Initialized
DEBUG - 2012-01-10 22:10:57 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:10:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:10:57 --> Final output sent to browser
DEBUG - 2012-01-10 22:10:57 --> Total execution time: 1.0238
DEBUG - 2012-01-10 22:10:58 --> Config Class Initialized
DEBUG - 2012-01-10 22:10:58 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:10:58 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:10:58 --> URI Class Initialized
DEBUG - 2012-01-10 22:10:58 --> Router Class Initialized
ERROR - 2012-01-10 22:10:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:10:59 --> Config Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:10:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:10:59 --> URI Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Router Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Output Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Security Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Input Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:10:59 --> Language Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Loader Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:10:59 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Session Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:10:59 --> Session routines successfully run
DEBUG - 2012-01-10 22:10:59 --> Controller Class Initialized
DEBUG - 2012-01-10 22:10:59 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:10:59 --> Final output sent to browser
DEBUG - 2012-01-10 22:10:59 --> Total execution time: 0.3565
DEBUG - 2012-01-10 22:10:59 --> Config Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:10:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:11:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:11:00 --> URI Class Initialized
DEBUG - 2012-01-10 22:11:00 --> Router Class Initialized
ERROR - 2012-01-10 22:11:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:11:07 --> Config Class Initialized
DEBUG - 2012-01-10 22:11:07 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:11:07 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:11:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:11:07 --> URI Class Initialized
DEBUG - 2012-01-10 22:11:07 --> Router Class Initialized
DEBUG - 2012-01-10 22:11:07 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:11:08 --> Output Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Security Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Input Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:11:08 --> Language Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Loader Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:11:08 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Session Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:11:08 --> Session routines successfully run
DEBUG - 2012-01-10 22:11:08 --> Controller Class Initialized
DEBUG - 2012-01-10 22:11:08 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:11:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:11:08 --> Final output sent to browser
DEBUG - 2012-01-10 22:11:08 --> Total execution time: 0.5739
DEBUG - 2012-01-10 22:11:09 --> Config Class Initialized
DEBUG - 2012-01-10 22:11:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:11:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:11:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:11:09 --> URI Class Initialized
DEBUG - 2012-01-10 22:11:09 --> Router Class Initialized
ERROR - 2012-01-10 22:11:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 22:11:17 --> Config Class Initialized
DEBUG - 2012-01-10 22:11:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:11:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:11:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:11:17 --> URI Class Initialized
DEBUG - 2012-01-10 22:11:17 --> Router Class Initialized
DEBUG - 2012-01-10 22:11:17 --> Output Class Initialized
DEBUG - 2012-01-10 22:11:17 --> Security Class Initialized
DEBUG - 2012-01-10 22:11:18 --> Input Class Initialized
DEBUG - 2012-01-10 22:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:11:18 --> Language Class Initialized
DEBUG - 2012-01-10 22:11:18 --> Loader Class Initialized
DEBUG - 2012-01-10 22:11:18 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:11:18 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:11:18 --> Session Class Initialized
DEBUG - 2012-01-10 22:11:18 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:11:18 --> A session cookie was not found.
DEBUG - 2012-01-10 22:11:18 --> Session routines successfully run
DEBUG - 2012-01-10 22:11:18 --> Controller Class Initialized
DEBUG - 2012-01-10 22:11:18 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 22:11:18 --> Final output sent to browser
DEBUG - 2012-01-10 22:11:18 --> Total execution time: 0.4269
DEBUG - 2012-01-10 22:11:20 --> Config Class Initialized
DEBUG - 2012-01-10 22:11:20 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:11:20 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:11:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:11:20 --> URI Class Initialized
DEBUG - 2012-01-10 22:11:20 --> Router Class Initialized
DEBUG - 2012-01-10 22:11:20 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:11:20 --> Output Class Initialized
DEBUG - 2012-01-10 22:11:20 --> Security Class Initialized
DEBUG - 2012-01-10 22:11:20 --> Input Class Initialized
DEBUG - 2012-01-10 22:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:11:20 --> Language Class Initialized
DEBUG - 2012-01-10 22:11:21 --> Loader Class Initialized
DEBUG - 2012-01-10 22:11:21 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:11:21 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:11:21 --> Session Class Initialized
DEBUG - 2012-01-10 22:11:21 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:11:21 --> Session routines successfully run
DEBUG - 2012-01-10 22:11:21 --> Controller Class Initialized
DEBUG - 2012-01-10 22:11:21 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:11:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:11:21 --> Final output sent to browser
DEBUG - 2012-01-10 22:11:21 --> Total execution time: 0.4234
DEBUG - 2012-01-10 22:11:23 --> Config Class Initialized
DEBUG - 2012-01-10 22:11:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:11:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:11:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:11:23 --> URI Class Initialized
DEBUG - 2012-01-10 22:11:23 --> Router Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Output Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Security Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Input Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:11:24 --> Language Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Loader Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:11:24 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Session Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:11:24 --> Session routines successfully run
DEBUG - 2012-01-10 22:11:24 --> Controller Class Initialized
DEBUG - 2012-01-10 22:11:24 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:11:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:11:24 --> Final output sent to browser
DEBUG - 2012-01-10 22:11:24 --> Total execution time: 0.9718
DEBUG - 2012-01-10 22:11:26 --> Config Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:11:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:11:26 --> URI Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Router Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Output Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Security Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Input Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:11:26 --> Language Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Loader Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:11:26 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Session Class Initialized
DEBUG - 2012-01-10 22:11:26 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:11:26 --> Session routines successfully run
DEBUG - 2012-01-10 22:11:26 --> Controller Class Initialized
DEBUG - 2012-01-10 22:11:26 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:11:26 --> Final output sent to browser
DEBUG - 2012-01-10 22:11:26 --> Total execution time: 0.5377
DEBUG - 2012-01-10 22:15:59 --> Config Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:15:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:15:59 --> URI Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Router Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Output Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Security Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Input Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:15:59 --> Language Class Initialized
DEBUG - 2012-01-10 22:15:59 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:01 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:01 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:01 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:01 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:01 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:01 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:01 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:16:01 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:01 --> Total execution time: 2.7403
DEBUG - 2012-01-10 22:16:07 --> Config Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:16:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:16:07 --> URI Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Router Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Output Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Security Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Input Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:16:07 --> Language Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:07 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:07 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:08 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:08 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:08 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:16:08 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:08 --> Total execution time: 0.4073
DEBUG - 2012-01-10 22:16:09 --> Config Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:16:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:16:09 --> URI Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Router Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Output Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Security Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Input Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:16:09 --> Language Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:09 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:10 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:10 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:10 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:10 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:10 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:10 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:16:10 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:10 --> Total execution time: 0.4584
DEBUG - 2012-01-10 22:16:12 --> Config Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:16:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:16:12 --> URI Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Router Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Output Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Security Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Input Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:16:12 --> Language Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:12 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:13 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:13 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:13 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:13 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:13 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:13 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:16:13 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:13 --> Total execution time: 0.7729
DEBUG - 2012-01-10 22:16:15 --> Config Class Initialized
DEBUG - 2012-01-10 22:16:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:16:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:16:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:16:16 --> URI Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Router Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Output Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Security Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Input Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:16:16 --> Language Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:16 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:16 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:16 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:16 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:16:16 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:16 --> Total execution time: 0.4730
DEBUG - 2012-01-10 22:16:18 --> Config Class Initialized
DEBUG - 2012-01-10 22:16:18 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:16:18 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:16:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:16:18 --> URI Class Initialized
DEBUG - 2012-01-10 22:16:18 --> Router Class Initialized
DEBUG - 2012-01-10 22:16:18 --> Output Class Initialized
DEBUG - 2012-01-10 22:16:18 --> Security Class Initialized
DEBUG - 2012-01-10 22:16:18 --> Input Class Initialized
DEBUG - 2012-01-10 22:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:16:18 --> Language Class Initialized
DEBUG - 2012-01-10 22:16:19 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:19 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:19 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:19 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:19 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:19 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:19 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:16:19 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:19 --> Total execution time: 0.8326
DEBUG - 2012-01-10 22:16:23 --> Config Class Initialized
DEBUG - 2012-01-10 22:16:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:16:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:16:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:16:23 --> URI Class Initialized
DEBUG - 2012-01-10 22:16:23 --> Router Class Initialized
DEBUG - 2012-01-10 22:16:23 --> No URI present. Default controller set.
DEBUG - 2012-01-10 22:16:24 --> Output Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Security Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Input Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:16:24 --> Language Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:24 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:24 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:24 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:24 --> Pagination Class Initialized
DEBUG - 2012-01-10 22:16:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 22:16:24 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:24 --> Total execution time: 1.0578
DEBUG - 2012-01-10 22:16:26 --> Config Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:16:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:16:26 --> URI Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Router Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Output Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Security Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Input Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:16:26 --> Language Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Loader Class Initialized
DEBUG - 2012-01-10 22:16:26 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:16:27 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:16:27 --> Session Class Initialized
DEBUG - 2012-01-10 22:16:27 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:16:27 --> Session routines successfully run
DEBUG - 2012-01-10 22:16:27 --> Controller Class Initialized
DEBUG - 2012-01-10 22:16:27 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:16:27 --> Final output sent to browser
DEBUG - 2012-01-10 22:16:27 --> Total execution time: 0.5020
DEBUG - 2012-01-10 22:17:02 --> Config Class Initialized
DEBUG - 2012-01-10 22:17:02 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:17:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:17:03 --> URI Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Router Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Output Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Security Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Input Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:17:03 --> Language Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Loader Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:17:03 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Session Class Initialized
DEBUG - 2012-01-10 22:17:03 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:17:03 --> Session routines successfully run
DEBUG - 2012-01-10 22:17:03 --> Controller Class Initialized
DEBUG - 2012-01-10 22:17:03 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:17:03 --> Final output sent to browser
DEBUG - 2012-01-10 22:17:03 --> Total execution time: 1.1356
DEBUG - 2012-01-10 22:17:34 --> Config Class Initialized
DEBUG - 2012-01-10 22:17:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:17:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:17:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:17:34 --> URI Class Initialized
DEBUG - 2012-01-10 22:17:34 --> Router Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Output Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Security Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Input Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:17:35 --> Language Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Loader Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:17:35 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Session Class Initialized
DEBUG - 2012-01-10 22:17:35 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:17:35 --> Session routines successfully run
DEBUG - 2012-01-10 22:17:35 --> Controller Class Initialized
DEBUG - 2012-01-10 22:17:35 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:17:35 --> Final output sent to browser
DEBUG - 2012-01-10 22:17:35 --> Total execution time: 1.9670
DEBUG - 2012-01-10 22:18:16 --> Config Class Initialized
DEBUG - 2012-01-10 22:18:16 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:18:16 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:18:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:18:16 --> URI Class Initialized
DEBUG - 2012-01-10 22:18:16 --> Router Class Initialized
DEBUG - 2012-01-10 22:18:16 --> Output Class Initialized
DEBUG - 2012-01-10 22:18:16 --> Security Class Initialized
DEBUG - 2012-01-10 22:18:17 --> Input Class Initialized
DEBUG - 2012-01-10 22:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:18:17 --> Language Class Initialized
DEBUG - 2012-01-10 22:18:17 --> Loader Class Initialized
DEBUG - 2012-01-10 22:18:17 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:18:17 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:18:17 --> Session Class Initialized
DEBUG - 2012-01-10 22:18:17 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:18:17 --> Session routines successfully run
DEBUG - 2012-01-10 22:18:17 --> Controller Class Initialized
DEBUG - 2012-01-10 22:18:17 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:18:17 --> Final output sent to browser
DEBUG - 2012-01-10 22:18:17 --> Total execution time: 0.4574
DEBUG - 2012-01-10 22:18:43 --> Config Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:18:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:18:43 --> URI Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Router Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Output Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Security Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Input Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:18:43 --> Language Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Loader Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:18:43 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Session Class Initialized
DEBUG - 2012-01-10 22:18:43 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:18:43 --> Session routines successfully run
DEBUG - 2012-01-10 22:18:43 --> Controller Class Initialized
DEBUG - 2012-01-10 22:18:43 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:18:43 --> Final output sent to browser
DEBUG - 2012-01-10 22:18:43 --> Total execution time: 0.4516
DEBUG - 2012-01-10 22:19:23 --> Config Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:19:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:19:23 --> URI Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Router Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Output Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Security Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Input Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:19:23 --> Language Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Loader Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:19:23 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Session Class Initialized
DEBUG - 2012-01-10 22:19:23 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:19:23 --> Session routines successfully run
DEBUG - 2012-01-10 22:19:23 --> Controller Class Initialized
DEBUG - 2012-01-10 22:19:24 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:19:24 --> Final output sent to browser
DEBUG - 2012-01-10 22:19:24 --> Total execution time: 0.4011
DEBUG - 2012-01-10 22:19:35 --> Config Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:19:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:19:35 --> URI Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Router Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Output Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Security Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Input Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:19:35 --> Language Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Loader Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:19:35 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Session Class Initialized
DEBUG - 2012-01-10 22:19:35 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:19:35 --> Session routines successfully run
DEBUG - 2012-01-10 22:19:35 --> Controller Class Initialized
DEBUG - 2012-01-10 22:19:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:19:35 --> Final output sent to browser
DEBUG - 2012-01-10 22:19:35 --> Total execution time: 0.4972
DEBUG - 2012-01-10 22:19:37 --> Config Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:19:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:19:37 --> URI Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Router Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Output Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Security Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Input Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:19:37 --> Language Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Loader Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:19:37 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Session Class Initialized
DEBUG - 2012-01-10 22:19:37 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:19:37 --> Session routines successfully run
DEBUG - 2012-01-10 22:19:37 --> Controller Class Initialized
DEBUG - 2012-01-10 22:19:37 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:19:37 --> Final output sent to browser
DEBUG - 2012-01-10 22:19:37 --> Total execution time: 0.4633
DEBUG - 2012-01-10 22:19:39 --> Config Class Initialized
DEBUG - 2012-01-10 22:19:39 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:19:39 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:19:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:19:39 --> URI Class Initialized
DEBUG - 2012-01-10 22:19:39 --> Router Class Initialized
DEBUG - 2012-01-10 22:19:39 --> Output Class Initialized
DEBUG - 2012-01-10 22:19:39 --> Security Class Initialized
DEBUG - 2012-01-10 22:19:39 --> Input Class Initialized
DEBUG - 2012-01-10 22:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:19:40 --> Language Class Initialized
DEBUG - 2012-01-10 22:19:40 --> Loader Class Initialized
DEBUG - 2012-01-10 22:19:40 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:19:40 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:19:40 --> Session Class Initialized
DEBUG - 2012-01-10 22:19:40 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:19:40 --> Session routines successfully run
DEBUG - 2012-01-10 22:19:40 --> Controller Class Initialized
DEBUG - 2012-01-10 22:19:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:19:40 --> Final output sent to browser
DEBUG - 2012-01-10 22:19:40 --> Total execution time: 0.5623
DEBUG - 2012-01-10 22:19:41 --> Config Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:19:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:19:41 --> URI Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Router Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Output Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Security Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Input Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:19:41 --> Language Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Loader Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:19:41 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Session Class Initialized
DEBUG - 2012-01-10 22:19:41 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:19:41 --> Session routines successfully run
DEBUG - 2012-01-10 22:19:42 --> Controller Class Initialized
DEBUG - 2012-01-10 22:19:42 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:19:42 --> Final output sent to browser
DEBUG - 2012-01-10 22:19:42 --> Total execution time: 0.4683
DEBUG - 2012-01-10 22:19:43 --> Config Class Initialized
DEBUG - 2012-01-10 22:19:43 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:19:43 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:19:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:19:43 --> URI Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Router Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Output Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Security Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Input Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:19:44 --> Language Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Loader Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:19:44 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Session Class Initialized
DEBUG - 2012-01-10 22:19:44 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:19:44 --> Session routines successfully run
DEBUG - 2012-01-10 22:19:44 --> Controller Class Initialized
DEBUG - 2012-01-10 22:19:44 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:19:44 --> Final output sent to browser
DEBUG - 2012-01-10 22:19:44 --> Total execution time: 0.4927
DEBUG - 2012-01-10 22:19:45 --> Config Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:19:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:19:45 --> URI Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Router Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Output Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Security Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Input Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:19:45 --> Language Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Loader Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:19:45 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Session Class Initialized
DEBUG - 2012-01-10 22:19:45 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:19:45 --> Session routines successfully run
DEBUG - 2012-01-10 22:19:45 --> Controller Class Initialized
DEBUG - 2012-01-10 22:19:45 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:19:45 --> Final output sent to browser
DEBUG - 2012-01-10 22:19:45 --> Total execution time: 0.5226
DEBUG - 2012-01-10 22:20:23 --> Config Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:20:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:20:23 --> URI Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Router Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Output Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Security Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Input Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:20:23 --> Language Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Loader Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:20:23 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Session Class Initialized
DEBUG - 2012-01-10 22:20:23 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:20:23 --> Session routines successfully run
DEBUG - 2012-01-10 22:20:23 --> Controller Class Initialized
DEBUG - 2012-01-10 22:20:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:20:23 --> Final output sent to browser
DEBUG - 2012-01-10 22:20:23 --> Total execution time: 0.4716
DEBUG - 2012-01-10 22:20:24 --> Config Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:20:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:20:24 --> URI Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Router Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Output Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Security Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Input Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:20:24 --> Language Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Loader Class Initialized
DEBUG - 2012-01-10 22:20:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:20:24 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:20:25 --> Session Class Initialized
DEBUG - 2012-01-10 22:20:25 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:20:25 --> Session routines successfully run
DEBUG - 2012-01-10 22:20:25 --> Controller Class Initialized
DEBUG - 2012-01-10 22:20:25 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:20:25 --> Final output sent to browser
DEBUG - 2012-01-10 22:20:25 --> Total execution time: 0.4457
DEBUG - 2012-01-10 22:23:16 --> Config Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:23:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:23:16 --> URI Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Router Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Output Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Security Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Input Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:23:16 --> Language Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Loader Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:23:16 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Session Class Initialized
DEBUG - 2012-01-10 22:23:16 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:23:16 --> Session routines successfully run
DEBUG - 2012-01-10 22:23:16 --> Controller Class Initialized
DEBUG - 2012-01-10 22:23:16 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:23:16 --> Final output sent to browser
DEBUG - 2012-01-10 22:23:16 --> Total execution time: 0.4738
DEBUG - 2012-01-10 22:24:03 --> Config Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:24:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:24:03 --> URI Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Router Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Output Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Security Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Input Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:24:03 --> Language Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Loader Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:24:03 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Session Class Initialized
DEBUG - 2012-01-10 22:24:03 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:24:03 --> Session routines successfully run
DEBUG - 2012-01-10 22:24:03 --> Controller Class Initialized
DEBUG - 2012-01-10 22:24:03 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:24:03 --> Final output sent to browser
DEBUG - 2012-01-10 22:24:03 --> Total execution time: 0.4197
DEBUG - 2012-01-10 22:27:37 --> Config Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:27:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:27:37 --> URI Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Router Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Output Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Security Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Input Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:27:37 --> Language Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Loader Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:27:37 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Session Class Initialized
DEBUG - 2012-01-10 22:27:37 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:27:37 --> Session routines successfully run
DEBUG - 2012-01-10 22:27:37 --> Controller Class Initialized
DEBUG - 2012-01-10 22:27:37 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:27:37 --> Final output sent to browser
DEBUG - 2012-01-10 22:27:37 --> Total execution time: 1.4073
DEBUG - 2012-01-10 22:27:56 --> Config Class Initialized
DEBUG - 2012-01-10 22:27:56 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:27:56 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:27:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:27:57 --> URI Class Initialized
DEBUG - 2012-01-10 22:27:57 --> Router Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Output Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Security Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Input Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:27:58 --> Language Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Loader Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:27:58 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Session Class Initialized
DEBUG - 2012-01-10 22:27:58 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:27:58 --> Session routines successfully run
DEBUG - 2012-01-10 22:27:58 --> Controller Class Initialized
DEBUG - 2012-01-10 22:27:58 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:27:58 --> Final output sent to browser
DEBUG - 2012-01-10 22:27:58 --> Total execution time: 1.7671
DEBUG - 2012-01-10 22:29:55 --> Config Class Initialized
DEBUG - 2012-01-10 22:29:55 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:29:55 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:29:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:29:55 --> URI Class Initialized
DEBUG - 2012-01-10 22:29:55 --> Router Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Output Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Security Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Input Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:29:56 --> Language Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Loader Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:29:56 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Session Class Initialized
DEBUG - 2012-01-10 22:29:56 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:29:56 --> Session routines successfully run
DEBUG - 2012-01-10 22:29:56 --> Controller Class Initialized
DEBUG - 2012-01-10 22:29:56 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:29:56 --> Final output sent to browser
DEBUG - 2012-01-10 22:29:56 --> Total execution time: 0.4768
DEBUG - 2012-01-10 22:30:09 --> Config Class Initialized
DEBUG - 2012-01-10 22:30:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:30:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:30:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:30:09 --> URI Class Initialized
DEBUG - 2012-01-10 22:30:09 --> Router Class Initialized
DEBUG - 2012-01-10 22:30:10 --> Output Class Initialized
DEBUG - 2012-01-10 22:30:11 --> Security Class Initialized
DEBUG - 2012-01-10 22:30:11 --> Input Class Initialized
DEBUG - 2012-01-10 22:30:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:30:11 --> Language Class Initialized
DEBUG - 2012-01-10 22:30:11 --> Loader Class Initialized
DEBUG - 2012-01-10 22:30:11 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:30:11 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:30:11 --> Session Class Initialized
DEBUG - 2012-01-10 22:30:11 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:30:11 --> Session routines successfully run
DEBUG - 2012-01-10 22:30:11 --> Controller Class Initialized
DEBUG - 2012-01-10 22:30:11 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:30:11 --> Final output sent to browser
DEBUG - 2012-01-10 22:30:11 --> Total execution time: 1.9337
DEBUG - 2012-01-10 22:30:51 --> Config Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:30:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:30:51 --> URI Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Router Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Output Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Security Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Input Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:30:51 --> Language Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Loader Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:30:51 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Session Class Initialized
DEBUG - 2012-01-10 22:30:51 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:30:51 --> Session routines successfully run
DEBUG - 2012-01-10 22:30:51 --> Controller Class Initialized
DEBUG - 2012-01-10 22:30:51 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:30:51 --> Final output sent to browser
DEBUG - 2012-01-10 22:30:52 --> Total execution time: 0.3865
DEBUG - 2012-01-10 22:31:47 --> Config Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:31:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:31:47 --> URI Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Router Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Output Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Security Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Input Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:31:47 --> Language Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Loader Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:31:47 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Session Class Initialized
DEBUG - 2012-01-10 22:31:47 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:31:47 --> Session routines successfully run
DEBUG - 2012-01-10 22:31:47 --> Controller Class Initialized
DEBUG - 2012-01-10 22:31:48 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:31:48 --> Final output sent to browser
DEBUG - 2012-01-10 22:31:48 --> Total execution time: 0.5013
DEBUG - 2012-01-10 22:33:10 --> Config Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:33:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:33:10 --> URI Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Router Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Output Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Security Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Input Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:33:10 --> Language Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Loader Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:33:10 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Session Class Initialized
DEBUG - 2012-01-10 22:33:10 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:33:10 --> Session routines successfully run
DEBUG - 2012-01-10 22:33:10 --> Controller Class Initialized
DEBUG - 2012-01-10 22:33:10 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:33:10 --> Final output sent to browser
DEBUG - 2012-01-10 22:33:10 --> Total execution time: 0.6900
DEBUG - 2012-01-10 22:33:11 --> Config Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:33:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:33:11 --> URI Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Router Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Output Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Security Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Input Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:33:11 --> Language Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Loader Class Initialized
DEBUG - 2012-01-10 22:33:11 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:33:12 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:33:12 --> Session Class Initialized
DEBUG - 2012-01-10 22:33:12 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:33:12 --> Session routines successfully run
DEBUG - 2012-01-10 22:33:12 --> Controller Class Initialized
DEBUG - 2012-01-10 22:33:12 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 22:33:12 --> Final output sent to browser
DEBUG - 2012-01-10 22:33:12 --> Total execution time: 0.4686
DEBUG - 2012-01-10 22:33:13 --> Config Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:33:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:33:13 --> URI Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Router Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Output Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Security Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Input Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:33:13 --> Language Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Loader Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:33:13 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Session Class Initialized
DEBUG - 2012-01-10 22:33:13 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:33:13 --> Session routines successfully run
DEBUG - 2012-01-10 22:33:13 --> Controller Class Initialized
DEBUG - 2012-01-10 22:33:13 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:33:13 --> Final output sent to browser
DEBUG - 2012-01-10 22:33:13 --> Total execution time: 0.5158
DEBUG - 2012-01-10 22:35:26 --> Config Class Initialized
DEBUG - 2012-01-10 22:35:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:35:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:35:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:35:26 --> URI Class Initialized
DEBUG - 2012-01-10 22:35:26 --> Router Class Initialized
DEBUG - 2012-01-10 22:35:26 --> Output Class Initialized
DEBUG - 2012-01-10 22:35:26 --> Security Class Initialized
DEBUG - 2012-01-10 22:35:26 --> Input Class Initialized
DEBUG - 2012-01-10 22:35:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:35:27 --> Language Class Initialized
DEBUG - 2012-01-10 22:35:27 --> Loader Class Initialized
DEBUG - 2012-01-10 22:35:27 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:35:27 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:35:27 --> Session Class Initialized
DEBUG - 2012-01-10 22:35:27 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:35:27 --> Session routines successfully run
DEBUG - 2012-01-10 22:35:27 --> Controller Class Initialized
DEBUG - 2012-01-10 22:35:27 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:35:27 --> Final output sent to browser
DEBUG - 2012-01-10 22:35:27 --> Total execution time: 0.4805
DEBUG - 2012-01-10 22:35:30 --> Config Class Initialized
DEBUG - 2012-01-10 22:35:30 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:35:30 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:35:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:35:30 --> URI Class Initialized
DEBUG - 2012-01-10 22:35:30 --> Router Class Initialized
ERROR - 2012-01-10 22:35:30 --> 404 Page Not Found --> comments
DEBUG - 2012-01-10 22:45:59 --> Config Class Initialized
DEBUG - 2012-01-10 22:45:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:45:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:45:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:45:59 --> URI Class Initialized
DEBUG - 2012-01-10 22:45:59 --> Router Class Initialized
DEBUG - 2012-01-10 22:45:59 --> Output Class Initialized
DEBUG - 2012-01-10 22:45:59 --> Security Class Initialized
DEBUG - 2012-01-10 22:45:59 --> Input Class Initialized
DEBUG - 2012-01-10 22:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:45:59 --> Language Class Initialized
DEBUG - 2012-01-10 22:46:00 --> Loader Class Initialized
DEBUG - 2012-01-10 22:46:00 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:46:00 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:46:00 --> Session Class Initialized
DEBUG - 2012-01-10 22:46:00 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:46:00 --> Session routines successfully run
DEBUG - 2012-01-10 22:46:00 --> Controller Class Initialized
DEBUG - 2012-01-10 22:46:00 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:46:00 --> Final output sent to browser
DEBUG - 2012-01-10 22:46:00 --> Total execution time: 0.5389
DEBUG - 2012-01-10 22:46:02 --> Config Class Initialized
DEBUG - 2012-01-10 22:46:02 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:46:02 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:46:02 --> URI Class Initialized
DEBUG - 2012-01-10 22:46:02 --> Router Class Initialized
ERROR - 2012-01-10 22:46:02 --> 404 Page Not Found --> comments
DEBUG - 2012-01-10 22:47:59 --> Config Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:47:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:47:59 --> URI Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Router Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Output Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Security Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Input Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:47:59 --> Language Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Loader Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:47:59 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:47:59 --> Session Class Initialized
DEBUG - 2012-01-10 22:48:00 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:48:00 --> Session routines successfully run
DEBUG - 2012-01-10 22:48:00 --> Controller Class Initialized
DEBUG - 2012-01-10 22:48:00 --> Final output sent to browser
DEBUG - 2012-01-10 22:48:00 --> Total execution time: 0.6835
DEBUG - 2012-01-10 22:49:44 --> Config Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:49:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:49:44 --> URI Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Router Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Output Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Security Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Input Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:49:44 --> Language Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Loader Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:49:44 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Session Class Initialized
DEBUG - 2012-01-10 22:49:44 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:49:44 --> Session routines successfully run
DEBUG - 2012-01-10 22:49:44 --> Controller Class Initialized
ERROR - 2012-01-10 22:49:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at A:\home\codeigniter.blog\www\application\controllers\user\comments.php:8) A:\home\codeigniter.blog\www\system\helpers\url_helper.php 546
DEBUG - 2012-01-10 22:50:01 --> Config Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:50:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:50:01 --> URI Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Router Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Output Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Security Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Input Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:50:01 --> Language Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Loader Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:50:01 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Session Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:50:01 --> Session routines successfully run
DEBUG - 2012-01-10 22:50:01 --> Controller Class Initialized
DEBUG - 2012-01-10 22:50:01 --> Config Class Initialized
DEBUG - 2012-01-10 22:50:02 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:50:02 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:50:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:50:02 --> URI Class Initialized
DEBUG - 2012-01-10 22:50:02 --> Router Class Initialized
ERROR - 2012-01-10 22:50:02 --> 404 Page Not Found --> articel
DEBUG - 2012-01-10 22:50:11 --> Config Class Initialized
DEBUG - 2012-01-10 22:50:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:50:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:50:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:50:12 --> URI Class Initialized
DEBUG - 2012-01-10 22:50:12 --> Router Class Initialized
ERROR - 2012-01-10 22:50:12 --> 404 Page Not Found --> articel
DEBUG - 2012-01-10 22:50:27 --> Config Class Initialized
DEBUG - 2012-01-10 22:50:27 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:50:27 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:50:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:50:27 --> URI Class Initialized
DEBUG - 2012-01-10 22:50:27 --> Router Class Initialized
ERROR - 2012-01-10 22:50:27 --> 404 Page Not Found --> articel
DEBUG - 2012-01-10 22:50:31 --> Config Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:50:31 --> URI Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Router Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Output Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Security Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Input Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:50:31 --> Language Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Loader Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:50:31 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Session Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:50:31 --> Session routines successfully run
DEBUG - 2012-01-10 22:50:31 --> Controller Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Config Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:50:31 --> URI Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Router Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Output Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Security Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Input Class Initialized
DEBUG - 2012-01-10 22:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:50:32 --> Language Class Initialized
DEBUG - 2012-01-10 22:50:32 --> Loader Class Initialized
DEBUG - 2012-01-10 22:50:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:50:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:50:32 --> Session Class Initialized
DEBUG - 2012-01-10 22:50:32 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:50:32 --> Session routines successfully run
DEBUG - 2012-01-10 22:50:32 --> Controller Class Initialized
DEBUG - 2012-01-10 22:50:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:50:32 --> Final output sent to browser
DEBUG - 2012-01-10 22:50:32 --> Total execution time: 0.4851
DEBUG - 2012-01-10 22:55:26 --> Config Class Initialized
DEBUG - 2012-01-10 22:55:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:55:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:55:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:55:27 --> URI Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Router Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Output Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Security Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Input Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:55:27 --> Language Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Loader Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:55:27 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Session Class Initialized
DEBUG - 2012-01-10 22:55:27 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:55:27 --> Session routines successfully run
DEBUG - 2012-01-10 22:55:27 --> Controller Class Initialized
DEBUG - 2012-01-10 22:55:27 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 22:55:27 --> Final output sent to browser
DEBUG - 2012-01-10 22:55:27 --> Total execution time: 0.4461
DEBUG - 2012-01-10 22:55:33 --> Config Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Hooks Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Utf8 Class Initialized
DEBUG - 2012-01-10 22:55:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 22:55:33 --> URI Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Router Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Output Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Security Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Input Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 22:55:33 --> Language Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Loader Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Helper loaded: url_helper
DEBUG - 2012-01-10 22:55:33 --> Database Driver Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Session Class Initialized
DEBUG - 2012-01-10 22:55:33 --> Helper loaded: string_helper
DEBUG - 2012-01-10 22:55:33 --> Session routines successfully run
DEBUG - 2012-01-10 22:55:33 --> Controller Class Initialized
DEBUG - 2012-01-10 22:55:33 --> DB Transaction Failure
ERROR - 2012-01-10 22:55:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`codeigniter.blog`.`comments`, CONSTRAINT `fk_comments_articles` FOREIGN KEY (`id_article`) REFERENCES `articles` (`id_article`) ON DELETE CASCADE ON UPDATE CASCADE)
DEBUG - 2012-01-10 22:55:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-10 23:00:57 --> Config Class Initialized
DEBUG - 2012-01-10 23:00:57 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:00:57 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:00:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:00:57 --> URI Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Router Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Output Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Security Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Input Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:00:58 --> Language Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Loader Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:00:58 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Session Class Initialized
DEBUG - 2012-01-10 23:00:58 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:00:58 --> Session routines successfully run
DEBUG - 2012-01-10 23:00:58 --> Controller Class Initialized
DEBUG - 2012-01-10 23:00:58 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:00:58 --> Final output sent to browser
DEBUG - 2012-01-10 23:00:58 --> Total execution time: 0.5176
DEBUG - 2012-01-10 23:01:01 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:01 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:01 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:01 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:01 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:01 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:02 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:02 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:02 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:02 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:02 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:02 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:02 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:01:02 --> Final output sent to browser
DEBUG - 2012-01-10 23:01:02 --> Total execution time: 0.4020
DEBUG - 2012-01-10 23:01:22 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:22 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:22 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:22 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:23 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:23 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:23 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:23 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:23 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:23 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:23 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:23 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:23 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:23 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:01:23 --> Final output sent to browser
DEBUG - 2012-01-10 23:01:23 --> Total execution time: 0.3827
DEBUG - 2012-01-10 23:01:29 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:29 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:29 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:29 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:29 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:29 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:29 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:29 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:01:29 --> Final output sent to browser
DEBUG - 2012-01-10 23:01:29 --> Total execution time: 0.5023
DEBUG - 2012-01-10 23:01:32 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:32 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:32 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:32 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:32 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:32 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:01:32 --> Final output sent to browser
DEBUG - 2012-01-10 23:01:32 --> Total execution time: 0.5236
DEBUG - 2012-01-10 23:01:40 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:40 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:40 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:40 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:40 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:41 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:41 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:41 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:41 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:41 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:01:41 --> Final output sent to browser
DEBUG - 2012-01-10 23:01:41 --> Total execution time: 0.5550
DEBUG - 2012-01-10 23:01:42 --> Config Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:01:42 --> URI Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Router Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Output Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Security Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Input Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:01:42 --> Language Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Loader Class Initialized
DEBUG - 2012-01-10 23:01:42 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:01:43 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:01:43 --> Session Class Initialized
DEBUG - 2012-01-10 23:01:43 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:01:43 --> Session routines successfully run
DEBUG - 2012-01-10 23:01:43 --> Controller Class Initialized
DEBUG - 2012-01-10 23:01:43 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:01:43 --> Final output sent to browser
DEBUG - 2012-01-10 23:01:43 --> Total execution time: 0.5672
DEBUG - 2012-01-10 23:03:06 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:06 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:06 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:03:06 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:06 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:06 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:06 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:07 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:07 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:07 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:07 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:07 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:03:07 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:03:07 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:07 --> Total execution time: 0.4490
DEBUG - 2012-01-10 23:03:08 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:08 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:08 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:03:08 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:08 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:08 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:08 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:08 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:08 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:08 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:08 --> Controller Class Initialized
ERROR - 2012-01-10 23:03:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:08 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:03:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:03:08 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:08 --> Total execution time: 0.6811
DEBUG - 2012-01-10 23:03:09 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:09 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:09 --> Router Class Initialized
ERROR - 2012-01-10 23:03:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:10 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:10 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:10 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:10 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:10 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:10 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:10 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:10 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:03:10 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:10 --> Total execution time: 0.4370
DEBUG - 2012-01-10 23:03:10 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:11 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:11 --> Router Class Initialized
ERROR - 2012-01-10 23:03:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:12 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:12 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:12 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:12 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:12 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:12 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:13 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:13 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:13 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:13 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:03:13 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:13 --> Total execution time: 0.4214
DEBUG - 2012-01-10 23:03:13 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:13 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:13 --> Router Class Initialized
ERROR - 2012-01-10 23:03:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:14 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:14 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:14 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:14 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:14 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:14 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:14 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:14 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:03:14 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:14 --> Total execution time: 0.4565
DEBUG - 2012-01-10 23:03:15 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:15 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:15 --> Router Class Initialized
ERROR - 2012-01-10 23:03:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:17 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:17 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:17 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:17 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:17 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:17 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:03:17 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:17 --> Total execution time: 0.4383
DEBUG - 2012-01-10 23:03:17 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:17 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:17 --> Router Class Initialized
ERROR - 2012-01-10 23:03:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:19 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:19 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:19 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:19 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:19 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:19 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:03:19 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:19 --> Total execution time: 0.4200
DEBUG - 2012-01-10 23:03:19 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:19 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:19 --> Router Class Initialized
ERROR - 2012-01-10 23:03:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:36 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:36 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:36 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:36 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:36 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:36 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:36 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:36 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:36 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:36 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:36 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:36 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:37 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:03:37 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:37 --> Total execution time: 0.4344
DEBUG - 2012-01-10 23:03:37 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:37 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:37 --> Router Class Initialized
ERROR - 2012-01-10 23:03:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:03:50 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:50 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Router Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Output Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Security Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Input Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:03:50 --> Language Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Loader Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:03:50 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Session Class Initialized
DEBUG - 2012-01-10 23:03:50 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:03:50 --> Session routines successfully run
DEBUG - 2012-01-10 23:03:50 --> Controller Class Initialized
DEBUG - 2012-01-10 23:03:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:03:50 --> Final output sent to browser
DEBUG - 2012-01-10 23:03:50 --> Total execution time: 0.3443
DEBUG - 2012-01-10 23:03:51 --> Config Class Initialized
DEBUG - 2012-01-10 23:03:51 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:03:51 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:03:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:03:51 --> URI Class Initialized
DEBUG - 2012-01-10 23:03:51 --> Router Class Initialized
ERROR - 2012-01-10 23:03:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:04:28 --> Config Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:04:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:04:28 --> URI Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Router Class Initialized
DEBUG - 2012-01-10 23:04:28 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:04:28 --> Output Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Security Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Input Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:04:28 --> Language Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Loader Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:04:28 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Session Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:04:28 --> Session routines successfully run
DEBUG - 2012-01-10 23:04:28 --> Controller Class Initialized
DEBUG - 2012-01-10 23:04:28 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:04:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:04:28 --> Final output sent to browser
DEBUG - 2012-01-10 23:04:28 --> Total execution time: 0.3735
DEBUG - 2012-01-10 23:04:29 --> Config Class Initialized
DEBUG - 2012-01-10 23:04:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:04:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:04:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:04:29 --> URI Class Initialized
DEBUG - 2012-01-10 23:04:29 --> Router Class Initialized
ERROR - 2012-01-10 23:04:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:04:44 --> Config Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:04:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:04:44 --> URI Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Router Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Output Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Security Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Input Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:04:44 --> Language Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Loader Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:04:44 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Session Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:04:44 --> Session routines successfully run
DEBUG - 2012-01-10 23:04:44 --> Controller Class Initialized
DEBUG - 2012-01-10 23:04:44 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:04:44 --> Final output sent to browser
DEBUG - 2012-01-10 23:04:44 --> Total execution time: 0.3375
DEBUG - 2012-01-10 23:04:44 --> Config Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:04:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:04:44 --> URI Class Initialized
DEBUG - 2012-01-10 23:04:44 --> Router Class Initialized
ERROR - 2012-01-10 23:04:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:05:11 --> Config Class Initialized
DEBUG - 2012-01-10 23:05:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:05:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:05:12 --> URI Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Router Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Output Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Security Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Input Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:05:12 --> Language Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Loader Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:05:12 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Session Class Initialized
DEBUG - 2012-01-10 23:05:12 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:05:12 --> Session routines successfully run
DEBUG - 2012-01-10 23:05:12 --> Controller Class Initialized
DEBUG - 2012-01-10 23:05:12 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:05:12 --> Final output sent to browser
DEBUG - 2012-01-10 23:05:12 --> Total execution time: 0.4929
DEBUG - 2012-01-10 23:05:14 --> Config Class Initialized
DEBUG - 2012-01-10 23:05:14 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:05:14 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:05:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:05:14 --> URI Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Router Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Output Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Security Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Input Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:05:15 --> Language Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Loader Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:05:15 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Session Class Initialized
DEBUG - 2012-01-10 23:05:15 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:05:15 --> Session routines successfully run
DEBUG - 2012-01-10 23:05:15 --> Controller Class Initialized
DEBUG - 2012-01-10 23:05:15 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:05:15 --> Final output sent to browser
DEBUG - 2012-01-10 23:05:15 --> Total execution time: 0.4368
DEBUG - 2012-01-10 23:05:17 --> Config Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:05:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:05:17 --> URI Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Router Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Output Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Security Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Input Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:05:17 --> Language Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Loader Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:05:17 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Session Class Initialized
DEBUG - 2012-01-10 23:05:17 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:05:17 --> Session routines successfully run
DEBUG - 2012-01-10 23:05:17 --> Controller Class Initialized
DEBUG - 2012-01-10 23:05:17 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:05:17 --> Final output sent to browser
DEBUG - 2012-01-10 23:05:17 --> Total execution time: 0.4047
DEBUG - 2012-01-10 23:05:29 --> Config Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:05:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:05:29 --> URI Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Router Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Output Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Security Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Input Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:05:29 --> Language Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Loader Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:05:29 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Session Class Initialized
DEBUG - 2012-01-10 23:05:29 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:05:29 --> Session routines successfully run
DEBUG - 2012-01-10 23:05:29 --> Controller Class Initialized
DEBUG - 2012-01-10 23:05:29 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:05:29 --> Final output sent to browser
DEBUG - 2012-01-10 23:05:29 --> Total execution time: 0.4586
DEBUG - 2012-01-10 23:06:17 --> Config Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:06:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:06:17 --> URI Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Router Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Output Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Security Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Input Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:06:17 --> Language Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Loader Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:06:17 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Session Class Initialized
DEBUG - 2012-01-10 23:06:17 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:06:17 --> Session routines successfully run
DEBUG - 2012-01-10 23:06:17 --> Controller Class Initialized
DEBUG - 2012-01-10 23:06:17 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:06:17 --> Final output sent to browser
DEBUG - 2012-01-10 23:06:17 --> Total execution time: 1.3683
DEBUG - 2012-01-10 23:06:31 --> Config Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:06:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:06:31 --> URI Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Router Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Output Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Security Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Input Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:06:31 --> Language Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Loader Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:06:31 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Session Class Initialized
DEBUG - 2012-01-10 23:06:31 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:06:31 --> Session routines successfully run
DEBUG - 2012-01-10 23:06:31 --> Controller Class Initialized
DEBUG - 2012-01-10 23:06:31 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:06:31 --> Final output sent to browser
DEBUG - 2012-01-10 23:06:31 --> Total execution time: 0.2153
DEBUG - 2012-01-10 23:07:52 --> Config Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:07:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:07:52 --> URI Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Router Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Output Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Security Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Input Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:07:52 --> Language Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Loader Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:07:52 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Session Class Initialized
DEBUG - 2012-01-10 23:07:52 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:07:52 --> Session routines successfully run
DEBUG - 2012-01-10 23:07:52 --> Controller Class Initialized
DEBUG - 2012-01-10 23:07:52 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:07:52 --> Final output sent to browser
DEBUG - 2012-01-10 23:07:52 --> Total execution time: 0.3902
DEBUG - 2012-01-10 23:08:01 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:02 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:02 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:02 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:02 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:02 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:02 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:02 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:08:02 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:02 --> Total execution time: 0.3984
DEBUG - 2012-01-10 23:08:05 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:05 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:05 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:08:05 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:05 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:05 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:05 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:05 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:05 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:08:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:08:05 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:05 --> Total execution time: 0.3912
DEBUG - 2012-01-10 23:08:07 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:07 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:07 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:07 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:07 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:08 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:08 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:08 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:08 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:08 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:08:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:08:08 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:08 --> Total execution time: 0.7811
DEBUG - 2012-01-10 23:08:09 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:09 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:10 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:10 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:10 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:10 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:10 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:08:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:08:10 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:10 --> Total execution time: 0.4520
DEBUG - 2012-01-10 23:08:23 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:23 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:23 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:23 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:23 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:23 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:23 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:08:23 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:23 --> Total execution time: 0.3422
DEBUG - 2012-01-10 23:08:24 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:24 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:24 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:24 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:24 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:24 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:24 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:08:24 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:24 --> Total execution time: 0.3308
DEBUG - 2012-01-10 23:08:25 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:25 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:25 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:25 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:25 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:25 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:25 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:08:25 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:25 --> Total execution time: 0.3678
DEBUG - 2012-01-10 23:08:26 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:26 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:26 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:26 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:27 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:27 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:27 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:27 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:27 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:27 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:08:27 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:27 --> Total execution time: 0.3802
DEBUG - 2012-01-10 23:08:28 --> Config Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:08:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:08:28 --> URI Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Router Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Output Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Security Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Input Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:08:28 --> Language Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Loader Class Initialized
DEBUG - 2012-01-10 23:08:28 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:08:29 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:08:29 --> Session Class Initialized
DEBUG - 2012-01-10 23:08:29 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:08:29 --> Session routines successfully run
DEBUG - 2012-01-10 23:08:29 --> Controller Class Initialized
DEBUG - 2012-01-10 23:08:29 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:08:29 --> Final output sent to browser
DEBUG - 2012-01-10 23:08:29 --> Total execution time: 0.8686
DEBUG - 2012-01-10 23:10:56 --> Config Class Initialized
DEBUG - 2012-01-10 23:10:56 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:10:56 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:10:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:10:56 --> URI Class Initialized
DEBUG - 2012-01-10 23:10:56 --> Router Class Initialized
DEBUG - 2012-01-10 23:10:56 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:10:56 --> Output Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Security Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Input Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:10:57 --> Language Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Loader Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:10:57 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Session Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:10:57 --> Session routines successfully run
DEBUG - 2012-01-10 23:10:57 --> Controller Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:10:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:10:57 --> Final output sent to browser
DEBUG - 2012-01-10 23:10:57 --> Total execution time: 0.4610
DEBUG - 2012-01-10 23:10:57 --> Config Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:10:57 --> URI Class Initialized
DEBUG - 2012-01-10 23:10:57 --> Router Class Initialized
ERROR - 2012-01-10 23:10:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:10:59 --> Config Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:10:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:10:59 --> URI Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Router Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Output Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Security Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Input Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:10:59 --> Language Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Loader Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:10:59 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Session Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:10:59 --> Session routines successfully run
DEBUG - 2012-01-10 23:10:59 --> Controller Class Initialized
DEBUG - 2012-01-10 23:10:59 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:10:59 --> Final output sent to browser
DEBUG - 2012-01-10 23:10:59 --> Total execution time: 0.3969
DEBUG - 2012-01-10 23:10:59 --> Config Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:10:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:10:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:10:59 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:00 --> Router Class Initialized
ERROR - 2012-01-10 23:11:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:02 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:02 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:03 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:03 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:03 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:03 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:03 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:03 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:11:03 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:03 --> Total execution time: 0.3823
DEBUG - 2012-01-10 23:11:03 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:03 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:03 --> Router Class Initialized
ERROR - 2012-01-10 23:11:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:04 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:04 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:04 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:04 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:04 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:04 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:04 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:04 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:11:05 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:05 --> Total execution time: 0.4085
DEBUG - 2012-01-10 23:11:05 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:05 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:05 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:05 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:05 --> Router Class Initialized
ERROR - 2012-01-10 23:11:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:07 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:07 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:07 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:07 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:08 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:08 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:08 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:08 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:08 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:11:08 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:08 --> Total execution time: 0.7761
DEBUG - 2012-01-10 23:11:09 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:09 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:09 --> Router Class Initialized
ERROR - 2012-01-10 23:11:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:09 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:09 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:09 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:09 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:10 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:10 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:10 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:10 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:10 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:11:10 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:10 --> Total execution time: 0.4144
DEBUG - 2012-01-10 23:11:10 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:10 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:10 --> Router Class Initialized
ERROR - 2012-01-10 23:11:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:11 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:11 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:11 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:11 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:11 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:11 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:11 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:12 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:12 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:12 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:12 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:12 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:12 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:12 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:12 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:11:12 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:12 --> Total execution time: 0.3988
DEBUG - 2012-01-10 23:11:12 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:12 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:12 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:12 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:12 --> Router Class Initialized
ERROR - 2012-01-10 23:11:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:13 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:13 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:13 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:13 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:13 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:14 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:14 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:14 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:14 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:14 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:11:14 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:14 --> Total execution time: 0.9243
DEBUG - 2012-01-10 23:11:14 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:14 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:14 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:14 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:14 --> Router Class Initialized
ERROR - 2012-01-10 23:11:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:32 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:32 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:32 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:32 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:32 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:32 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:11:32 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:32 --> Total execution time: 0.3546
DEBUG - 2012-01-10 23:11:33 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:33 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:33 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:33 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:33 --> Router Class Initialized
ERROR - 2012-01-10 23:11:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:11:59 --> Config Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:11:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:11:59 --> URI Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Router Class Initialized
DEBUG - 2012-01-10 23:11:59 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:11:59 --> Output Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Security Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Input Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:11:59 --> Language Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Loader Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:11:59 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Session Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:11:59 --> Session routines successfully run
DEBUG - 2012-01-10 23:11:59 --> Controller Class Initialized
DEBUG - 2012-01-10 23:11:59 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:11:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:11:59 --> Final output sent to browser
DEBUG - 2012-01-10 23:11:59 --> Total execution time: 0.4330
DEBUG - 2012-01-10 23:12:00 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:00 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:00 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:00 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:00 --> Router Class Initialized
ERROR - 2012-01-10 23:12:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:12:01 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:01 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Router Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Output Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Security Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Input Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:12:01 --> Language Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Loader Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:12:01 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:12:01 --> Session Class Initialized
DEBUG - 2012-01-10 23:12:02 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:12:02 --> Session routines successfully run
DEBUG - 2012-01-10 23:12:02 --> Controller Class Initialized
DEBUG - 2012-01-10 23:12:02 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:12:02 --> Final output sent to browser
DEBUG - 2012-01-10 23:12:02 --> Total execution time: 0.3391
DEBUG - 2012-01-10 23:12:02 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:02 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:02 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:02 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:02 --> Router Class Initialized
ERROR - 2012-01-10 23:12:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:12:03 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:03 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Router Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Output Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Security Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Input Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:12:03 --> Language Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Loader Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:12:03 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Session Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:12:03 --> Session routines successfully run
DEBUG - 2012-01-10 23:12:03 --> Controller Class Initialized
DEBUG - 2012-01-10 23:12:03 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:12:03 --> Final output sent to browser
DEBUG - 2012-01-10 23:12:03 --> Total execution time: 0.4237
DEBUG - 2012-01-10 23:12:03 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:03 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:03 --> Router Class Initialized
ERROR - 2012-01-10 23:12:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:12:05 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:05 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:05 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:05 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:05 --> Router Class Initialized
DEBUG - 2012-01-10 23:12:05 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:12:05 --> Output Class Initialized
DEBUG - 2012-01-10 23:12:05 --> Security Class Initialized
DEBUG - 2012-01-10 23:12:05 --> Input Class Initialized
DEBUG - 2012-01-10 23:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:12:05 --> Language Class Initialized
DEBUG - 2012-01-10 23:12:05 --> Loader Class Initialized
DEBUG - 2012-01-10 23:12:06 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:12:06 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:12:06 --> Session Class Initialized
DEBUG - 2012-01-10 23:12:06 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:12:06 --> Session routines successfully run
DEBUG - 2012-01-10 23:12:06 --> Controller Class Initialized
DEBUG - 2012-01-10 23:12:06 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:12:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:12:06 --> Final output sent to browser
DEBUG - 2012-01-10 23:12:06 --> Total execution time: 0.3840
DEBUG - 2012-01-10 23:12:06 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:06 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:06 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:06 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:06 --> Router Class Initialized
ERROR - 2012-01-10 23:12:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:12:15 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:15 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Router Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Output Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Security Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Input Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:12:15 --> Language Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Loader Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:12:15 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Session Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:12:15 --> Session routines successfully run
DEBUG - 2012-01-10 23:12:15 --> Controller Class Initialized
DEBUG - 2012-01-10 23:12:15 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:12:15 --> Final output sent to browser
DEBUG - 2012-01-10 23:12:15 --> Total execution time: 0.3602
DEBUG - 2012-01-10 23:12:15 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:15 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:15 --> Router Class Initialized
ERROR - 2012-01-10 23:12:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-10 23:12:22 --> Config Class Initialized
DEBUG - 2012-01-10 23:12:22 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:12:22 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:12:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:12:22 --> URI Class Initialized
DEBUG - 2012-01-10 23:12:22 --> Router Class Initialized
DEBUG - 2012-01-10 23:12:22 --> Output Class Initialized
DEBUG - 2012-01-10 23:12:23 --> Security Class Initialized
DEBUG - 2012-01-10 23:12:23 --> Input Class Initialized
DEBUG - 2012-01-10 23:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:12:23 --> Language Class Initialized
DEBUG - 2012-01-10 23:12:23 --> Loader Class Initialized
DEBUG - 2012-01-10 23:12:23 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:12:23 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:12:23 --> Session Class Initialized
DEBUG - 2012-01-10 23:12:23 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:12:23 --> Session routines successfully run
DEBUG - 2012-01-10 23:12:23 --> Controller Class Initialized
DEBUG - 2012-01-10 23:12:23 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:12:23 --> Final output sent to browser
DEBUG - 2012-01-10 23:12:23 --> Total execution time: 0.3728
DEBUG - 2012-01-10 23:16:09 --> Config Class Initialized
DEBUG - 2012-01-10 23:16:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:16:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:16:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:16:09 --> URI Class Initialized
DEBUG - 2012-01-10 23:16:09 --> Router Class Initialized
DEBUG - 2012-01-10 23:16:09 --> Output Class Initialized
DEBUG - 2012-01-10 23:16:09 --> Security Class Initialized
DEBUG - 2012-01-10 23:16:10 --> Input Class Initialized
DEBUG - 2012-01-10 23:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:16:10 --> Language Class Initialized
DEBUG - 2012-01-10 23:16:10 --> Loader Class Initialized
DEBUG - 2012-01-10 23:16:10 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:16:10 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:16:10 --> Session Class Initialized
DEBUG - 2012-01-10 23:16:10 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:16:10 --> Session routines successfully run
DEBUG - 2012-01-10 23:16:10 --> Controller Class Initialized
DEBUG - 2012-01-10 23:16:10 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:16:10 --> Final output sent to browser
DEBUG - 2012-01-10 23:16:10 --> Total execution time: 0.4614
DEBUG - 2012-01-10 23:16:13 --> Config Class Initialized
DEBUG - 2012-01-10 23:16:13 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:16:13 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:16:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:16:13 --> URI Class Initialized
DEBUG - 2012-01-10 23:16:13 --> Router Class Initialized
DEBUG - 2012-01-10 23:16:13 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:16:13 --> Output Class Initialized
DEBUG - 2012-01-10 23:16:13 --> Security Class Initialized
DEBUG - 2012-01-10 23:16:13 --> Input Class Initialized
DEBUG - 2012-01-10 23:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:16:14 --> Language Class Initialized
DEBUG - 2012-01-10 23:16:14 --> Loader Class Initialized
DEBUG - 2012-01-10 23:16:14 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:16:14 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:16:14 --> Session Class Initialized
DEBUG - 2012-01-10 23:16:14 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:16:14 --> Session routines successfully run
DEBUG - 2012-01-10 23:16:14 --> Controller Class Initialized
DEBUG - 2012-01-10 23:16:14 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:16:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:16:14 --> Final output sent to browser
DEBUG - 2012-01-10 23:16:14 --> Total execution time: 0.5394
DEBUG - 2012-01-10 23:16:43 --> Config Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:16:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:16:43 --> URI Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Router Class Initialized
DEBUG - 2012-01-10 23:16:43 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:16:43 --> Output Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Security Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Input Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:16:43 --> Language Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Loader Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:16:43 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Session Class Initialized
DEBUG - 2012-01-10 23:16:43 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:16:44 --> Session routines successfully run
DEBUG - 2012-01-10 23:16:44 --> Controller Class Initialized
DEBUG - 2012-01-10 23:16:44 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:16:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:16:44 --> Final output sent to browser
DEBUG - 2012-01-10 23:16:44 --> Total execution time: 0.4933
DEBUG - 2012-01-10 23:17:05 --> Config Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:17:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:17:05 --> URI Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Router Class Initialized
DEBUG - 2012-01-10 23:17:05 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:17:05 --> Output Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Security Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Input Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:17:05 --> Language Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Loader Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:17:05 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Session Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:17:05 --> Session routines successfully run
DEBUG - 2012-01-10 23:17:05 --> Controller Class Initialized
DEBUG - 2012-01-10 23:17:05 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:17:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:17:05 --> Final output sent to browser
DEBUG - 2012-01-10 23:17:05 --> Total execution time: 0.2542
DEBUG - 2012-01-10 23:17:09 --> Config Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:17:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:17:09 --> URI Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Router Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Output Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Security Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Input Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:17:09 --> Language Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Loader Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:17:09 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Session Class Initialized
DEBUG - 2012-01-10 23:17:09 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:17:09 --> Session routines successfully run
DEBUG - 2012-01-10 23:17:09 --> Controller Class Initialized
DEBUG - 2012-01-10 23:17:09 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:17:09 --> Final output sent to browser
DEBUG - 2012-01-10 23:17:09 --> Total execution time: 0.2696
DEBUG - 2012-01-10 23:17:11 --> Config Class Initialized
DEBUG - 2012-01-10 23:17:11 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:17:11 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:17:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:17:11 --> URI Class Initialized
DEBUG - 2012-01-10 23:17:11 --> Router Class Initialized
DEBUG - 2012-01-10 23:17:11 --> Output Class Initialized
DEBUG - 2012-01-10 23:17:12 --> Security Class Initialized
DEBUG - 2012-01-10 23:17:12 --> Input Class Initialized
DEBUG - 2012-01-10 23:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:17:12 --> Language Class Initialized
DEBUG - 2012-01-10 23:17:12 --> Loader Class Initialized
DEBUG - 2012-01-10 23:17:12 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:17:12 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:17:12 --> Session Class Initialized
DEBUG - 2012-01-10 23:17:12 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:17:12 --> Session routines successfully run
DEBUG - 2012-01-10 23:17:12 --> Controller Class Initialized
DEBUG - 2012-01-10 23:17:12 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:17:12 --> Final output sent to browser
DEBUG - 2012-01-10 23:17:12 --> Total execution time: 0.1996
DEBUG - 2012-01-10 23:17:21 --> Config Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:17:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:17:21 --> URI Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Router Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Output Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Security Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Input Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:17:21 --> Language Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Loader Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:17:21 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Session Class Initialized
DEBUG - 2012-01-10 23:17:21 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:17:21 --> Session routines successfully run
DEBUG - 2012-01-10 23:17:21 --> Controller Class Initialized
DEBUG - 2012-01-10 23:17:21 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:17:21 --> Final output sent to browser
DEBUG - 2012-01-10 23:17:21 --> Total execution time: 0.2179
DEBUG - 2012-01-10 23:18:28 --> Config Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:18:28 --> URI Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Router Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Output Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Security Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Input Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:18:28 --> Language Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Loader Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:18:28 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Session Class Initialized
DEBUG - 2012-01-10 23:18:28 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:18:28 --> Session routines successfully run
DEBUG - 2012-01-10 23:18:28 --> Controller Class Initialized
DEBUG - 2012-01-10 23:18:28 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:18:28 --> Final output sent to browser
DEBUG - 2012-01-10 23:18:28 --> Total execution time: 0.4241
DEBUG - 2012-01-10 23:18:34 --> Config Class Initialized
DEBUG - 2012-01-10 23:18:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:18:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:18:34 --> URI Class Initialized
DEBUG - 2012-01-10 23:18:34 --> Router Class Initialized
DEBUG - 2012-01-10 23:18:34 --> Output Class Initialized
DEBUG - 2012-01-10 23:18:34 --> Security Class Initialized
DEBUG - 2012-01-10 23:18:34 --> Input Class Initialized
DEBUG - 2012-01-10 23:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:18:35 --> Language Class Initialized
DEBUG - 2012-01-10 23:18:35 --> Loader Class Initialized
DEBUG - 2012-01-10 23:18:35 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:18:35 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:18:35 --> Session Class Initialized
DEBUG - 2012-01-10 23:18:35 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:18:35 --> Session routines successfully run
DEBUG - 2012-01-10 23:18:35 --> Controller Class Initialized
DEBUG - 2012-01-10 23:18:35 --> DB Transaction Failure
ERROR - 2012-01-10 23:18:35 --> Query error: Unknown column 'user' in 'where clause'
DEBUG - 2012-01-10 23:18:35 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-10 23:19:32 --> Config Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:19:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:19:32 --> URI Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Router Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Output Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Security Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Input Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:19:32 --> Language Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Loader Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:19:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Session Class Initialized
DEBUG - 2012-01-10 23:19:32 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:19:32 --> Session routines successfully run
DEBUG - 2012-01-10 23:19:32 --> Controller Class Initialized
DEBUG - 2012-01-10 23:19:32 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:19:32 --> Final output sent to browser
DEBUG - 2012-01-10 23:19:32 --> Total execution time: 0.4368
DEBUG - 2012-01-10 23:19:38 --> Config Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:19:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:19:38 --> URI Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Router Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Output Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Security Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Input Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:19:38 --> Language Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Loader Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:19:38 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Session Class Initialized
DEBUG - 2012-01-10 23:19:38 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:19:38 --> Session routines successfully run
DEBUG - 2012-01-10 23:19:38 --> Controller Class Initialized
DEBUG - 2012-01-10 23:19:38 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:19:38 --> Final output sent to browser
DEBUG - 2012-01-10 23:19:38 --> Total execution time: 0.4554
DEBUG - 2012-01-10 23:20:03 --> Config Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:20:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:20:03 --> URI Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Router Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Output Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Security Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Input Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:20:03 --> Language Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Loader Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:20:03 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Session Class Initialized
DEBUG - 2012-01-10 23:20:03 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:20:03 --> Session routines successfully run
DEBUG - 2012-01-10 23:20:03 --> Controller Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Config Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:20:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:20:04 --> URI Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Router Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Output Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Security Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Input Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:20:04 --> Language Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Loader Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:20:04 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Session Class Initialized
DEBUG - 2012-01-10 23:20:04 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:20:04 --> Session routines successfully run
DEBUG - 2012-01-10 23:20:04 --> Controller Class Initialized
ERROR - 2012-01-10 23:20:04 --> Severity: Notice  --> Undefined property: Home::$pagination A:\home\codeigniter.blog\www\application\controllers\admin\home.php 9
DEBUG - 2012-01-10 23:21:31 --> Config Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:21:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:21:31 --> URI Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Router Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Output Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Security Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Input Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:21:31 --> Language Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Loader Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:21:31 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Session Class Initialized
DEBUG - 2012-01-10 23:21:31 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:21:31 --> Session routines successfully run
DEBUG - 2012-01-10 23:21:31 --> Controller Class Initialized
ERROR - 2012-01-10 23:21:31 --> Severity: Notice  --> Undefined property: Home::$pagination A:\home\codeigniter.blog\www\application\controllers\admin\home.php 12
DEBUG - 2012-01-10 23:23:32 --> Config Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:23:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:23:32 --> URI Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Router Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Output Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Security Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Input Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:23:32 --> Language Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Loader Class Initialized
DEBUG - 2012-01-10 23:23:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:23:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:23:33 --> Session Class Initialized
DEBUG - 2012-01-10 23:23:33 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:23:33 --> Session routines successfully run
DEBUG - 2012-01-10 23:23:33 --> Controller Class Initialized
ERROR - 2012-01-10 23:23:33 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\admin\home.php 28
ERROR - 2012-01-10 23:23:33 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\admin\home.php 28
ERROR - 2012-01-10 23:23:33 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\admin\home.php 28
ERROR - 2012-01-10 23:23:33 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\admin\home.php 28
ERROR - 2012-01-10 23:23:33 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\admin\home.php 28
ERROR - 2012-01-10 23:23:33 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\admin\home.php 28
ERROR - 2012-01-10 23:23:33 --> Severity: Notice  --> Undefined variable: pages A:\home\codeigniter.blog\www\application\views\admin\home.php 33
DEBUG - 2012-01-10 23:23:33 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:23:33 --> Final output sent to browser
DEBUG - 2012-01-10 23:23:33 --> Total execution time: 1.2151
DEBUG - 2012-01-10 23:25:47 --> Config Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:25:47 --> URI Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Router Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Output Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Security Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Input Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:25:47 --> Language Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Loader Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:25:47 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Session Class Initialized
DEBUG - 2012-01-10 23:25:47 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:25:47 --> Session routines successfully run
DEBUG - 2012-01-10 23:25:47 --> Controller Class Initialized
ERROR - 2012-01-10 23:25:47 --> Severity: Notice  --> Undefined variable: id A:\home\codeigniter.blog\www\application\controllers\admin\home.php 13
DEBUG - 2012-01-10 23:25:47 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:25:47 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:25:47 --> Final output sent to browser
DEBUG - 2012-01-10 23:25:47 --> Total execution time: 0.4523
DEBUG - 2012-01-10 23:26:04 --> Config Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:26:04 --> URI Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Router Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Output Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Security Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Input Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:26:04 --> Language Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Loader Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:26:04 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Session Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:26:04 --> Session routines successfully run
DEBUG - 2012-01-10 23:26:04 --> Controller Class Initialized
DEBUG - 2012-01-10 23:26:04 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:26:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:26:04 --> Final output sent to browser
DEBUG - 2012-01-10 23:26:04 --> Total execution time: 0.4702
DEBUG - 2012-01-10 23:26:07 --> Config Class Initialized
DEBUG - 2012-01-10 23:26:07 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:26:07 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:26:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:26:07 --> URI Class Initialized
DEBUG - 2012-01-10 23:26:07 --> Router Class Initialized
ERROR - 2012-01-10 23:26:07 --> 404 Page Not Found --> admin/2
DEBUG - 2012-01-10 23:27:40 --> Config Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:27:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:27:40 --> URI Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Router Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Output Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Security Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Input Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:27:40 --> Language Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Loader Class Initialized
DEBUG - 2012-01-10 23:27:40 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:27:40 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:27:41 --> Session Class Initialized
DEBUG - 2012-01-10 23:27:41 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:27:41 --> Session routines successfully run
DEBUG - 2012-01-10 23:27:41 --> Controller Class Initialized
DEBUG - 2012-01-10 23:27:41 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:27:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:27:41 --> Final output sent to browser
DEBUG - 2012-01-10 23:27:41 --> Total execution time: 0.4266
DEBUG - 2012-01-10 23:27:49 --> Config Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:27:49 --> URI Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Router Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Output Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Security Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Input Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:27:49 --> Language Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Loader Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:27:49 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Session Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:27:49 --> Session routines successfully run
DEBUG - 2012-01-10 23:27:49 --> Controller Class Initialized
DEBUG - 2012-01-10 23:27:49 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:27:49 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:27:49 --> Final output sent to browser
DEBUG - 2012-01-10 23:27:49 --> Total execution time: 0.3711
DEBUG - 2012-01-10 23:27:55 --> Config Class Initialized
DEBUG - 2012-01-10 23:27:55 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:27:55 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:27:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:27:55 --> URI Class Initialized
DEBUG - 2012-01-10 23:27:55 --> Router Class Initialized
ERROR - 2012-01-10 23:27:55 --> 404 Page Not Found --> auth
DEBUG - 2012-01-10 23:28:18 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:18 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:18 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:18 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:18 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:18 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:18 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:18 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:18 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:18 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:18 --> A session cookie was not found.
DEBUG - 2012-01-10 23:28:18 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:18 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:18 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:28:18 --> Final output sent to browser
DEBUG - 2012-01-10 23:28:18 --> Total execution time: 0.1481
DEBUG - 2012-01-10 23:28:25 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:25 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:25 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:25 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:26 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:26 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:26 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:26 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:26 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:26 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:26 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:28:26 --> Final output sent to browser
DEBUG - 2012-01-10 23:28:26 --> Total execution time: 0.1891
DEBUG - 2012-01-10 23:28:30 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:30 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:30 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:30 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:30 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:30 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:30 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:30 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:30 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:30 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:30 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:30 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:30 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-10 23:28:30 --> Final output sent to browser
DEBUG - 2012-01-10 23:28:30 --> Total execution time: 0.1547
DEBUG - 2012-01-10 23:28:37 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:37 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:37 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:37 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:37 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:37 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:37 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:37 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:37 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:37 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:37 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:37 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:28:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:28:37 --> Final output sent to browser
DEBUG - 2012-01-10 23:28:37 --> Total execution time: 0.2169
DEBUG - 2012-01-10 23:28:41 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:41 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:41 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:41 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:41 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:41 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:41 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:28:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:28:41 --> Final output sent to browser
DEBUG - 2012-01-10 23:28:41 --> Total execution time: 0.1586
DEBUG - 2012-01-10 23:28:43 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:43 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:43 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:43 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:43 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:43 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:43 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:28:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:28:43 --> Final output sent to browser
DEBUG - 2012-01-10 23:28:43 --> Total execution time: 0.2057
DEBUG - 2012-01-10 23:28:45 --> Config Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:28:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:28:45 --> URI Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Router Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Output Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Security Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Input Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:28:45 --> Language Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Loader Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:28:45 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Session Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:28:45 --> Session routines successfully run
DEBUG - 2012-01-10 23:28:45 --> Controller Class Initialized
DEBUG - 2012-01-10 23:28:45 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:28:45 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:28:45 --> Final output sent to browser
DEBUG - 2012-01-10 23:28:45 --> Total execution time: 0.2133
DEBUG - 2012-01-10 23:29:34 --> Config Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:29:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:29:34 --> URI Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Router Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Output Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Security Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Input Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:29:34 --> Language Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Loader Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:29:34 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Session Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:29:34 --> Session routines successfully run
DEBUG - 2012-01-10 23:29:34 --> Controller Class Initialized
DEBUG - 2012-01-10 23:29:34 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:29:35 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:29:35 --> Final output sent to browser
DEBUG - 2012-01-10 23:29:35 --> Total execution time: 0.4964
DEBUG - 2012-01-10 23:29:49 --> Config Class Initialized
DEBUG - 2012-01-10 23:29:49 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:29:49 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:29:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:29:49 --> URI Class Initialized
DEBUG - 2012-01-10 23:29:49 --> Router Class Initialized
DEBUG - 2012-01-10 23:29:49 --> Output Class Initialized
DEBUG - 2012-01-10 23:29:49 --> Security Class Initialized
DEBUG - 2012-01-10 23:29:49 --> Input Class Initialized
DEBUG - 2012-01-10 23:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:29:49 --> Language Class Initialized
DEBUG - 2012-01-10 23:29:50 --> Loader Class Initialized
DEBUG - 2012-01-10 23:29:50 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:29:50 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:29:50 --> Session Class Initialized
DEBUG - 2012-01-10 23:29:50 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:29:50 --> Session routines successfully run
DEBUG - 2012-01-10 23:29:50 --> Controller Class Initialized
DEBUG - 2012-01-10 23:29:50 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:29:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:29:50 --> Final output sent to browser
DEBUG - 2012-01-10 23:29:50 --> Total execution time: 0.4264
DEBUG - 2012-01-10 23:29:52 --> Config Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:29:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:29:52 --> URI Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Router Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Output Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Security Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Input Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:29:52 --> Language Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Loader Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:29:52 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Session Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:29:52 --> Session routines successfully run
DEBUG - 2012-01-10 23:29:52 --> Controller Class Initialized
DEBUG - 2012-01-10 23:29:52 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:29:52 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:29:52 --> Final output sent to browser
DEBUG - 2012-01-10 23:29:52 --> Total execution time: 0.5693
DEBUG - 2012-01-10 23:52:48 --> Config Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:52:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:52:48 --> URI Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Router Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Output Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Security Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Input Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:52:48 --> Language Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Loader Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:52:48 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Session Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:52:48 --> Session routines successfully run
DEBUG - 2012-01-10 23:52:48 --> Controller Class Initialized
DEBUG - 2012-01-10 23:52:48 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:52:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:52:48 --> Final output sent to browser
DEBUG - 2012-01-10 23:52:48 --> Total execution time: 0.1879
DEBUG - 2012-01-10 23:52:51 --> Config Class Initialized
DEBUG - 2012-01-10 23:52:51 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:52:51 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:52:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:52:51 --> URI Class Initialized
DEBUG - 2012-01-10 23:52:51 --> Router Class Initialized
DEBUG - 2012-01-10 23:52:51 --> Output Class Initialized
DEBUG - 2012-01-10 23:52:51 --> Security Class Initialized
DEBUG - 2012-01-10 23:52:51 --> Input Class Initialized
DEBUG - 2012-01-10 23:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:52:51 --> Language Class Initialized
ERROR - 2012-01-10 23:52:51 --> 404 Page Not Found --> article/index
DEBUG - 2012-01-10 23:53:29 --> Config Class Initialized
DEBUG - 2012-01-10 23:53:29 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:53:29 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:53:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:53:29 --> URI Class Initialized
DEBUG - 2012-01-10 23:53:29 --> Router Class Initialized
DEBUG - 2012-01-10 23:53:29 --> Output Class Initialized
DEBUG - 2012-01-10 23:53:29 --> Security Class Initialized
DEBUG - 2012-01-10 23:53:29 --> Input Class Initialized
DEBUG - 2012-01-10 23:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:53:29 --> Language Class Initialized
ERROR - 2012-01-10 23:53:29 --> 404 Page Not Found --> article/index
DEBUG - 2012-01-10 23:53:54 --> Config Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:53:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:53:54 --> URI Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Router Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Output Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Security Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Input Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:53:54 --> Language Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Loader Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:53:54 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Session Class Initialized
DEBUG - 2012-01-10 23:53:54 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:53:54 --> Session routines successfully run
DEBUG - 2012-01-10 23:53:54 --> Controller Class Initialized
DEBUG - 2012-01-10 23:53:54 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:53:54 --> Final output sent to browser
DEBUG - 2012-01-10 23:53:54 --> Total execution time: 0.4349
DEBUG - 2012-01-10 23:54:01 --> Config Class Initialized
DEBUG - 2012-01-10 23:54:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:54:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:54:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:54:02 --> URI Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Router Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Output Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Security Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Input Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:54:02 --> Language Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Loader Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:54:02 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Session Class Initialized
DEBUG - 2012-01-10 23:54:02 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:54:02 --> Session routines successfully run
DEBUG - 2012-01-10 23:54:02 --> Controller Class Initialized
DEBUG - 2012-01-10 23:54:02 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-10 23:54:02 --> Final output sent to browser
DEBUG - 2012-01-10 23:54:02 --> Total execution time: 0.4697
DEBUG - 2012-01-10 23:55:01 --> Config Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:55:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:55:01 --> URI Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Router Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Output Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Security Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Input Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:55:01 --> Language Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Loader Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:55:01 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Session Class Initialized
DEBUG - 2012-01-10 23:55:01 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:55:01 --> Session routines successfully run
DEBUG - 2012-01-10 23:55:01 --> Controller Class Initialized
DEBUG - 2012-01-10 23:55:01 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:55:01 --> Final output sent to browser
DEBUG - 2012-01-10 23:55:01 --> Total execution time: 0.4221
DEBUG - 2012-01-10 23:55:04 --> Config Class Initialized
DEBUG - 2012-01-10 23:55:04 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:55:04 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:55:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:55:04 --> URI Class Initialized
DEBUG - 2012-01-10 23:55:04 --> Router Class Initialized
DEBUG - 2012-01-10 23:55:04 --> Output Class Initialized
DEBUG - 2012-01-10 23:55:04 --> Security Class Initialized
DEBUG - 2012-01-10 23:55:04 --> Input Class Initialized
DEBUG - 2012-01-10 23:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:55:04 --> Language Class Initialized
ERROR - 2012-01-10 23:55:04 --> 404 Page Not Found --> category/index
DEBUG - 2012-01-10 23:57:15 --> Config Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:57:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:57:15 --> URI Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Router Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Output Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Security Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Input Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:57:15 --> Language Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Loader Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:57:15 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Session Class Initialized
DEBUG - 2012-01-10 23:57:15 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:57:15 --> Session routines successfully run
DEBUG - 2012-01-10 23:57:15 --> Controller Class Initialized
DEBUG - 2012-01-10 23:57:15 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:57:15 --> Final output sent to browser
DEBUG - 2012-01-10 23:57:15 --> Total execution time: 0.4347
DEBUG - 2012-01-10 23:57:32 --> Config Class Initialized
DEBUG - 2012-01-10 23:57:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:57:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:57:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:57:33 --> URI Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Router Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Output Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Security Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Input Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:57:33 --> Language Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Loader Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:57:33 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:57:33 --> Session Class Initialized
DEBUG - 2012-01-10 23:57:34 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:57:34 --> Session routines successfully run
DEBUG - 2012-01-10 23:57:34 --> Controller Class Initialized
DEBUG - 2012-01-10 23:57:34 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:57:34 --> Final output sent to browser
DEBUG - 2012-01-10 23:57:34 --> Total execution time: 1.5513
DEBUG - 2012-01-10 23:57:48 --> Config Class Initialized
DEBUG - 2012-01-10 23:57:48 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:57:48 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:57:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:57:48 --> URI Class Initialized
DEBUG - 2012-01-10 23:57:48 --> Router Class Initialized
DEBUG - 2012-01-10 23:57:48 --> No URI present. Default controller set.
DEBUG - 2012-01-10 23:57:48 --> Output Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Security Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Input Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:57:49 --> Language Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Loader Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:57:49 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Session Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:57:49 --> Session routines successfully run
DEBUG - 2012-01-10 23:57:49 --> Controller Class Initialized
DEBUG - 2012-01-10 23:57:49 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:57:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-10 23:57:49 --> Final output sent to browser
DEBUG - 2012-01-10 23:57:49 --> Total execution time: 0.4940
DEBUG - 2012-01-10 23:57:51 --> Config Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:57:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:57:51 --> URI Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Router Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Output Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Security Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Input Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:57:51 --> Language Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Loader Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:57:51 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:57:51 --> Session Class Initialized
DEBUG - 2012-01-10 23:57:52 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:57:52 --> Session routines successfully run
DEBUG - 2012-01-10 23:57:52 --> Controller Class Initialized
DEBUG - 2012-01-10 23:57:52 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-10 23:57:52 --> Final output sent to browser
DEBUG - 2012-01-10 23:57:52 --> Total execution time: 0.5299
DEBUG - 2012-01-10 23:58:03 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:04 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:04 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:04 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:04 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:04 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:04 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:04 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:58:04 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:04 --> Total execution time: 0.3778
DEBUG - 2012-01-10 23:58:22 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:22 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:22 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:22 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:22 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:22 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:22 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:22 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:58:22 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:22 --> Total execution time: 0.4638
DEBUG - 2012-01-10 23:58:24 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:24 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:24 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:24 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:25 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:25 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:25 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:25 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:25 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:25 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:58:25 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:58:25 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:25 --> Total execution time: 1.1962
DEBUG - 2012-01-10 23:58:28 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:28 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:28 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:28 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:28 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:29 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:29 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:29 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:29 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:29 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:29 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:58:29 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:29 --> Total execution time: 0.4389
DEBUG - 2012-01-10 23:58:32 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:32 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:32 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:32 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:32 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:32 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:32 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:58:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:58:33 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:33 --> Total execution time: 0.5265
DEBUG - 2012-01-10 23:58:34 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:34 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:34 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:34 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:34 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:35 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:35 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:35 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:35 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-10 23:58:35 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:35 --> Total execution time: 0.8516
DEBUG - 2012-01-10 23:58:36 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:36 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:36 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:36 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:36 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:36 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:36 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:58:37 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:58:37 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:37 --> Total execution time: 0.5423
DEBUG - 2012-01-10 23:58:38 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:38 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:38 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:38 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:38 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:38 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:38 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:58:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:58:38 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:38 --> Total execution time: 0.4975
DEBUG - 2012-01-10 23:58:40 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:40 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:40 --> Language Class Initialized
DEBUG - 2012-01-10 23:58:40 --> Loader Class Initialized
DEBUG - 2012-01-10 23:58:41 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:58:41 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:58:41 --> Session Class Initialized
DEBUG - 2012-01-10 23:58:41 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:58:41 --> Session routines successfully run
DEBUG - 2012-01-10 23:58:41 --> Controller Class Initialized
DEBUG - 2012-01-10 23:58:41 --> Pagination Class Initialized
DEBUG - 2012-01-10 23:58:41 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-10 23:58:41 --> Final output sent to browser
DEBUG - 2012-01-10 23:58:41 --> Total execution time: 1.1459
DEBUG - 2012-01-10 23:58:44 --> Config Class Initialized
DEBUG - 2012-01-10 23:58:44 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:58:44 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:58:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:58:45 --> URI Class Initialized
DEBUG - 2012-01-10 23:58:45 --> Router Class Initialized
DEBUG - 2012-01-10 23:58:45 --> Output Class Initialized
DEBUG - 2012-01-10 23:58:45 --> Security Class Initialized
DEBUG - 2012-01-10 23:58:45 --> Input Class Initialized
DEBUG - 2012-01-10 23:58:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:58:45 --> Language Class Initialized
ERROR - 2012-01-10 23:58:45 --> 404 Page Not Found --> category/index
DEBUG - 2012-01-10 23:59:46 --> Config Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Hooks Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Utf8 Class Initialized
DEBUG - 2012-01-10 23:59:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-10 23:59:46 --> URI Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Router Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Output Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Security Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Input Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-10 23:59:46 --> Language Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Loader Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Helper loaded: url_helper
DEBUG - 2012-01-10 23:59:46 --> Database Driver Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Session Class Initialized
DEBUG - 2012-01-10 23:59:46 --> Helper loaded: string_helper
DEBUG - 2012-01-10 23:59:46 --> Session routines successfully run
DEBUG - 2012-01-10 23:59:46 --> Controller Class Initialized
DEBUG - 2012-01-10 23:59:46 --> File loaded: application/views/admin/category.php
DEBUG - 2012-01-10 23:59:46 --> Final output sent to browser
DEBUG - 2012-01-10 23:59:46 --> Total execution time: 0.3968

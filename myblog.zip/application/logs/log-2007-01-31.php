<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2007-01-31 21:17:01 --> Config Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:17:01 --> URI Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Router Class Initialized
DEBUG - 2007-01-31 21:17:01 --> No URI present. Default controller set.
DEBUG - 2007-01-31 21:17:01 --> Output Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Security Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Input Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:17:01 --> Language Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Loader Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:17:01 --> Database Driver Class Initialized
ERROR - 2007-01-31 21:17:01 --> Unable to select database: blog
DEBUG - 2007-01-31 21:17:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2007-01-31 21:17:01 --> Config Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:17:01 --> URI Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Router Class Initialized
ERROR - 2007-01-31 21:17:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-31 21:17:01 --> Config Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:17:01 --> URI Class Initialized
DEBUG - 2007-01-31 21:17:01 --> Router Class Initialized
ERROR - 2007-01-31 21:17:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-31 21:18:38 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:38 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:38 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Router Class Initialized
DEBUG - 2007-01-31 21:18:38 --> No URI present. Default controller set.
DEBUG - 2007-01-31 21:18:38 --> Output Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Security Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Input Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:18:38 --> Language Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Loader Class Initialized
DEBUG - 2007-01-31 21:18:38 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:18:38 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Session Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:18:39 --> Session routines successfully run
DEBUG - 2007-01-31 21:18:39 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Controller Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Pagination Class Initialized
DEBUG - 2007-01-31 21:18:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:18:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:18:39 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-01-31 21:18:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:18:39 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-31 21:18:39 --> Final output sent to browser
DEBUG - 2007-01-31 21:18:39 --> Total execution time: 0.1637
DEBUG - 2007-01-31 21:18:39 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:39 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:39 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Router Class Initialized
ERROR - 2007-01-31 21:18:39 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-31 21:18:39 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:39 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:39 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:39 --> Router Class Initialized
ERROR - 2007-01-31 21:18:39 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-31 21:18:44 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:44 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Router Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Output Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Security Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Input Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:18:44 --> Language Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Loader Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:18:44 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Session Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:18:44 --> Session routines successfully run
DEBUG - 2007-01-31 21:18:44 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Controller Class Initialized
DEBUG - 2007-01-31 21:18:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:18:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:18:44 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 21:18:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:18:44 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 21:18:44 --> Final output sent to browser
DEBUG - 2007-01-31 21:18:44 --> Total execution time: 0.1600
DEBUG - 2007-01-31 21:18:44 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:44 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Router Class Initialized
ERROR - 2007-01-31 21:18:44 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-31 21:18:44 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:44 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Router Class Initialized
ERROR - 2007-01-31 21:18:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-31 21:18:44 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:44 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:44 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:44 --> Router Class Initialized
ERROR - 2007-01-31 21:18:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2007-01-31 21:18:50 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:50 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:50 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Router Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Output Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Security Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Input Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:18:50 --> Language Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Loader Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:18:50 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Session Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:18:50 --> Session routines successfully run
DEBUG - 2007-01-31 21:18:50 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:50 --> Controller Class Initialized
DEBUG - 2007-01-31 21:18:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:18:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:18:50 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-01-31 21:18:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:18:50 --> File loaded: application/views/user/category.php
DEBUG - 2007-01-31 21:18:50 --> Final output sent to browser
DEBUG - 2007-01-31 21:18:50 --> Total execution time: 0.1592
DEBUG - 2007-01-31 21:18:52 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:52 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:52 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Router Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Output Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Security Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Input Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:18:52 --> Language Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Loader Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:18:52 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Session Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:18:52 --> Session routines successfully run
DEBUG - 2007-01-31 21:18:52 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:52 --> Controller Class Initialized
DEBUG - 2007-01-31 21:18:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:18:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:18:52 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-01-31 21:18:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:18:52 --> File loaded: application/views/user/category.php
DEBUG - 2007-01-31 21:18:52 --> Final output sent to browser
DEBUG - 2007-01-31 21:18:52 --> Total execution time: 0.1424
DEBUG - 2007-01-31 21:18:54 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:54 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Router Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Output Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Security Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Input Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:18:54 --> Language Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Loader Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:18:54 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Session Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:18:54 --> Session routines successfully run
DEBUG - 2007-01-31 21:18:54 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Controller Class Initialized
DEBUG - 2007-01-31 21:18:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:18:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:18:54 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-01-31 21:18:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:18:54 --> File loaded: application/views/user/category.php
DEBUG - 2007-01-31 21:18:54 --> Final output sent to browser
DEBUG - 2007-01-31 21:18:54 --> Total execution time: 0.1741
DEBUG - 2007-01-31 21:18:54 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:54 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:54 --> Router Class Initialized
ERROR - 2007-01-31 21:18:54 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-31 21:18:57 --> Config Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:18:57 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:18:57 --> URI Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Router Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Output Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Security Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Input Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:18:57 --> Language Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Loader Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:18:57 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Session Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:18:57 --> Session routines successfully run
DEBUG - 2007-01-31 21:18:57 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Model Class Initialized
DEBUG - 2007-01-31 21:18:57 --> Controller Class Initialized
DEBUG - 2007-01-31 21:18:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:18:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:18:57 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-01-31 21:18:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:18:57 --> File loaded: application/views/user/category.php
DEBUG - 2007-01-31 21:18:57 --> Final output sent to browser
DEBUG - 2007-01-31 21:18:57 --> Total execution time: 0.1515
DEBUG - 2007-01-31 21:19:00 --> Config Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:19:00 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:19:00 --> URI Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Router Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Output Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Security Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Input Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:19:00 --> Language Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Loader Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:19:00 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Session Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:19:00 --> Session routines successfully run
DEBUG - 2007-01-31 21:19:00 --> Model Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Model Class Initialized
DEBUG - 2007-01-31 21:19:00 --> Controller Class Initialized
DEBUG - 2007-01-31 21:19:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:19:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:19:00 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 21:19:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:19:00 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 21:19:00 --> Final output sent to browser
DEBUG - 2007-01-31 21:19:00 --> Total execution time: 0.1498
DEBUG - 2007-01-31 21:19:53 --> Config Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:19:53 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:19:53 --> URI Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Router Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Output Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Security Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Input Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:19:53 --> Language Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Loader Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:19:53 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Session Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:19:53 --> Session routines successfully run
DEBUG - 2007-01-31 21:19:53 --> Model Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Model Class Initialized
DEBUG - 2007-01-31 21:19:53 --> Controller Class Initialized
DEBUG - 2007-01-31 21:19:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:19:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:19:53 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 21:19:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:19:53 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 21:19:53 --> Final output sent to browser
DEBUG - 2007-01-31 21:19:53 --> Total execution time: 0.1636
DEBUG - 2007-01-31 21:22:19 --> Config Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Hooks Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Utf8 Class Initialized
DEBUG - 2007-01-31 21:22:19 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 21:22:19 --> URI Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Router Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Output Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Security Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Input Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 21:22:19 --> Language Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Loader Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Helper loaded: url_helper
DEBUG - 2007-01-31 21:22:19 --> Database Driver Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Session Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Helper loaded: string_helper
DEBUG - 2007-01-31 21:22:19 --> Session routines successfully run
DEBUG - 2007-01-31 21:22:19 --> Model Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Model Class Initialized
DEBUG - 2007-01-31 21:22:19 --> Controller Class Initialized
DEBUG - 2007-01-31 21:22:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 21:22:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 21:22:19 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 21:22:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 21:22:19 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 21:22:19 --> Final output sent to browser
DEBUG - 2007-01-31 21:22:19 --> Total execution time: 0.1608
DEBUG - 2007-01-31 23:04:10 --> Config Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:04:10 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:04:10 --> URI Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Router Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Output Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Security Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Input Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:04:10 --> Language Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Loader Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:04:10 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Session Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:04:10 --> Session routines successfully run
DEBUG - 2007-01-31 23:04:10 --> Model Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Model Class Initialized
DEBUG - 2007-01-31 23:04:10 --> Controller Class Initialized
DEBUG - 2007-01-31 23:04:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:04:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:04:10 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:04:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:04:10 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:04:10 --> Final output sent to browser
DEBUG - 2007-01-31 23:04:10 --> Total execution time: 0.1668
DEBUG - 2007-01-31 23:07:52 --> Config Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:07:52 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:07:52 --> URI Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Router Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Output Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Security Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Input Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:07:52 --> Language Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Loader Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:07:52 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Session Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:07:52 --> Session routines successfully run
DEBUG - 2007-01-31 23:07:52 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:52 --> Controller Class Initialized
DEBUG - 2007-01-31 23:07:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:07:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:07:52 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:07:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:07:52 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:07:52 --> Final output sent to browser
DEBUG - 2007-01-31 23:07:52 --> Total execution time: 0.1680
DEBUG - 2007-01-31 23:07:53 --> Config Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:07:53 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:07:53 --> URI Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Router Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Output Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Security Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Input Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:07:53 --> Language Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Loader Class Initialized
DEBUG - 2007-01-31 23:07:53 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:07:53 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:07:54 --> Session Class Initialized
DEBUG - 2007-01-31 23:07:54 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:07:54 --> Session routines successfully run
DEBUG - 2007-01-31 23:07:54 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:54 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:54 --> Controller Class Initialized
DEBUG - 2007-01-31 23:07:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:07:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:07:54 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:07:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:07:54 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:07:54 --> Final output sent to browser
DEBUG - 2007-01-31 23:07:54 --> Total execution time: 0.1532
DEBUG - 2007-01-31 23:07:55 --> Config Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:07:55 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:07:55 --> URI Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Router Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Output Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Security Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Input Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:07:55 --> Language Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Loader Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:07:55 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Session Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:07:55 --> Session routines successfully run
DEBUG - 2007-01-31 23:07:55 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:55 --> Controller Class Initialized
DEBUG - 2007-01-31 23:07:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:07:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:07:55 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:07:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:07:55 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:07:55 --> Final output sent to browser
DEBUG - 2007-01-31 23:07:55 --> Total execution time: 0.2411
DEBUG - 2007-01-31 23:07:56 --> Config Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:07:56 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:07:56 --> URI Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Router Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Output Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Security Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Input Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:07:56 --> Language Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Loader Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:07:56 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Session Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:07:56 --> Session routines successfully run
DEBUG - 2007-01-31 23:07:56 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:56 --> Controller Class Initialized
DEBUG - 2007-01-31 23:07:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:07:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:07:56 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:07:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:07:56 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:07:56 --> Final output sent to browser
DEBUG - 2007-01-31 23:07:56 --> Total execution time: 0.1598
DEBUG - 2007-01-31 23:07:59 --> Config Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:07:59 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:07:59 --> URI Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Router Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Output Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Security Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Input Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:07:59 --> Language Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Loader Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:07:59 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Session Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:07:59 --> Session routines successfully run
DEBUG - 2007-01-31 23:07:59 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Model Class Initialized
DEBUG - 2007-01-31 23:07:59 --> Controller Class Initialized
DEBUG - 2007-01-31 23:07:59 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:07:59 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:07:59 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:07:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:07:59 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:07:59 --> Final output sent to browser
DEBUG - 2007-01-31 23:07:59 --> Total execution time: 0.2645
DEBUG - 2007-01-31 23:08:00 --> Config Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:08:00 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:08:00 --> URI Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Router Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Output Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Security Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Input Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:08:00 --> Language Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Loader Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:08:00 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Session Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:08:00 --> Session routines successfully run
DEBUG - 2007-01-31 23:08:00 --> Model Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Model Class Initialized
DEBUG - 2007-01-31 23:08:00 --> Controller Class Initialized
DEBUG - 2007-01-31 23:08:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:08:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:08:00 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:08:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:08:00 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:08:00 --> Final output sent to browser
DEBUG - 2007-01-31 23:08:00 --> Total execution time: 0.1604
DEBUG - 2007-01-31 23:09:44 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:44 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:44 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:44 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:44 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:44 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:44 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:44 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:44 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:44 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:44 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:44 --> Total execution time: 0.1662
DEBUG - 2007-01-31 23:09:45 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:45 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:45 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:45 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:45 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:45 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:45 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:45 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:45 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:45 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:45 --> Total execution time: 0.1544
DEBUG - 2007-01-31 23:09:46 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:46 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:46 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:46 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:46 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:46 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:47 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:47 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:47 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:47 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:47 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:47 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:47 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:47 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:47 --> Total execution time: 0.1777
DEBUG - 2007-01-31 23:09:48 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:48 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:48 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:48 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:48 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:48 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:48 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:48 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:48 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:48 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:48 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:48 --> Total execution time: 0.1608
DEBUG - 2007-01-31 23:09:49 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:49 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:49 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:49 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:49 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:50 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:50 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:50 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:50 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:50 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:50 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:50 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:50 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:50 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:50 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:50 --> Total execution time: 0.1630
DEBUG - 2007-01-31 23:09:51 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:51 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:51 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:51 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:52 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:52 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:52 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:52 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:52 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:52 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:52 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:52 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:52 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:52 --> Total execution time: 0.1511
DEBUG - 2007-01-31 23:09:53 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:53 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:53 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:53 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:53 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:53 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:53 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:53 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:53 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:53 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:53 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:53 --> Total execution time: 0.1510
DEBUG - 2007-01-31 23:09:54 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:54 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:54 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:54 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:54 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:54 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:54 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:54 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:54 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:54 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:54 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:54 --> Total execution time: 0.1862
DEBUG - 2007-01-31 23:09:55 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:55 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:55 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:55 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:55 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:55 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:55 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:55 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:55 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:55 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:55 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:55 --> Total execution time: 0.1529
DEBUG - 2007-01-31 23:09:56 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:56 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:56 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:56 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:56 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:56 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:56 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:56 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:56 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:56 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:56 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:56 --> Total execution time: 0.1711
DEBUG - 2007-01-31 23:09:57 --> Config Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:09:57 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:09:57 --> URI Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Router Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Output Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Security Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Input Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:09:57 --> Language Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Loader Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:09:57 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Session Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:09:57 --> Session routines successfully run
DEBUG - 2007-01-31 23:09:57 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Model Class Initialized
DEBUG - 2007-01-31 23:09:57 --> Controller Class Initialized
DEBUG - 2007-01-31 23:09:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:09:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:09:57 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:09:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:09:57 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:09:57 --> Final output sent to browser
DEBUG - 2007-01-31 23:09:57 --> Total execution time: 0.1476
DEBUG - 2007-01-31 23:10:26 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:26 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Router Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Output Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Security Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Input Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:10:26 --> Language Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Loader Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:10:26 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Session Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:10:26 --> Session routines successfully run
DEBUG - 2007-01-31 23:10:26 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Controller Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:26 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:26 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Router Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Output Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Security Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Input Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:10:26 --> Language Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Loader Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:10:26 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Session Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:10:26 --> Session routines successfully run
DEBUG - 2007-01-31 23:10:26 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:26 --> Controller Class Initialized
DEBUG - 2007-01-31 23:10:26 --> File loaded: application/views/admin/login.php
DEBUG - 2007-01-31 23:10:26 --> Final output sent to browser
DEBUG - 2007-01-31 23:10:26 --> Total execution time: 0.1428
DEBUG - 2007-01-31 23:10:32 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:32 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:32 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Router Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Output Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Security Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Input Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:10:32 --> Language Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Loader Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:10:32 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Session Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:10:32 --> Session routines successfully run
DEBUG - 2007-01-31 23:10:32 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Controller Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:32 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:32 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Router Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Output Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Security Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Input Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:10:32 --> Language Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Loader Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:10:32 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Session Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:10:32 --> Session routines successfully run
DEBUG - 2007-01-31 23:10:32 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Controller Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Pagination Class Initialized
ERROR - 2007-01-31 23:10:32 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2007-01-31 23:10:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2007-01-31 23:10:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2007-01-31 23:10:32 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2007-01-31 23:10:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2007-01-31 23:10:32 --> File loaded: application/views/admin/home.php
DEBUG - 2007-01-31 23:10:32 --> Final output sent to browser
DEBUG - 2007-01-31 23:10:32 --> Total execution time: 0.1579
DEBUG - 2007-01-31 23:10:32 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:32 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:32 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:32 --> Router Class Initialized
ERROR - 2007-01-31 23:10:32 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-31 23:10:41 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:41 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:41 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Router Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Output Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Security Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Input Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:10:41 --> Language Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Loader Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:10:41 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Session Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:10:41 --> Session routines successfully run
DEBUG - 2007-01-31 23:10:41 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:41 --> Controller Class Initialized
DEBUG - 2007-01-31 23:10:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:10:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:10:41 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-01-31 23:10:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:10:41 --> File loaded: application/views/user/category.php
DEBUG - 2007-01-31 23:10:41 --> Final output sent to browser
DEBUG - 2007-01-31 23:10:41 --> Total execution time: 0.3285
DEBUG - 2007-01-31 23:10:45 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:45 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:45 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Router Class Initialized
DEBUG - 2007-01-31 23:10:45 --> No URI present. Default controller set.
DEBUG - 2007-01-31 23:10:45 --> Output Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Security Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Input Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:10:45 --> Language Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Loader Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:10:45 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Session Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:10:45 --> Session routines successfully run
DEBUG - 2007-01-31 23:10:45 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Model Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Controller Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Pagination Class Initialized
DEBUG - 2007-01-31 23:10:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:10:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:10:45 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2007-01-31 23:10:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:10:45 --> File loaded: application/views/user/home.php
DEBUG - 2007-01-31 23:10:45 --> Final output sent to browser
DEBUG - 2007-01-31 23:10:45 --> Total execution time: 0.1593
DEBUG - 2007-01-31 23:10:45 --> Config Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:10:45 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:10:45 --> URI Class Initialized
DEBUG - 2007-01-31 23:10:45 --> Router Class Initialized
ERROR - 2007-01-31 23:10:45 --> 404 Page Not Found --> lessons
DEBUG - 2007-01-31 23:16:26 --> Config Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:16:26 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:16:26 --> URI Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Router Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Output Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Security Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Input Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:16:26 --> Language Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Loader Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:16:26 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Session Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:16:26 --> Session routines successfully run
DEBUG - 2007-01-31 23:16:26 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:26 --> Controller Class Initialized
DEBUG - 2007-01-31 23:16:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:16:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:16:26 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:16:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:16:26 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:16:26 --> Final output sent to browser
DEBUG - 2007-01-31 23:16:26 --> Total execution time: 0.1581
DEBUG - 2007-01-31 23:16:34 --> Config Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:16:34 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:16:34 --> URI Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Router Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Output Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Security Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Input Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:16:34 --> Language Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Loader Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:16:34 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Session Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:16:34 --> Session routines successfully run
DEBUG - 2007-01-31 23:16:34 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:34 --> Controller Class Initialized
DEBUG - 2007-01-31 23:16:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:16:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:16:34 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:16:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:16:34 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:16:34 --> Final output sent to browser
DEBUG - 2007-01-31 23:16:34 --> Total execution time: 0.1582
DEBUG - 2007-01-31 23:16:35 --> Config Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:16:35 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:16:35 --> URI Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Router Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Output Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Security Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Input Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:16:35 --> Language Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Loader Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:16:35 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Session Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:16:35 --> Session routines successfully run
DEBUG - 2007-01-31 23:16:35 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:35 --> Controller Class Initialized
DEBUG - 2007-01-31 23:16:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:16:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:16:35 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:16:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:16:35 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:16:35 --> Final output sent to browser
DEBUG - 2007-01-31 23:16:35 --> Total execution time: 0.1512
DEBUG - 2007-01-31 23:16:37 --> Config Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:16:37 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:16:37 --> URI Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Router Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Output Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Security Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Input Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:16:37 --> Language Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Loader Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:16:37 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Session Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:16:37 --> Session routines successfully run
DEBUG - 2007-01-31 23:16:37 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Model Class Initialized
DEBUG - 2007-01-31 23:16:37 --> Controller Class Initialized
DEBUG - 2007-01-31 23:16:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:16:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:16:37 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:16:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:16:37 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:16:37 --> Final output sent to browser
DEBUG - 2007-01-31 23:16:37 --> Total execution time: 0.1575
DEBUG - 2007-01-31 23:18:39 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:39 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:39 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:39 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:39 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:39 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:39 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:39 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:39 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:39 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:39 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:39 --> Total execution time: 0.1797
DEBUG - 2007-01-31 23:18:42 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:42 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:42 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:42 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:42 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:42 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:42 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:42 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:42 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:42 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:42 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:42 --> Total execution time: 0.1617
DEBUG - 2007-01-31 23:18:43 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:43 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:43 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:43 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:43 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:43 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:43 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:43 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:43 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:43 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:43 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:43 --> Total execution time: 0.1799
DEBUG - 2007-01-31 23:18:47 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:47 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:47 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:47 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:47 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:47 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:47 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:47 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:47 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:47 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:47 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:47 --> Total execution time: 0.2202
DEBUG - 2007-01-31 23:18:48 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:48 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:48 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:48 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:48 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:48 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:48 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:48 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:48 --> Total execution time: 0.1669
DEBUG - 2007-01-31 23:18:48 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:48 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:48 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:48 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:48 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:48 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:48 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:48 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:48 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:48 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:48 --> Total execution time: 0.1626
DEBUG - 2007-01-31 23:18:49 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:49 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:49 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:49 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:49 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:49 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:49 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:49 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:49 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:49 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:49 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:49 --> Total execution time: 0.1653
DEBUG - 2007-01-31 23:18:50 --> Config Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:18:50 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:18:50 --> URI Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Router Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Output Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Security Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Input Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:18:50 --> Language Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Loader Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:18:50 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Session Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:18:50 --> Session routines successfully run
DEBUG - 2007-01-31 23:18:50 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Model Class Initialized
DEBUG - 2007-01-31 23:18:50 --> Controller Class Initialized
DEBUG - 2007-01-31 23:18:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:18:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:18:50 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:18:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:18:50 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:18:50 --> Final output sent to browser
DEBUG - 2007-01-31 23:18:50 --> Total execution time: 0.1689
DEBUG - 2007-01-31 23:21:04 --> Config Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Hooks Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Utf8 Class Initialized
DEBUG - 2007-01-31 23:21:04 --> UTF-8 Support Enabled
DEBUG - 2007-01-31 23:21:04 --> URI Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Router Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Output Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Security Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Input Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2007-01-31 23:21:04 --> Language Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Loader Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Helper loaded: url_helper
DEBUG - 2007-01-31 23:21:04 --> Database Driver Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Session Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Helper loaded: string_helper
DEBUG - 2007-01-31 23:21:04 --> Session routines successfully run
DEBUG - 2007-01-31 23:21:04 --> Model Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Model Class Initialized
DEBUG - 2007-01-31 23:21:04 --> Controller Class Initialized
DEBUG - 2007-01-31 23:21:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2007-01-31 23:21:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2007-01-31 23:21:04 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2007-01-31 23:21:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2007-01-31 23:21:04 --> File loaded: application/views/user/article.php
DEBUG - 2007-01-31 23:21:04 --> Final output sent to browser
DEBUG - 2007-01-31 23:21:04 --> Total execution time: 0.1682

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-09 20:42:57 --> Config Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:42:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:42:57 --> URI Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Router Class Initialized
DEBUG - 2012-01-09 20:42:57 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:42:57 --> Output Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Security Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Input Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:42:57 --> Language Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Loader Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:42:57 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Controller Class Initialized
DEBUG - 2012-01-09 20:42:57 --> DB Transaction Failure
ERROR - 2012-01-09 20:42:57 --> Query error: Table 'codeigniter.blog.category' doesn't exist
DEBUG - 2012-01-09 20:42:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 20:42:57 --> Config Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:42:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:42:57 --> URI Class Initialized
DEBUG - 2012-01-09 20:42:57 --> Router Class Initialized
ERROR - 2012-01-09 20:42:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:43:23 --> Config Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:43:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:43:23 --> URI Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Router Class Initialized
DEBUG - 2012-01-09 20:43:23 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:43:23 --> Output Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Security Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Input Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:43:23 --> Language Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Loader Class Initialized
DEBUG - 2012-01-09 20:43:23 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:43:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:43:24 --> Controller Class Initialized
DEBUG - 2012-01-09 20:43:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:43:24 --> Final output sent to browser
DEBUG - 2012-01-09 20:43:24 --> Total execution time: 0.5345
DEBUG - 2012-01-09 20:43:24 --> Config Class Initialized
DEBUG - 2012-01-09 20:43:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:43:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:43:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:43:24 --> URI Class Initialized
DEBUG - 2012-01-09 20:43:24 --> Router Class Initialized
ERROR - 2012-01-09 20:43:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:46:45 --> Config Class Initialized
DEBUG - 2012-01-09 20:46:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:46:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:46:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:46:45 --> URI Class Initialized
DEBUG - 2012-01-09 20:46:45 --> Router Class Initialized
DEBUG - 2012-01-09 20:46:45 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:46:45 --> Output Class Initialized
DEBUG - 2012-01-09 20:46:45 --> Security Class Initialized
DEBUG - 2012-01-09 20:46:45 --> Input Class Initialized
DEBUG - 2012-01-09 20:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:46:45 --> Language Class Initialized
DEBUG - 2012-01-09 20:46:45 --> Loader Class Initialized
DEBUG - 2012-01-09 20:46:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:46:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:46:46 --> Controller Class Initialized
DEBUG - 2012-01-09 20:46:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:46:46 --> Final output sent to browser
DEBUG - 2012-01-09 20:46:46 --> Total execution time: 0.3868
DEBUG - 2012-01-09 20:46:46 --> Config Class Initialized
DEBUG - 2012-01-09 20:46:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:46:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:46:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:46:46 --> URI Class Initialized
DEBUG - 2012-01-09 20:46:46 --> Router Class Initialized
ERROR - 2012-01-09 20:46:46 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:47:03 --> Config Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:47:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:47:03 --> URI Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Router Class Initialized
DEBUG - 2012-01-09 20:47:03 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:47:03 --> Output Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Security Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Input Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:47:03 --> Language Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Loader Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:47:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Controller Class Initialized
DEBUG - 2012-01-09 20:47:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:47:03 --> Final output sent to browser
DEBUG - 2012-01-09 20:47:03 --> Total execution time: 0.3164
DEBUG - 2012-01-09 20:47:03 --> Config Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:47:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:47:03 --> URI Class Initialized
DEBUG - 2012-01-09 20:47:03 --> Router Class Initialized
ERROR - 2012-01-09 20:47:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:47:38 --> Config Class Initialized
DEBUG - 2012-01-09 20:47:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:47:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:47:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:47:38 --> URI Class Initialized
DEBUG - 2012-01-09 20:47:38 --> Router Class Initialized
DEBUG - 2012-01-09 20:47:38 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:47:39 --> Output Class Initialized
DEBUG - 2012-01-09 20:47:39 --> Security Class Initialized
DEBUG - 2012-01-09 20:47:39 --> Input Class Initialized
DEBUG - 2012-01-09 20:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:47:39 --> Language Class Initialized
DEBUG - 2012-01-09 20:47:39 --> Loader Class Initialized
DEBUG - 2012-01-09 20:47:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:47:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:47:39 --> Controller Class Initialized
DEBUG - 2012-01-09 20:47:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:47:39 --> Final output sent to browser
DEBUG - 2012-01-09 20:47:39 --> Total execution time: 1.2835
DEBUG - 2012-01-09 20:47:40 --> Config Class Initialized
DEBUG - 2012-01-09 20:47:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:47:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:47:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:47:40 --> URI Class Initialized
DEBUG - 2012-01-09 20:47:40 --> Router Class Initialized
ERROR - 2012-01-09 20:47:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:48:52 --> Config Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:48:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:48:52 --> URI Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Router Class Initialized
DEBUG - 2012-01-09 20:48:52 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:48:52 --> Output Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Security Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Input Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:48:52 --> Language Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Loader Class Initialized
DEBUG - 2012-01-09 20:48:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:48:53 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:48:53 --> Controller Class Initialized
DEBUG - 2012-01-09 20:48:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:48:53 --> Final output sent to browser
DEBUG - 2012-01-09 20:48:53 --> Total execution time: 0.3304
DEBUG - 2012-01-09 20:48:53 --> Config Class Initialized
DEBUG - 2012-01-09 20:48:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:48:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:48:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:48:53 --> URI Class Initialized
DEBUG - 2012-01-09 20:48:53 --> Router Class Initialized
ERROR - 2012-01-09 20:48:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:50:40 --> Config Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:50:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:50:40 --> URI Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Router Class Initialized
DEBUG - 2012-01-09 20:50:40 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:50:40 --> Output Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Security Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Input Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:50:40 --> Language Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Loader Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:50:40 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Controller Class Initialized
DEBUG - 2012-01-09 20:50:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:50:40 --> Final output sent to browser
DEBUG - 2012-01-09 20:50:40 --> Total execution time: 0.3529
DEBUG - 2012-01-09 20:50:40 --> Config Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:50:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:50:40 --> URI Class Initialized
DEBUG - 2012-01-09 20:50:40 --> Router Class Initialized
ERROR - 2012-01-09 20:50:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:51:28 --> Config Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:51:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:51:28 --> URI Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Router Class Initialized
DEBUG - 2012-01-09 20:51:28 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:51:28 --> Output Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Security Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Input Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:51:28 --> Language Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Loader Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:51:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:51:28 --> Controller Class Initialized
DEBUG - 2012-01-09 20:51:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:51:28 --> Final output sent to browser
DEBUG - 2012-01-09 20:51:28 --> Total execution time: 0.3628
DEBUG - 2012-01-09 20:54:04 --> Config Class Initialized
DEBUG - 2012-01-09 20:54:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:54:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:54:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:54:04 --> URI Class Initialized
DEBUG - 2012-01-09 20:54:05 --> Router Class Initialized
DEBUG - 2012-01-09 20:54:05 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:54:05 --> Output Class Initialized
DEBUG - 2012-01-09 20:54:05 --> Security Class Initialized
DEBUG - 2012-01-09 20:54:05 --> Input Class Initialized
DEBUG - 2012-01-09 20:54:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:54:05 --> Language Class Initialized
DEBUG - 2012-01-09 20:54:05 --> Loader Class Initialized
DEBUG - 2012-01-09 20:54:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:54:05 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:54:05 --> Controller Class Initialized
DEBUG - 2012-01-09 20:54:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:54:05 --> Final output sent to browser
DEBUG - 2012-01-09 20:54:05 --> Total execution time: 0.3995
DEBUG - 2012-01-09 20:54:27 --> Config Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:54:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:54:27 --> URI Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Router Class Initialized
DEBUG - 2012-01-09 20:54:27 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:54:27 --> Output Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Security Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Input Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:54:27 --> Language Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Loader Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:54:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:54:27 --> Controller Class Initialized
DEBUG - 2012-01-09 20:54:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:54:27 --> Final output sent to browser
DEBUG - 2012-01-09 20:54:27 --> Total execution time: 0.4092
DEBUG - 2012-01-09 20:55:00 --> Config Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:55:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:55:00 --> URI Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Router Class Initialized
DEBUG - 2012-01-09 20:55:00 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:55:00 --> Output Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Security Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Input Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:55:00 --> Language Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Loader Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:55:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:55:00 --> Controller Class Initialized
DEBUG - 2012-01-09 20:55:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:55:00 --> Final output sent to browser
DEBUG - 2012-01-09 20:55:00 --> Total execution time: 0.3596
DEBUG - 2012-01-09 20:58:09 --> Config Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:58:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:58:09 --> URI Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Router Class Initialized
DEBUG - 2012-01-09 20:58:09 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:58:09 --> Output Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Security Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Input Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:58:09 --> Language Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Loader Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:58:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:58:09 --> Controller Class Initialized
DEBUG - 2012-01-09 20:58:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:58:09 --> Final output sent to browser
DEBUG - 2012-01-09 20:58:09 --> Total execution time: 0.3903
DEBUG - 2012-01-09 20:58:10 --> Config Class Initialized
DEBUG - 2012-01-09 20:58:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:58:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:58:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:58:10 --> URI Class Initialized
DEBUG - 2012-01-09 20:58:10 --> Router Class Initialized
ERROR - 2012-01-09 20:58:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 20:58:12 --> Config Class Initialized
DEBUG - 2012-01-09 20:58:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:58:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:58:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:58:13 --> URI Class Initialized
DEBUG - 2012-01-09 20:58:13 --> Router Class Initialized
DEBUG - 2012-01-09 20:58:13 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:58:13 --> Output Class Initialized
DEBUG - 2012-01-09 20:58:13 --> Security Class Initialized
DEBUG - 2012-01-09 20:58:13 --> Input Class Initialized
DEBUG - 2012-01-09 20:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:58:13 --> Language Class Initialized
DEBUG - 2012-01-09 20:58:13 --> Loader Class Initialized
DEBUG - 2012-01-09 20:58:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:58:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:58:13 --> Controller Class Initialized
DEBUG - 2012-01-09 20:58:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:58:13 --> Final output sent to browser
DEBUG - 2012-01-09 20:58:13 --> Total execution time: 0.3866
DEBUG - 2012-01-09 20:59:12 --> Config Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:59:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:59:13 --> URI Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Router Class Initialized
DEBUG - 2012-01-09 20:59:13 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:59:13 --> Output Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Security Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Input Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:59:13 --> Language Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Loader Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:59:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:59:13 --> Controller Class Initialized
DEBUG - 2012-01-09 20:59:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:59:13 --> Final output sent to browser
DEBUG - 2012-01-09 20:59:13 --> Total execution time: 0.3377
DEBUG - 2012-01-09 20:59:42 --> Config Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 20:59:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 20:59:42 --> URI Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Router Class Initialized
DEBUG - 2012-01-09 20:59:42 --> No URI present. Default controller set.
DEBUG - 2012-01-09 20:59:42 --> Output Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Security Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Input Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 20:59:42 --> Language Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Loader Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 20:59:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 20:59:42 --> Controller Class Initialized
DEBUG - 2012-01-09 20:59:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 20:59:42 --> Final output sent to browser
DEBUG - 2012-01-09 20:59:42 --> Total execution time: 0.6905
DEBUG - 2012-01-09 21:00:10 --> Config Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:00:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:00:11 --> URI Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Router Class Initialized
DEBUG - 2012-01-09 21:00:11 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:00:11 --> Output Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Security Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Input Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:00:11 --> Language Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Loader Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:00:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:00:11 --> Controller Class Initialized
DEBUG - 2012-01-09 21:00:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:00:11 --> Final output sent to browser
DEBUG - 2012-01-09 21:00:11 --> Total execution time: 0.7145
DEBUG - 2012-01-09 21:00:35 --> Config Class Initialized
DEBUG - 2012-01-09 21:00:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:00:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:00:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:00:35 --> URI Class Initialized
DEBUG - 2012-01-09 21:00:35 --> Router Class Initialized
DEBUG - 2012-01-09 21:00:35 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:00:35 --> Output Class Initialized
DEBUG - 2012-01-09 21:00:35 --> Security Class Initialized
DEBUG - 2012-01-09 21:00:35 --> Input Class Initialized
DEBUG - 2012-01-09 21:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:00:35 --> Language Class Initialized
DEBUG - 2012-01-09 21:00:35 --> Loader Class Initialized
DEBUG - 2012-01-09 21:00:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:00:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:00:36 --> Controller Class Initialized
DEBUG - 2012-01-09 21:00:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:00:36 --> Final output sent to browser
DEBUG - 2012-01-09 21:00:36 --> Total execution time: 0.3711
DEBUG - 2012-01-09 21:00:36 --> Config Class Initialized
DEBUG - 2012-01-09 21:00:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:00:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:00:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:00:36 --> URI Class Initialized
DEBUG - 2012-01-09 21:00:36 --> Router Class Initialized
ERROR - 2012-01-09 21:00:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:00:48 --> Config Class Initialized
DEBUG - 2012-01-09 21:00:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:00:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:00:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:00:48 --> URI Class Initialized
DEBUG - 2012-01-09 21:00:48 --> Router Class Initialized
DEBUG - 2012-01-09 21:00:48 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:00:48 --> Output Class Initialized
DEBUG - 2012-01-09 21:00:48 --> Security Class Initialized
DEBUG - 2012-01-09 21:00:48 --> Input Class Initialized
DEBUG - 2012-01-09 21:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:00:49 --> Language Class Initialized
DEBUG - 2012-01-09 21:00:49 --> Loader Class Initialized
DEBUG - 2012-01-09 21:00:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:00:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:00:49 --> Controller Class Initialized
DEBUG - 2012-01-09 21:00:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:00:49 --> Final output sent to browser
DEBUG - 2012-01-09 21:00:49 --> Total execution time: 0.4706
DEBUG - 2012-01-09 21:02:57 --> Config Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:02:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:02:57 --> URI Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Router Class Initialized
DEBUG - 2012-01-09 21:02:57 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:02:57 --> Output Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Security Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Input Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:02:57 --> Language Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Loader Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:02:57 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:02:57 --> Controller Class Initialized
DEBUG - 2012-01-09 21:02:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:02:57 --> Final output sent to browser
DEBUG - 2012-01-09 21:02:57 --> Total execution time: 0.3322
DEBUG - 2012-01-09 21:03:06 --> Config Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:03:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:03:06 --> URI Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Router Class Initialized
DEBUG - 2012-01-09 21:03:06 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:03:06 --> Output Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Security Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Input Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:03:06 --> Language Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Loader Class Initialized
DEBUG - 2012-01-09 21:03:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:03:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:03:07 --> Controller Class Initialized
DEBUG - 2012-01-09 21:03:07 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:03:07 --> Final output sent to browser
DEBUG - 2012-01-09 21:03:07 --> Total execution time: 0.3522
DEBUG - 2012-01-09 21:03:07 --> Config Class Initialized
DEBUG - 2012-01-09 21:03:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:03:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:03:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:03:07 --> URI Class Initialized
DEBUG - 2012-01-09 21:03:07 --> Router Class Initialized
ERROR - 2012-01-09 21:03:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:06:44 --> Config Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:06:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:06:44 --> URI Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Router Class Initialized
DEBUG - 2012-01-09 21:06:44 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:06:44 --> Output Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Security Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Input Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:06:44 --> Language Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Loader Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:06:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:06:44 --> Controller Class Initialized
DEBUG - 2012-01-09 21:06:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:06:44 --> Final output sent to browser
DEBUG - 2012-01-09 21:06:44 --> Total execution time: 0.4404
DEBUG - 2012-01-09 21:07:49 --> Config Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:07:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:07:49 --> URI Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Router Class Initialized
DEBUG - 2012-01-09 21:07:49 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:07:49 --> Output Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Security Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Input Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:07:49 --> Language Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Loader Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:07:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:07:49 --> Controller Class Initialized
DEBUG - 2012-01-09 21:07:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:07:49 --> Final output sent to browser
DEBUG - 2012-01-09 21:07:49 --> Total execution time: 0.3533
DEBUG - 2012-01-09 21:09:11 --> Config Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:09:11 --> URI Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Router Class Initialized
DEBUG - 2012-01-09 21:09:11 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:09:11 --> Output Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Security Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Input Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:09:11 --> Language Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Loader Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:09:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:09:11 --> Controller Class Initialized
DEBUG - 2012-01-09 21:09:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:09:11 --> Final output sent to browser
DEBUG - 2012-01-09 21:09:11 --> Total execution time: 0.3881
DEBUG - 2012-01-09 21:10:13 --> Config Class Initialized
DEBUG - 2012-01-09 21:10:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:10:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:10:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:10:13 --> URI Class Initialized
DEBUG - 2012-01-09 21:10:13 --> Router Class Initialized
DEBUG - 2012-01-09 21:10:13 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:10:13 --> Output Class Initialized
DEBUG - 2012-01-09 21:10:13 --> Security Class Initialized
DEBUG - 2012-01-09 21:10:13 --> Input Class Initialized
DEBUG - 2012-01-09 21:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:10:13 --> Language Class Initialized
DEBUG - 2012-01-09 21:10:14 --> Loader Class Initialized
DEBUG - 2012-01-09 21:10:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:10:14 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:10:14 --> Controller Class Initialized
DEBUG - 2012-01-09 21:10:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:10:14 --> Final output sent to browser
DEBUG - 2012-01-09 21:10:14 --> Total execution time: 0.3856
DEBUG - 2012-01-09 21:11:02 --> Config Class Initialized
DEBUG - 2012-01-09 21:11:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:11:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:11:03 --> URI Class Initialized
DEBUG - 2012-01-09 21:11:03 --> Router Class Initialized
DEBUG - 2012-01-09 21:11:03 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:11:03 --> Output Class Initialized
DEBUG - 2012-01-09 21:11:03 --> Security Class Initialized
DEBUG - 2012-01-09 21:11:03 --> Input Class Initialized
DEBUG - 2012-01-09 21:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:11:03 --> Language Class Initialized
DEBUG - 2012-01-09 21:11:03 --> Loader Class Initialized
DEBUG - 2012-01-09 21:11:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:11:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:11:03 --> Controller Class Initialized
DEBUG - 2012-01-09 21:11:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:11:03 --> Final output sent to browser
DEBUG - 2012-01-09 21:11:03 --> Total execution time: 0.3852
DEBUG - 2012-01-09 21:11:38 --> Config Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:11:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:11:38 --> URI Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Router Class Initialized
DEBUG - 2012-01-09 21:11:38 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:11:38 --> Output Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Security Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Input Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:11:38 --> Language Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Loader Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:11:38 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:11:38 --> Controller Class Initialized
DEBUG - 2012-01-09 21:11:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:11:38 --> Final output sent to browser
DEBUG - 2012-01-09 21:11:38 --> Total execution time: 0.3465
DEBUG - 2012-01-09 21:12:16 --> Config Class Initialized
DEBUG - 2012-01-09 21:12:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:12:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:12:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:12:16 --> URI Class Initialized
DEBUG - 2012-01-09 21:12:16 --> Router Class Initialized
DEBUG - 2012-01-09 21:12:16 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:12:16 --> Output Class Initialized
DEBUG - 2012-01-09 21:12:16 --> Security Class Initialized
DEBUG - 2012-01-09 21:12:16 --> Input Class Initialized
DEBUG - 2012-01-09 21:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:12:16 --> Language Class Initialized
DEBUG - 2012-01-09 21:12:16 --> Loader Class Initialized
DEBUG - 2012-01-09 21:12:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:12:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:12:17 --> Controller Class Initialized
DEBUG - 2012-01-09 21:12:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:12:17 --> Final output sent to browser
DEBUG - 2012-01-09 21:12:17 --> Total execution time: 0.5486
DEBUG - 2012-01-09 21:13:36 --> Config Class Initialized
DEBUG - 2012-01-09 21:13:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:13:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:13:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:13:36 --> URI Class Initialized
DEBUG - 2012-01-09 21:13:36 --> Router Class Initialized
DEBUG - 2012-01-09 21:13:36 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:13:36 --> Output Class Initialized
DEBUG - 2012-01-09 21:13:37 --> Security Class Initialized
DEBUG - 2012-01-09 21:13:37 --> Input Class Initialized
DEBUG - 2012-01-09 21:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:13:37 --> Language Class Initialized
DEBUG - 2012-01-09 21:13:37 --> Loader Class Initialized
DEBUG - 2012-01-09 21:13:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:13:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:13:37 --> Controller Class Initialized
DEBUG - 2012-01-09 21:13:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:13:37 --> Final output sent to browser
DEBUG - 2012-01-09 21:13:37 --> Total execution time: 1.6479
DEBUG - 2012-01-09 21:17:24 --> Config Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:17:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:17:24 --> URI Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Router Class Initialized
DEBUG - 2012-01-09 21:17:24 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:17:24 --> Output Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Security Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Input Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:17:24 --> Language Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Loader Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:17:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:17:24 --> Controller Class Initialized
DEBUG - 2012-01-09 21:17:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:17:24 --> Final output sent to browser
DEBUG - 2012-01-09 21:17:24 --> Total execution time: 0.3983
DEBUG - 2012-01-09 21:18:17 --> Config Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:18:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:18:17 --> URI Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Router Class Initialized
DEBUG - 2012-01-09 21:18:17 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:18:17 --> Output Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Security Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Input Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:18:17 --> Language Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Loader Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:18:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:18:17 --> Controller Class Initialized
DEBUG - 2012-01-09 21:18:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:18:17 --> Final output sent to browser
DEBUG - 2012-01-09 21:18:17 --> Total execution time: 0.3252
DEBUG - 2012-01-09 21:19:20 --> Config Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:19:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:19:20 --> URI Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Router Class Initialized
DEBUG - 2012-01-09 21:19:20 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:19:20 --> Output Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Security Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Input Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:19:20 --> Language Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Loader Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:19:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:19:20 --> Controller Class Initialized
DEBUG - 2012-01-09 21:19:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:19:20 --> Final output sent to browser
DEBUG - 2012-01-09 21:19:20 --> Total execution time: 0.3330
DEBUG - 2012-01-09 21:20:47 --> Config Class Initialized
DEBUG - 2012-01-09 21:20:47 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:20:47 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:20:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:20:47 --> URI Class Initialized
DEBUG - 2012-01-09 21:20:47 --> Router Class Initialized
DEBUG - 2012-01-09 21:20:48 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:20:48 --> Output Class Initialized
DEBUG - 2012-01-09 21:20:48 --> Security Class Initialized
DEBUG - 2012-01-09 21:20:48 --> Input Class Initialized
DEBUG - 2012-01-09 21:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:20:48 --> Language Class Initialized
DEBUG - 2012-01-09 21:20:48 --> Loader Class Initialized
DEBUG - 2012-01-09 21:20:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:20:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:20:49 --> Controller Class Initialized
DEBUG - 2012-01-09 21:20:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:20:49 --> Final output sent to browser
DEBUG - 2012-01-09 21:20:49 --> Total execution time: 1.4197
DEBUG - 2012-01-09 21:21:03 --> Config Class Initialized
DEBUG - 2012-01-09 21:21:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:21:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:21:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:21:04 --> URI Class Initialized
DEBUG - 2012-01-09 21:21:04 --> Router Class Initialized
DEBUG - 2012-01-09 21:21:04 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:21:04 --> Output Class Initialized
DEBUG - 2012-01-09 21:21:04 --> Security Class Initialized
DEBUG - 2012-01-09 21:21:04 --> Input Class Initialized
DEBUG - 2012-01-09 21:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:21:04 --> Language Class Initialized
DEBUG - 2012-01-09 21:21:04 --> Loader Class Initialized
DEBUG - 2012-01-09 21:21:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:21:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:21:04 --> Controller Class Initialized
DEBUG - 2012-01-09 21:21:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:21:04 --> Final output sent to browser
DEBUG - 2012-01-09 21:21:04 --> Total execution time: 0.4799
DEBUG - 2012-01-09 21:22:05 --> Config Class Initialized
DEBUG - 2012-01-09 21:22:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:22:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:22:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:22:06 --> URI Class Initialized
DEBUG - 2012-01-09 21:22:06 --> Router Class Initialized
DEBUG - 2012-01-09 21:22:06 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:22:06 --> Output Class Initialized
DEBUG - 2012-01-09 21:22:06 --> Security Class Initialized
DEBUG - 2012-01-09 21:22:06 --> Input Class Initialized
DEBUG - 2012-01-09 21:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:22:06 --> Language Class Initialized
DEBUG - 2012-01-09 21:22:06 --> Loader Class Initialized
DEBUG - 2012-01-09 21:22:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:22:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:22:06 --> Controller Class Initialized
DEBUG - 2012-01-09 21:22:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:22:06 --> Final output sent to browser
DEBUG - 2012-01-09 21:22:06 --> Total execution time: 1.3315
DEBUG - 2012-01-09 21:22:26 --> Config Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:22:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:22:26 --> URI Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Router Class Initialized
DEBUG - 2012-01-09 21:22:26 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:22:26 --> Output Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Security Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Input Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:22:26 --> Language Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Loader Class Initialized
DEBUG - 2012-01-09 21:22:26 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:22:26 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:22:27 --> Controller Class Initialized
DEBUG - 2012-01-09 21:22:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:22:27 --> Final output sent to browser
DEBUG - 2012-01-09 21:22:27 --> Total execution time: 0.3489
DEBUG - 2012-01-09 21:23:15 --> Config Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:23:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:23:15 --> URI Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Router Class Initialized
DEBUG - 2012-01-09 21:23:15 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:23:15 --> Output Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Security Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Input Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:23:15 --> Language Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Loader Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:23:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:23:15 --> Controller Class Initialized
DEBUG - 2012-01-09 21:23:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:23:15 --> Final output sent to browser
DEBUG - 2012-01-09 21:23:15 --> Total execution time: 0.4375
DEBUG - 2012-01-09 21:23:28 --> Config Class Initialized
DEBUG - 2012-01-09 21:23:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:23:29 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:23:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:23:29 --> URI Class Initialized
DEBUG - 2012-01-09 21:23:29 --> Router Class Initialized
DEBUG - 2012-01-09 21:23:30 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:23:30 --> Output Class Initialized
DEBUG - 2012-01-09 21:23:30 --> Security Class Initialized
DEBUG - 2012-01-09 21:23:30 --> Input Class Initialized
DEBUG - 2012-01-09 21:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:23:30 --> Language Class Initialized
DEBUG - 2012-01-09 21:23:30 --> Loader Class Initialized
DEBUG - 2012-01-09 21:23:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:23:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:23:30 --> Controller Class Initialized
DEBUG - 2012-01-09 21:23:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:23:30 --> Final output sent to browser
DEBUG - 2012-01-09 21:23:30 --> Total execution time: 1.5117
DEBUG - 2012-01-09 21:24:39 --> Config Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:24:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:24:39 --> URI Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Router Class Initialized
DEBUG - 2012-01-09 21:24:39 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:24:39 --> Output Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Security Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Input Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:24:39 --> Language Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Loader Class Initialized
DEBUG - 2012-01-09 21:24:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:24:40 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:24:40 --> Controller Class Initialized
DEBUG - 2012-01-09 21:24:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:24:40 --> Final output sent to browser
DEBUG - 2012-01-09 21:24:40 --> Total execution time: 0.4445
DEBUG - 2012-01-09 21:25:08 --> Config Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:25:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:25:08 --> URI Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Router Class Initialized
DEBUG - 2012-01-09 21:25:08 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:25:08 --> Output Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Security Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Input Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:25:08 --> Language Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Loader Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:25:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:25:08 --> Controller Class Initialized
DEBUG - 2012-01-09 21:25:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:25:08 --> Final output sent to browser
DEBUG - 2012-01-09 21:25:08 --> Total execution time: 0.5035
DEBUG - 2012-01-09 21:27:21 --> Config Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:27:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:27:21 --> URI Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Router Class Initialized
DEBUG - 2012-01-09 21:27:21 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:27:21 --> Output Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Security Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Input Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:27:21 --> Language Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Loader Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:27:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:27:21 --> Controller Class Initialized
DEBUG - 2012-01-09 21:27:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:27:21 --> Final output sent to browser
DEBUG - 2012-01-09 21:27:21 --> Total execution time: 0.4065
DEBUG - 2012-01-09 21:30:32 --> Config Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:30:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:30:32 --> URI Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Router Class Initialized
DEBUG - 2012-01-09 21:30:32 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:30:32 --> Output Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Security Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Input Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:30:32 --> Language Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Loader Class Initialized
DEBUG - 2012-01-09 21:30:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:30:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:30:33 --> Controller Class Initialized
DEBUG - 2012-01-09 21:30:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:30:33 --> Final output sent to browser
DEBUG - 2012-01-09 21:30:33 --> Total execution time: 0.4178
DEBUG - 2012-01-09 21:30:35 --> Config Class Initialized
DEBUG - 2012-01-09 21:30:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:30:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:30:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:30:35 --> URI Class Initialized
DEBUG - 2012-01-09 21:30:35 --> Router Class Initialized
ERROR - 2012-01-09 21:30:35 --> 404 Page Not Found --> article
DEBUG - 2012-01-09 21:31:26 --> Config Class Initialized
DEBUG - 2012-01-09 21:31:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:31:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:31:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:31:26 --> URI Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Router Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Output Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Security Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Input Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:31:27 --> Language Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Loader Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:31:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:31:27 --> Controller Class Initialized
DEBUG - 2012-01-09 21:31:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:31:27 --> Final output sent to browser
DEBUG - 2012-01-09 21:31:27 --> Total execution time: 0.3662
DEBUG - 2012-01-09 21:31:30 --> Config Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:31:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:31:30 --> URI Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Router Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Output Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Security Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Input Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:31:30 --> Language Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Loader Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:31:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:31:30 --> Controller Class Initialized
DEBUG - 2012-01-09 21:31:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:31:30 --> Final output sent to browser
DEBUG - 2012-01-09 21:31:30 --> Total execution time: 0.3850
DEBUG - 2012-01-09 21:32:57 --> Config Class Initialized
DEBUG - 2012-01-09 21:32:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:32:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:32:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:32:57 --> URI Class Initialized
DEBUG - 2012-01-09 21:32:57 --> Router Class Initialized
DEBUG - 2012-01-09 21:32:57 --> Output Class Initialized
DEBUG - 2012-01-09 21:32:57 --> Security Class Initialized
DEBUG - 2012-01-09 21:32:57 --> Input Class Initialized
DEBUG - 2012-01-09 21:32:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:32:57 --> Language Class Initialized
DEBUG - 2012-01-09 21:32:58 --> Loader Class Initialized
DEBUG - 2012-01-09 21:32:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:32:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:32:58 --> Controller Class Initialized
DEBUG - 2012-01-09 21:32:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:32:58 --> Final output sent to browser
DEBUG - 2012-01-09 21:32:58 --> Total execution time: 0.3769
DEBUG - 2012-01-09 21:33:00 --> Config Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:33:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:33:00 --> URI Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Router Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Output Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Security Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Input Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:33:00 --> Language Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Loader Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:33:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:33:00 --> Controller Class Initialized
DEBUG - 2012-01-09 21:33:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:33:00 --> Final output sent to browser
DEBUG - 2012-01-09 21:33:00 --> Total execution time: 0.5277
DEBUG - 2012-01-09 21:33:36 --> Config Class Initialized
DEBUG - 2012-01-09 21:33:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:33:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:33:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:33:37 --> URI Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Router Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Output Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Security Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Input Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:33:37 --> Language Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Loader Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:33:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:33:37 --> Controller Class Initialized
DEBUG - 2012-01-09 21:33:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:33:37 --> Final output sent to browser
DEBUG - 2012-01-09 21:33:37 --> Total execution time: 1.4408
DEBUG - 2012-01-09 21:34:15 --> Config Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:34:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:34:15 --> URI Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Router Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Output Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Security Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Input Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:34:15 --> Language Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Loader Class Initialized
DEBUG - 2012-01-09 21:34:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:34:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:34:16 --> Controller Class Initialized
DEBUG - 2012-01-09 21:34:16 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:34:16 --> Final output sent to browser
DEBUG - 2012-01-09 21:34:16 --> Total execution time: 0.3978
DEBUG - 2012-01-09 21:34:49 --> Config Class Initialized
DEBUG - 2012-01-09 21:34:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:34:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:34:50 --> URI Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Router Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Output Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Security Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Input Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:34:50 --> Language Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Loader Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:34:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:34:50 --> Controller Class Initialized
DEBUG - 2012-01-09 21:34:50 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:34:50 --> Final output sent to browser
DEBUG - 2012-01-09 21:34:50 --> Total execution time: 1.3437
DEBUG - 2012-01-09 21:35:42 --> Config Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:35:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:35:42 --> URI Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Router Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Output Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Security Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Input Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:35:42 --> Language Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Loader Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:35:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:35:42 --> Controller Class Initialized
DEBUG - 2012-01-09 21:35:42 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:35:42 --> Final output sent to browser
DEBUG - 2012-01-09 21:35:42 --> Total execution time: 0.3707
DEBUG - 2012-01-09 21:35:46 --> Config Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:35:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:35:46 --> URI Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Router Class Initialized
DEBUG - 2012-01-09 21:35:46 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:35:46 --> Output Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Security Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Input Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:35:46 --> Language Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Loader Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:35:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:35:46 --> Controller Class Initialized
DEBUG - 2012-01-09 21:35:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:35:46 --> Final output sent to browser
DEBUG - 2012-01-09 21:35:46 --> Total execution time: 0.5656
DEBUG - 2012-01-09 21:35:48 --> Config Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:35:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:35:48 --> URI Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Router Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Output Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Security Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Input Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:35:48 --> Language Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Loader Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:35:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:35:48 --> Controller Class Initialized
DEBUG - 2012-01-09 21:35:48 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:35:48 --> Final output sent to browser
DEBUG - 2012-01-09 21:35:48 --> Total execution time: 0.4721
DEBUG - 2012-01-09 21:35:50 --> Config Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:35:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:35:50 --> URI Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Router Class Initialized
DEBUG - 2012-01-09 21:35:50 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:35:50 --> Output Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Security Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Input Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:35:50 --> Language Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Loader Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:35:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:35:50 --> Controller Class Initialized
DEBUG - 2012-01-09 21:35:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:35:50 --> Final output sent to browser
DEBUG - 2012-01-09 21:35:50 --> Total execution time: 0.4677
DEBUG - 2012-01-09 21:35:54 --> Config Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:35:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:35:54 --> URI Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Router Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Output Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Security Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Input Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:35:54 --> Language Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Loader Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:35:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:35:54 --> Controller Class Initialized
DEBUG - 2012-01-09 21:35:54 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:35:54 --> Final output sent to browser
DEBUG - 2012-01-09 21:35:54 --> Total execution time: 0.4824
DEBUG - 2012-01-09 21:35:56 --> Config Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:35:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:35:56 --> URI Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Router Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Output Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Security Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Input Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:35:56 --> Language Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Loader Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:35:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:35:56 --> Controller Class Initialized
DEBUG - 2012-01-09 21:35:56 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:35:56 --> Final output sent to browser
DEBUG - 2012-01-09 21:35:56 --> Total execution time: 0.4528
DEBUG - 2012-01-09 21:35:58 --> Config Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:35:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:35:58 --> URI Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Router Class Initialized
DEBUG - 2012-01-09 21:35:58 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:35:58 --> Output Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Security Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Input Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:35:58 --> Language Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Loader Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:35:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:35:58 --> Controller Class Initialized
DEBUG - 2012-01-09 21:35:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:35:58 --> Final output sent to browser
DEBUG - 2012-01-09 21:35:58 --> Total execution time: 0.4679
DEBUG - 2012-01-09 21:36:00 --> Config Class Initialized
DEBUG - 2012-01-09 21:36:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:36:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:36:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:36:00 --> URI Class Initialized
DEBUG - 2012-01-09 21:36:00 --> Router Class Initialized
DEBUG - 2012-01-09 21:36:00 --> Output Class Initialized
DEBUG - 2012-01-09 21:36:00 --> Security Class Initialized
DEBUG - 2012-01-09 21:36:00 --> Input Class Initialized
DEBUG - 2012-01-09 21:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:36:00 --> Language Class Initialized
DEBUG - 2012-01-09 21:36:01 --> Loader Class Initialized
DEBUG - 2012-01-09 21:36:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:36:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:36:01 --> Controller Class Initialized
DEBUG - 2012-01-09 21:36:01 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:36:01 --> Final output sent to browser
DEBUG - 2012-01-09 21:36:01 --> Total execution time: 1.0371
DEBUG - 2012-01-09 21:36:18 --> Config Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:36:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:36:18 --> URI Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Router Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Output Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Security Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Input Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:36:18 --> Language Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Loader Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:36:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:36:18 --> Controller Class Initialized
DEBUG - 2012-01-09 21:36:18 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:36:18 --> Final output sent to browser
DEBUG - 2012-01-09 21:36:18 --> Total execution time: 1.1841
DEBUG - 2012-01-09 21:36:44 --> Config Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:36:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:36:44 --> URI Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Router Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Output Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Security Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Input Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:36:44 --> Language Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Loader Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:36:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:36:44 --> Controller Class Initialized
DEBUG - 2012-01-09 21:36:44 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:36:44 --> Final output sent to browser
DEBUG - 2012-01-09 21:36:44 --> Total execution time: 0.4091
DEBUG - 2012-01-09 21:38:00 --> Config Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:38:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:38:00 --> URI Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Router Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Output Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Security Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Input Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:38:00 --> Language Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Loader Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:38:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:38:00 --> Controller Class Initialized
DEBUG - 2012-01-09 21:38:00 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:38:00 --> Final output sent to browser
DEBUG - 2012-01-09 21:38:00 --> Total execution time: 0.4335
DEBUG - 2012-01-09 21:38:02 --> Config Class Initialized
DEBUG - 2012-01-09 21:38:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:38:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:38:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:38:02 --> URI Class Initialized
DEBUG - 2012-01-09 21:38:02 --> Router Class Initialized
DEBUG - 2012-01-09 21:38:02 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:38:02 --> Output Class Initialized
DEBUG - 2012-01-09 21:38:02 --> Security Class Initialized
DEBUG - 2012-01-09 21:38:02 --> Input Class Initialized
DEBUG - 2012-01-09 21:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:38:02 --> Language Class Initialized
DEBUG - 2012-01-09 21:38:02 --> Loader Class Initialized
DEBUG - 2012-01-09 21:38:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:38:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:38:03 --> Controller Class Initialized
DEBUG - 2012-01-09 21:38:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:38:03 --> Final output sent to browser
DEBUG - 2012-01-09 21:38:03 --> Total execution time: 0.5396
DEBUG - 2012-01-09 21:38:08 --> Config Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:38:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:38:08 --> URI Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Router Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Output Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Security Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Input Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:38:08 --> Language Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Loader Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:38:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:38:08 --> Controller Class Initialized
DEBUG - 2012-01-09 21:38:08 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:38:08 --> Final output sent to browser
DEBUG - 2012-01-09 21:38:08 --> Total execution time: 0.9592
DEBUG - 2012-01-09 21:38:11 --> Config Class Initialized
DEBUG - 2012-01-09 21:38:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:38:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:38:12 --> URI Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Router Class Initialized
DEBUG - 2012-01-09 21:38:12 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:38:12 --> Output Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Security Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Input Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:38:12 --> Language Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Loader Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:38:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:38:12 --> Controller Class Initialized
DEBUG - 2012-01-09 21:38:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:38:12 --> Final output sent to browser
DEBUG - 2012-01-09 21:38:12 --> Total execution time: 0.4495
DEBUG - 2012-01-09 21:38:16 --> Config Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:38:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:38:16 --> URI Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Router Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Output Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Security Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Input Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:38:16 --> Language Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Loader Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:38:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:38:16 --> Controller Class Initialized
DEBUG - 2012-01-09 21:38:16 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:38:16 --> Final output sent to browser
DEBUG - 2012-01-09 21:38:16 --> Total execution time: 0.3620
DEBUG - 2012-01-09 21:38:18 --> Config Class Initialized
DEBUG - 2012-01-09 21:38:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:38:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:38:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:38:18 --> URI Class Initialized
DEBUG - 2012-01-09 21:38:18 --> Router Class Initialized
ERROR - 2012-01-09 21:38:18 --> 404 Page Not Found --> category
DEBUG - 2012-01-09 21:38:21 --> Config Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:38:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:38:21 --> URI Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Router Class Initialized
DEBUG - 2012-01-09 21:38:21 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:38:21 --> Output Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Security Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Input Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:38:21 --> Language Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Loader Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:38:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:38:21 --> Controller Class Initialized
DEBUG - 2012-01-09 21:38:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:38:21 --> Final output sent to browser
DEBUG - 2012-01-09 21:38:21 --> Total execution time: 0.3577
DEBUG - 2012-01-09 21:40:17 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:17 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Router Class Initialized
DEBUG - 2012-01-09 21:40:17 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:40:17 --> Output Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Security Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Input Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:40:17 --> Language Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Loader Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:40:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:40:17 --> Controller Class Initialized
DEBUG - 2012-01-09 21:40:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:40:17 --> Final output sent to browser
DEBUG - 2012-01-09 21:40:17 --> Total execution time: 1.2661
DEBUG - 2012-01-09 21:40:22 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:22 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Router Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Output Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Security Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Input Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:40:22 --> Language Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Loader Class Initialized
DEBUG - 2012-01-09 21:40:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:40:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:40:23 --> Controller Class Initialized
DEBUG - 2012-01-09 21:40:23 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:40:23 --> Final output sent to browser
DEBUG - 2012-01-09 21:40:23 --> Total execution time: 0.4569
DEBUG - 2012-01-09 21:40:28 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:28 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Router Class Initialized
DEBUG - 2012-01-09 21:40:28 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:40:28 --> Output Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Security Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Input Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:40:28 --> Language Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Loader Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:40:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:40:28 --> Controller Class Initialized
DEBUG - 2012-01-09 21:40:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:40:28 --> Final output sent to browser
DEBUG - 2012-01-09 21:40:28 --> Total execution time: 0.6495
DEBUG - 2012-01-09 21:40:30 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:30 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Router Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Output Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Security Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Input Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:40:30 --> Language Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Loader Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:40:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:40:30 --> Controller Class Initialized
DEBUG - 2012-01-09 21:40:30 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:40:30 --> Final output sent to browser
DEBUG - 2012-01-09 21:40:30 --> Total execution time: 0.3918
DEBUG - 2012-01-09 21:40:32 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:32 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Router Class Initialized
DEBUG - 2012-01-09 21:40:32 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:40:32 --> Output Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Security Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Input Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:40:32 --> Language Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Loader Class Initialized
DEBUG - 2012-01-09 21:40:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:40:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:40:33 --> Controller Class Initialized
DEBUG - 2012-01-09 21:40:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:40:33 --> Final output sent to browser
DEBUG - 2012-01-09 21:40:33 --> Total execution time: 0.3736
DEBUG - 2012-01-09 21:40:34 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:34 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Router Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Output Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Security Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Input Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:40:34 --> Language Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Loader Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:40:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:40:34 --> Controller Class Initialized
DEBUG - 2012-01-09 21:40:34 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:40:34 --> Final output sent to browser
DEBUG - 2012-01-09 21:40:34 --> Total execution time: 0.3346
DEBUG - 2012-01-09 21:40:36 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:36 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Router Class Initialized
DEBUG - 2012-01-09 21:40:36 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:40:36 --> Output Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Security Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Input Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:40:36 --> Language Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Loader Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:40:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:40:36 --> Controller Class Initialized
DEBUG - 2012-01-09 21:40:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:40:36 --> Final output sent to browser
DEBUG - 2012-01-09 21:40:36 --> Total execution time: 0.4132
DEBUG - 2012-01-09 21:40:41 --> Config Class Initialized
DEBUG - 2012-01-09 21:40:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:40:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:40:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:40:41 --> URI Class Initialized
DEBUG - 2012-01-09 21:40:41 --> Router Class Initialized
ERROR - 2012-01-09 21:40:41 --> 404 Page Not Found --> category
DEBUG - 2012-01-09 21:41:01 --> Config Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:41:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:41:01 --> URI Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Router Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Output Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Security Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Input Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:41:01 --> Language Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Loader Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:41:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:41:01 --> Controller Class Initialized
DEBUG - 2012-01-09 21:41:01 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:41:01 --> Final output sent to browser
DEBUG - 2012-01-09 21:41:01 --> Total execution time: 0.3075
DEBUG - 2012-01-09 21:41:04 --> Config Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:41:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:41:04 --> URI Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Router Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Output Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Security Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Input Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:41:04 --> Language Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Loader Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:41:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:41:04 --> Controller Class Initialized
DEBUG - 2012-01-09 21:41:04 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:41:04 --> Final output sent to browser
DEBUG - 2012-01-09 21:41:04 --> Total execution time: 0.2959
DEBUG - 2012-01-09 21:41:05 --> Config Class Initialized
DEBUG - 2012-01-09 21:41:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:41:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:41:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:41:05 --> URI Class Initialized
DEBUG - 2012-01-09 21:41:05 --> Router Class Initialized
DEBUG - 2012-01-09 21:41:05 --> Output Class Initialized
DEBUG - 2012-01-09 21:41:05 --> Security Class Initialized
DEBUG - 2012-01-09 21:41:05 --> Input Class Initialized
DEBUG - 2012-01-09 21:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:41:06 --> Language Class Initialized
DEBUG - 2012-01-09 21:41:06 --> Loader Class Initialized
DEBUG - 2012-01-09 21:41:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:41:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:41:06 --> Controller Class Initialized
DEBUG - 2012-01-09 21:41:06 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:41:06 --> Final output sent to browser
DEBUG - 2012-01-09 21:41:06 --> Total execution time: 0.3031
DEBUG - 2012-01-09 21:41:07 --> Config Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:41:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:41:07 --> URI Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Router Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Output Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Security Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Input Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:41:07 --> Language Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Loader Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:41:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:41:07 --> Controller Class Initialized
DEBUG - 2012-01-09 21:41:07 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:41:07 --> Final output sent to browser
DEBUG - 2012-01-09 21:41:07 --> Total execution time: 0.3013
DEBUG - 2012-01-09 21:41:08 --> Config Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:41:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:41:08 --> URI Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Router Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Output Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Security Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Input Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:41:08 --> Language Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Loader Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:41:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:41:08 --> Controller Class Initialized
DEBUG - 2012-01-09 21:41:08 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:41:08 --> Final output sent to browser
DEBUG - 2012-01-09 21:41:08 --> Total execution time: 0.3105
DEBUG - 2012-01-09 21:41:30 --> Config Class Initialized
DEBUG - 2012-01-09 21:41:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:41:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:41:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:41:30 --> URI Class Initialized
DEBUG - 2012-01-09 21:41:30 --> Router Class Initialized
DEBUG - 2012-01-09 21:41:30 --> Output Class Initialized
DEBUG - 2012-01-09 21:41:31 --> Security Class Initialized
DEBUG - 2012-01-09 21:41:31 --> Input Class Initialized
DEBUG - 2012-01-09 21:41:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:41:31 --> Language Class Initialized
DEBUG - 2012-01-09 21:41:31 --> Loader Class Initialized
DEBUG - 2012-01-09 21:41:31 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:41:31 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:41:31 --> Controller Class Initialized
DEBUG - 2012-01-09 21:41:31 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:41:31 --> Final output sent to browser
DEBUG - 2012-01-09 21:41:31 --> Total execution time: 1.3542
DEBUG - 2012-01-09 21:41:45 --> Config Class Initialized
DEBUG - 2012-01-09 21:41:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:41:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:41:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:41:46 --> URI Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Router Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Output Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Security Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Input Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:41:46 --> Language Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Loader Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:41:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:41:46 --> Controller Class Initialized
DEBUG - 2012-01-09 21:41:46 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:41:46 --> Final output sent to browser
DEBUG - 2012-01-09 21:41:46 --> Total execution time: 0.3332
DEBUG - 2012-01-09 21:42:08 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:08 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:08 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:09 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:09 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:09 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:09 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:09 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:09 --> Controller Class Initialized
DEBUG - 2012-01-09 21:42:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:42:09 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:09 --> Total execution time: 0.3732
DEBUG - 2012-01-09 21:42:10 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:11 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:11 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:11 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:42:11 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:11 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:11 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:11 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:11 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:11 --> Controller Class Initialized
DEBUG - 2012-01-09 21:42:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:42:11 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:11 --> Total execution time: 0.9208
DEBUG - 2012-01-09 21:42:12 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:13 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:13 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:13 --> Controller Class Initialized
DEBUG - 2012-01-09 21:42:13 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:42:13 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:13 --> Total execution time: 0.4924
DEBUG - 2012-01-09 21:42:16 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:16 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:16 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:16 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:16 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:16 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:17 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:17 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:17 --> Controller Class Initialized
DEBUG - 2012-01-09 21:42:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:42:17 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:17 --> Total execution time: 0.7041
DEBUG - 2012-01-09 21:42:20 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:21 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:21 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:21 --> Controller Class Initialized
DEBUG - 2012-01-09 21:42:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:42:21 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:21 --> Total execution time: 0.3340
DEBUG - 2012-01-09 21:42:24 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:24 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:24 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:24 --> Controller Class Initialized
DEBUG - 2012-01-09 21:42:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:42:24 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:24 --> Total execution time: 0.3659
DEBUG - 2012-01-09 21:42:25 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:25 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:26 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:26 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:26 --> Controller Class Initialized
DEBUG - 2012-01-09 21:42:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:42:26 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:26 --> Total execution time: 0.3821
DEBUG - 2012-01-09 21:42:51 --> Config Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:42:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:42:52 --> URI Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Router Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Output Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Security Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Input Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:42:52 --> Language Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Loader Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:42:52 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:42:52 --> Controller Class Initialized
ERROR - 2012-01-09 21:42:53 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\user\category.php 25
ERROR - 2012-01-09 21:42:53 --> Severity: Notice  --> Trying to get property of non-object A:\home\codeigniter.blog\www\application\views\user\category.php 26
DEBUG - 2012-01-09 21:42:53 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:42:53 --> Final output sent to browser
DEBUG - 2012-01-09 21:42:53 --> Total execution time: 1.2472
DEBUG - 2012-01-09 21:43:48 --> Config Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:43:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:43:48 --> URI Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Router Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Output Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Security Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Input Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:43:48 --> Language Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Loader Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:43:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:43:48 --> Controller Class Initialized
ERROR - 2012-01-09 21:43:48 --> Severity: Notice  --> Undefined property: stdClass::$id_article A:\home\codeigniter.blog\www\application\views\user\category.php 26
ERROR - 2012-01-09 21:43:48 --> Severity: Notice  --> Undefined property: stdClass::$text A:\home\codeigniter.blog\www\application\views\user\category.php 27
DEBUG - 2012-01-09 21:43:48 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:43:48 --> Final output sent to browser
DEBUG - 2012-01-09 21:43:48 --> Total execution time: 0.3462
DEBUG - 2012-01-09 21:44:28 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:28 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:28 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:28 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:44:28 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:28 --> Total execution time: 0.3527
DEBUG - 2012-01-09 21:44:31 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:31 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:31 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:31 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:31 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:31 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:44:31 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:31 --> Total execution time: 0.3294
DEBUG - 2012-01-09 21:44:32 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:32 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:32 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:32 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:33 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:33 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:44:33 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:33 --> Total execution time: 0.3103
DEBUG - 2012-01-09 21:44:34 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:34 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:34 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:34 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:44:34 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:34 --> Total execution time: 0.7188
DEBUG - 2012-01-09 21:44:36 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:36 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:36 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:36 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:36 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:44:36 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:36 --> Total execution time: 0.3099
DEBUG - 2012-01-09 21:44:37 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:37 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:37 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:37 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:44:37 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:37 --> Total execution time: 0.3654
DEBUG - 2012-01-09 21:44:40 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:40 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:40 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:44:40 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:40 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:40 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:40 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:44:40 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:40 --> Total execution time: 0.4080
DEBUG - 2012-01-09 21:44:41 --> Config Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:44:42 --> URI Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Router Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Output Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Security Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Input Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:44:42 --> Language Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Loader Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:44:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:44:42 --> Controller Class Initialized
DEBUG - 2012-01-09 21:44:42 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:44:42 --> Final output sent to browser
DEBUG - 2012-01-09 21:44:42 --> Total execution time: 0.3199
DEBUG - 2012-01-09 21:47:01 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:01 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:01 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:47:01 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:01 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:01 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:47:01 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:01 --> Total execution time: 0.3909
DEBUG - 2012-01-09 21:47:01 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:02 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:02 --> Router Class Initialized
ERROR - 2012-01-09 21:47:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:04 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:04 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:04 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:04 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:04 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:47:04 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:04 --> Total execution time: 0.3113
DEBUG - 2012-01-09 21:47:05 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:05 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:05 --> Router Class Initialized
ERROR - 2012-01-09 21:47:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:20 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:20 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:20 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:20 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:47:20 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:20 --> Total execution time: 0.3708
DEBUG - 2012-01-09 21:47:21 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:21 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:21 --> Router Class Initialized
ERROR - 2012-01-09 21:47:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:49 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:49 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:49 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:49 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:49 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:49 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:50 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:50 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:50 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:47:50 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:50 --> Total execution time: 0.3575
DEBUG - 2012-01-09 21:47:50 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:50 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:50 --> Router Class Initialized
ERROR - 2012-01-09 21:47:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:53 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:53 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:53 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:53 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:53 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:53 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:47:53 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:53 --> Total execution time: 0.3273
DEBUG - 2012-01-09 21:47:54 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:54 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:54 --> Router Class Initialized
ERROR - 2012-01-09 21:47:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:55 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:55 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:55 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:55 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:55 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:47:55 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:55 --> Total execution time: 0.3659
DEBUG - 2012-01-09 21:47:56 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:56 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Router Class Initialized
ERROR - 2012-01-09 21:47:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:56 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:56 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:56 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:56 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:56 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:47:56 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:56 --> Total execution time: 0.3237
DEBUG - 2012-01-09 21:47:57 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:57 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:57 --> Router Class Initialized
ERROR - 2012-01-09 21:47:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:58 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:58 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Router Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Output Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Security Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Input Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:47:58 --> Language Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Loader Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:47:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:47:58 --> Controller Class Initialized
DEBUG - 2012-01-09 21:47:58 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:47:58 --> Final output sent to browser
DEBUG - 2012-01-09 21:47:58 --> Total execution time: 0.3319
DEBUG - 2012-01-09 21:47:59 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:59 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:59 --> Router Class Initialized
ERROR - 2012-01-09 21:47:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:47:59 --> Config Class Initialized
DEBUG - 2012-01-09 21:47:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:47:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:47:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:47:59 --> URI Class Initialized
DEBUG - 2012-01-09 21:47:59 --> Router Class Initialized
DEBUG - 2012-01-09 21:48:00 --> Output Class Initialized
DEBUG - 2012-01-09 21:48:00 --> Security Class Initialized
DEBUG - 2012-01-09 21:48:00 --> Input Class Initialized
DEBUG - 2012-01-09 21:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:48:00 --> Language Class Initialized
DEBUG - 2012-01-09 21:48:00 --> Loader Class Initialized
DEBUG - 2012-01-09 21:48:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:48:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:48:00 --> Controller Class Initialized
DEBUG - 2012-01-09 21:48:00 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:48:00 --> Final output sent to browser
DEBUG - 2012-01-09 21:48:00 --> Total execution time: 0.3542
DEBUG - 2012-01-09 21:48:01 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:01 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Router Class Initialized
ERROR - 2012-01-09 21:48:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:48:01 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:01 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Router Class Initialized
DEBUG - 2012-01-09 21:48:01 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:48:01 --> Output Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Security Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Input Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:48:01 --> Language Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Loader Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:48:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:48:01 --> Controller Class Initialized
DEBUG - 2012-01-09 21:48:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:48:02 --> Final output sent to browser
DEBUG - 2012-01-09 21:48:02 --> Total execution time: 0.3511
DEBUG - 2012-01-09 21:48:02 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:02 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:02 --> Router Class Initialized
ERROR - 2012-01-09 21:48:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:48:03 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:03 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Router Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Output Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Security Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Input Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:48:03 --> Language Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Loader Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:48:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Controller Class Initialized
DEBUG - 2012-01-09 21:48:03 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:48:03 --> Final output sent to browser
DEBUG - 2012-01-09 21:48:03 --> Total execution time: 0.3544
DEBUG - 2012-01-09 21:48:03 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:03 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:03 --> Router Class Initialized
ERROR - 2012-01-09 21:48:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:48:06 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:06 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:06 --> Router Class Initialized
DEBUG - 2012-01-09 21:48:06 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:48:07 --> Output Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Security Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Input Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:48:07 --> Language Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Loader Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:48:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Controller Class Initialized
DEBUG - 2012-01-09 21:48:07 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:48:07 --> Final output sent to browser
DEBUG - 2012-01-09 21:48:07 --> Total execution time: 0.4054
DEBUG - 2012-01-09 21:48:07 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:07 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:07 --> Router Class Initialized
ERROR - 2012-01-09 21:48:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:48:08 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:09 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Router Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Output Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Security Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Input Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:48:09 --> Language Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Loader Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:48:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Controller Class Initialized
DEBUG - 2012-01-09 21:48:09 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:48:09 --> Final output sent to browser
DEBUG - 2012-01-09 21:48:09 --> Total execution time: 0.3962
DEBUG - 2012-01-09 21:48:09 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:09 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:09 --> Router Class Initialized
ERROR - 2012-01-09 21:48:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:48:10 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:10 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Router Class Initialized
DEBUG - 2012-01-09 21:48:10 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:48:10 --> Output Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Security Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Input Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:48:10 --> Language Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Loader Class Initialized
DEBUG - 2012-01-09 21:48:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:48:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:48:11 --> Controller Class Initialized
DEBUG - 2012-01-09 21:48:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:48:11 --> Final output sent to browser
DEBUG - 2012-01-09 21:48:11 --> Total execution time: 0.4321
DEBUG - 2012-01-09 21:48:11 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:11 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:11 --> Router Class Initialized
ERROR - 2012-01-09 21:48:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:48:53 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:53 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Router Class Initialized
DEBUG - 2012-01-09 21:48:53 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:48:53 --> Output Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Security Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Input Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:48:53 --> Language Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Loader Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:48:53 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:48:53 --> Controller Class Initialized
DEBUG - 2012-01-09 21:48:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:48:53 --> Final output sent to browser
DEBUG - 2012-01-09 21:48:53 --> Total execution time: 0.4202
DEBUG - 2012-01-09 21:48:54 --> Config Class Initialized
DEBUG - 2012-01-09 21:48:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:48:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:48:54 --> URI Class Initialized
DEBUG - 2012-01-09 21:48:54 --> Router Class Initialized
ERROR - 2012-01-09 21:48:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:01 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:01 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:01 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:01 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:01 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:01 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:01 --> Total execution time: 0.3484
DEBUG - 2012-01-09 21:49:02 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:02 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:02 --> Router Class Initialized
ERROR - 2012-01-09 21:49:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:03 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:03 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:03 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:03 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:03 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:03 --> Total execution time: 0.3332
DEBUG - 2012-01-09 21:49:03 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:03 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:03 --> Router Class Initialized
ERROR - 2012-01-09 21:49:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:04 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:04 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:04 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:04 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:04 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:05 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:05 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:05 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:05 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:05 --> Total execution time: 0.3595
DEBUG - 2012-01-09 21:49:05 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:05 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:05 --> Router Class Initialized
ERROR - 2012-01-09 21:49:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:06 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:06 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:06 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:07 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:07 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:07 --> Total execution time: 0.7773
DEBUG - 2012-01-09 21:49:07 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:07 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:07 --> Router Class Initialized
ERROR - 2012-01-09 21:49:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:09 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:09 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:09 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:09 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:49:09 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:09 --> Total execution time: 0.3518
DEBUG - 2012-01-09 21:49:09 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:10 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:10 --> Router Class Initialized
ERROR - 2012-01-09 21:49:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:12 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:12 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:12 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:12 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:12 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:12 --> Total execution time: 0.3180
DEBUG - 2012-01-09 21:49:12 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:12 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:12 --> Router Class Initialized
ERROR - 2012-01-09 21:49:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:13 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:13 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:13 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:13 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:13 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:13 --> Total execution time: 0.3499
DEBUG - 2012-01-09 21:49:14 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:14 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:14 --> Router Class Initialized
ERROR - 2012-01-09 21:49:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:15 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:15 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:15 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:15 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:15 --> Total execution time: 0.3423
DEBUG - 2012-01-09 21:49:15 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:15 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:15 --> Router Class Initialized
ERROR - 2012-01-09 21:49:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:16 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:16 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:16 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:16 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:16 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:16 --> Total execution time: 0.3672
DEBUG - 2012-01-09 21:49:17 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:17 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:17 --> Router Class Initialized
ERROR - 2012-01-09 21:49:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:18 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:18 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:18 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:18 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:49:18 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:18 --> Total execution time: 0.3401
DEBUG - 2012-01-09 21:49:18 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:18 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:18 --> Router Class Initialized
ERROR - 2012-01-09 21:49:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:21 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:21 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:21 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:21 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:21 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:49:21 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:21 --> Total execution time: 0.3931
DEBUG - 2012-01-09 21:49:22 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:22 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Router Class Initialized
ERROR - 2012-01-09 21:49:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:49:22 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:22 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Router Class Initialized
DEBUG - 2012-01-09 21:49:22 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:49:22 --> Output Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Security Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Input Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:49:22 --> Language Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Loader Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:49:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:49:22 --> Controller Class Initialized
DEBUG - 2012-01-09 21:49:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:49:23 --> Final output sent to browser
DEBUG - 2012-01-09 21:49:23 --> Total execution time: 0.3322
DEBUG - 2012-01-09 21:49:23 --> Config Class Initialized
DEBUG - 2012-01-09 21:49:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:49:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:49:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:49:23 --> URI Class Initialized
DEBUG - 2012-01-09 21:49:23 --> Router Class Initialized
ERROR - 2012-01-09 21:49:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 21:50:19 --> Config Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:50:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:50:19 --> URI Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Router Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Output Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Security Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Input Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:50:19 --> Language Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Loader Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:50:19 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:50:19 --> Controller Class Initialized
DEBUG - 2012-01-09 21:50:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:50:19 --> Final output sent to browser
DEBUG - 2012-01-09 21:50:19 --> Total execution time: 0.3252
DEBUG - 2012-01-09 21:50:22 --> Config Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:50:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:50:22 --> URI Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Router Class Initialized
DEBUG - 2012-01-09 21:50:22 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:50:22 --> Output Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Security Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Input Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:50:22 --> Language Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Loader Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:50:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:50:22 --> Controller Class Initialized
DEBUG - 2012-01-09 21:50:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:50:22 --> Final output sent to browser
DEBUG - 2012-01-09 21:50:22 --> Total execution time: 0.3457
DEBUG - 2012-01-09 21:55:51 --> Config Class Initialized
DEBUG - 2012-01-09 21:55:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:55:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:55:52 --> URI Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Router Class Initialized
DEBUG - 2012-01-09 21:55:52 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:55:52 --> Output Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Security Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Input Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:55:52 --> Language Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Loader Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:55:52 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:55:52 --> Controller Class Initialized
DEBUG - 2012-01-09 21:55:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:55:52 --> Final output sent to browser
DEBUG - 2012-01-09 21:55:52 --> Total execution time: 0.3518
DEBUG - 2012-01-09 21:55:54 --> Config Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:55:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:55:54 --> URI Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Router Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Output Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Security Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Input Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:55:54 --> Language Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Loader Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:55:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:55:54 --> Controller Class Initialized
DEBUG - 2012-01-09 21:55:54 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:55:54 --> Final output sent to browser
DEBUG - 2012-01-09 21:55:54 --> Total execution time: 0.3836
DEBUG - 2012-01-09 21:55:55 --> Config Class Initialized
DEBUG - 2012-01-09 21:55:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:55:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:55:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:55:56 --> URI Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Router Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Output Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Security Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Input Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:55:56 --> Language Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Loader Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:55:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Controller Class Initialized
DEBUG - 2012-01-09 21:55:56 --> Pagination Class Initialized
DEBUG - 2012-01-09 21:55:56 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 21:55:56 --> Final output sent to browser
DEBUG - 2012-01-09 21:55:56 --> Total execution time: 0.3637
DEBUG - 2012-01-09 21:55:58 --> Config Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:55:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:55:58 --> URI Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Router Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Output Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Security Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Input Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:55:58 --> Language Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Loader Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:55:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:55:58 --> Controller Class Initialized
DEBUG - 2012-01-09 21:55:58 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 21:55:58 --> Final output sent to browser
DEBUG - 2012-01-09 21:55:58 --> Total execution time: 0.3627
DEBUG - 2012-01-09 21:55:59 --> Config Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:55:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:55:59 --> URI Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Router Class Initialized
DEBUG - 2012-01-09 21:55:59 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:55:59 --> Output Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Security Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Input Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:55:59 --> Language Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Loader Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:55:59 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:55:59 --> Controller Class Initialized
DEBUG - 2012-01-09 21:55:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:55:59 --> Final output sent to browser
DEBUG - 2012-01-09 21:55:59 --> Total execution time: 0.3773
DEBUG - 2012-01-09 21:57:21 --> Config Class Initialized
DEBUG - 2012-01-09 21:57:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:57:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:57:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:57:21 --> URI Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Router Class Initialized
DEBUG - 2012-01-09 21:57:22 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:57:22 --> Output Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Security Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Input Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:57:22 --> Language Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Loader Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:57:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Controller Class Initialized
DEBUG - 2012-01-09 21:57:22 --> Pagination Class Initialized
DEBUG - 2012-01-09 21:57:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:57:22 --> Final output sent to browser
DEBUG - 2012-01-09 21:57:22 --> Total execution time: 0.4321
DEBUG - 2012-01-09 21:57:24 --> Config Class Initialized
DEBUG - 2012-01-09 21:57:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:57:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:57:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:57:24 --> URI Class Initialized
DEBUG - 2012-01-09 21:57:24 --> Router Class Initialized
DEBUG - 2012-01-09 21:57:24 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:57:24 --> Output Class Initialized
DEBUG - 2012-01-09 21:57:24 --> Security Class Initialized
DEBUG - 2012-01-09 21:57:24 --> Input Class Initialized
DEBUG - 2012-01-09 21:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:57:25 --> Language Class Initialized
DEBUG - 2012-01-09 21:57:25 --> Loader Class Initialized
DEBUG - 2012-01-09 21:57:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:57:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:57:25 --> Controller Class Initialized
DEBUG - 2012-01-09 21:57:25 --> Pagination Class Initialized
DEBUG - 2012-01-09 21:57:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:57:25 --> Final output sent to browser
DEBUG - 2012-01-09 21:57:25 --> Total execution time: 0.3723
DEBUG - 2012-01-09 21:57:54 --> Config Class Initialized
DEBUG - 2012-01-09 21:57:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:57:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:57:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:57:54 --> URI Class Initialized
DEBUG - 2012-01-09 21:57:54 --> Router Class Initialized
DEBUG - 2012-01-09 21:57:54 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:57:54 --> Output Class Initialized
DEBUG - 2012-01-09 21:57:54 --> Security Class Initialized
DEBUG - 2012-01-09 21:57:54 --> Input Class Initialized
DEBUG - 2012-01-09 21:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:57:54 --> Language Class Initialized
DEBUG - 2012-01-09 21:58:03 --> Config Class Initialized
DEBUG - 2012-01-09 21:58:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:58:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:58:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:58:03 --> URI Class Initialized
DEBUG - 2012-01-09 21:58:03 --> Router Class Initialized
DEBUG - 2012-01-09 21:58:04 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:58:04 --> Output Class Initialized
DEBUG - 2012-01-09 21:58:04 --> Security Class Initialized
DEBUG - 2012-01-09 21:58:04 --> Input Class Initialized
DEBUG - 2012-01-09 21:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:58:04 --> Language Class Initialized
DEBUG - 2012-01-09 21:58:04 --> Loader Class Initialized
DEBUG - 2012-01-09 21:58:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:58:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:58:04 --> Controller Class Initialized
DEBUG - 2012-01-09 21:58:04 --> Pagination Class Initialized
DEBUG - 2012-01-09 21:58:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:58:04 --> Final output sent to browser
DEBUG - 2012-01-09 21:58:04 --> Total execution time: 1.4567
DEBUG - 2012-01-09 21:58:23 --> Config Class Initialized
DEBUG - 2012-01-09 21:58:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:58:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:58:24 --> URI Class Initialized
DEBUG - 2012-01-09 21:58:24 --> Router Class Initialized
DEBUG - 2012-01-09 21:58:24 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:58:24 --> Output Class Initialized
DEBUG - 2012-01-09 21:58:24 --> Security Class Initialized
DEBUG - 2012-01-09 21:58:24 --> Input Class Initialized
DEBUG - 2012-01-09 21:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:58:25 --> Language Class Initialized
DEBUG - 2012-01-09 21:58:25 --> Loader Class Initialized
DEBUG - 2012-01-09 21:58:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:58:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:58:25 --> Controller Class Initialized
DEBUG - 2012-01-09 21:58:25 --> Pagination Class Initialized
DEBUG - 2012-01-09 21:58:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:58:25 --> Final output sent to browser
DEBUG - 2012-01-09 21:58:25 --> Total execution time: 1.4433
DEBUG - 2012-01-09 21:58:27 --> Config Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:58:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:58:27 --> URI Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Router Class Initialized
DEBUG - 2012-01-09 21:58:27 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:58:27 --> Output Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Security Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Input Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:58:27 --> Language Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Loader Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:58:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Controller Class Initialized
DEBUG - 2012-01-09 21:58:27 --> Pagination Class Initialized
DEBUG - 2012-01-09 21:58:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:58:27 --> Final output sent to browser
DEBUG - 2012-01-09 21:58:27 --> Total execution time: 0.4033
DEBUG - 2012-01-09 21:58:32 --> Config Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 21:58:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 21:58:32 --> URI Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Router Class Initialized
DEBUG - 2012-01-09 21:58:32 --> No URI present. Default controller set.
DEBUG - 2012-01-09 21:58:32 --> Output Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Security Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Input Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 21:58:32 --> Language Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Loader Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 21:58:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Controller Class Initialized
DEBUG - 2012-01-09 21:58:32 --> Pagination Class Initialized
DEBUG - 2012-01-09 21:58:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 21:58:32 --> Final output sent to browser
DEBUG - 2012-01-09 21:58:32 --> Total execution time: 0.6724
DEBUG - 2012-01-09 22:02:26 --> Config Class Initialized
DEBUG - 2012-01-09 22:02:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:02:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:02:26 --> URI Class Initialized
DEBUG - 2012-01-09 22:02:26 --> Router Class Initialized
DEBUG - 2012-01-09 22:02:26 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:02:27 --> Output Class Initialized
DEBUG - 2012-01-09 22:02:27 --> Security Class Initialized
DEBUG - 2012-01-09 22:02:27 --> Input Class Initialized
DEBUG - 2012-01-09 22:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:02:27 --> Language Class Initialized
DEBUG - 2012-01-09 22:02:27 --> Loader Class Initialized
DEBUG - 2012-01-09 22:02:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:02:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:02:27 --> Controller Class Initialized
DEBUG - 2012-01-09 22:02:27 --> Pagination Class Initialized
ERROR - 2012-01-09 22:02:27 --> Severity: Notice  --> Undefined property: Home::$articles A:\home\codeigniter.blog\www\application\controllers\user\home.php 11
DEBUG - 2012-01-09 22:03:38 --> Config Class Initialized
DEBUG - 2012-01-09 22:03:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:03:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:03:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:03:38 --> URI Class Initialized
DEBUG - 2012-01-09 22:03:38 --> Router Class Initialized
DEBUG - 2012-01-09 22:03:38 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:03:38 --> Output Class Initialized
DEBUG - 2012-01-09 22:03:39 --> Security Class Initialized
DEBUG - 2012-01-09 22:03:39 --> Input Class Initialized
DEBUG - 2012-01-09 22:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:03:39 --> Language Class Initialized
DEBUG - 2012-01-09 22:03:39 --> Loader Class Initialized
DEBUG - 2012-01-09 22:03:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:03:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:03:39 --> Controller Class Initialized
DEBUG - 2012-01-09 22:03:39 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Config Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:06:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:06:01 --> URI Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Router Class Initialized
DEBUG - 2012-01-09 22:06:01 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:06:01 --> Output Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Security Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Input Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:06:01 --> Language Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Loader Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:06:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:06:01 --> Controller Class Initialized
DEBUG - 2012-01-09 22:06:02 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Config Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:06:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:06:37 --> URI Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Router Class Initialized
DEBUG - 2012-01-09 22:06:37 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:06:37 --> Output Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Security Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Input Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:06:37 --> Language Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Loader Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:06:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Controller Class Initialized
DEBUG - 2012-01-09 22:06:37 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Config Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:06:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:06:55 --> URI Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Router Class Initialized
DEBUG - 2012-01-09 22:06:55 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:06:55 --> Output Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Security Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Input Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:06:55 --> Language Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Loader Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:06:55 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Controller Class Initialized
DEBUG - 2012-01-09 22:06:55 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Config Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:08:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:08:03 --> URI Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Router Class Initialized
DEBUG - 2012-01-09 22:08:03 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:08:03 --> Output Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Security Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Input Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:08:03 --> Language Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Loader Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:08:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Controller Class Initialized
DEBUG - 2012-01-09 22:08:03 --> Pagination Class Initialized
ERROR - 2012-01-09 22:08:03 --> Severity: Notice  --> Undefined variable: id A:\home\codeigniter.blog\www\application\controllers\user\home.php 24
DEBUG - 2012-01-09 22:08:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:08:03 --> Final output sent to browser
DEBUG - 2012-01-09 22:08:03 --> Total execution time: 0.9587
DEBUG - 2012-01-09 22:08:36 --> Config Class Initialized
DEBUG - 2012-01-09 22:08:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:08:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:08:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:08:37 --> URI Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Router Class Initialized
DEBUG - 2012-01-09 22:08:37 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:08:37 --> Output Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Security Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Input Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:08:37 --> Language Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Loader Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:08:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Controller Class Initialized
DEBUG - 2012-01-09 22:08:37 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:08:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:08:37 --> Final output sent to browser
DEBUG - 2012-01-09 22:08:37 --> Total execution time: 0.3669
DEBUG - 2012-01-09 22:08:40 --> Config Class Initialized
DEBUG - 2012-01-09 22:08:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:08:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:08:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:08:40 --> URI Class Initialized
DEBUG - 2012-01-09 22:08:40 --> Router Class Initialized
ERROR - 2012-01-09 22:08:40 --> 404 Page Not Found --> 2
DEBUG - 2012-01-09 22:09:25 --> Config Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:09:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:09:25 --> URI Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Router Class Initialized
DEBUG - 2012-01-09 22:09:25 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:09:25 --> Output Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Security Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Input Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:09:25 --> Language Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Loader Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:09:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Controller Class Initialized
DEBUG - 2012-01-09 22:09:25 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:09:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:09:25 --> Final output sent to browser
DEBUG - 2012-01-09 22:09:25 --> Total execution time: 0.3220
DEBUG - 2012-01-09 22:09:28 --> Config Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:09:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:09:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Router Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Output Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:09:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:09:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:09:28 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:09:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:09:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:09:28 --> Total execution time: 0.3799
DEBUG - 2012-01-09 22:09:30 --> Config Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:09:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:09:30 --> URI Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Router Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Output Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Security Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Input Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:09:30 --> Language Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Loader Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:09:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Controller Class Initialized
DEBUG - 2012-01-09 22:09:30 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:09:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:09:30 --> Final output sent to browser
DEBUG - 2012-01-09 22:09:30 --> Total execution time: 0.3969
DEBUG - 2012-01-09 22:09:33 --> Config Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:09:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:09:33 --> URI Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Router Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Output Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Security Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Input Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:09:33 --> Language Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Loader Class Initialized
DEBUG - 2012-01-09 22:09:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:09:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:09:34 --> Controller Class Initialized
DEBUG - 2012-01-09 22:09:34 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:09:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:09:34 --> Final output sent to browser
DEBUG - 2012-01-09 22:09:34 --> Total execution time: 0.8023
DEBUG - 2012-01-09 22:09:35 --> Config Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:09:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:09:35 --> URI Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Router Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Output Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Security Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Input Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:09:35 --> Language Class Initialized
DEBUG - 2012-01-09 22:09:35 --> Loader Class Initialized
DEBUG - 2012-01-09 22:09:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:09:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:09:36 --> Controller Class Initialized
DEBUG - 2012-01-09 22:09:36 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:09:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:09:36 --> Final output sent to browser
DEBUG - 2012-01-09 22:09:36 --> Total execution time: 0.4111
DEBUG - 2012-01-09 22:09:58 --> Config Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:09:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:09:58 --> URI Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Router Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Output Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Security Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Input Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:09:58 --> Language Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Loader Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:09:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Controller Class Initialized
DEBUG - 2012-01-09 22:09:58 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:09:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:09:58 --> Final output sent to browser
DEBUG - 2012-01-09 22:09:58 --> Total execution time: 0.3474
DEBUG - 2012-01-09 22:10:01 --> Config Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:10:01 --> URI Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Router Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Output Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Security Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Input Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:10:01 --> Language Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Loader Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:10:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Controller Class Initialized
DEBUG - 2012-01-09 22:10:01 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:10:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:10:01 --> Final output sent to browser
DEBUG - 2012-01-09 22:10:01 --> Total execution time: 0.3506
DEBUG - 2012-01-09 22:10:03 --> Config Class Initialized
DEBUG - 2012-01-09 22:10:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:10:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:10:04 --> URI Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Router Class Initialized
DEBUG - 2012-01-09 22:10:04 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:10:04 --> Output Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Security Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Input Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:10:04 --> Language Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Loader Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:10:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Controller Class Initialized
DEBUG - 2012-01-09 22:10:04 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:10:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:10:04 --> Final output sent to browser
DEBUG - 2012-01-09 22:10:04 --> Total execution time: 0.3686
DEBUG - 2012-01-09 22:10:05 --> Config Class Initialized
DEBUG - 2012-01-09 22:10:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:10:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:10:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:10:05 --> URI Class Initialized
DEBUG - 2012-01-09 22:10:05 --> Router Class Initialized
DEBUG - 2012-01-09 22:10:05 --> Output Class Initialized
DEBUG - 2012-01-09 22:10:05 --> Security Class Initialized
DEBUG - 2012-01-09 22:10:05 --> Input Class Initialized
DEBUG - 2012-01-09 22:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:10:05 --> Language Class Initialized
DEBUG - 2012-01-09 22:10:06 --> Loader Class Initialized
DEBUG - 2012-01-09 22:10:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:10:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:10:06 --> Controller Class Initialized
DEBUG - 2012-01-09 22:10:06 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:10:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:10:06 --> Final output sent to browser
DEBUG - 2012-01-09 22:10:06 --> Total execution time: 0.4050
DEBUG - 2012-01-09 22:10:07 --> Config Class Initialized
DEBUG - 2012-01-09 22:10:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:10:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:10:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:10:08 --> URI Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Router Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Output Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Security Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Input Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:10:08 --> Language Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Loader Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:10:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Controller Class Initialized
DEBUG - 2012-01-09 22:10:08 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:10:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:10:08 --> Final output sent to browser
DEBUG - 2012-01-09 22:10:08 --> Total execution time: 0.4303
DEBUG - 2012-01-09 22:10:10 --> Config Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:10:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:10:10 --> URI Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Router Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Output Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Security Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Input Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:10:10 --> Language Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Loader Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:10:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Controller Class Initialized
DEBUG - 2012-01-09 22:10:10 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:10:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:10:10 --> Final output sent to browser
DEBUG - 2012-01-09 22:10:10 --> Total execution time: 0.4292
DEBUG - 2012-01-09 22:11:21 --> Config Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:11:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:11:21 --> URI Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Router Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Output Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Security Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Input Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:11:21 --> Language Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Loader Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:11:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Controller Class Initialized
DEBUG - 2012-01-09 22:11:21 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:11:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:11:21 --> Final output sent to browser
DEBUG - 2012-01-09 22:11:21 --> Total execution time: 0.3869
DEBUG - 2012-01-09 22:12:11 --> Config Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:12:11 --> URI Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Router Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Output Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Security Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Input Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:12:11 --> Language Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Loader Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:12:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Controller Class Initialized
DEBUG - 2012-01-09 22:12:11 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:12:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:12:11 --> Final output sent to browser
DEBUG - 2012-01-09 22:12:11 --> Total execution time: 0.4141
DEBUG - 2012-01-09 22:12:35 --> Config Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:12:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:12:35 --> URI Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Router Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Output Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Security Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Input Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:12:35 --> Language Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Loader Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:12:35 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Controller Class Initialized
DEBUG - 2012-01-09 22:12:35 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:12:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:12:36 --> Final output sent to browser
DEBUG - 2012-01-09 22:12:36 --> Total execution time: 0.4118
DEBUG - 2012-01-09 22:12:44 --> Config Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:12:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:12:44 --> URI Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Router Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Output Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Security Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Input Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:12:44 --> Language Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Loader Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:12:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Controller Class Initialized
DEBUG - 2012-01-09 22:12:44 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:12:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:12:44 --> Final output sent to browser
DEBUG - 2012-01-09 22:12:44 --> Total execution time: 0.3887
DEBUG - 2012-01-09 22:12:46 --> Config Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:12:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:12:46 --> URI Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Router Class Initialized
DEBUG - 2012-01-09 22:12:46 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:12:46 --> Output Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Security Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Input Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:12:46 --> Language Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Loader Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:12:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Controller Class Initialized
DEBUG - 2012-01-09 22:12:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:12:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:12:46 --> Final output sent to browser
DEBUG - 2012-01-09 22:12:46 --> Total execution time: 0.3599
DEBUG - 2012-01-09 22:12:48 --> Config Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:12:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:12:48 --> URI Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Router Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Output Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Security Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Input Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:12:48 --> Language Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Loader Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:12:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Controller Class Initialized
DEBUG - 2012-01-09 22:12:48 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:12:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:12:48 --> Final output sent to browser
DEBUG - 2012-01-09 22:12:48 --> Total execution time: 0.3852
DEBUG - 2012-01-09 22:12:50 --> Config Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:12:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:12:50 --> URI Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Router Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Output Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Security Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Input Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:12:50 --> Language Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Loader Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:12:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Controller Class Initialized
DEBUG - 2012-01-09 22:12:50 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:12:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:12:50 --> Final output sent to browser
DEBUG - 2012-01-09 22:12:50 --> Total execution time: 0.3948
DEBUG - 2012-01-09 22:12:52 --> Config Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:12:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:12:52 --> URI Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Router Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Output Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Security Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Input Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:12:52 --> Language Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Loader Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:12:52 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Controller Class Initialized
DEBUG - 2012-01-09 22:12:52 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:12:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:12:52 --> Final output sent to browser
DEBUG - 2012-01-09 22:12:52 --> Total execution time: 0.3854
DEBUG - 2012-01-09 22:13:38 --> Config Class Initialized
DEBUG - 2012-01-09 22:13:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:13:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:13:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:13:38 --> URI Class Initialized
DEBUG - 2012-01-09 22:13:38 --> Router Class Initialized
DEBUG - 2012-01-09 22:13:38 --> Output Class Initialized
DEBUG - 2012-01-09 22:13:38 --> Security Class Initialized
DEBUG - 2012-01-09 22:13:38 --> Input Class Initialized
DEBUG - 2012-01-09 22:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:13:39 --> Language Class Initialized
DEBUG - 2012-01-09 22:13:39 --> Loader Class Initialized
DEBUG - 2012-01-09 22:13:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:13:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:13:39 --> Controller Class Initialized
DEBUG - 2012-01-09 22:13:39 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:13:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:13:39 --> Final output sent to browser
DEBUG - 2012-01-09 22:13:39 --> Total execution time: 0.5622
DEBUG - 2012-01-09 22:13:41 --> Config Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:13:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:13:41 --> URI Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Router Class Initialized
DEBUG - 2012-01-09 22:13:41 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:13:41 --> Output Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Security Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Input Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:13:41 --> Language Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Loader Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:13:41 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Controller Class Initialized
DEBUG - 2012-01-09 22:13:41 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:13:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:13:41 --> Final output sent to browser
DEBUG - 2012-01-09 22:13:41 --> Total execution time: 0.5828
DEBUG - 2012-01-09 22:13:43 --> Config Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:13:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:13:43 --> URI Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Router Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Output Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Security Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Input Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:13:43 --> Language Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Loader Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:13:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Controller Class Initialized
DEBUG - 2012-01-09 22:13:43 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:13:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:13:43 --> Final output sent to browser
DEBUG - 2012-01-09 22:13:43 --> Total execution time: 0.4458
DEBUG - 2012-01-09 22:13:44 --> Config Class Initialized
DEBUG - 2012-01-09 22:13:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:13:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:13:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:13:44 --> URI Class Initialized
DEBUG - 2012-01-09 22:13:44 --> Router Class Initialized
DEBUG - 2012-01-09 22:13:44 --> Output Class Initialized
DEBUG - 2012-01-09 22:13:44 --> Security Class Initialized
DEBUG - 2012-01-09 22:13:44 --> Input Class Initialized
DEBUG - 2012-01-09 22:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:13:45 --> Language Class Initialized
DEBUG - 2012-01-09 22:13:45 --> Loader Class Initialized
DEBUG - 2012-01-09 22:13:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:13:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:13:45 --> Controller Class Initialized
DEBUG - 2012-01-09 22:13:45 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:13:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:13:45 --> Final output sent to browser
DEBUG - 2012-01-09 22:13:45 --> Total execution time: 0.3838
DEBUG - 2012-01-09 22:14:56 --> Config Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:14:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:14:56 --> URI Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Router Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Output Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Security Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Input Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:14:56 --> Language Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Loader Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:14:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Controller Class Initialized
DEBUG - 2012-01-09 22:14:56 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:14:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:14:56 --> Final output sent to browser
DEBUG - 2012-01-09 22:14:56 --> Total execution time: 0.4059
DEBUG - 2012-01-09 22:14:58 --> Config Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:14:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:14:58 --> URI Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Router Class Initialized
DEBUG - 2012-01-09 22:14:58 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:14:58 --> Output Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Security Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Input Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:14:58 --> Language Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Loader Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:14:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Controller Class Initialized
DEBUG - 2012-01-09 22:14:58 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:14:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:14:58 --> Final output sent to browser
DEBUG - 2012-01-09 22:14:58 --> Total execution time: 0.3578
DEBUG - 2012-01-09 22:14:59 --> Config Class Initialized
DEBUG - 2012-01-09 22:14:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:14:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:14:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:15:00 --> URI Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Router Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Output Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Security Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Input Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:15:00 --> Language Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Loader Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:15:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Controller Class Initialized
DEBUG - 2012-01-09 22:15:00 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:15:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:15:00 --> Final output sent to browser
DEBUG - 2012-01-09 22:15:00 --> Total execution time: 0.3893
DEBUG - 2012-01-09 22:15:01 --> Config Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:15:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:15:01 --> URI Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Router Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Output Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Security Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Input Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:15:01 --> Language Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Loader Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:15:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Controller Class Initialized
DEBUG - 2012-01-09 22:15:01 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:15:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:15:01 --> Final output sent to browser
DEBUG - 2012-01-09 22:15:01 --> Total execution time: 0.8006
DEBUG - 2012-01-09 22:15:03 --> Config Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:15:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:15:03 --> URI Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Router Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Output Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Security Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Input Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:15:03 --> Language Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Loader Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:15:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Controller Class Initialized
DEBUG - 2012-01-09 22:15:03 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:15:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:15:03 --> Final output sent to browser
DEBUG - 2012-01-09 22:15:03 --> Total execution time: 0.3909
DEBUG - 2012-01-09 22:15:07 --> Config Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:15:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:15:07 --> URI Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Router Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Output Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Security Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Input Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:15:07 --> Language Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Loader Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:15:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:15:07 --> Controller Class Initialized
DEBUG - 2012-01-09 22:15:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:15:07 --> Final output sent to browser
DEBUG - 2012-01-09 22:15:07 --> Total execution time: 0.3424
DEBUG - 2012-01-09 22:15:08 --> Config Class Initialized
DEBUG - 2012-01-09 22:15:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:15:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:15:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:15:09 --> URI Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Router Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Output Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Security Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Input Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:15:09 --> Language Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Loader Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:15:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:15:09 --> Controller Class Initialized
DEBUG - 2012-01-09 22:15:09 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:15:09 --> Final output sent to browser
DEBUG - 2012-01-09 22:15:09 --> Total execution time: 0.3495
DEBUG - 2012-01-09 22:15:10 --> Config Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:15:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:15:10 --> URI Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Router Class Initialized
DEBUG - 2012-01-09 22:15:10 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:15:10 --> Output Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Security Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Input Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:15:10 --> Language Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Loader Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:15:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Controller Class Initialized
DEBUG - 2012-01-09 22:15:10 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:15:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:15:10 --> Final output sent to browser
DEBUG - 2012-01-09 22:15:10 --> Total execution time: 0.4329
DEBUG - 2012-01-09 22:16:46 --> Config Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:16:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:16:46 --> URI Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Router Class Initialized
DEBUG - 2012-01-09 22:16:46 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:16:46 --> Output Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Security Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Input Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:16:46 --> Language Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Loader Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:16:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Controller Class Initialized
DEBUG - 2012-01-09 22:16:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:16:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:16:46 --> Final output sent to browser
DEBUG - 2012-01-09 22:16:46 --> Total execution time: 0.3332
DEBUG - 2012-01-09 22:16:48 --> Config Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:16:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:16:48 --> URI Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Router Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Output Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Security Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Input Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:16:48 --> Language Class Initialized
DEBUG - 2012-01-09 22:16:48 --> Loader Class Initialized
DEBUG - 2012-01-09 22:16:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:16:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:16:49 --> Controller Class Initialized
DEBUG - 2012-01-09 22:16:49 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:16:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:16:49 --> Final output sent to browser
DEBUG - 2012-01-09 22:16:49 --> Total execution time: 0.3738
DEBUG - 2012-01-09 22:16:50 --> Config Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:16:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:16:50 --> URI Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Router Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Output Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Security Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Input Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:16:50 --> Language Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Loader Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:16:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Controller Class Initialized
DEBUG - 2012-01-09 22:16:50 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:16:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:16:50 --> Final output sent to browser
DEBUG - 2012-01-09 22:16:50 --> Total execution time: 0.4481
DEBUG - 2012-01-09 22:16:52 --> Config Class Initialized
DEBUG - 2012-01-09 22:16:52 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:16:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:16:52 --> URI Class Initialized
DEBUG - 2012-01-09 22:16:52 --> Router Class Initialized
DEBUG - 2012-01-09 22:16:52 --> Output Class Initialized
DEBUG - 2012-01-09 22:16:52 --> Security Class Initialized
DEBUG - 2012-01-09 22:16:52 --> Input Class Initialized
DEBUG - 2012-01-09 22:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:16:53 --> Language Class Initialized
DEBUG - 2012-01-09 22:16:53 --> Loader Class Initialized
DEBUG - 2012-01-09 22:16:53 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:16:53 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:16:53 --> Controller Class Initialized
DEBUG - 2012-01-09 22:16:53 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:16:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:16:53 --> Final output sent to browser
DEBUG - 2012-01-09 22:16:53 --> Total execution time: 0.3683
DEBUG - 2012-01-09 22:16:54 --> Config Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:16:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:16:54 --> URI Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Router Class Initialized
DEBUG - 2012-01-09 22:16:54 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:16:54 --> Output Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Security Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Input Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:16:54 --> Language Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Loader Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:16:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Controller Class Initialized
DEBUG - 2012-01-09 22:16:54 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:16:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:16:55 --> Final output sent to browser
DEBUG - 2012-01-09 22:16:55 --> Total execution time: 0.6044
DEBUG - 2012-01-09 22:16:58 --> Config Class Initialized
DEBUG - 2012-01-09 22:16:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:16:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:16:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:16:58 --> URI Class Initialized
DEBUG - 2012-01-09 22:16:58 --> Router Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Output Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Security Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Input Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:16:59 --> Language Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Loader Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:16:59 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Controller Class Initialized
DEBUG - 2012-01-09 22:16:59 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:16:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:16:59 --> Final output sent to browser
DEBUG - 2012-01-09 22:16:59 --> Total execution time: 0.4292
DEBUG - 2012-01-09 22:17:00 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:01 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:01 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:01 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:01 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:01 --> Total execution time: 0.3458
DEBUG - 2012-01-09 22:17:02 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:02 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:02 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:17:02 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:02 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:02 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:03 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:03 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:03 --> Total execution time: 0.4332
DEBUG - 2012-01-09 22:17:04 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:04 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:04 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:04 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:04 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:04 --> Total execution time: 0.3745
DEBUG - 2012-01-09 22:17:06 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:06 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:06 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:07 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:07 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:07 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:07 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:07 --> Total execution time: 0.5869
DEBUG - 2012-01-09 22:17:09 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:10 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:10 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:10 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:10 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:17:10 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:10 --> Total execution time: 0.3185
DEBUG - 2012-01-09 22:17:11 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:12 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:12 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:12 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:12 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:17:12 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:12 --> Total execution time: 0.7627
DEBUG - 2012-01-09 22:17:13 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:13 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:13 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:13 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:17:13 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:13 --> Total execution time: 0.3194
DEBUG - 2012-01-09 22:17:14 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:14 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:14 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:14 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:14 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:14 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:17:14 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:14 --> Total execution time: 0.3429
DEBUG - 2012-01-09 22:17:16 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:16 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:16 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:16 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:17:16 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:16 --> Total execution time: 0.3154
DEBUG - 2012-01-09 22:17:17 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:17 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:17 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:17 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:18 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:17:18 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:18 --> Total execution time: 0.7813
DEBUG - 2012-01-09 22:17:19 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:19 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:19 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:19 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:19 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:17:19 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:19 --> Total execution time: 0.4254
DEBUG - 2012-01-09 22:17:21 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:21 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:21 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:21 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:17:21 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:21 --> Total execution time: 0.3209
DEBUG - 2012-01-09 22:17:23 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:23 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:23 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:23 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:23 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:17:23 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:23 --> Total execution time: 0.3592
DEBUG - 2012-01-09 22:17:25 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:25 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:25 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:25 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:25 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:17:25 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:25 --> Total execution time: 0.3280
DEBUG - 2012-01-09 22:17:26 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:26 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:26 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:17:26 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:26 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:26 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:26 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:26 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:26 --> Total execution time: 0.4237
DEBUG - 2012-01-09 22:17:28 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:28 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:28 --> Total execution time: 0.5102
DEBUG - 2012-01-09 22:17:29 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:29 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:30 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:30 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:30 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:30 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:30 --> Total execution time: 0.3443
DEBUG - 2012-01-09 22:17:32 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:32 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:32 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:32 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:32 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:32 --> Total execution time: 0.3415
DEBUG - 2012-01-09 22:17:33 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:33 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:33 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:17:33 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:33 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:34 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:34 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:34 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:34 --> Total execution time: 0.7989
DEBUG - 2012-01-09 22:17:35 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:36 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:36 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:36 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:36 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:36 --> Total execution time: 0.3755
DEBUG - 2012-01-09 22:17:37 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:37 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:37 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:37 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:37 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:37 --> Total execution time: 0.4628
DEBUG - 2012-01-09 22:17:40 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:40 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:40 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:40 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:40 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:41 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:41 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:41 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:41 --> Total execution time: 0.9708
DEBUG - 2012-01-09 22:17:44 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:44 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:44 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:17:44 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:44 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:44 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:44 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:44 --> Total execution time: 0.3424
DEBUG - 2012-01-09 22:17:45 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:46 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:46 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:46 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:46 --> Total execution time: 0.9016
DEBUG - 2012-01-09 22:17:47 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:47 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:47 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:48 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:48 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:48 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:48 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:48 --> Total execution time: 0.3484
DEBUG - 2012-01-09 22:17:50 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:50 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:50 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:50 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:50 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:17:50 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:50 --> Total execution time: 0.3980
DEBUG - 2012-01-09 22:17:51 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:52 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:52 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:17:52 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:52 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:52 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:52 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:52 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:52 --> Total execution time: 0.3839
DEBUG - 2012-01-09 22:17:54 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:54 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:54 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:54 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:54 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:54 --> Total execution time: 0.3609
DEBUG - 2012-01-09 22:17:55 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:55 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:55 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:55 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:55 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:55 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:55 --> Total execution time: 0.3557
DEBUG - 2012-01-09 22:17:57 --> Config Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:17:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:17:57 --> URI Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Router Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Output Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Security Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Input Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:17:57 --> Language Class Initialized
DEBUG - 2012-01-09 22:17:57 --> Loader Class Initialized
DEBUG - 2012-01-09 22:17:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:17:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:17:58 --> Controller Class Initialized
DEBUG - 2012-01-09 22:17:58 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:17:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:17:58 --> Final output sent to browser
DEBUG - 2012-01-09 22:17:58 --> Total execution time: 0.4175
DEBUG - 2012-01-09 22:18:01 --> Config Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:18:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:18:02 --> URI Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Router Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Output Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Security Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Input Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:18:02 --> Language Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Loader Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:18:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:18:02 --> Controller Class Initialized
DEBUG - 2012-01-09 22:18:02 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:18:02 --> Final output sent to browser
DEBUG - 2012-01-09 22:18:02 --> Total execution time: 0.3438
DEBUG - 2012-01-09 22:18:05 --> Config Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:18:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:18:05 --> URI Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Router Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Output Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Security Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Input Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:18:05 --> Language Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Loader Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:18:05 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:18:05 --> Controller Class Initialized
DEBUG - 2012-01-09 22:18:05 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:18:05 --> Final output sent to browser
DEBUG - 2012-01-09 22:18:05 --> Total execution time: 0.4140
DEBUG - 2012-01-09 22:18:07 --> Config Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:18:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:18:07 --> URI Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Router Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Output Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Security Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Input Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:18:07 --> Language Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Loader Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:18:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:18:07 --> Controller Class Initialized
DEBUG - 2012-01-09 22:18:07 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:18:07 --> Final output sent to browser
DEBUG - 2012-01-09 22:18:07 --> Total execution time: 0.3294
DEBUG - 2012-01-09 22:18:09 --> Config Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:18:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:18:09 --> URI Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Router Class Initialized
DEBUG - 2012-01-09 22:18:09 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:18:09 --> Output Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Security Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Input Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:18:09 --> Language Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Loader Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:18:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Controller Class Initialized
DEBUG - 2012-01-09 22:18:09 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:18:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:18:09 --> Final output sent to browser
DEBUG - 2012-01-09 22:18:09 --> Total execution time: 0.3882
DEBUG - 2012-01-09 22:18:12 --> Config Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:18:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:18:12 --> URI Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Router Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Output Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Security Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Input Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:18:12 --> Language Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Loader Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:18:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Controller Class Initialized
DEBUG - 2012-01-09 22:18:12 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:18:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:18:12 --> Final output sent to browser
DEBUG - 2012-01-09 22:18:12 --> Total execution time: 0.3533
DEBUG - 2012-01-09 22:18:13 --> Config Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:18:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:18:13 --> URI Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Router Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Output Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Security Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Input Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:18:13 --> Language Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Loader Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:18:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Controller Class Initialized
DEBUG - 2012-01-09 22:18:13 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:18:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:18:14 --> Final output sent to browser
DEBUG - 2012-01-09 22:18:14 --> Total execution time: 0.3790
DEBUG - 2012-01-09 22:19:12 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:12 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:12 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:13 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:13 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:13 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:13 --> Total execution time: 0.3878
DEBUG - 2012-01-09 22:19:15 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:15 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:15 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:15 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:15 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:15 --> Total execution time: 0.4027
DEBUG - 2012-01-09 22:19:17 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:17 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:17 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:19:17 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:17 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:17 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:17 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:17 --> Total execution time: 0.4451
DEBUG - 2012-01-09 22:19:19 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:19 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:19 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:19 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:19 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:19 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:19 --> Total execution time: 0.3315
DEBUG - 2012-01-09 22:19:20 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:20 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:20 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:21 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:21 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:21 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:21 --> Total execution time: 0.3911
DEBUG - 2012-01-09 22:19:22 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:22 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:23 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:23 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:23 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:23 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:23 --> Total execution time: 0.3854
DEBUG - 2012-01-09 22:19:25 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:25 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:25 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:19:25 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:25 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:25 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:25 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:25 --> Total execution time: 0.3950
DEBUG - 2012-01-09 22:19:27 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:27 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:27 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:27 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:27 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:27 --> Total execution time: 0.3642
DEBUG - 2012-01-09 22:19:30 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:30 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:31 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:31 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:31 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:31 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:31 --> Total execution time: 0.4506
DEBUG - 2012-01-09 22:19:32 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:32 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:32 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:32 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:32 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:32 --> Total execution time: 0.3681
DEBUG - 2012-01-09 22:19:34 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:34 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:34 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:19:34 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:34 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:34 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:34 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:34 --> Total execution time: 0.3662
DEBUG - 2012-01-09 22:19:36 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:36 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:36 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:36 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:37 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:37 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:19:37 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:37 --> Total execution time: 0.9076
DEBUG - 2012-01-09 22:19:38 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:38 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:38 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:38 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:38 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:19:38 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:38 --> Total execution time: 0.3292
DEBUG - 2012-01-09 22:19:39 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:39 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:39 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:39 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:39 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:19:39 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:39 --> Total execution time: 0.3752
DEBUG - 2012-01-09 22:19:40 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:41 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:41 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:19:41 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:41 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:41 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:41 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:41 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:41 --> Total execution time: 0.5043
DEBUG - 2012-01-09 22:19:42 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:42 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:42 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:42 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:42 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:19:42 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:42 --> Total execution time: 0.3709
DEBUG - 2012-01-09 22:19:46 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:47 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:47 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:47 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:47 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:47 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:19:47 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:47 --> Total execution time: 0.8252
DEBUG - 2012-01-09 22:19:50 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:50 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:50 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:50 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:19:50 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:50 --> Total execution time: 0.3522
DEBUG - 2012-01-09 22:19:51 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:51 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:51 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:51 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:51 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:51 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:19:51 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:51 --> Total execution time: 0.3715
DEBUG - 2012-01-09 22:19:53 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:53 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:54 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:54 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:19:54 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:54 --> Total execution time: 0.3687
DEBUG - 2012-01-09 22:19:55 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:55 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:55 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:55 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:55 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:55 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:19:55 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:55 --> Total execution time: 0.3645
DEBUG - 2012-01-09 22:19:56 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:56 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:56 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:19:56 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:56 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:56 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:56 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:56 --> Total execution time: 0.4282
DEBUG - 2012-01-09 22:19:58 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:58 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:58 --> Language Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Loader Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:19:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Controller Class Initialized
DEBUG - 2012-01-09 22:19:58 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:19:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:19:58 --> Final output sent to browser
DEBUG - 2012-01-09 22:19:58 --> Total execution time: 0.3660
DEBUG - 2012-01-09 22:19:59 --> Config Class Initialized
DEBUG - 2012-01-09 22:19:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:19:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:19:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:19:59 --> URI Class Initialized
DEBUG - 2012-01-09 22:19:59 --> Router Class Initialized
DEBUG - 2012-01-09 22:19:59 --> Output Class Initialized
DEBUG - 2012-01-09 22:19:59 --> Security Class Initialized
DEBUG - 2012-01-09 22:19:59 --> Input Class Initialized
DEBUG - 2012-01-09 22:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:19:59 --> Language Class Initialized
DEBUG - 2012-01-09 22:20:00 --> Loader Class Initialized
DEBUG - 2012-01-09 22:20:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:20:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:20:00 --> Controller Class Initialized
DEBUG - 2012-01-09 22:20:00 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:20:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:20:00 --> Final output sent to browser
DEBUG - 2012-01-09 22:20:00 --> Total execution time: 0.3850
DEBUG - 2012-01-09 22:20:59 --> Config Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:20:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:20:59 --> URI Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Router Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Output Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Security Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Input Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:20:59 --> Language Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Loader Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:20:59 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Controller Class Initialized
DEBUG - 2012-01-09 22:20:59 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:20:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:20:59 --> Final output sent to browser
DEBUG - 2012-01-09 22:20:59 --> Total execution time: 0.1651
DEBUG - 2012-01-09 22:21:00 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:00 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:00 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:00 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:21:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:21:00 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:00 --> Total execution time: 0.1342
DEBUG - 2012-01-09 22:21:02 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:02 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:02 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:21:02 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:02 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:02 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:21:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:21:02 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:02 --> Total execution time: 0.1535
DEBUG - 2012-01-09 22:21:03 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:03 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:03 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:03 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:03 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:21:03 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:03 --> Total execution time: 0.1635
DEBUG - 2012-01-09 22:21:04 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:05 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:05 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:21:05 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:05 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:05 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:21:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:21:05 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:05 --> Total execution time: 0.1884
DEBUG - 2012-01-09 22:21:05 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:05 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:05 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:05 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:05 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:06 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:21:06 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:06 --> Total execution time: 0.1484
DEBUG - 2012-01-09 22:21:06 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:06 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:06 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:06 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:06 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:21:06 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:06 --> Total execution time: 0.1263
DEBUG - 2012-01-09 22:21:08 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:08 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:08 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:08 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:21:08 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:08 --> Total execution time: 0.1540
DEBUG - 2012-01-09 22:21:09 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:09 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:09 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:09 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:21:09 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:09 --> Total execution time: 0.1313
DEBUG - 2012-01-09 22:21:10 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:10 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:10 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:10 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:11 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:21:11 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:11 --> Total execution time: 0.1259
DEBUG - 2012-01-09 22:21:12 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:12 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:12 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:21:12 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:12 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:12 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:21:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:21:12 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:12 --> Total execution time: 0.2093
DEBUG - 2012-01-09 22:21:14 --> Config Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:21:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:21:14 --> URI Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Router Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Output Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Security Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Input Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:21:14 --> Language Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Loader Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:21:14 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:21:14 --> Controller Class Initialized
DEBUG - 2012-01-09 22:21:14 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:21:14 --> Final output sent to browser
DEBUG - 2012-01-09 22:21:14 --> Total execution time: 0.1568
DEBUG - 2012-01-09 22:22:37 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:37 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:37 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:22:37 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:37 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:37 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:37 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:37 --> Total execution time: 0.2079
DEBUG - 2012-01-09 22:22:38 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:38 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:38 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:38 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:38 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:22:38 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:38 --> Total execution time: 0.1530
DEBUG - 2012-01-09 22:22:39 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:39 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:39 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:39 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:39 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:22:39 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:39 --> Total execution time: 0.1796
DEBUG - 2012-01-09 22:22:40 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:40 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:40 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:40 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:40 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:22:40 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:40 --> Total execution time: 0.1617
DEBUG - 2012-01-09 22:22:41 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:41 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:41 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:41 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:41 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:22:41 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:41 --> Total execution time: 0.1393
DEBUG - 2012-01-09 22:22:42 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:42 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:42 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:42 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:42 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:22:42 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:42 --> Total execution time: 0.2443
DEBUG - 2012-01-09 22:22:43 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:43 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:43 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:43 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:22:43 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:43 --> Total execution time: 0.1263
DEBUG - 2012-01-09 22:22:45 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:45 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:45 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:22:45 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:45 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:45 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:45 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:45 --> Total execution time: 0.2278
DEBUG - 2012-01-09 22:22:46 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:46 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:46 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:46 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:46 --> Total execution time: 0.1506
DEBUG - 2012-01-09 22:22:48 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:48 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:48 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:48 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:48 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:48 --> Total execution time: 0.1621
DEBUG - 2012-01-09 22:22:49 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:49 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:49 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:49 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:49 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:49 --> Total execution time: 0.1514
DEBUG - 2012-01-09 22:22:50 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:50 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:50 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:22:50 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:50 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:51 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:51 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:51 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:51 --> Total execution time: 0.1582
DEBUG - 2012-01-09 22:22:52 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:52 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:52 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:52 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:52 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:52 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:52 --> Total execution time: 0.1665
DEBUG - 2012-01-09 22:22:53 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:53 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:53 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:53 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:53 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:53 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:53 --> Total execution time: 0.2327
DEBUG - 2012-01-09 22:22:54 --> Config Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:22:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:22:54 --> URI Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Router Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Output Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Security Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Input Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:22:54 --> Language Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Loader Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:22:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Controller Class Initialized
DEBUG - 2012-01-09 22:22:54 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:22:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:22:54 --> Final output sent to browser
DEBUG - 2012-01-09 22:22:54 --> Total execution time: 0.2355
DEBUG - 2012-01-09 22:23:01 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:01 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:01 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:01 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:02 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:02 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:23:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:23:02 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:02 --> Total execution time: 0.1815
DEBUG - 2012-01-09 22:23:07 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:07 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:07 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:07 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:23:07 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:07 --> Total execution time: 0.1449
DEBUG - 2012-01-09 22:23:08 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:08 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:08 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:08 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:23:08 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:08 --> Total execution time: 0.1300
DEBUG - 2012-01-09 22:23:10 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:10 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:10 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:10 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:10 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:23:10 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:10 --> Total execution time: 0.1645
DEBUG - 2012-01-09 22:23:11 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:11 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:11 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:11 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:23:11 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:11 --> Total execution time: 0.2063
DEBUG - 2012-01-09 22:23:15 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:15 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:15 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:23:15 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:15 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:15 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:23:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:23:15 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:15 --> Total execution time: 0.1446
DEBUG - 2012-01-09 22:23:17 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:17 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:17 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:17 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:23:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:23:17 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:17 --> Total execution time: 0.1717
DEBUG - 2012-01-09 22:23:20 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:20 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:20 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:20 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:23:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:23:20 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:20 --> Total execution time: 0.1385
DEBUG - 2012-01-09 22:23:28 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Router Class Initialized
DEBUG - 2012-01-09 22:23:28 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:23:28 --> Output Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:23:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:23:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:23:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:23:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:23:28 --> Total execution time: 0.1428
DEBUG - 2012-01-09 22:23:28 --> Config Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:23:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:23:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:23:28 --> Router Class Initialized
ERROR - 2012-01-09 22:23:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:25:52 --> Config Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:25:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:25:52 --> URI Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Router Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Output Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Security Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Input Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:25:52 --> Language Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Loader Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:25:52 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Controller Class Initialized
DEBUG - 2012-01-09 22:25:52 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:25:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:25:52 --> Final output sent to browser
DEBUG - 2012-01-09 22:25:52 --> Total execution time: 0.1527
DEBUG - 2012-01-09 22:25:54 --> Config Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:25:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:25:54 --> URI Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Router Class Initialized
DEBUG - 2012-01-09 22:25:54 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:25:54 --> Output Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Security Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Input Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:25:54 --> Language Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Loader Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:25:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Controller Class Initialized
DEBUG - 2012-01-09 22:25:54 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:25:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:25:54 --> Final output sent to browser
DEBUG - 2012-01-09 22:25:54 --> Total execution time: 0.2013
DEBUG - 2012-01-09 22:25:56 --> Config Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:25:56 --> URI Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Router Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Output Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Security Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Input Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:25:56 --> Language Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Loader Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:25:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Controller Class Initialized
DEBUG - 2012-01-09 22:25:56 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:25:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:25:56 --> Final output sent to browser
DEBUG - 2012-01-09 22:25:56 --> Total execution time: 0.1759
DEBUG - 2012-01-09 22:25:57 --> Config Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:25:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:25:57 --> URI Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Router Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Output Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Security Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Input Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:25:57 --> Language Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Loader Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:25:57 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Controller Class Initialized
DEBUG - 2012-01-09 22:25:57 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:25:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:25:57 --> Final output sent to browser
DEBUG - 2012-01-09 22:25:57 --> Total execution time: 0.1803
DEBUG - 2012-01-09 22:26:16 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:16 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:16 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:17 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:17 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:26:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:26:17 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:17 --> Total execution time: 0.4660
DEBUG - 2012-01-09 22:26:20 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:20 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:20 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:20 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:26:20 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:20 --> Total execution time: 0.3943
DEBUG - 2012-01-09 22:26:24 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:24 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:24 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:24 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:26:24 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:24 --> Total execution time: 0.3950
DEBUG - 2012-01-09 22:26:26 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:26 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:26 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:26 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:26 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:26:26 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:26 --> Total execution time: 0.4915
DEBUG - 2012-01-09 22:26:30 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:31 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:31 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:31 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:31 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:31 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:26:31 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:31 --> Total execution time: 0.5292
DEBUG - 2012-01-09 22:26:33 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:33 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:33 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:26:33 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:33 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:33 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:33 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:26:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:26:33 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:33 --> Total execution time: 0.5019
DEBUG - 2012-01-09 22:26:35 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:35 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:35 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:35 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:35 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:36 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:36 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:36 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:36 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:36 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:26:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:26:36 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:36 --> Total execution time: 0.5004
DEBUG - 2012-01-09 22:26:49 --> Config Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:26:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:26:49 --> URI Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Router Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Output Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Security Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Input Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:26:49 --> Language Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Loader Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:26:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Controller Class Initialized
DEBUG - 2012-01-09 22:26:49 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:26:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:26:49 --> Final output sent to browser
DEBUG - 2012-01-09 22:26:49 --> Total execution time: 0.3856
DEBUG - 2012-01-09 22:27:00 --> Config Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:27:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:27:00 --> URI Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Router Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Output Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Security Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Input Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:27:00 --> Language Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Loader Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:27:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Controller Class Initialized
DEBUG - 2012-01-09 22:27:00 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:27:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:27:00 --> Final output sent to browser
DEBUG - 2012-01-09 22:27:00 --> Total execution time: 0.4217
DEBUG - 2012-01-09 22:27:19 --> Config Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:27:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:27:19 --> URI Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Router Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Output Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Security Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Input Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:27:19 --> Language Class Initialized
DEBUG - 2012-01-09 22:27:19 --> Loader Class Initialized
DEBUG - 2012-01-09 22:27:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:27:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:27:20 --> Controller Class Initialized
DEBUG - 2012-01-09 22:27:20 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:27:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:27:20 --> Final output sent to browser
DEBUG - 2012-01-09 22:27:20 --> Total execution time: 0.4150
DEBUG - 2012-01-09 22:27:42 --> Config Class Initialized
DEBUG - 2012-01-09 22:27:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:27:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:27:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:27:43 --> URI Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Router Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Output Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Security Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Input Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:27:43 --> Language Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Loader Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:27:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Controller Class Initialized
DEBUG - 2012-01-09 22:27:43 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:27:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:27:43 --> Final output sent to browser
DEBUG - 2012-01-09 22:27:43 --> Total execution time: 0.4402
DEBUG - 2012-01-09 22:27:47 --> Config Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:27:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:27:47 --> URI Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Router Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Output Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Security Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Input Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:27:47 --> Language Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Loader Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:27:47 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Controller Class Initialized
DEBUG - 2012-01-09 22:27:47 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:27:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:27:48 --> Final output sent to browser
DEBUG - 2012-01-09 22:27:48 --> Total execution time: 0.5354
DEBUG - 2012-01-09 22:27:49 --> Config Class Initialized
DEBUG - 2012-01-09 22:27:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:27:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:27:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:27:49 --> URI Class Initialized
DEBUG - 2012-01-09 22:27:49 --> Router Class Initialized
DEBUG - 2012-01-09 22:27:49 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:27:49 --> Output Class Initialized
DEBUG - 2012-01-09 22:27:49 --> Security Class Initialized
DEBUG - 2012-01-09 22:27:50 --> Input Class Initialized
DEBUG - 2012-01-09 22:27:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:27:50 --> Language Class Initialized
DEBUG - 2012-01-09 22:27:50 --> Loader Class Initialized
DEBUG - 2012-01-09 22:27:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:27:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:27:50 --> Controller Class Initialized
DEBUG - 2012-01-09 22:27:50 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:27:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:27:50 --> Final output sent to browser
DEBUG - 2012-01-09 22:27:50 --> Total execution time: 0.4080
DEBUG - 2012-01-09 22:28:25 --> Config Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:28:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:28:25 --> URI Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Router Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Output Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Security Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Input Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:28:25 --> Language Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Loader Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:28:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:28:25 --> Controller Class Initialized
DEBUG - 2012-01-09 22:28:25 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:28:25 --> Final output sent to browser
DEBUG - 2012-01-09 22:28:25 --> Total execution time: 0.3720
DEBUG - 2012-01-09 22:28:59 --> Config Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:28:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:28:59 --> URI Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Router Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Output Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Security Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Input Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:28:59 --> Language Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Loader Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:28:59 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:28:59 --> Controller Class Initialized
DEBUG - 2012-01-09 22:28:59 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:28:59 --> Final output sent to browser
DEBUG - 2012-01-09 22:28:59 --> Total execution time: 0.3812
DEBUG - 2012-01-09 22:29:01 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:01 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:01 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:29:01 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:01 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:01 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:29:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:29:01 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:02 --> Total execution time: 0.5780
DEBUG - 2012-01-09 22:29:04 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:04 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:04 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:04 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:29:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:29:04 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:04 --> Total execution time: 0.4439
DEBUG - 2012-01-09 22:29:06 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:06 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:06 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:06 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:29:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:29:06 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:06 --> Total execution time: 0.6821
DEBUG - 2012-01-09 22:29:09 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:09 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:09 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:09 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:29:09 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:09 --> Total execution time: 0.4899
DEBUG - 2012-01-09 22:29:11 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:11 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:11 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:11 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:29:11 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:11 --> Total execution time: 0.4342
DEBUG - 2012-01-09 22:29:13 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:13 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:13 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:13 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:13 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:29:13 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:13 --> Total execution time: 0.6617
DEBUG - 2012-01-09 22:29:15 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:15 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:15 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:29:15 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:15 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:15 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:29:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:29:15 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:15 --> Total execution time: 0.5509
DEBUG - 2012-01-09 22:29:18 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:18 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:18 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:18 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:29:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:29:18 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:18 --> Total execution time: 0.4560
DEBUG - 2012-01-09 22:29:20 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:20 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:20 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:20 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:29:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:29:20 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:20 --> Total execution time: 0.4335
DEBUG - 2012-01-09 22:29:23 --> Config Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:29:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:29:23 --> URI Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Router Class Initialized
DEBUG - 2012-01-09 22:29:23 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:29:23 --> Output Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Security Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Input Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:29:23 --> Language Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Loader Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:29:23 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Controller Class Initialized
DEBUG - 2012-01-09 22:29:23 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:29:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:29:24 --> Final output sent to browser
DEBUG - 2012-01-09 22:29:24 --> Total execution time: 0.9838
DEBUG - 2012-01-09 22:33:08 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:09 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:09 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:33:09 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:09 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:09 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:09 --> Total execution time: 0.3554
DEBUG - 2012-01-09 22:33:09 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:09 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:09 --> Router Class Initialized
ERROR - 2012-01-09 22:33:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:12 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:12 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:12 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:12 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:12 --> Total execution time: 0.3911
DEBUG - 2012-01-09 22:33:12 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:13 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:13 --> Router Class Initialized
ERROR - 2012-01-09 22:33:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:14 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:14 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:14 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:15 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:15 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:15 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:15 --> Total execution time: 0.3991
DEBUG - 2012-01-09 22:33:15 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:15 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:15 --> Router Class Initialized
ERROR - 2012-01-09 22:33:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:16 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:16 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:16 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:16 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:16 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:33:16 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:16 --> Total execution time: 0.3599
DEBUG - 2012-01-09 22:33:17 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:17 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:17 --> Router Class Initialized
ERROR - 2012-01-09 22:33:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:18 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:18 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:18 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:33:18 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:18 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:18 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:18 --> Total execution time: 0.4849
DEBUG - 2012-01-09 22:33:18 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:18 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:18 --> Router Class Initialized
ERROR - 2012-01-09 22:33:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:19 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:19 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:19 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:19 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:19 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:33:19 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:19 --> Total execution time: 0.4270
DEBUG - 2012-01-09 22:33:20 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:20 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:20 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:20 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Router Class Initialized
ERROR - 2012-01-09 22:33:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:20 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:21 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:21 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:21 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:33:21 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:21 --> Total execution time: 0.4934
DEBUG - 2012-01-09 22:33:21 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:21 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:21 --> Router Class Initialized
ERROR - 2012-01-09 22:33:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:22 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:22 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:22 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:22 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:22 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:33:22 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:22 --> Total execution time: 0.3431
DEBUG - 2012-01-09 22:33:23 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:23 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Router Class Initialized
ERROR - 2012-01-09 22:33:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:23 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:23 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:23 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:23 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:23 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:24 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:33:24 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:24 --> Total execution time: 0.4034
DEBUG - 2012-01-09 22:33:24 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:24 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:24 --> Router Class Initialized
ERROR - 2012-01-09 22:33:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:25 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:25 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:25 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:33:25 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:25 --> Total execution time: 0.3826
DEBUG - 2012-01-09 22:33:25 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:26 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Router Class Initialized
ERROR - 2012-01-09 22:33:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:26 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:26 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:26 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:33:27 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:27 --> Total execution time: 0.3392
DEBUG - 2012-01-09 22:33:27 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:27 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Router Class Initialized
ERROR - 2012-01-09 22:33:27 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:27 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:27 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:27 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:33:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:28 --> Total execution time: 0.3552
DEBUG - 2012-01-09 22:33:28 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:28 --> Router Class Initialized
ERROR - 2012-01-09 22:33:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:29 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:29 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:29 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:29 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:29 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:33:29 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:29 --> Total execution time: 0.3846
DEBUG - 2012-01-09 22:33:29 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:29 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:30 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Router Class Initialized
ERROR - 2012-01-09 22:33:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:30 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:30 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:30 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:33:30 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:30 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:30 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:31 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:31 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:31 --> Total execution time: 0.5684
DEBUG - 2012-01-09 22:33:31 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:31 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:31 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:31 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:31 --> Router Class Initialized
ERROR - 2012-01-09 22:33:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:32 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:32 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:33 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:33 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:33 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:33 --> Total execution time: 0.3857
DEBUG - 2012-01-09 22:33:33 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:33 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:33 --> Router Class Initialized
ERROR - 2012-01-09 22:33:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:35 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:35 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:35 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:35 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:35 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:35 --> Total execution time: 0.4029
DEBUG - 2012-01-09 22:33:35 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:35 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:35 --> Router Class Initialized
ERROR - 2012-01-09 22:33:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:41 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:41 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:41 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:41 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:41 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:42 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:42 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:42 --> Total execution time: 0.3664
DEBUG - 2012-01-09 22:33:42 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:42 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:42 --> Router Class Initialized
ERROR - 2012-01-09 22:33:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:33:43 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:43 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Router Class Initialized
DEBUG - 2012-01-09 22:33:43 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:33:43 --> Output Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Security Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Input Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:33:43 --> Language Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Loader Class Initialized
DEBUG - 2012-01-09 22:33:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:33:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:33:44 --> Controller Class Initialized
DEBUG - 2012-01-09 22:33:44 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:33:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:33:44 --> Final output sent to browser
DEBUG - 2012-01-09 22:33:44 --> Total execution time: 0.3971
DEBUG - 2012-01-09 22:33:44 --> Config Class Initialized
DEBUG - 2012-01-09 22:33:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:33:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:33:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:33:44 --> URI Class Initialized
DEBUG - 2012-01-09 22:33:44 --> Router Class Initialized
ERROR - 2012-01-09 22:33:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 22:35:42 --> Config Class Initialized
DEBUG - 2012-01-09 22:35:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:35:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:35:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:35:42 --> URI Class Initialized
DEBUG - 2012-01-09 22:35:42 --> Router Class Initialized
DEBUG - 2012-01-09 22:35:42 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:35:42 --> Output Class Initialized
DEBUG - 2012-01-09 22:35:42 --> Security Class Initialized
DEBUG - 2012-01-09 22:35:42 --> Input Class Initialized
DEBUG - 2012-01-09 22:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:35:42 --> Language Class Initialized
DEBUG - 2012-01-09 22:35:42 --> Loader Class Initialized
DEBUG - 2012-01-09 22:35:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:35:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:35:43 --> Controller Class Initialized
DEBUG - 2012-01-09 22:35:43 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:35:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:35:43 --> Final output sent to browser
DEBUG - 2012-01-09 22:35:43 --> Total execution time: 0.4542
DEBUG - 2012-01-09 22:36:08 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:08 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:08 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:08 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:36:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:36:08 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:08 --> Total execution time: 0.4315
DEBUG - 2012-01-09 22:36:09 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:09 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:09 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:10 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:10 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:36:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:36:10 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:10 --> Total execution time: 0.4716
DEBUG - 2012-01-09 22:36:11 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:12 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:12 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:12 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:12 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:36:12 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:12 --> Total execution time: 0.4129
DEBUG - 2012-01-09 22:36:14 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:14 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:14 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:14 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:14 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:15 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:15 --> Total execution time: 0.8985
DEBUG - 2012-01-09 22:36:17 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:17 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:17 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:17 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:17 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:17 --> Total execution time: 0.5385
DEBUG - 2012-01-09 22:36:18 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:18 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:18 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:19 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:19 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:19 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:19 --> Total execution time: 0.3350
DEBUG - 2012-01-09 22:36:20 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:20 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:20 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:20 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:21 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:21 --> Total execution time: 1.0044
DEBUG - 2012-01-09 22:36:25 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:25 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:25 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:26 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:26 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:26 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:26 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:26 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:26 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:26 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:26 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:26 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:26 --> Total execution time: 0.7563
DEBUG - 2012-01-09 22:36:28 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:28 --> Total execution time: 0.4330
DEBUG - 2012-01-09 22:36:29 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:29 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:29 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:29 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:29 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:29 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:29 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:29 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:30 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:30 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:30 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:30 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:30 --> Total execution time: 0.3722
DEBUG - 2012-01-09 22:36:31 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:31 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:31 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:31 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:31 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:31 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:32 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:32 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:32 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:32 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:32 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:32 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:32 --> Total execution time: 0.7618
DEBUG - 2012-01-09 22:36:33 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:33 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:33 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:33 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:33 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:33 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:33 --> Total execution time: 0.4193
DEBUG - 2012-01-09 22:36:37 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:37 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:37 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:37 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:37 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:37 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:37 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:37 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:37 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:38 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:38 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:38 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:38 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:36:38 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:38 --> Total execution time: 0.8637
DEBUG - 2012-01-09 22:36:40 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:40 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:40 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:36:40 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:40 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:40 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:40 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:36:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:36:40 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:40 --> Total execution time: 0.4496
DEBUG - 2012-01-09 22:36:42 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:43 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:43 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:43 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:36:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:36:43 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:43 --> Total execution time: 1.0365
DEBUG - 2012-01-09 22:36:45 --> Config Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:36:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:36:45 --> URI Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Router Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Output Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Security Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Input Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:36:45 --> Language Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Loader Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:36:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:36:45 --> Controller Class Initialized
DEBUG - 2012-01-09 22:36:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:36:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:36:46 --> Final output sent to browser
DEBUG - 2012-01-09 22:36:46 --> Total execution time: 0.3681
DEBUG - 2012-01-09 22:38:44 --> Config Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:38:44 --> URI Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Router Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Output Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Security Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Input Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:38:44 --> Language Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Loader Class Initialized
DEBUG - 2012-01-09 22:38:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:38:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:38:45 --> Controller Class Initialized
DEBUG - 2012-01-09 22:38:45 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:38:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:38:45 --> Final output sent to browser
DEBUG - 2012-01-09 22:38:45 --> Total execution time: 0.9890
DEBUG - 2012-01-09 22:38:51 --> Config Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:38:51 --> URI Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Router Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Output Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Security Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Input Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:38:51 --> Language Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Loader Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:38:51 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Controller Class Initialized
DEBUG - 2012-01-09 22:38:51 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:38:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:38:51 --> Final output sent to browser
DEBUG - 2012-01-09 22:38:51 --> Total execution time: 0.3794
DEBUG - 2012-01-09 22:40:00 --> Config Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:40:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:40:00 --> URI Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Router Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Output Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Security Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Input Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:40:00 --> Language Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Loader Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:40:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:40:00 --> Controller Class Initialized
ERROR - 2012-01-09 22:40:00 --> Severity: Notice  --> Undefined property: Auth::$session A:\home\codeigniter.blog\www\application\controllers\admin\auth.php 8
DEBUG - 2012-01-09 22:40:30 --> Config Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:40:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:40:30 --> URI Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Router Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Output Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Security Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Input Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:40:30 --> Language Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Loader Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:40:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:40:30 --> Session Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Config Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:42:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:42:34 --> URI Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Router Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Output Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Security Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Input Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:42:34 --> Language Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Loader Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:42:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:42:34 --> Session Class Initialized
DEBUG - 2012-01-09 22:42:35 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:42:35 --> A session cookie was not found.
DEBUG - 2012-01-09 22:42:35 --> Session routines successfully run
DEBUG - 2012-01-09 22:42:35 --> Controller Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Config Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:46:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:46:21 --> URI Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Router Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Output Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Security Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Input Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:46:21 --> Language Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Loader Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:46:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Session Class Initialized
DEBUG - 2012-01-09 22:46:21 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:46:22 --> Session routines successfully run
DEBUG - 2012-01-09 22:46:22 --> Controller Class Initialized
DEBUG - 2012-01-09 22:46:22 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:46:22 --> Final output sent to browser
DEBUG - 2012-01-09 22:46:22 --> Total execution time: 0.4574
DEBUG - 2012-01-09 22:46:27 --> Config Class Initialized
DEBUG - 2012-01-09 22:46:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:46:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:46:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:46:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Router Class Initialized
DEBUG - 2012-01-09 22:46:28 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:46:28 --> Output Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:46:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:46:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Session Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:46:28 --> Session routines successfully run
DEBUG - 2012-01-09 22:46:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:46:28 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:46:28 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:46:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:46:28 --> Total execution time: 0.4737
DEBUG - 2012-01-09 22:46:54 --> Config Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:46:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:46:54 --> URI Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Router Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Output Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Security Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Input Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:46:54 --> Language Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Loader Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:46:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Session Class Initialized
DEBUG - 2012-01-09 22:46:54 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:46:54 --> Session routines successfully run
DEBUG - 2012-01-09 22:46:54 --> Controller Class Initialized
DEBUG - 2012-01-09 22:46:54 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:46:54 --> Final output sent to browser
DEBUG - 2012-01-09 22:46:54 --> Total execution time: 0.4865
DEBUG - 2012-01-09 22:46:55 --> Config Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:46:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:46:55 --> URI Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Router Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Output Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Security Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Input Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:46:55 --> Language Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Loader Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:46:55 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Session Class Initialized
DEBUG - 2012-01-09 22:46:55 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:46:55 --> Session routines successfully run
DEBUG - 2012-01-09 22:46:55 --> Controller Class Initialized
DEBUG - 2012-01-09 22:46:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:46:56 --> Final output sent to browser
DEBUG - 2012-01-09 22:46:56 --> Total execution time: 0.5726
DEBUG - 2012-01-09 22:47:01 --> Config Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:47:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:47:01 --> URI Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Router Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Output Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Security Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Input Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:47:01 --> Language Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Loader Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:47:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Session Class Initialized
DEBUG - 2012-01-09 22:47:01 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:47:01 --> Session routines successfully run
DEBUG - 2012-01-09 22:47:01 --> Controller Class Initialized
DEBUG - 2012-01-09 22:47:01 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:47:01 --> Final output sent to browser
DEBUG - 2012-01-09 22:47:01 --> Total execution time: 0.3859
DEBUG - 2012-01-09 22:47:45 --> Config Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:47:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:47:45 --> URI Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Router Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Output Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Security Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Input Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:47:45 --> Language Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Loader Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:47:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Session Class Initialized
DEBUG - 2012-01-09 22:47:45 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:47:45 --> Session routines successfully run
DEBUG - 2012-01-09 22:47:45 --> Controller Class Initialized
DEBUG - 2012-01-09 22:47:45 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:47:45 --> Final output sent to browser
DEBUG - 2012-01-09 22:47:45 --> Total execution time: 0.4211
DEBUG - 2012-01-09 22:50:13 --> Config Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:50:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:50:13 --> URI Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Router Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Output Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Security Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Input Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:50:13 --> Language Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Loader Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:50:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Session Class Initialized
DEBUG - 2012-01-09 22:50:13 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:50:13 --> Session routines successfully run
DEBUG - 2012-01-09 22:50:13 --> Controller Class Initialized
DEBUG - 2012-01-09 22:50:13 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:50:13 --> Final output sent to browser
DEBUG - 2012-01-09 22:50:13 --> Total execution time: 0.4710
DEBUG - 2012-01-09 22:50:27 --> Config Class Initialized
DEBUG - 2012-01-09 22:50:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:50:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:50:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:50:27 --> URI Class Initialized
DEBUG - 2012-01-09 22:50:27 --> Router Class Initialized
DEBUG - 2012-01-09 22:50:27 --> Output Class Initialized
DEBUG - 2012-01-09 22:50:27 --> Security Class Initialized
DEBUG - 2012-01-09 22:50:27 --> Input Class Initialized
DEBUG - 2012-01-09 22:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:50:27 --> Language Class Initialized
DEBUG - 2012-01-09 22:50:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:50:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:50:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:50:28 --> Session Class Initialized
DEBUG - 2012-01-09 22:50:28 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:50:28 --> Session routines successfully run
DEBUG - 2012-01-09 22:50:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:50:28 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:50:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:50:28 --> Total execution time: 0.4077
DEBUG - 2012-01-09 22:51:24 --> Config Class Initialized
DEBUG - 2012-01-09 22:51:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:51:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:51:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:51:24 --> URI Class Initialized
DEBUG - 2012-01-09 22:51:24 --> Router Class Initialized
DEBUG - 2012-01-09 22:51:24 --> Output Class Initialized
DEBUG - 2012-01-09 22:51:24 --> Security Class Initialized
DEBUG - 2012-01-09 22:51:25 --> Input Class Initialized
DEBUG - 2012-01-09 22:51:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:51:25 --> Language Class Initialized
DEBUG - 2012-01-09 22:51:25 --> Loader Class Initialized
DEBUG - 2012-01-09 22:51:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:51:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:51:25 --> Session Class Initialized
DEBUG - 2012-01-09 22:51:25 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:51:25 --> Session routines successfully run
DEBUG - 2012-01-09 22:51:25 --> Controller Class Initialized
DEBUG - 2012-01-09 22:51:25 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:51:25 --> Final output sent to browser
DEBUG - 2012-01-09 22:51:25 --> Total execution time: 1.8891
DEBUG - 2012-01-09 22:52:15 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:15 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:15 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:16 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:16 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:16 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:16 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:16 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:17 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:17 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:17 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:17 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:17 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:52:17 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:17 --> Total execution time: 1.6897
DEBUG - 2012-01-09 22:52:21 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:21 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:21 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:21 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:21 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:22 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:22 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:22 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:22 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:22 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:22 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:22 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:22 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:52:22 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:22 --> Total execution time: 1.0205
DEBUG - 2012-01-09 22:52:24 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:24 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:24 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:24 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:24 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:24 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:25 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:25 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:25 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:25 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:25 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:25 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:25 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 22:52:25 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:25 --> Total execution time: 0.4587
DEBUG - 2012-01-09 22:52:27 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:28 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:28 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:52:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:28 --> Total execution time: 1.0596
DEBUG - 2012-01-09 22:52:30 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:30 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:30 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:30 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:30 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:30 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:52:30 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:30 --> Total execution time: 0.5953
DEBUG - 2012-01-09 22:52:33 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:33 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:33 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:33 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:33 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:33 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:33 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:34 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:34 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:34 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:34 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:34 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 22:52:34 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:34 --> Total execution time: 1.0818
DEBUG - 2012-01-09 22:52:35 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:35 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:35 --> No URI present. Default controller set.
DEBUG - 2012-01-09 22:52:35 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:35 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:35 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:36 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:36 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:36 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:36 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:36 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:52:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:52:36 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:36 --> Total execution time: 0.6039
DEBUG - 2012-01-09 22:52:38 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:38 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:38 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:38 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:38 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:38 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:39 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:39 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:39 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:39 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:39 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:39 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:39 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:52:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:52:39 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:39 --> Total execution time: 1.1543
DEBUG - 2012-01-09 22:52:41 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:41 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:41 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:42 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:42 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:42 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:42 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:42 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:52:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:52:42 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:42 --> Total execution time: 0.4567
DEBUG - 2012-01-09 22:52:46 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:46 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:46 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:47 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:47 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:47 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:47 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:47 --> Pagination Class Initialized
DEBUG - 2012-01-09 22:52:47 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 22:52:47 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:47 --> Total execution time: 0.4535
DEBUG - 2012-01-09 22:52:55 --> Config Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:52:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:52:55 --> URI Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Router Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Output Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Security Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Input Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:52:55 --> Language Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Loader Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:52:55 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Session Class Initialized
DEBUG - 2012-01-09 22:52:55 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:52:55 --> Session routines successfully run
DEBUG - 2012-01-09 22:52:55 --> Controller Class Initialized
DEBUG - 2012-01-09 22:52:55 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:52:55 --> Final output sent to browser
DEBUG - 2012-01-09 22:52:55 --> Total execution time: 0.3906
DEBUG - 2012-01-09 22:53:28 --> Config Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:53:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:53:28 --> URI Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Router Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Output Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Security Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Input Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:53:28 --> Language Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Loader Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:53:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Session Class Initialized
DEBUG - 2012-01-09 22:53:28 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:53:28 --> Session routines successfully run
DEBUG - 2012-01-09 22:53:28 --> Controller Class Initialized
DEBUG - 2012-01-09 22:53:28 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:53:28 --> Final output sent to browser
DEBUG - 2012-01-09 22:53:28 --> Total execution time: 0.4014
DEBUG - 2012-01-09 22:54:36 --> Config Class Initialized
DEBUG - 2012-01-09 22:54:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:54:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:54:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:54:36 --> URI Class Initialized
DEBUG - 2012-01-09 22:54:36 --> Router Class Initialized
DEBUG - 2012-01-09 22:54:36 --> Output Class Initialized
DEBUG - 2012-01-09 22:54:36 --> Security Class Initialized
DEBUG - 2012-01-09 22:54:36 --> Input Class Initialized
DEBUG - 2012-01-09 22:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:54:36 --> Language Class Initialized
DEBUG - 2012-01-09 22:54:37 --> Loader Class Initialized
DEBUG - 2012-01-09 22:54:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:54:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:54:37 --> Session Class Initialized
DEBUG - 2012-01-09 22:54:37 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:54:37 --> Session routines successfully run
DEBUG - 2012-01-09 22:54:37 --> Controller Class Initialized
DEBUG - 2012-01-09 22:54:37 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:54:37 --> Final output sent to browser
DEBUG - 2012-01-09 22:54:37 --> Total execution time: 0.4432
DEBUG - 2012-01-09 22:56:45 --> Config Class Initialized
DEBUG - 2012-01-09 22:56:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 22:56:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 22:56:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 22:56:45 --> URI Class Initialized
DEBUG - 2012-01-09 22:56:45 --> Router Class Initialized
DEBUG - 2012-01-09 22:56:45 --> Output Class Initialized
DEBUG - 2012-01-09 22:56:46 --> Security Class Initialized
DEBUG - 2012-01-09 22:56:46 --> Input Class Initialized
DEBUG - 2012-01-09 22:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 22:56:46 --> Language Class Initialized
DEBUG - 2012-01-09 22:56:46 --> Loader Class Initialized
DEBUG - 2012-01-09 22:56:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 22:56:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 22:56:46 --> Session Class Initialized
DEBUG - 2012-01-09 22:56:46 --> Helper loaded: string_helper
DEBUG - 2012-01-09 22:56:46 --> Session routines successfully run
DEBUG - 2012-01-09 22:56:46 --> Controller Class Initialized
DEBUG - 2012-01-09 22:56:46 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 22:56:46 --> Final output sent to browser
DEBUG - 2012-01-09 22:56:46 --> Total execution time: 0.4420
DEBUG - 2012-01-09 23:00:44 --> Config Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:00:44 --> URI Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Router Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Output Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Security Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Input Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:00:44 --> Language Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Loader Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:00:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Session Class Initialized
DEBUG - 2012-01-09 23:00:44 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:00:44 --> Session routines successfully run
DEBUG - 2012-01-09 23:00:44 --> Controller Class Initialized
DEBUG - 2012-01-09 23:00:44 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:00:44 --> Final output sent to browser
DEBUG - 2012-01-09 23:00:44 --> Total execution time: 0.6912
DEBUG - 2012-01-09 23:01:27 --> Config Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:01:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:01:27 --> URI Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Router Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Output Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Security Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Input Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:01:27 --> Language Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Loader Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:01:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Session Class Initialized
DEBUG - 2012-01-09 23:01:27 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:01:27 --> Session routines successfully run
DEBUG - 2012-01-09 23:01:27 --> Controller Class Initialized
DEBUG - 2012-01-09 23:01:27 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:01:27 --> Final output sent to browser
DEBUG - 2012-01-09 23:01:27 --> Total execution time: 0.4295
DEBUG - 2012-01-09 23:01:42 --> Config Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:01:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:01:42 --> URI Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Router Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Output Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Security Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Input Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:01:42 --> Language Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Loader Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:01:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Session Class Initialized
DEBUG - 2012-01-09 23:01:42 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:01:42 --> Session routines successfully run
DEBUG - 2012-01-09 23:01:42 --> Controller Class Initialized
DEBUG - 2012-01-09 23:01:42 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:01:42 --> Final output sent to browser
DEBUG - 2012-01-09 23:01:42 --> Total execution time: 0.3821
DEBUG - 2012-01-09 23:02:02 --> Config Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:02:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:02:02 --> URI Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Router Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Output Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Security Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Input Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:02:02 --> Language Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Loader Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:02:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Session Class Initialized
DEBUG - 2012-01-09 23:02:02 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:02:02 --> Session routines successfully run
DEBUG - 2012-01-09 23:02:02 --> Controller Class Initialized
DEBUG - 2012-01-09 23:02:02 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:02:02 --> Final output sent to browser
DEBUG - 2012-01-09 23:02:02 --> Total execution time: 0.8656
DEBUG - 2012-01-09 23:02:17 --> Config Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:02:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:02:17 --> URI Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Router Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Output Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Security Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Input Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:02:17 --> Language Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Loader Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:02:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Session Class Initialized
DEBUG - 2012-01-09 23:02:17 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:02:17 --> Session routines successfully run
DEBUG - 2012-01-09 23:02:17 --> Controller Class Initialized
DEBUG - 2012-01-09 23:02:17 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:02:17 --> Final output sent to browser
DEBUG - 2012-01-09 23:02:17 --> Total execution time: 0.3967
DEBUG - 2012-01-09 23:03:31 --> Config Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:03:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:03:31 --> URI Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Router Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Output Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Security Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Input Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:03:31 --> Language Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Loader Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:03:31 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Session Class Initialized
DEBUG - 2012-01-09 23:03:31 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:03:31 --> Session routines successfully run
DEBUG - 2012-01-09 23:03:31 --> Controller Class Initialized
DEBUG - 2012-01-09 23:03:31 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:03:31 --> Final output sent to browser
DEBUG - 2012-01-09 23:03:31 --> Total execution time: 0.4404
DEBUG - 2012-01-09 23:04:43 --> Config Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:04:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:04:43 --> URI Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Router Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Output Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Security Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Input Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:04:43 --> Language Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Loader Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:04:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Session Class Initialized
DEBUG - 2012-01-09 23:04:43 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:04:43 --> Session routines successfully run
DEBUG - 2012-01-09 23:04:43 --> Controller Class Initialized
DEBUG - 2012-01-09 23:04:43 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:04:43 --> Final output sent to browser
DEBUG - 2012-01-09 23:04:43 --> Total execution time: 0.3931
DEBUG - 2012-01-09 23:05:29 --> Config Class Initialized
DEBUG - 2012-01-09 23:05:29 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:05:29 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:05:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:05:29 --> URI Class Initialized
DEBUG - 2012-01-09 23:05:29 --> Router Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Output Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Security Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Input Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:05:30 --> Language Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Loader Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:05:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Session Class Initialized
DEBUG - 2012-01-09 23:05:30 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:05:30 --> Session routines successfully run
DEBUG - 2012-01-09 23:05:30 --> Controller Class Initialized
DEBUG - 2012-01-09 23:05:30 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:05:30 --> Final output sent to browser
DEBUG - 2012-01-09 23:05:30 --> Total execution time: 0.4101
DEBUG - 2012-01-09 23:05:32 --> Config Class Initialized
DEBUG - 2012-01-09 23:05:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:05:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:05:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:05:32 --> URI Class Initialized
DEBUG - 2012-01-09 23:05:32 --> Router Class Initialized
DEBUG - 2012-01-09 23:05:32 --> Output Class Initialized
DEBUG - 2012-01-09 23:05:32 --> Security Class Initialized
DEBUG - 2012-01-09 23:05:32 --> Input Class Initialized
DEBUG - 2012-01-09 23:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:05:33 --> Language Class Initialized
DEBUG - 2012-01-09 23:05:33 --> Loader Class Initialized
DEBUG - 2012-01-09 23:05:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:05:33 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:05:33 --> Session Class Initialized
DEBUG - 2012-01-09 23:05:33 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:05:33 --> Session routines successfully run
DEBUG - 2012-01-09 23:05:33 --> Controller Class Initialized
DEBUG - 2012-01-09 23:05:33 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:05:33 --> Final output sent to browser
DEBUG - 2012-01-09 23:05:33 --> Total execution time: 0.4510
DEBUG - 2012-01-09 23:05:38 --> Config Class Initialized
DEBUG - 2012-01-09 23:05:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:05:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:05:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:05:38 --> URI Class Initialized
DEBUG - 2012-01-09 23:05:38 --> Router Class Initialized
DEBUG - 2012-01-09 23:05:38 --> Output Class Initialized
DEBUG - 2012-01-09 23:05:38 --> Security Class Initialized
DEBUG - 2012-01-09 23:05:38 --> Input Class Initialized
DEBUG - 2012-01-09 23:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:05:38 --> Language Class Initialized
DEBUG - 2012-01-09 23:05:39 --> Loader Class Initialized
DEBUG - 2012-01-09 23:05:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:05:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:05:39 --> Session Class Initialized
DEBUG - 2012-01-09 23:05:39 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:05:39 --> Session routines successfully run
DEBUG - 2012-01-09 23:05:39 --> Controller Class Initialized
DEBUG - 2012-01-09 23:05:39 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:05:39 --> Final output sent to browser
DEBUG - 2012-01-09 23:05:39 --> Total execution time: 0.9639
DEBUG - 2012-01-09 23:05:50 --> Config Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:05:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:05:50 --> URI Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Router Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Output Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Security Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Input Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:05:50 --> Language Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Loader Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:05:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Session Class Initialized
DEBUG - 2012-01-09 23:05:50 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:05:50 --> Session routines successfully run
DEBUG - 2012-01-09 23:05:50 --> Controller Class Initialized
DEBUG - 2012-01-09 23:05:50 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:05:50 --> Final output sent to browser
DEBUG - 2012-01-09 23:05:50 --> Total execution time: 0.4297
DEBUG - 2012-01-09 23:08:57 --> Config Class Initialized
DEBUG - 2012-01-09 23:08:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:08:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:08:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:08:57 --> URI Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Router Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Output Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Security Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Input Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:08:58 --> Language Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Loader Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:08:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Session Class Initialized
DEBUG - 2012-01-09 23:08:58 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:08:58 --> Session routines successfully run
DEBUG - 2012-01-09 23:08:58 --> Controller Class Initialized
DEBUG - 2012-01-09 23:08:58 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:08:58 --> Final output sent to browser
DEBUG - 2012-01-09 23:08:58 --> Total execution time: 1.5170
DEBUG - 2012-01-09 23:09:45 --> Config Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:09:45 --> URI Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Router Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Output Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Security Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Input Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:09:45 --> Language Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Loader Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:09:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Session Class Initialized
DEBUG - 2012-01-09 23:09:45 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:09:45 --> Session routines successfully run
DEBUG - 2012-01-09 23:09:45 --> Controller Class Initialized
DEBUG - 2012-01-09 23:09:45 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:09:45 --> Final output sent to browser
DEBUG - 2012-01-09 23:09:45 --> Total execution time: 0.3978
DEBUG - 2012-01-09 23:09:59 --> Config Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:09:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:09:59 --> URI Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Router Class Initialized
DEBUG - 2012-01-09 23:09:59 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:09:59 --> Output Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Security Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Input Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:09:59 --> Language Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Loader Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:09:59 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Session Class Initialized
DEBUG - 2012-01-09 23:09:59 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:09:59 --> Session routines successfully run
DEBUG - 2012-01-09 23:09:59 --> Controller Class Initialized
DEBUG - 2012-01-09 23:10:00 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:10:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:10:00 --> Final output sent to browser
DEBUG - 2012-01-09 23:10:00 --> Total execution time: 0.6155
DEBUG - 2012-01-09 23:10:19 --> Config Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:10:19 --> URI Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Router Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Output Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Security Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Input Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:10:19 --> Language Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Loader Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:10:19 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Session Class Initialized
DEBUG - 2012-01-09 23:10:19 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:10:19 --> Session routines successfully run
DEBUG - 2012-01-09 23:10:19 --> Controller Class Initialized
DEBUG - 2012-01-09 23:10:19 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:10:19 --> Final output sent to browser
DEBUG - 2012-01-09 23:10:19 --> Total execution time: 0.3815
DEBUG - 2012-01-09 23:11:34 --> Config Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:11:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:11:34 --> URI Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Router Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Output Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Security Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Input Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:11:34 --> Language Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Loader Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:11:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Session Class Initialized
DEBUG - 2012-01-09 23:11:34 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:11:34 --> Session routines successfully run
DEBUG - 2012-01-09 23:11:34 --> Controller Class Initialized
DEBUG - 2012-01-09 23:11:34 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:11:34 --> Final output sent to browser
DEBUG - 2012-01-09 23:11:34 --> Total execution time: 0.3857
DEBUG - 2012-01-09 23:12:24 --> Config Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:12:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:12:24 --> URI Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Router Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Output Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Security Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Input Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:12:24 --> Language Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Loader Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:12:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Session Class Initialized
DEBUG - 2012-01-09 23:12:24 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:12:24 --> Session routines successfully run
DEBUG - 2012-01-09 23:12:24 --> Controller Class Initialized
DEBUG - 2012-01-09 23:12:24 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:12:24 --> Final output sent to browser
DEBUG - 2012-01-09 23:12:24 --> Total execution time: 0.3971
DEBUG - 2012-01-09 23:14:05 --> Config Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:14:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:14:05 --> URI Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Router Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Output Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Security Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Input Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:14:05 --> Language Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Loader Class Initialized
DEBUG - 2012-01-09 23:14:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:14:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:14:06 --> Session Class Initialized
DEBUG - 2012-01-09 23:14:06 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:14:06 --> Session routines successfully run
DEBUG - 2012-01-09 23:14:06 --> Controller Class Initialized
DEBUG - 2012-01-09 23:14:06 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:14:06 --> Final output sent to browser
DEBUG - 2012-01-09 23:14:06 --> Total execution time: 0.5615
DEBUG - 2012-01-09 23:14:57 --> Config Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:14:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:14:57 --> URI Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Router Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Output Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Security Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Input Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:14:57 --> Language Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Loader Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:14:57 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Session Class Initialized
DEBUG - 2012-01-09 23:14:57 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:14:57 --> Session routines successfully run
DEBUG - 2012-01-09 23:14:57 --> Controller Class Initialized
DEBUG - 2012-01-09 23:14:57 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:14:57 --> Final output sent to browser
DEBUG - 2012-01-09 23:14:57 --> Total execution time: 0.9580
DEBUG - 2012-01-09 23:15:57 --> Config Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:15:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:15:57 --> URI Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Router Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Output Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Security Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Input Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:15:57 --> Language Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Loader Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:15:57 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Session Class Initialized
DEBUG - 2012-01-09 23:15:57 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:15:57 --> Session routines successfully run
DEBUG - 2012-01-09 23:15:57 --> Controller Class Initialized
DEBUG - 2012-01-09 23:15:57 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:15:57 --> Final output sent to browser
DEBUG - 2012-01-09 23:15:57 --> Total execution time: 0.3888
DEBUG - 2012-01-09 23:16:26 --> Config Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:16:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:16:26 --> URI Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Router Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Output Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Security Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Input Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:16:26 --> Language Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Loader Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:16:26 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Session Class Initialized
DEBUG - 2012-01-09 23:16:26 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:16:26 --> Session routines successfully run
DEBUG - 2012-01-09 23:16:26 --> Controller Class Initialized
DEBUG - 2012-01-09 23:16:26 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:16:26 --> Final output sent to browser
DEBUG - 2012-01-09 23:16:26 --> Total execution time: 0.5070
DEBUG - 2012-01-09 23:16:56 --> Config Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:16:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:16:56 --> URI Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Router Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Output Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Security Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Input Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:16:56 --> Language Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Loader Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:16:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Session Class Initialized
DEBUG - 2012-01-09 23:16:56 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:16:56 --> Session routines successfully run
DEBUG - 2012-01-09 23:16:56 --> Controller Class Initialized
DEBUG - 2012-01-09 23:16:56 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-09 23:16:56 --> Final output sent to browser
DEBUG - 2012-01-09 23:16:56 --> Total execution time: 0.4081
DEBUG - 2012-01-09 23:17:17 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:17 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:17 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:17:17 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:17 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:17 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:17 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:18 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:18 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:18 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:18 --> Total execution time: 0.4982
DEBUG - 2012-01-09 23:17:30 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:30 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:30 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:30 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:30 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:30 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:30 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:30 --> Total execution time: 0.4811
DEBUG - 2012-01-09 23:17:32 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:32 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:32 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:32 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:32 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:32 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:32 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:32 --> Total execution time: 0.6361
DEBUG - 2012-01-09 23:17:34 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:34 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:34 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:34 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:34 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:34 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:34 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:34 --> Total execution time: 0.6695
DEBUG - 2012-01-09 23:17:36 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:36 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:36 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:17:36 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:36 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:37 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:37 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:37 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:37 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:37 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:37 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:37 --> Total execution time: 0.4973
DEBUG - 2012-01-09 23:17:38 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:38 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:38 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:38 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:38 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:39 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:39 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:39 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:39 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:39 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:39 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:39 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:39 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:39 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:39 --> Total execution time: 0.5539
DEBUG - 2012-01-09 23:17:41 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:41 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:41 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:41 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:41 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:41 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:41 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:41 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:41 --> Total execution time: 0.4490
DEBUG - 2012-01-09 23:17:43 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:43 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:43 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:17:43 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:43 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:43 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:43 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:43 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:43 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:43 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:43 --> Total execution time: 0.6008
DEBUG - 2012-01-09 23:17:45 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:45 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:45 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:46 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:46 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:46 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:46 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:46 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:46 --> Total execution time: 0.4740
DEBUG - 2012-01-09 23:17:48 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:48 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:48 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:48 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:48 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:48 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:48 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:48 --> Total execution time: 0.7351
DEBUG - 2012-01-09 23:17:51 --> Config Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:17:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:17:51 --> URI Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Router Class Initialized
DEBUG - 2012-01-09 23:17:51 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:17:51 --> Output Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Security Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Input Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:17:51 --> Language Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Loader Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:17:51 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Session Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:17:51 --> Session routines successfully run
DEBUG - 2012-01-09 23:17:51 --> Controller Class Initialized
DEBUG - 2012-01-09 23:17:51 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:17:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:17:51 --> Final output sent to browser
DEBUG - 2012-01-09 23:17:51 --> Total execution time: 0.6215
DEBUG - 2012-01-09 23:18:11 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:11 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:11 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:11 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:11 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:11 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:11 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:11 --> Total execution time: 0.7707
DEBUG - 2012-01-09 23:18:14 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:14 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:14 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:14 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:14 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:14 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:14 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:14 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:14 --> Total execution time: 0.1928
DEBUG - 2012-01-09 23:18:16 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:16 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:16 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:16 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:16 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:16 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:16 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:16 --> Total execution time: 0.3737
DEBUG - 2012-01-09 23:18:18 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:18 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:18 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:18:18 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:18 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:18 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:18 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:18 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:18 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:18 --> Total execution time: 0.2515
DEBUG - 2012-01-09 23:18:20 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:20 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:20 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:20 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:20 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:20 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:20 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:20 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:20 --> Total execution time: 0.2009
DEBUG - 2012-01-09 23:18:22 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:22 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:22 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:23 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:23 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:23 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:23 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:23 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:23 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:23 --> Total execution time: 0.1805
DEBUG - 2012-01-09 23:18:24 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:24 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:24 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:24 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:24 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:24 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:24 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:24 --> Total execution time: 0.1996
DEBUG - 2012-01-09 23:18:26 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:26 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:26 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:26 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:26 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:26 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:26 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:26 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:26 --> Total execution time: 0.1525
DEBUG - 2012-01-09 23:18:27 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:27 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:27 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:27 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:27 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:27 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:27 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:27 --> Total execution time: 0.1580
DEBUG - 2012-01-09 23:18:28 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:28 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:28 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:28 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:28 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:28 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:28 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:28 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:28 --> Total execution time: 0.2110
DEBUG - 2012-01-09 23:18:30 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:30 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:30 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:30 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:30 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:30 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:30 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:30 --> Total execution time: 0.2028
DEBUG - 2012-01-09 23:18:32 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:32 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:32 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:32 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:32 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:32 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:18:32 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:32 --> Total execution time: 0.2502
DEBUG - 2012-01-09 23:18:34 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:34 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:34 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:34 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:34 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:34 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:34 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:34 --> Total execution time: 0.1811
DEBUG - 2012-01-09 23:18:35 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:35 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:35 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:36 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:36 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:36 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:36 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:36 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:18:36 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:36 --> Total execution time: 0.2727
DEBUG - 2012-01-09 23:18:37 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:37 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:37 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:18:37 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:37 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:37 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:37 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:37 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:37 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:37 --> Total execution time: 0.2926
DEBUG - 2012-01-09 23:18:39 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:39 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:39 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:39 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:39 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:39 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:39 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:18:39 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:39 --> Total execution time: 0.2341
DEBUG - 2012-01-09 23:18:41 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:41 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:41 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:18:41 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:41 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:41 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:41 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:41 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:41 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:41 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:41 --> Total execution time: 0.3509
DEBUG - 2012-01-09 23:18:42 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:42 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:42 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:43 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:43 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:43 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:43 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:43 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:43 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:43 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:43 --> Total execution time: 0.2023
DEBUG - 2012-01-09 23:18:44 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:44 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:44 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:44 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:44 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:44 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:44 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:44 --> Total execution time: 0.2036
DEBUG - 2012-01-09 23:18:46 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:46 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:46 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:46 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:46 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:46 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:46 --> Total execution time: 0.2042
DEBUG - 2012-01-09 23:18:48 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:48 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:48 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:18:48 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:48 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:48 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:48 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:48 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:18:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:18:48 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:48 --> Total execution time: 0.2014
DEBUG - 2012-01-09 23:18:52 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:52 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:52 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:52 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:52 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:52 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:52 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:52 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:18:52 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:52 --> Total execution time: 0.3563
DEBUG - 2012-01-09 23:18:56 --> Config Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:18:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:18:56 --> URI Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Router Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Output Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Security Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Input Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:18:56 --> Language Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Loader Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:18:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Session Class Initialized
DEBUG - 2012-01-09 23:18:56 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:18:56 --> Session routines successfully run
DEBUG - 2012-01-09 23:18:56 --> Controller Class Initialized
DEBUG - 2012-01-09 23:18:56 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:18:56 --> Final output sent to browser
DEBUG - 2012-01-09 23:18:56 --> Total execution time: 0.2150
DEBUG - 2012-01-09 23:19:10 --> Config Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:19:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:19:10 --> URI Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Router Class Initialized
DEBUG - 2012-01-09 23:19:10 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:19:10 --> Output Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Security Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Input Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:19:10 --> Language Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Loader Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:19:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Session Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:19:10 --> Session routines successfully run
DEBUG - 2012-01-09 23:19:10 --> Controller Class Initialized
DEBUG - 2012-01-09 23:19:10 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:19:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:19:10 --> Final output sent to browser
DEBUG - 2012-01-09 23:19:10 --> Total execution time: 0.4662
DEBUG - 2012-01-09 23:19:40 --> Config Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:19:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:19:40 --> URI Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Router Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Output Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Security Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Input Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:19:40 --> Language Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Loader Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:19:40 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Session Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:19:40 --> Session routines successfully run
DEBUG - 2012-01-09 23:19:40 --> Controller Class Initialized
DEBUG - 2012-01-09 23:19:40 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:19:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:19:40 --> Final output sent to browser
DEBUG - 2012-01-09 23:19:40 --> Total execution time: 0.4737
DEBUG - 2012-01-09 23:19:42 --> Config Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:19:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:19:42 --> URI Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Router Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Output Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Security Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Input Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:19:42 --> Language Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Loader Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:19:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Session Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:19:42 --> Session routines successfully run
DEBUG - 2012-01-09 23:19:42 --> Controller Class Initialized
DEBUG - 2012-01-09 23:19:42 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:19:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:19:42 --> Final output sent to browser
DEBUG - 2012-01-09 23:19:42 --> Total execution time: 0.5078
DEBUG - 2012-01-09 23:19:44 --> Config Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:19:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:19:44 --> URI Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Router Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Output Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Security Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Input Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:19:44 --> Language Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Loader Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:19:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Session Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:19:44 --> Session routines successfully run
DEBUG - 2012-01-09 23:19:44 --> Controller Class Initialized
DEBUG - 2012-01-09 23:19:44 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:19:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:19:45 --> Final output sent to browser
DEBUG - 2012-01-09 23:19:45 --> Total execution time: 0.6267
DEBUG - 2012-01-09 23:19:46 --> Config Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:19:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:19:46 --> URI Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Router Class Initialized
DEBUG - 2012-01-09 23:19:46 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:19:46 --> Output Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Security Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Input Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:19:46 --> Language Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Loader Class Initialized
DEBUG - 2012-01-09 23:19:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:19:47 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:19:47 --> Session Class Initialized
DEBUG - 2012-01-09 23:19:47 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:19:47 --> Session routines successfully run
DEBUG - 2012-01-09 23:19:47 --> Controller Class Initialized
DEBUG - 2012-01-09 23:19:47 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:19:47 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:19:47 --> Final output sent to browser
DEBUG - 2012-01-09 23:19:47 --> Total execution time: 0.5005
DEBUG - 2012-01-09 23:19:48 --> Config Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:19:48 --> URI Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Router Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Output Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Security Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Input Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:19:48 --> Language Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Loader Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:19:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Session Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:19:48 --> Session routines successfully run
DEBUG - 2012-01-09 23:19:48 --> Controller Class Initialized
DEBUG - 2012-01-09 23:19:48 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:19:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:19:48 --> Final output sent to browser
DEBUG - 2012-01-09 23:19:48 --> Total execution time: 0.6039
DEBUG - 2012-01-09 23:19:50 --> Config Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:19:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:19:50 --> URI Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Router Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Output Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Security Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Input Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:19:50 --> Language Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Loader Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:19:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Session Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:19:50 --> Session routines successfully run
DEBUG - 2012-01-09 23:19:50 --> Controller Class Initialized
DEBUG - 2012-01-09 23:19:50 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:19:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:19:50 --> Final output sent to browser
DEBUG - 2012-01-09 23:19:50 --> Total execution time: 0.4932
DEBUG - 2012-01-09 23:20:00 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:01 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:01 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:01 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:01 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:01 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:01 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:20:01 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:20:01 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:01 --> Total execution time: 0.4809
DEBUG - 2012-01-09 23:20:02 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:02 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:02 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:20:02 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:02 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:03 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:03 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:03 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:03 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:03 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:20:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:20:03 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:03 --> Total execution time: 0.5021
DEBUG - 2012-01-09 23:20:04 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:04 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:04 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:04 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:04 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:04 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:04 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:20:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:20:04 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:04 --> Total execution time: 0.5140
DEBUG - 2012-01-09 23:20:06 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:07 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:07 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:07 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:07 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:07 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:07 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:20:07 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:07 --> Total execution time: 0.6798
DEBUG - 2012-01-09 23:20:08 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:08 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:08 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:08 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:08 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:08 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:08 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:09 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:09 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:09 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:09 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:09 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:09 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:20:09 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:09 --> Total execution time: 0.6577
DEBUG - 2012-01-09 23:20:10 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:10 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:10 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:10 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:10 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:10 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:10 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:20:10 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:10 --> Total execution time: 0.5311
DEBUG - 2012-01-09 23:20:12 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:12 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:12 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:12 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:12 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:13 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:13 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:13 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:13 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:20:13 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:13 --> Total execution time: 1.2510
DEBUG - 2012-01-09 23:20:14 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:14 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:14 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:14 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:14 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:14 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:14 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:14 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:20:14 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:14 --> Total execution time: 0.4554
DEBUG - 2012-01-09 23:20:16 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:16 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:16 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:16 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:16 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:16 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:16 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:20:16 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:16 --> Total execution time: 0.4858
DEBUG - 2012-01-09 23:20:18 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:18 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:18 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:20:18 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:18 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:18 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:18 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:18 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:20:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:20:19 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:19 --> Total execution time: 1.0523
DEBUG - 2012-01-09 23:20:21 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:21 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:22 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:22 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:22 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:22 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:20:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:20:22 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:22 --> Total execution time: 0.4714
DEBUG - 2012-01-09 23:20:24 --> Config Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:20:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:20:24 --> URI Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Router Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Output Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Security Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Input Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:20:24 --> Language Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Loader Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:20:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Session Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:20:24 --> Session routines successfully run
DEBUG - 2012-01-09 23:20:24 --> Controller Class Initialized
DEBUG - 2012-01-09 23:20:24 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:20:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:20:24 --> Final output sent to browser
DEBUG - 2012-01-09 23:20:24 --> Total execution time: 0.6609
DEBUG - 2012-01-09 23:21:00 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:00 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:00 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:00 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:00 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:00 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:21:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:21:00 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:00 --> Total execution time: 0.4966
DEBUG - 2012-01-09 23:21:03 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:03 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:03 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:03 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:03 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:03 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:21:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:21:03 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:03 --> Total execution time: 0.5067
DEBUG - 2012-01-09 23:21:05 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:05 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:05 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:21:05 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:05 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:05 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:05 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:05 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:05 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:21:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:21:06 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:06 --> Total execution time: 0.6454
DEBUG - 2012-01-09 23:21:08 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:08 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:08 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:09 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:09 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:09 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:09 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:09 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:09 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:21:09 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:09 --> Total execution time: 0.9517
DEBUG - 2012-01-09 23:21:11 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:11 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:11 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:11 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:11 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:11 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:11 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:21:11 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:11 --> Total execution time: 0.6237
DEBUG - 2012-01-09 23:21:13 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:13 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:13 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:13 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:13 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:13 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:21:13 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:13 --> Total execution time: 0.7386
DEBUG - 2012-01-09 23:21:15 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:15 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:15 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:15 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:15 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:15 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:15 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:21:15 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:15 --> Total execution time: 0.5013
DEBUG - 2012-01-09 23:21:16 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:16 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:16 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:17 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:17 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:17 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:17 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:21:17 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:17 --> Total execution time: 0.6064
DEBUG - 2012-01-09 23:21:18 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:19 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:19 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:19 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:19 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:19 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:19 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:21:19 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:19 --> Total execution time: 1.0384
DEBUG - 2012-01-09 23:21:21 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:21 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:21 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:21 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:21 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:21 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:21 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:21 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:21:21 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:21 --> Total execution time: 0.5360
DEBUG - 2012-01-09 23:21:22 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:23 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:23 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:21:23 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:23 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:23 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:23 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:23 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:23 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:21:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:21:23 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:23 --> Total execution time: 0.6643
DEBUG - 2012-01-09 23:21:25 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:21:25 --> URI Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Router Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Output Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Security Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Input Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:21:25 --> Language Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Loader Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:21:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Session Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:21:25 --> Session routines successfully run
DEBUG - 2012-01-09 23:21:25 --> Controller Class Initialized
DEBUG - 2012-01-09 23:21:25 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:21:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:21:25 --> Final output sent to browser
DEBUG - 2012-01-09 23:21:25 --> Total execution time: 0.5359
DEBUG - 2012-01-09 23:21:59 --> Config Class Initialized
DEBUG - 2012-01-09 23:21:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:21:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:21:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:00 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:00 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:00 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:00 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:00 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:00 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:22:00 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:00 --> Total execution time: 0.4076
DEBUG - 2012-01-09 23:22:02 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:02 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:02 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:02 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:02 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:02 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:02 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:22:02 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:02 --> Total execution time: 0.4812
DEBUG - 2012-01-09 23:22:03 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:03 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:03 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:22:03 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:03 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:03 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:03 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:04 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:04 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:04 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:04 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:04 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:22:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:22:04 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:04 --> Total execution time: 0.5794
DEBUG - 2012-01-09 23:22:44 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:44 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:44 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:44 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:44 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:44 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:44 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:22:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:22:44 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:44 --> Total execution time: 0.2334
DEBUG - 2012-01-09 23:22:46 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:46 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:46 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:46 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:46 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:46 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:46 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:22:46 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:22:46 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:46 --> Total execution time: 0.2154
DEBUG - 2012-01-09 23:22:48 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:48 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:48 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:48 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:48 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:48 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:48 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:22:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:22:48 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:48 --> Total execution time: 0.1942
DEBUG - 2012-01-09 23:22:49 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:49 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:49 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:49 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:22:49 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:49 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:49 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:50 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:50 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:50 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:50 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:50 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:50 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:50 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:22:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:22:50 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:50 --> Total execution time: 0.5192
DEBUG - 2012-01-09 23:22:51 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:51 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:51 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:51 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:51 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:51 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:51 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:22:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:22:51 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:51 --> Total execution time: 0.2157
DEBUG - 2012-01-09 23:22:53 --> Config Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:22:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:22:53 --> URI Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Router Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Output Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Security Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Input Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:22:53 --> Language Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Loader Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:22:53 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Session Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:22:53 --> Session routines successfully run
DEBUG - 2012-01-09 23:22:53 --> Controller Class Initialized
DEBUG - 2012-01-09 23:22:53 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:22:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:22:53 --> Final output sent to browser
DEBUG - 2012-01-09 23:22:53 --> Total execution time: 0.2486
DEBUG - 2012-01-09 23:36:15 --> Config Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:36:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:36:15 --> URI Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Router Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Output Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Security Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Input Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:36:15 --> Language Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Loader Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:36:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Session Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:36:15 --> Session routines successfully run
DEBUG - 2012-01-09 23:36:15 --> Controller Class Initialized
DEBUG - 2012-01-09 23:36:15 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:36:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:36:15 --> Final output sent to browser
DEBUG - 2012-01-09 23:36:15 --> Total execution time: 0.4052
DEBUG - 2012-01-09 23:36:22 --> Config Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:36:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:36:22 --> URI Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Router Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Output Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Security Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Input Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:36:22 --> Language Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Loader Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:36:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Session Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:36:22 --> Session routines successfully run
DEBUG - 2012-01-09 23:36:22 --> Controller Class Initialized
DEBUG - 2012-01-09 23:36:22 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:36:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:36:22 --> Final output sent to browser
DEBUG - 2012-01-09 23:36:22 --> Total execution time: 0.4298
DEBUG - 2012-01-09 23:36:25 --> Config Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:36:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:36:25 --> URI Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Router Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Output Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Security Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Input Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:36:25 --> Language Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Loader Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:36:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Session Class Initialized
DEBUG - 2012-01-09 23:36:25 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:36:25 --> Session routines successfully run
DEBUG - 2012-01-09 23:36:26 --> Controller Class Initialized
DEBUG - 2012-01-09 23:36:26 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:36:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:36:26 --> Final output sent to browser
DEBUG - 2012-01-09 23:36:26 --> Total execution time: 0.7432
DEBUG - 2012-01-09 23:36:30 --> Config Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:36:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:36:30 --> URI Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Router Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Output Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Security Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Input Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:36:30 --> Language Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Loader Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:36:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Session Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:36:30 --> Session routines successfully run
DEBUG - 2012-01-09 23:36:30 --> Controller Class Initialized
DEBUG - 2012-01-09 23:36:30 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:36:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:36:30 --> Final output sent to browser
DEBUG - 2012-01-09 23:36:30 --> Total execution time: 0.4337
DEBUG - 2012-01-09 23:36:33 --> Config Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:36:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:36:33 --> URI Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Router Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Output Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Security Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Input Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:36:33 --> Language Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Loader Class Initialized
DEBUG - 2012-01-09 23:36:33 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:36:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:36:34 --> Session Class Initialized
DEBUG - 2012-01-09 23:36:34 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:36:34 --> Session routines successfully run
DEBUG - 2012-01-09 23:36:34 --> Controller Class Initialized
DEBUG - 2012-01-09 23:36:34 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:36:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:36:34 --> Final output sent to browser
DEBUG - 2012-01-09 23:36:34 --> Total execution time: 0.4518
DEBUG - 2012-01-09 23:41:06 --> Config Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:41:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:41:06 --> URI Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Router Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Output Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Security Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Input Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:41:06 --> Language Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Loader Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:41:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Session Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:41:06 --> Session routines successfully run
DEBUG - 2012-01-09 23:41:06 --> Controller Class Initialized
DEBUG - 2012-01-09 23:41:06 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:41:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:41:06 --> Final output sent to browser
DEBUG - 2012-01-09 23:41:06 --> Total execution time: 0.4876
DEBUG - 2012-01-09 23:42:35 --> Config Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:42:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:42:35 --> URI Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Router Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Output Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Security Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Input Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:42:35 --> Language Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Loader Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:42:35 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Session Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:42:35 --> Session routines successfully run
DEBUG - 2012-01-09 23:42:35 --> Controller Class Initialized
DEBUG - 2012-01-09 23:42:35 --> Pagination Class Initialized
ERROR - 2012-01-09 23:42:35 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
ERROR - 2012-01-09 23:42:35 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
DEBUG - 2012-01-09 23:42:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:42:35 --> Final output sent to browser
DEBUG - 2012-01-09 23:42:35 --> Total execution time: 0.4234
DEBUG - 2012-01-09 23:42:58 --> Config Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:42:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:42:58 --> URI Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Router Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Output Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Security Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Input Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:42:58 --> Language Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Loader Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:42:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Session Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:42:58 --> Session routines successfully run
DEBUG - 2012-01-09 23:42:58 --> Controller Class Initialized
DEBUG - 2012-01-09 23:42:58 --> Pagination Class Initialized
ERROR - 2012-01-09 23:42:58 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
ERROR - 2012-01-09 23:42:58 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
DEBUG - 2012-01-09 23:42:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:42:58 --> Final output sent to browser
DEBUG - 2012-01-09 23:42:58 --> Total execution time: 0.4337
DEBUG - 2012-01-09 23:43:18 --> Config Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:43:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:43:18 --> URI Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Router Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Output Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Security Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Input Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:43:18 --> Language Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Loader Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:43:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Session Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:43:18 --> Session routines successfully run
DEBUG - 2012-01-09 23:43:18 --> Controller Class Initialized
DEBUG - 2012-01-09 23:43:18 --> Pagination Class Initialized
ERROR - 2012-01-09 23:43:18 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
ERROR - 2012-01-09 23:43:19 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
DEBUG - 2012-01-09 23:43:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:43:19 --> Final output sent to browser
DEBUG - 2012-01-09 23:43:19 --> Total execution time: 0.5188
DEBUG - 2012-01-09 23:43:23 --> Config Class Initialized
DEBUG - 2012-01-09 23:43:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:43:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:43:24 --> URI Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Router Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Output Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Security Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Input Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:43:24 --> Language Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Loader Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:43:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Session Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:43:24 --> Session routines successfully run
DEBUG - 2012-01-09 23:43:24 --> Controller Class Initialized
DEBUG - 2012-01-09 23:43:24 --> Pagination Class Initialized
ERROR - 2012-01-09 23:43:24 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
ERROR - 2012-01-09 23:43:24 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
DEBUG - 2012-01-09 23:43:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:43:24 --> Final output sent to browser
DEBUG - 2012-01-09 23:43:24 --> Total execution time: 0.7071
DEBUG - 2012-01-09 23:43:25 --> Config Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:43:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:43:25 --> URI Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Router Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Output Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Security Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Input Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:43:25 --> Language Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Loader Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:43:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Session Class Initialized
DEBUG - 2012-01-09 23:43:25 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:43:25 --> Session routines successfully run
DEBUG - 2012-01-09 23:43:25 --> Controller Class Initialized
DEBUG - 2012-01-09 23:43:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:43:26 --> Final output sent to browser
DEBUG - 2012-01-09 23:43:26 --> Total execution time: 0.4904
DEBUG - 2012-01-09 23:43:26 --> Config Class Initialized
DEBUG - 2012-01-09 23:43:26 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:43:26 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:43:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:43:26 --> URI Class Initialized
DEBUG - 2012-01-09 23:43:26 --> Router Class Initialized
DEBUG - 2012-01-09 23:43:26 --> Output Class Initialized
DEBUG - 2012-01-09 23:43:27 --> Security Class Initialized
DEBUG - 2012-01-09 23:43:27 --> Input Class Initialized
DEBUG - 2012-01-09 23:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:43:27 --> Language Class Initialized
DEBUG - 2012-01-09 23:43:27 --> Loader Class Initialized
DEBUG - 2012-01-09 23:43:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:43:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:43:27 --> Session Class Initialized
DEBUG - 2012-01-09 23:43:27 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:43:27 --> Session routines successfully run
DEBUG - 2012-01-09 23:43:27 --> Controller Class Initialized
DEBUG - 2012-01-09 23:43:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:43:27 --> Final output sent to browser
DEBUG - 2012-01-09 23:43:27 --> Total execution time: 0.4272
DEBUG - 2012-01-09 23:43:29 --> Config Class Initialized
DEBUG - 2012-01-09 23:43:29 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:43:29 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:43:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:43:30 --> URI Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Router Class Initialized
DEBUG - 2012-01-09 23:43:30 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:43:30 --> Output Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Security Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Input Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:43:30 --> Language Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Loader Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:43:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Session Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:43:30 --> Session routines successfully run
DEBUG - 2012-01-09 23:43:30 --> Controller Class Initialized
DEBUG - 2012-01-09 23:43:30 --> Pagination Class Initialized
ERROR - 2012-01-09 23:43:30 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
ERROR - 2012-01-09 23:43:30 --> Severity: Notice  --> Undefined property: stdClass::$comments A:\home\codeigniter.blog\www\application\views\user\home.php 28
DEBUG - 2012-01-09 23:43:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:43:30 --> Final output sent to browser
DEBUG - 2012-01-09 23:43:30 --> Total execution time: 0.8506
DEBUG - 2012-01-09 23:44:16 --> Config Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:44:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:44:16 --> URI Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Router Class Initialized
DEBUG - 2012-01-09 23:44:16 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:44:16 --> Output Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Security Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Input Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:44:16 --> Language Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Loader Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:44:16 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Session Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:44:16 --> Session routines successfully run
DEBUG - 2012-01-09 23:44:16 --> Controller Class Initialized
DEBUG - 2012-01-09 23:44:16 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:44:16 --> DB Transaction Failure
ERROR - 2012-01-09 23:44:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.id_article, `a`.`title`, `a`.`text`, `a`.`date`, COUNT(c.id_comment) AS `commen' at line 3
DEBUG - 2012-01-09 23:44:16 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 23:45:17 --> Config Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:45:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:45:17 --> URI Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Router Class Initialized
DEBUG - 2012-01-09 23:45:17 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:45:17 --> Output Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Security Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Input Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:45:17 --> Language Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Loader Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:45:17 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Session Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:45:17 --> Session routines successfully run
DEBUG - 2012-01-09 23:45:17 --> Controller Class Initialized
DEBUG - 2012-01-09 23:45:17 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:45:17 --> DB Transaction Failure
ERROR - 2012-01-09 23:45:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.id_article, `a`.`title`, `a`.`text`, `a`.`date`, COUNT(c.id_comment) AS `commen' at line 3
DEBUG - 2012-01-09 23:45:17 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 23:45:59 --> Config Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:45:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:45:59 --> URI Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Router Class Initialized
DEBUG - 2012-01-09 23:45:59 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:45:59 --> Output Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Security Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Input Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:45:59 --> Language Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Loader Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:45:59 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Session Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:45:59 --> Session routines successfully run
DEBUG - 2012-01-09 23:45:59 --> Controller Class Initialized
DEBUG - 2012-01-09 23:45:59 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:45:59 --> DB Transaction Failure
ERROR - 2012-01-09 23:45:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.id_article, `a`.`title`, `a`.`text`, `a`.`date`, COUNT(c.id_comment) AS `commen' at line 3
DEBUG - 2012-01-09 23:45:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 23:46:07 --> Config Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:46:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:46:07 --> URI Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Router Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Output Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Security Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Input Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:46:07 --> Language Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Loader Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:46:07 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:46:07 --> Session Class Initialized
DEBUG - 2012-01-09 23:46:08 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:46:08 --> Session routines successfully run
DEBUG - 2012-01-09 23:46:08 --> Controller Class Initialized
DEBUG - 2012-01-09 23:46:08 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:46:08 --> DB Transaction Failure
ERROR - 2012-01-09 23:46:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.id_article, `a`.`title`, `a`.`text`, `a`.`date`, COUNT(c.id_comment) AS `commen' at line 3
DEBUG - 2012-01-09 23:46:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 23:47:02 --> Config Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:47:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:47:02 --> URI Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Router Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Output Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Security Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Input Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:47:02 --> Language Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Loader Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:47:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Session Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:47:02 --> Session routines successfully run
DEBUG - 2012-01-09 23:47:02 --> Controller Class Initialized
DEBUG - 2012-01-09 23:47:02 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:47:02 --> DB Transaction Failure
ERROR - 2012-01-09 23:47:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.id_article, `a`.`title`, `a`.`text`, `a`.`date`, COUNT(c.id_comment) AS `commen' at line 3
DEBUG - 2012-01-09 23:47:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 23:47:45 --> Config Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:47:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:47:45 --> URI Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Router Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Output Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Security Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Input Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:47:45 --> Language Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Loader Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:47:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Session Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:47:45 --> Session routines successfully run
DEBUG - 2012-01-09 23:47:45 --> Controller Class Initialized
DEBUG - 2012-01-09 23:47:45 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:47:45 --> DB Transaction Failure
ERROR - 2012-01-09 23:47:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.id_article, `a`.`title`, `a`.`text`, `a`.`date`, COUNT(c.id_comment) AS `commen' at line 3
DEBUG - 2012-01-09 23:47:45 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 23:47:48 --> Config Class Initialized
DEBUG - 2012-01-09 23:47:48 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:47:48 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:47:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:47:48 --> URI Class Initialized
DEBUG - 2012-01-09 23:47:48 --> Router Class Initialized
DEBUG - 2012-01-09 23:47:49 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:47:49 --> Output Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Security Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Input Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:47:49 --> Language Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Loader Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:47:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Session Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:47:49 --> Session routines successfully run
DEBUG - 2012-01-09 23:47:49 --> Controller Class Initialized
DEBUG - 2012-01-09 23:47:49 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:47:49 --> DB Transaction Failure
ERROR - 2012-01-09 23:47:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.id_article, `a`.`title`, `a`.`text`, `a`.`date`, COUNT(c.id_comment) AS `commen' at line 3
DEBUG - 2012-01-09 23:47:49 --> Language file loaded: language/english/db_lang.php
DEBUG - 2012-01-09 23:48:23 --> Config Class Initialized
DEBUG - 2012-01-09 23:48:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:48:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:48:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:48:23 --> URI Class Initialized
DEBUG - 2012-01-09 23:48:23 --> Router Class Initialized
DEBUG - 2012-01-09 23:48:23 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:48:23 --> Output Class Initialized
DEBUG - 2012-01-09 23:48:23 --> Security Class Initialized
DEBUG - 2012-01-09 23:48:23 --> Input Class Initialized
DEBUG - 2012-01-09 23:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:48:23 --> Language Class Initialized
DEBUG - 2012-01-09 23:48:23 --> Loader Class Initialized
DEBUG - 2012-01-09 23:48:24 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:48:24 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:48:24 --> Session Class Initialized
DEBUG - 2012-01-09 23:48:24 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:48:24 --> Session routines successfully run
DEBUG - 2012-01-09 23:48:24 --> Controller Class Initialized
DEBUG - 2012-01-09 23:48:24 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:48:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:48:24 --> Final output sent to browser
DEBUG - 2012-01-09 23:48:24 --> Total execution time: 0.4927
DEBUG - 2012-01-09 23:48:27 --> Config Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:48:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:48:27 --> URI Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Router Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Output Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Security Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Input Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:48:27 --> Language Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Loader Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:48:27 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Session Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:48:27 --> Session routines successfully run
DEBUG - 2012-01-09 23:48:27 --> Controller Class Initialized
DEBUG - 2012-01-09 23:48:27 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:48:27 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:48:27 --> Final output sent to browser
DEBUG - 2012-01-09 23:48:27 --> Total execution time: 0.4556
DEBUG - 2012-01-09 23:48:29 --> Config Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:48:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:48:29 --> URI Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Router Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Output Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Security Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Input Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:48:29 --> Language Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Loader Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:48:29 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Session Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:48:29 --> Session routines successfully run
DEBUG - 2012-01-09 23:48:29 --> Controller Class Initialized
DEBUG - 2012-01-09 23:48:29 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:48:29 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:48:29 --> Final output sent to browser
DEBUG - 2012-01-09 23:48:29 --> Total execution time: 0.5737
DEBUG - 2012-01-09 23:48:31 --> Config Class Initialized
DEBUG - 2012-01-09 23:48:31 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:48:31 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:48:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:48:31 --> URI Class Initialized
DEBUG - 2012-01-09 23:48:31 --> Router Class Initialized
DEBUG - 2012-01-09 23:48:31 --> Output Class Initialized
DEBUG - 2012-01-09 23:48:31 --> Security Class Initialized
DEBUG - 2012-01-09 23:48:31 --> Input Class Initialized
DEBUG - 2012-01-09 23:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:48:32 --> Language Class Initialized
DEBUG - 2012-01-09 23:48:32 --> Loader Class Initialized
DEBUG - 2012-01-09 23:48:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:48:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:48:32 --> Session Class Initialized
DEBUG - 2012-01-09 23:48:32 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:48:32 --> Session routines successfully run
DEBUG - 2012-01-09 23:48:32 --> Controller Class Initialized
DEBUG - 2012-01-09 23:48:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:48:32 --> Final output sent to browser
DEBUG - 2012-01-09 23:48:32 --> Total execution time: 0.5248
DEBUG - 2012-01-09 23:48:33 --> Config Class Initialized
DEBUG - 2012-01-09 23:48:33 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:48:33 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:48:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:48:33 --> URI Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Router Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Output Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Security Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Input Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:48:34 --> Language Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Loader Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:48:34 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Session Class Initialized
DEBUG - 2012-01-09 23:48:34 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:48:34 --> Session routines successfully run
DEBUG - 2012-01-09 23:48:34 --> Controller Class Initialized
DEBUG - 2012-01-09 23:48:34 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-09 23:48:34 --> Final output sent to browser
DEBUG - 2012-01-09 23:48:34 --> Total execution time: 0.5112
DEBUG - 2012-01-09 23:48:36 --> Config Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:48:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:48:36 --> URI Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Router Class Initialized
DEBUG - 2012-01-09 23:48:36 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:48:36 --> Output Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Security Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Input Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:48:36 --> Language Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Loader Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:48:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Session Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:48:36 --> Session routines successfully run
DEBUG - 2012-01-09 23:48:36 --> Controller Class Initialized
DEBUG - 2012-01-09 23:48:36 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:48:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:48:36 --> Final output sent to browser
DEBUG - 2012-01-09 23:48:36 --> Total execution time: 0.5097
DEBUG - 2012-01-09 23:48:59 --> Config Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:48:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:48:59 --> URI Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Router Class Initialized
DEBUG - 2012-01-09 23:48:59 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:48:59 --> Output Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Security Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Input Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:48:59 --> Language Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Loader Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:48:59 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Session Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:48:59 --> Session routines successfully run
DEBUG - 2012-01-09 23:48:59 --> Controller Class Initialized
DEBUG - 2012-01-09 23:48:59 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:48:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:48:59 --> Final output sent to browser
DEBUG - 2012-01-09 23:48:59 --> Total execution time: 0.4534
DEBUG - 2012-01-09 23:49:18 --> Config Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:49:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:49:18 --> URI Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Router Class Initialized
DEBUG - 2012-01-09 23:49:18 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:49:18 --> Output Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Security Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Input Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:49:18 --> Language Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Loader Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:49:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Session Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:49:18 --> Session routines successfully run
DEBUG - 2012-01-09 23:49:18 --> Controller Class Initialized
DEBUG - 2012-01-09 23:49:18 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:49:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:49:18 --> Final output sent to browser
DEBUG - 2012-01-09 23:49:18 --> Total execution time: 0.5932
DEBUG - 2012-01-09 23:49:58 --> Config Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:49:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:49:58 --> URI Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Router Class Initialized
DEBUG - 2012-01-09 23:49:58 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:49:58 --> Output Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Security Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Input Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:49:58 --> Language Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Loader Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:49:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Session Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:49:58 --> Session routines successfully run
DEBUG - 2012-01-09 23:49:58 --> Controller Class Initialized
DEBUG - 2012-01-09 23:49:58 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:49:59 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:49:59 --> Final output sent to browser
DEBUG - 2012-01-09 23:49:59 --> Total execution time: 0.6666
DEBUG - 2012-01-09 23:51:12 --> Config Class Initialized
DEBUG - 2012-01-09 23:51:12 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:51:12 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:51:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:51:12 --> URI Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Router Class Initialized
DEBUG - 2012-01-09 23:51:13 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:51:13 --> Output Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Security Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Input Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:51:13 --> Language Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Loader Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:51:13 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Session Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:51:13 --> Session routines successfully run
DEBUG - 2012-01-09 23:51:13 --> Controller Class Initialized
DEBUG - 2012-01-09 23:51:13 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:51:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:51:13 --> Final output sent to browser
DEBUG - 2012-01-09 23:51:13 --> Total execution time: 0.5714
DEBUG - 2012-01-09 23:51:36 --> Config Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:51:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:51:36 --> URI Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Router Class Initialized
DEBUG - 2012-01-09 23:51:36 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:51:36 --> Output Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Security Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Input Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:51:36 --> Language Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Loader Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:51:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Session Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:51:36 --> Session routines successfully run
DEBUG - 2012-01-09 23:51:36 --> Controller Class Initialized
DEBUG - 2012-01-09 23:51:36 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:51:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:51:36 --> Final output sent to browser
DEBUG - 2012-01-09 23:51:36 --> Total execution time: 0.5075
DEBUG - 2012-01-09 23:51:57 --> Config Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:51:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:51:57 --> URI Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Router Class Initialized
DEBUG - 2012-01-09 23:51:57 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:51:57 --> Output Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Security Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Input Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:51:57 --> Language Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Loader Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:51:57 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Session Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:51:57 --> Session routines successfully run
DEBUG - 2012-01-09 23:51:57 --> Controller Class Initialized
DEBUG - 2012-01-09 23:51:57 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:51:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:51:57 --> Final output sent to browser
DEBUG - 2012-01-09 23:51:57 --> Total execution time: 0.4260
DEBUG - 2012-01-09 23:56:21 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:22 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:22 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:56:22 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:22 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:22 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:22 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:22 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:22 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:56:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:56:22 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:22 --> Total execution time: 0.5028
DEBUG - 2012-01-09 23:56:30 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:30 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:30 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:30 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:30 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:30 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:30 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:30 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:56:30 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:30 --> Total execution time: 0.4624
DEBUG - 2012-01-09 23:56:32 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:32 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:32 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:32 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:32 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:32 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:32 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:56:32 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:32 --> Total execution time: 0.4865
DEBUG - 2012-01-09 23:56:34 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:34 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:35 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:35 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:35 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:35 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:35 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:35 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:56:35 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:35 --> Total execution time: 0.6317
DEBUG - 2012-01-09 23:56:37 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:37 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:37 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:37 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:37 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:37 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:37 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:56:37 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:37 --> Total execution time: 0.4030
DEBUG - 2012-01-09 23:56:38 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:38 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:38 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:38 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:38 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:38 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:38 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:56:38 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:38 --> Total execution time: 0.4440
DEBUG - 2012-01-09 23:56:39 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:39 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:39 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:39 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:39 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:39 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:39 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:56:39 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:39 --> Total execution time: 0.4359
DEBUG - 2012-01-09 23:56:40 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:40 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:40 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:40 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:40 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:41 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:41 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:41 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:41 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:56:41 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:41 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-09 23:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:41 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:41 --> Total execution time: 1.3026
DEBUG - 2012-01-09 23:56:41 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:41 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:42 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:42 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:42 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:42 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:42 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:42 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:42 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:56:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:56:42 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:42 --> Total execution time: 0.8387
DEBUG - 2012-01-09 23:56:45 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:45 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:45 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:45 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:45 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:45 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:45 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:56:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:56:45 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:45 --> Total execution time: 0.4988
DEBUG - 2012-01-09 23:56:57 --> Config Class Initialized
DEBUG - 2012-01-09 23:56:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:56:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:56:58 --> URI Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Router Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Output Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Security Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Input Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:56:58 --> Language Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Loader Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:56:58 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Session Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:56:58 --> Session routines successfully run
DEBUG - 2012-01-09 23:56:58 --> Controller Class Initialized
DEBUG - 2012-01-09 23:56:58 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:56:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:56:58 --> Final output sent to browser
DEBUG - 2012-01-09 23:56:58 --> Total execution time: 0.4481
DEBUG - 2012-01-09 23:57:38 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:38 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:39 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Router Class Initialized
DEBUG - 2012-01-09 23:57:39 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:57:39 --> Output Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Security Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Input Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:57:39 --> Language Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Loader Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:57:39 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Session Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:57:39 --> A session cookie was not found.
DEBUG - 2012-01-09 23:57:39 --> Session routines successfully run
DEBUG - 2012-01-09 23:57:39 --> Controller Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:57:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:57:39 --> Final output sent to browser
DEBUG - 2012-01-09 23:57:39 --> Total execution time: 0.5297
DEBUG - 2012-01-09 23:57:39 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:39 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:39 --> Router Class Initialized
ERROR - 2012-01-09 23:57:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:57:49 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:49 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Router Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Output Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Security Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Input Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:57:49 --> Language Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Loader Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:57:49 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Session Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:57:49 --> Session routines successfully run
DEBUG - 2012-01-09 23:57:49 --> Controller Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:57:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:57:49 --> Final output sent to browser
DEBUG - 2012-01-09 23:57:49 --> Total execution time: 0.3615
DEBUG - 2012-01-09 23:57:49 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:49 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:49 --> Router Class Initialized
ERROR - 2012-01-09 23:57:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:57:51 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:51 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Router Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Output Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Security Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Input Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:57:51 --> Language Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Loader Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:57:51 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Session Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:57:51 --> Session routines successfully run
DEBUG - 2012-01-09 23:57:51 --> Controller Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:57:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:57:51 --> Final output sent to browser
DEBUG - 2012-01-09 23:57:51 --> Total execution time: 0.4459
DEBUG - 2012-01-09 23:57:51 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:51 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:51 --> Router Class Initialized
ERROR - 2012-01-09 23:57:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:57:53 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:53 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Router Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Output Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Security Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Input Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:57:53 --> Language Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Loader Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:57:53 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Session Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:57:53 --> Session routines successfully run
DEBUG - 2012-01-09 23:57:53 --> Controller Class Initialized
DEBUG - 2012-01-09 23:57:53 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:57:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:57:53 --> Final output sent to browser
DEBUG - 2012-01-09 23:57:53 --> Total execution time: 0.3991
DEBUG - 2012-01-09 23:57:54 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:54 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:54 --> Router Class Initialized
ERROR - 2012-01-09 23:57:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:57:55 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:55 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Router Class Initialized
DEBUG - 2012-01-09 23:57:55 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:57:55 --> Output Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Security Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Input Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:57:55 --> Language Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Loader Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:57:55 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Session Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:57:55 --> Session routines successfully run
DEBUG - 2012-01-09 23:57:55 --> Controller Class Initialized
DEBUG - 2012-01-09 23:57:55 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:57:55 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:57:55 --> Final output sent to browser
DEBUG - 2012-01-09 23:57:55 --> Total execution time: 0.4119
DEBUG - 2012-01-09 23:57:56 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:56 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:56 --> Router Class Initialized
ERROR - 2012-01-09 23:57:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:57:57 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:57 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Router Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Output Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Security Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Input Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:57:57 --> Language Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Loader Class Initialized
DEBUG - 2012-01-09 23:57:57 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:57:57 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:57:58 --> Session Class Initialized
DEBUG - 2012-01-09 23:57:58 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:57:58 --> Session routines successfully run
DEBUG - 2012-01-09 23:57:58 --> Controller Class Initialized
DEBUG - 2012-01-09 23:57:58 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:57:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:57:58 --> Final output sent to browser
DEBUG - 2012-01-09 23:57:58 --> Total execution time: 0.4319
DEBUG - 2012-01-09 23:57:58 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:58 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:58 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:58 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:58 --> Router Class Initialized
ERROR - 2012-01-09 23:57:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:57:59 --> Config Class Initialized
DEBUG - 2012-01-09 23:57:59 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:57:59 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:57:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:57:59 --> URI Class Initialized
DEBUG - 2012-01-09 23:57:59 --> Router Class Initialized
DEBUG - 2012-01-09 23:57:59 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:00 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:00 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:00 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:00 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:00 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:00 --> Total execution time: 0.4184
DEBUG - 2012-01-09 23:58:00 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:00 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:00 --> Router Class Initialized
ERROR - 2012-01-09 23:58:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:02 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:02 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:02 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:02 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:02 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:02 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:02 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:02 --> Total execution time: 0.4400
DEBUG - 2012-01-09 23:58:02 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:02 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:02 --> Router Class Initialized
ERROR - 2012-01-09 23:58:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:04 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:04 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:04 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:04 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:04 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:04 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:58:04 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:04 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:04 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:04 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:04 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:05 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:05 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:05 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:05 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:05 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:05 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:05 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:05 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:05 --> Total execution time: 0.7167
DEBUG - 2012-01-09 23:58:05 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:05 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:06 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Router Class Initialized
ERROR - 2012-01-09 23:58:06 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:06 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:06 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:06 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:06 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:06 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:06 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:06 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:06 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:06 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:06 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:06 --> Total execution time: 0.4173
DEBUG - 2012-01-09 23:58:07 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:07 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:07 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:07 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:07 --> Router Class Initialized
ERROR - 2012-01-09 23:58:07 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:08 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:08 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:08 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:08 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:08 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:08 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:08 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:08 --> Total execution time: 0.4272
DEBUG - 2012-01-09 23:58:09 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:09 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:09 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:09 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:09 --> Router Class Initialized
ERROR - 2012-01-09 23:58:09 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:35 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:35 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:35 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:35 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:35 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:35 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:58:36 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:36 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:36 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:36 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:36 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:36 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:36 --> Total execution time: 0.4597
DEBUG - 2012-01-09 23:58:36 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:36 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:36 --> Router Class Initialized
ERROR - 2012-01-09 23:58:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:49 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:49 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:49 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:49 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:50 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:50 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:50 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:50 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:50 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:50 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:50 --> Total execution time: 0.3998
DEBUG - 2012-01-09 23:58:50 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:50 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:50 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:50 --> Router Class Initialized
ERROR - 2012-01-09 23:58:50 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:53 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:53 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:53 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:53 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:53 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:53 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:53 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:54 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:54 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:54 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:54 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:54 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:54 --> Total execution time: 0.4260
DEBUG - 2012-01-09 23:58:54 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:54 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:54 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:54 --> Router Class Initialized
ERROR - 2012-01-09 23:58:54 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:58:56 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:56 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Router Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Output Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Security Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Input Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:58:56 --> Language Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Loader Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:58:56 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Session Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:58:56 --> Session routines successfully run
DEBUG - 2012-01-09 23:58:56 --> Controller Class Initialized
DEBUG - 2012-01-09 23:58:56 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:58:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:58:56 --> Final output sent to browser
DEBUG - 2012-01-09 23:58:56 --> Total execution time: 0.4156
DEBUG - 2012-01-09 23:58:57 --> Config Class Initialized
DEBUG - 2012-01-09 23:58:57 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:58:57 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:58:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:58:57 --> URI Class Initialized
DEBUG - 2012-01-09 23:58:57 --> Router Class Initialized
ERROR - 2012-01-09 23:58:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:08 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:08 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:08 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:08 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:08 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:08 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:08 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:08 --> Total execution time: 0.3850
DEBUG - 2012-01-09 23:59:08 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:08 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:08 --> Router Class Initialized
ERROR - 2012-01-09 23:59:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:10 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:10 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:10 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:59:10 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:10 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:10 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:10 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:10 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:10 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:10 --> Total execution time: 0.4956
DEBUG - 2012-01-09 23:59:10 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:10 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:10 --> Router Class Initialized
ERROR - 2012-01-09 23:59:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:13 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:13 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:13 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:13 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:13 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:13 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:14 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:14 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:14 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:14 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:14 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:14 --> Total execution time: 0.4109
DEBUG - 2012-01-09 23:59:14 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:14 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:14 --> Router Class Initialized
ERROR - 2012-01-09 23:59:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:15 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:15 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:15 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:15 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:15 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:16 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:16 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:16 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:16 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:16 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:16 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:16 --> Total execution time: 0.4377
DEBUG - 2012-01-09 23:59:16 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:16 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:16 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:16 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:16 --> Router Class Initialized
ERROR - 2012-01-09 23:59:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:18 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:18 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:18 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:18 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:18 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:18 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:18 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:18 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:18 --> Total execution time: 0.4345
DEBUG - 2012-01-09 23:59:19 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:19 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:19 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:19 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:19 --> Router Class Initialized
ERROR - 2012-01-09 23:59:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:20 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:20 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:20 --> No URI present. Default controller set.
DEBUG - 2012-01-09 23:59:20 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:20 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:20 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:20 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:20 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:20 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:20 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:20 --> Total execution time: 0.4209
DEBUG - 2012-01-09 23:59:21 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:21 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:21 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:21 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:21 --> Router Class Initialized
ERROR - 2012-01-09 23:59:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:22 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:22 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:22 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:22 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:23 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:23 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:23 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:23 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:23 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:23 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:23 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:23 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:23 --> Total execution time: 0.4310
DEBUG - 2012-01-09 23:59:23 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:23 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:23 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:23 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:23 --> Router Class Initialized
ERROR - 2012-01-09 23:59:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-09 23:59:24 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:24 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:24 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:25 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Router Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Output Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Security Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Input Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-09 23:59:25 --> Language Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Loader Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Helper loaded: url_helper
DEBUG - 2012-01-09 23:59:25 --> Database Driver Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Session Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Helper loaded: string_helper
DEBUG - 2012-01-09 23:59:25 --> Session routines successfully run
DEBUG - 2012-01-09 23:59:25 --> Controller Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Pagination Class Initialized
DEBUG - 2012-01-09 23:59:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-09 23:59:25 --> Final output sent to browser
DEBUG - 2012-01-09 23:59:25 --> Total execution time: 0.4040
DEBUG - 2012-01-09 23:59:25 --> Config Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Hooks Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Utf8 Class Initialized
DEBUG - 2012-01-09 23:59:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-09 23:59:25 --> URI Class Initialized
DEBUG - 2012-01-09 23:59:25 --> Router Class Initialized
ERROR - 2012-01-09 23:59:25 --> 404 Page Not Found --> favicon.ico

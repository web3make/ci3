<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-18 16:27:09 --> Config Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Hooks Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Utf8 Class Initialized
DEBUG - 2013-01-18 16:27:09 --> UTF-8 Support Enabled
DEBUG - 2013-01-18 16:27:09 --> URI Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Router Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Output Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Security Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Input Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-18 16:27:09 --> Language Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Loader Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Helper loaded: url_helper
DEBUG - 2013-01-18 16:27:09 --> Database Driver Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Session Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Helper loaded: string_helper
DEBUG - 2013-01-18 16:27:09 --> A session cookie was not found.
DEBUG - 2013-01-18 16:27:09 --> Session routines successfully run
DEBUG - 2013-01-18 16:27:09 --> Model Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Model Class Initialized
DEBUG - 2013-01-18 16:27:09 --> Controller Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Config Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Hooks Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Utf8 Class Initialized
DEBUG - 2013-01-18 16:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-01-18 16:27:10 --> URI Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Router Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Output Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Security Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Input Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-18 16:27:10 --> Language Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Loader Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Helper loaded: url_helper
DEBUG - 2013-01-18 16:27:10 --> Database Driver Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Session Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Helper loaded: string_helper
DEBUG - 2013-01-18 16:27:10 --> Session routines successfully run
DEBUG - 2013-01-18 16:27:10 --> Model Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Model Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Controller Class Initialized
DEBUG - 2013-01-18 16:27:10 --> File loaded: application/views/admin/login.php
DEBUG - 2013-01-18 16:27:10 --> Final output sent to browser
DEBUG - 2013-01-18 16:27:10 --> Total execution time: 0.1505
DEBUG - 2013-01-18 16:27:10 --> Config Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Hooks Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Utf8 Class Initialized
DEBUG - 2013-01-18 16:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-01-18 16:27:10 --> URI Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Router Class Initialized
ERROR - 2013-01-18 16:27:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-01-18 16:27:10 --> Config Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Hooks Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Utf8 Class Initialized
DEBUG - 2013-01-18 16:27:10 --> UTF-8 Support Enabled
DEBUG - 2013-01-18 16:27:10 --> URI Class Initialized
DEBUG - 2013-01-18 16:27:10 --> Router Class Initialized
ERROR - 2013-01-18 16:27:10 --> 404 Page Not Found --> favicon.ico

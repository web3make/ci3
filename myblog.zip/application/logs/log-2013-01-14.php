<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-01-14 12:11:35 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:35 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Router Class Initialized
DEBUG - 2013-01-14 12:11:35 --> No URI present. Default controller set.
DEBUG - 2013-01-14 12:11:35 --> Output Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Security Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Input Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:11:35 --> Language Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Loader Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:11:35 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Session Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:11:35 --> A session cookie was not found.
DEBUG - 2013-01-14 12:11:35 --> Session routines successfully run
DEBUG - 2013-01-14 12:11:35 --> Model Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Model Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Controller Class Initialized
DEBUG - 2013-01-14 12:11:35 --> Pagination Class Initialized
DEBUG - 2013-01-14 12:11:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-14 12:11:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-14 12:11:35 --> File loaded: application/views/user/blocks/articles.php
ERROR - 2013-01-14 12:11:35 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\user\home.php 7
DEBUG - 2013-01-14 12:11:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-14 12:11:35 --> File loaded: application/views/user/home.php
DEBUG - 2013-01-14 12:11:35 --> Final output sent to browser
DEBUG - 2013-01-14 12:11:35 --> Total execution time: 0.3903
DEBUG - 2013-01-14 12:11:36 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:36 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:36 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Router Class Initialized
ERROR - 2013-01-14 12:11:36 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-14 12:11:36 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:36 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:36 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Router Class Initialized
ERROR - 2013-01-14 12:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-01-14 12:11:36 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:36 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:36 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:36 --> Router Class Initialized
ERROR - 2013-01-14 12:11:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-01-14 12:11:41 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:41 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:42 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:42 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:42 --> Router Class Initialized
DEBUG - 2013-01-14 12:11:42 --> Output Class Initialized
DEBUG - 2013-01-14 12:11:42 --> Security Class Initialized
DEBUG - 2013-01-14 12:11:42 --> Input Class Initialized
DEBUG - 2013-01-14 12:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:11:42 --> Language Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:47 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:47 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Router Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Output Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Security Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Input Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:11:47 --> Language Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Loader Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:11:47 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Session Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:11:47 --> A session cookie was not found.
DEBUG - 2013-01-14 12:11:47 --> Session routines successfully run
DEBUG - 2013-01-14 12:11:47 --> Model Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Model Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Controller Class Initialized
DEBUG - 2013-01-14 12:11:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-14 12:11:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-14 12:11:47 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2013-01-14 12:11:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-14 12:11:47 --> File loaded: application/views/user/article.php
DEBUG - 2013-01-14 12:11:47 --> Final output sent to browser
DEBUG - 2013-01-14 12:11:47 --> Total execution time: 0.1322
DEBUG - 2013-01-14 12:11:47 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:47 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:47 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Router Class Initialized
ERROR - 2013-01-14 12:11:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-01-14 12:11:47 --> Config Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:11:47 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:11:47 --> URI Class Initialized
DEBUG - 2013-01-14 12:11:47 --> Router Class Initialized
ERROR - 2013-01-14 12:11:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2013-01-14 12:12:00 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:00 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:00 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:00 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:00 --> Router Class Initialized
ERROR - 2013-01-14 12:12:00 --> 404 Page Not Found --> article
DEBUG - 2013-01-14 12:12:04 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:04 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Router Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Output Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Security Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Input Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:12:04 --> Language Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Loader Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:12:04 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Session Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:12:04 --> Session routines successfully run
DEBUG - 2013-01-14 12:12:04 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:04 --> Controller Class Initialized
DEBUG - 2013-01-14 12:12:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2013-01-14 12:12:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2013-01-14 12:12:04 --> File loaded: application/views/user/blocks/comments.php
DEBUG - 2013-01-14 12:12:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2013-01-14 12:12:04 --> File loaded: application/views/user/article.php
DEBUG - 2013-01-14 12:12:04 --> Final output sent to browser
DEBUG - 2013-01-14 12:12:04 --> Total execution time: 0.1405
DEBUG - 2013-01-14 12:12:13 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:13 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Router Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Output Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Security Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Input Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:12:13 --> Language Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Loader Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:12:13 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Session Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:12:13 --> Session routines successfully run
DEBUG - 2013-01-14 12:12:13 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Controller Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:13 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Router Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Output Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Security Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Input Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:12:13 --> Language Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Loader Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:12:13 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Session Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:12:13 --> Session routines successfully run
DEBUG - 2013-01-14 12:12:13 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:13 --> Controller Class Initialized
DEBUG - 2013-01-14 12:12:13 --> File loaded: application/views/admin/login.php
DEBUG - 2013-01-14 12:12:13 --> Final output sent to browser
DEBUG - 2013-01-14 12:12:13 --> Total execution time: 0.1277
DEBUG - 2013-01-14 12:12:15 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:15 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Router Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Output Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Security Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Input Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:12:15 --> Language Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Loader Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:12:15 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Session Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:12:15 --> Session routines successfully run
DEBUG - 2013-01-14 12:12:15 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Controller Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:15 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Router Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Output Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Security Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Input Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:12:15 --> Language Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Loader Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:12:15 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Session Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:12:15 --> Session routines successfully run
DEBUG - 2013-01-14 12:12:15 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Controller Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Pagination Class Initialized
ERROR - 2013-01-14 12:12:15 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 12:12:15 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 12:12:15 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 12:12:15 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2013-01-14 12:12:15 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2013-01-14 12:12:15 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 12:12:15 --> File loaded: application/views/admin/home.php
DEBUG - 2013-01-14 12:12:15 --> Final output sent to browser
DEBUG - 2013-01-14 12:12:15 --> Total execution time: 0.1533
DEBUG - 2013-01-14 12:12:15 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:15 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:15 --> Router Class Initialized
ERROR - 2013-01-14 12:12:15 --> 404 Page Not Found --> lessons
DEBUG - 2013-01-14 12:12:22 --> Config Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:12:22 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:12:22 --> URI Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Router Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Output Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Security Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Input Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:12:22 --> Language Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Loader Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:12:22 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Session Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:12:22 --> Session routines successfully run
DEBUG - 2013-01-14 12:12:22 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Model Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Controller Class Initialized
DEBUG - 2013-01-14 12:12:22 --> Helper loaded: tinymce_helper
ERROR - 2013-01-14 12:12:22 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 12:12:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 12:12:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 12:12:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 12:12:22 --> File loaded: application/views/admin/article.php
DEBUG - 2013-01-14 12:12:22 --> Final output sent to browser
DEBUG - 2013-01-14 12:12:22 --> Total execution time: 0.2196
DEBUG - 2013-01-14 12:39:08 --> Config Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:39:08 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:39:08 --> URI Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Router Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Output Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Security Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Input Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:39:08 --> Language Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Loader Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:39:08 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Session Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:39:08 --> Session routines successfully run
DEBUG - 2013-01-14 12:39:08 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:08 --> Controller Class Initialized
ERROR - 2013-01-14 12:39:08 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 12:39:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 12:39:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 12:39:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 12:39:08 --> File loaded: application/views/admin/comments.php
DEBUG - 2013-01-14 12:39:08 --> Final output sent to browser
DEBUG - 2013-01-14 12:39:08 --> Total execution time: 0.2372
DEBUG - 2013-01-14 12:39:30 --> Config Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:39:30 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:39:30 --> URI Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Router Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Output Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Security Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Input Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:39:30 --> Language Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Loader Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:39:30 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Session Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:39:30 --> Session routines successfully run
DEBUG - 2013-01-14 12:39:30 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:30 --> Controller Class Initialized
ERROR - 2013-01-14 12:39:30 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 12:39:30 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 12:39:30 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 12:39:30 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 12:39:30 --> File loaded: application/views/admin/category_new.php
DEBUG - 2013-01-14 12:39:30 --> Final output sent to browser
DEBUG - 2013-01-14 12:39:30 --> Total execution time: 0.2606
DEBUG - 2013-01-14 12:39:34 --> Config Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:39:34 --> URI Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Router Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Output Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Security Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Input Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:39:34 --> Language Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Loader Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:39:34 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Session Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:39:34 --> Session routines successfully run
DEBUG - 2013-01-14 12:39:34 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Controller Class Initialized
DEBUG - 2013-01-14 12:39:34 --> Helper loaded: tinymce_helper
ERROR - 2013-01-14 12:39:34 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 12:39:34 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 12:39:34 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 12:39:34 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 12:39:34 --> File loaded: application/views/admin/page_create.php
DEBUG - 2013-01-14 12:39:34 --> Final output sent to browser
DEBUG - 2013-01-14 12:39:34 --> Total execution time: 0.2305
DEBUG - 2013-01-14 12:39:35 --> Config Class Initialized
DEBUG - 2013-01-14 12:39:35 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:39:35 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:39:35 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:39:35 --> URI Class Initialized
DEBUG - 2013-01-14 12:39:35 --> Router Class Initialized
DEBUG - 2013-01-14 12:39:35 --> Output Class Initialized
DEBUG - 2013-01-14 12:39:35 --> Security Class Initialized
DEBUG - 2013-01-14 12:39:35 --> Input Class Initialized
DEBUG - 2013-01-14 12:39:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:39:35 --> Language Class Initialized
DEBUG - 2013-01-14 12:39:36 --> Loader Class Initialized
DEBUG - 2013-01-14 12:39:36 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:39:36 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:39:36 --> Session Class Initialized
DEBUG - 2013-01-14 12:39:36 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:39:36 --> Session routines successfully run
DEBUG - 2013-01-14 12:39:36 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:36 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:36 --> Controller Class Initialized
ERROR - 2013-01-14 12:39:36 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 12:39:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 12:39:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 12:39:36 --> File loaded: application/views//admin/blocks/articles.php
DEBUG - 2013-01-14 12:39:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 12:39:36 --> File loaded: application/views/admin/category.php
DEBUG - 2013-01-14 12:39:36 --> Final output sent to browser
DEBUG - 2013-01-14 12:39:36 --> Total execution time: 0.2125
DEBUG - 2013-01-14 12:39:37 --> Config Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Hooks Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Utf8 Class Initialized
DEBUG - 2013-01-14 12:39:37 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 12:39:37 --> URI Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Router Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Output Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Security Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Input Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 12:39:37 --> Language Class Initialized
DEBUG - 2013-01-14 12:39:37 --> Loader Class Initialized
DEBUG - 2013-01-14 12:39:38 --> Helper loaded: url_helper
DEBUG - 2013-01-14 12:39:38 --> Database Driver Class Initialized
DEBUG - 2013-01-14 12:39:38 --> Session Class Initialized
DEBUG - 2013-01-14 12:39:38 --> Helper loaded: string_helper
DEBUG - 2013-01-14 12:39:38 --> Session routines successfully run
DEBUG - 2013-01-14 12:39:38 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:38 --> Model Class Initialized
DEBUG - 2013-01-14 12:39:38 --> Controller Class Initialized
DEBUG - 2013-01-14 12:39:38 --> Helper loaded: tinymce_helper
ERROR - 2013-01-14 12:39:38 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 12:39:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 12:39:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 12:39:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 12:39:38 --> File loaded: application/views/admin/article_create.php
DEBUG - 2013-01-14 12:39:38 --> Final output sent to browser
DEBUG - 2013-01-14 12:39:38 --> Total execution time: 0.2119
DEBUG - 2013-01-14 21:06:39 --> Config Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Hooks Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Utf8 Class Initialized
DEBUG - 2013-01-14 21:06:39 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 21:06:39 --> URI Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Router Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Output Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Security Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Input Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 21:06:39 --> Language Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Loader Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Helper loaded: url_helper
DEBUG - 2013-01-14 21:06:39 --> Database Driver Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Session Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Helper loaded: string_helper
DEBUG - 2013-01-14 21:06:39 --> A session cookie was not found.
DEBUG - 2013-01-14 21:06:39 --> Session routines successfully run
DEBUG - 2013-01-14 21:06:39 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Controller Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Config Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Hooks Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Utf8 Class Initialized
DEBUG - 2013-01-14 21:06:39 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 21:06:39 --> URI Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Router Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Output Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Security Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Input Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 21:06:39 --> Language Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Loader Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Helper loaded: url_helper
DEBUG - 2013-01-14 21:06:39 --> Database Driver Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Session Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Helper loaded: string_helper
DEBUG - 2013-01-14 21:06:39 --> Session routines successfully run
DEBUG - 2013-01-14 21:06:39 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:39 --> Controller Class Initialized
DEBUG - 2013-01-14 21:06:39 --> File loaded: application/views/admin/login.php
DEBUG - 2013-01-14 21:06:39 --> Final output sent to browser
DEBUG - 2013-01-14 21:06:39 --> Total execution time: 0.2427
DEBUG - 2013-01-14 21:06:41 --> Config Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Hooks Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Utf8 Class Initialized
DEBUG - 2013-01-14 21:06:41 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 21:06:41 --> URI Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Router Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Output Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Security Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Input Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 21:06:41 --> Language Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Loader Class Initialized
DEBUG - 2013-01-14 21:06:41 --> Helper loaded: url_helper
DEBUG - 2013-01-14 21:06:41 --> Database Driver Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Session Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Helper loaded: string_helper
DEBUG - 2013-01-14 21:06:42 --> Session routines successfully run
DEBUG - 2013-01-14 21:06:42 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Controller Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Config Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Hooks Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Utf8 Class Initialized
DEBUG - 2013-01-14 21:06:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 21:06:42 --> URI Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Router Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Output Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Security Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Input Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-01-14 21:06:42 --> Language Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Loader Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Helper loaded: url_helper
DEBUG - 2013-01-14 21:06:42 --> Database Driver Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Session Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Helper loaded: string_helper
DEBUG - 2013-01-14 21:06:42 --> Session routines successfully run
DEBUG - 2013-01-14 21:06:42 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Model Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Controller Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Pagination Class Initialized
ERROR - 2013-01-14 21:06:42 --> Severity: Notice  --> Undefined variable: site_name B:\home\blog\www\application\views\admin\blocks\header.php 14
DEBUG - 2013-01-14 21:06:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2013-01-14 21:06:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2013-01-14 21:06:42 --> File loaded: application/views//admin/blocks/articles.php
ERROR - 2013-01-14 21:06:42 --> Severity: Notice  --> Undefined variable: pages B:\home\blog\www\application\views\admin\home.php 11
DEBUG - 2013-01-14 21:06:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2013-01-14 21:06:42 --> File loaded: application/views/admin/home.php
DEBUG - 2013-01-14 21:06:42 --> Final output sent to browser
DEBUG - 2013-01-14 21:06:42 --> Total execution time: 0.3552
DEBUG - 2013-01-14 21:06:42 --> Config Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Hooks Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Utf8 Class Initialized
DEBUG - 2013-01-14 21:06:42 --> UTF-8 Support Enabled
DEBUG - 2013-01-14 21:06:42 --> URI Class Initialized
DEBUG - 2013-01-14 21:06:42 --> Router Class Initialized
ERROR - 2013-01-14 21:06:42 --> 404 Page Not Found --> lessons

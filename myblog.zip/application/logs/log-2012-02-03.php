<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-02-03 20:33:57 --> Config Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:33:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:33:57 --> URI Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Router Class Initialized
DEBUG - 2012-02-03 20:33:57 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:33:57 --> Output Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Security Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Input Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:33:57 --> Language Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Loader Class Initialized
DEBUG - 2012-02-03 20:33:57 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:33:57 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:33:58 --> Session Class Initialized
DEBUG - 2012-02-03 20:33:58 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:33:58 --> A session cookie was not found.
DEBUG - 2012-02-03 20:33:58 --> Session routines successfully run
DEBUG - 2012-02-03 20:33:58 --> Model Class Initialized
DEBUG - 2012-02-03 20:33:58 --> Model Class Initialized
DEBUG - 2012-02-03 20:33:58 --> Controller Class Initialized
DEBUG - 2012-02-03 20:33:58 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:33:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:33:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:33:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:33:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:33:58 --> Final output sent to browser
DEBUG - 2012-02-03 20:33:58 --> Total execution time: 0.6901
DEBUG - 2012-02-03 20:34:39 --> Config Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:34:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:34:39 --> URI Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Router Class Initialized
DEBUG - 2012-02-03 20:34:39 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:34:39 --> Output Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Security Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Input Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:34:39 --> Language Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Loader Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:34:39 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Session Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:34:39 --> Session routines successfully run
DEBUG - 2012-02-03 20:34:39 --> Model Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Model Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Controller Class Initialized
DEBUG - 2012-02-03 20:34:39 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:34:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:34:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:34:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:34:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:34:39 --> Final output sent to browser
DEBUG - 2012-02-03 20:34:39 --> Total execution time: 0.4943
DEBUG - 2012-02-03 20:37:13 --> Config Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:37:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:37:13 --> URI Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Router Class Initialized
DEBUG - 2012-02-03 20:37:13 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:37:13 --> Output Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Security Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Input Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:37:13 --> Language Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Loader Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:37:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Session Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:37:13 --> Session routines successfully run
DEBUG - 2012-02-03 20:37:13 --> Model Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Model Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Controller Class Initialized
DEBUG - 2012-02-03 20:37:13 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:37:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:37:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:37:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:37:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:37:13 --> Final output sent to browser
DEBUG - 2012-02-03 20:37:13 --> Total execution time: 0.4726
DEBUG - 2012-02-03 20:37:40 --> Config Class Initialized
DEBUG - 2012-02-03 20:37:40 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:37:40 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:37:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:37:41 --> URI Class Initialized
DEBUG - 2012-02-03 20:37:41 --> Router Class Initialized
DEBUG - 2012-02-03 20:37:41 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:37:41 --> Output Class Initialized
DEBUG - 2012-02-03 20:37:41 --> Security Class Initialized
DEBUG - 2012-02-03 20:37:41 --> Input Class Initialized
DEBUG - 2012-02-03 20:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:37:41 --> Language Class Initialized
DEBUG - 2012-02-03 20:37:41 --> Loader Class Initialized
DEBUG - 2012-02-03 20:37:42 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:37:42 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:37:42 --> Session Class Initialized
DEBUG - 2012-02-03 20:37:42 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:37:42 --> Session routines successfully run
DEBUG - 2012-02-03 20:37:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:37:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:37:42 --> Controller Class Initialized
DEBUG - 2012-02-03 20:37:42 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:37:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:37:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:37:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:37:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:37:42 --> Final output sent to browser
DEBUG - 2012-02-03 20:37:42 --> Total execution time: 1.7741
DEBUG - 2012-02-03 20:41:25 --> Config Class Initialized
DEBUG - 2012-02-03 20:41:25 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:41:25 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:41:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:41:25 --> URI Class Initialized
DEBUG - 2012-02-03 20:41:25 --> Router Class Initialized
ERROR - 2012-02-03 20:41:25 --> 404 Page Not Found --> lessons
DEBUG - 2012-02-03 20:41:36 --> Config Class Initialized
DEBUG - 2012-02-03 20:41:36 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:41:36 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:41:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:41:36 --> URI Class Initialized
DEBUG - 2012-02-03 20:41:36 --> Router Class Initialized
DEBUG - 2012-02-03 20:41:36 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:41:36 --> Output Class Initialized
DEBUG - 2012-02-03 20:41:36 --> Security Class Initialized
DEBUG - 2012-02-03 20:41:36 --> Input Class Initialized
DEBUG - 2012-02-03 20:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:41:36 --> Language Class Initialized
DEBUG - 2012-02-03 20:41:36 --> Loader Class Initialized
DEBUG - 2012-02-03 20:41:37 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:41:37 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:41:37 --> Session Class Initialized
DEBUG - 2012-02-03 20:41:37 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:41:37 --> Session routines successfully run
DEBUG - 2012-02-03 20:41:37 --> Model Class Initialized
DEBUG - 2012-02-03 20:41:37 --> Model Class Initialized
DEBUG - 2012-02-03 20:41:37 --> Controller Class Initialized
DEBUG - 2012-02-03 20:41:37 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:41:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:41:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:41:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:41:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:41:37 --> Final output sent to browser
DEBUG - 2012-02-03 20:41:37 --> Total execution time: 0.4466
DEBUG - 2012-02-03 20:41:50 --> Config Class Initialized
DEBUG - 2012-02-03 20:41:50 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:41:50 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:41:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:41:50 --> URI Class Initialized
DEBUG - 2012-02-03 20:41:50 --> Router Class Initialized
DEBUG - 2012-02-03 20:41:50 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:41:50 --> Output Class Initialized
DEBUG - 2012-02-03 20:41:50 --> Security Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Input Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:41:51 --> Language Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Loader Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:41:51 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Session Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:41:51 --> Session routines successfully run
DEBUG - 2012-02-03 20:41:51 --> Model Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Model Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Controller Class Initialized
DEBUG - 2012-02-03 20:41:51 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:41:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:41:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:41:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:41:51 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:41:51 --> Final output sent to browser
DEBUG - 2012-02-03 20:41:51 --> Total execution time: 0.4833
DEBUG - 2012-02-03 20:43:42 --> Config Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:43:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:43:42 --> URI Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Router Class Initialized
DEBUG - 2012-02-03 20:43:42 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:43:42 --> Output Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Security Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Input Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:43:42 --> Language Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Loader Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:43:42 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Session Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:43:42 --> Session routines successfully run
DEBUG - 2012-02-03 20:43:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Controller Class Initialized
DEBUG - 2012-02-03 20:43:42 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:43:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:43:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:43:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:43:42 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:43:42 --> Final output sent to browser
DEBUG - 2012-02-03 20:43:42 --> Total execution time: 0.5101
DEBUG - 2012-02-03 20:44:02 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:02 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:02 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:44:02 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:02 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:02 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:02 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:02 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:02 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:44:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:44:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:44:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:44:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:44:02 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:02 --> Total execution time: 0.4938
DEBUG - 2012-02-03 20:44:19 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:19 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:19 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:19 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:19 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:19 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:19 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:44:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:44:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:44:20 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 20:44:20 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:20 --> Total execution time: 1.6834
DEBUG - 2012-02-03 20:44:22 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:22 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:22 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:44:22 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:22 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:22 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:22 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:22 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:44:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:44:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:44:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:44:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:44:22 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:22 --> Total execution time: 0.8436
DEBUG - 2012-02-03 20:44:24 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:24 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:24 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:24 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:24 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:24 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:25 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:25 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:25 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:44:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:44:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:44:25 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 20:44:25 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:25 --> Total execution time: 0.4607
DEBUG - 2012-02-03 20:44:36 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:36 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:36 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:36 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:36 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:36 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:36 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:44:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:44:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:44:36 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 20:44:36 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:36 --> Total execution time: 0.4663
DEBUG - 2012-02-03 20:44:40 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:40 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:40 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:40 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:40 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:40 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:40 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:44:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:44:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:44:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 20:44:41 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:41 --> Total execution time: 1.0266
DEBUG - 2012-02-03 20:44:44 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:44 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:44 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:44 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:44 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:45 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:45 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:45 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:45 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:45 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:45 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:45 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:46 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:46 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:46 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:46 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:46 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:46 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:46 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:46 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:46 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-03 20:44:46 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:46 --> Total execution time: 0.8525
DEBUG - 2012-02-03 20:44:55 --> Config Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:44:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:44:55 --> URI Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Router Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Output Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Security Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Input Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:44:55 --> Language Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Loader Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:44:55 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Session Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:44:55 --> Session routines successfully run
DEBUG - 2012-02-03 20:44:55 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Model Class Initialized
DEBUG - 2012-02-03 20:44:55 --> Controller Class Initialized
DEBUG - 2012-02-03 20:44:55 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-03 20:44:55 --> Final output sent to browser
DEBUG - 2012-02-03 20:44:55 --> Total execution time: 0.5111
DEBUG - 2012-02-03 20:45:03 --> Config Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:45:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:45:03 --> URI Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Router Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Output Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Security Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Input Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:45:03 --> Language Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Loader Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:45:03 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Session Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:45:03 --> Session routines successfully run
DEBUG - 2012-02-03 20:45:03 --> Model Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Model Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Controller Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Config Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:45:03 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:45:03 --> URI Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Router Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Output Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Security Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Input Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:45:03 --> Language Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Loader Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:45:03 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Session Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:45:03 --> Session routines successfully run
DEBUG - 2012-02-03 20:45:03 --> Model Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Model Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Controller Class Initialized
DEBUG - 2012-02-03 20:45:03 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:45:04 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:45:04 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:45:04 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:45:04 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 20:45:04 --> Final output sent to browser
DEBUG - 2012-02-03 20:45:04 --> Total execution time: 0.4660
DEBUG - 2012-02-03 20:46:23 --> Config Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:46:23 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:46:23 --> URI Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Router Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Output Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Security Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Input Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:46:23 --> Language Class Initialized
DEBUG - 2012-02-03 20:46:23 --> Loader Class Initialized
DEBUG - 2012-02-03 20:46:24 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:46:24 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:46:24 --> Session Class Initialized
DEBUG - 2012-02-03 20:46:24 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:46:24 --> Session routines successfully run
DEBUG - 2012-02-03 20:46:24 --> Model Class Initialized
DEBUG - 2012-02-03 20:46:24 --> Model Class Initialized
DEBUG - 2012-02-03 20:46:24 --> Controller Class Initialized
DEBUG - 2012-02-03 20:46:24 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:46:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:46:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:46:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:46:24 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 20:46:24 --> Final output sent to browser
DEBUG - 2012-02-03 20:46:24 --> Total execution time: 0.4391
DEBUG - 2012-02-03 20:46:28 --> Config Class Initialized
DEBUG - 2012-02-03 20:46:28 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:46:28 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:46:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:46:28 --> URI Class Initialized
DEBUG - 2012-02-03 20:46:28 --> Router Class Initialized
DEBUG - 2012-02-03 20:46:28 --> Output Class Initialized
DEBUG - 2012-02-03 20:46:28 --> Security Class Initialized
DEBUG - 2012-02-03 20:46:28 --> Input Class Initialized
DEBUG - 2012-02-03 20:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:46:28 --> Language Class Initialized
DEBUG - 2012-02-03 20:46:29 --> Loader Class Initialized
DEBUG - 2012-02-03 20:46:29 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:46:29 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:46:29 --> Session Class Initialized
DEBUG - 2012-02-03 20:46:29 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:46:29 --> Session routines successfully run
DEBUG - 2012-02-03 20:46:29 --> Model Class Initialized
DEBUG - 2012-02-03 20:46:29 --> Model Class Initialized
DEBUG - 2012-02-03 20:46:29 --> Controller Class Initialized
DEBUG - 2012-02-03 20:46:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:46:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:46:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:46:29 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 20:46:29 --> Final output sent to browser
DEBUG - 2012-02-03 20:46:29 --> Total execution time: 0.8382
DEBUG - 2012-02-03 20:46:31 --> Config Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:46:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:46:31 --> URI Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Router Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Output Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Security Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Input Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:46:31 --> Language Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Loader Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:46:31 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Session Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:46:31 --> Session routines successfully run
DEBUG - 2012-02-03 20:46:31 --> Model Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Model Class Initialized
DEBUG - 2012-02-03 20:46:31 --> Controller Class Initialized
DEBUG - 2012-02-03 20:46:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:46:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:46:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:46:31 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 20:46:31 --> Final output sent to browser
DEBUG - 2012-02-03 20:46:31 --> Total execution time: 0.6664
DEBUG - 2012-02-03 20:50:11 --> Config Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:50:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:50:11 --> URI Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Router Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Output Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Security Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Input Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:50:11 --> Language Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Loader Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:50:11 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Session Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:50:11 --> Session routines successfully run
DEBUG - 2012-02-03 20:50:11 --> Model Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Model Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Controller Class Initialized
DEBUG - 2012-02-03 20:50:11 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:50:11 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:50:11 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:50:11 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:50:11 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 20:50:11 --> Final output sent to browser
DEBUG - 2012-02-03 20:50:11 --> Total execution time: 0.4504
DEBUG - 2012-02-03 20:51:18 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:18 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:18 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:18 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:18 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:18 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:18 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:51:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 20:51:18 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:18 --> Total execution time: 0.4032
DEBUG - 2012-02-03 20:51:20 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:20 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:20 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:20 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:20 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:20 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:20 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:20 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:20 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:20 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:20 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 20:51:20 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:20 --> Total execution time: 0.3682
DEBUG - 2012-02-03 20:51:22 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:22 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:22 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:22 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:22 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:22 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:22 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:22 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:22 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:22 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 20:51:22 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:22 --> Total execution time: 0.3830
DEBUG - 2012-02-03 20:51:24 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:24 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:24 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:24 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:24 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:24 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:24 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:24 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:24 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:24 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:24 --> File loaded: application/views/admin/article_create.php
DEBUG - 2012-02-03 20:51:24 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:24 --> Total execution time: 0.4323
DEBUG - 2012-02-03 20:51:27 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:27 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:27 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:27 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:27 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:27 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:27 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:27 --> File loaded: application/views/admin/category_new.php
DEBUG - 2012-02-03 20:51:27 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:27 --> Total execution time: 0.3901
DEBUG - 2012-02-03 20:51:30 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:30 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:30 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:30 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:30 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:30 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:30 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:31 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:31 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-02-03 20:51:31 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:31 --> Total execution time: 0.3664
DEBUG - 2012-02-03 20:51:32 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:32 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:32 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:32 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:32 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:32 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:32 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:51:32 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:32 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:32 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:32 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 20:51:32 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:32 --> Total execution time: 0.3887
DEBUG - 2012-02-03 20:51:35 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:35 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:35 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:35 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:35 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:35 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:35 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:36 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:36 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:36 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:36 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:36 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:36 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 20:51:36 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:36 --> Total execution time: 0.6044
DEBUG - 2012-02-03 20:51:37 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:37 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:37 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:37 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:37 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:37 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:37 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:37 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:37 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:37 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:37 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-02-03 20:51:37 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:37 --> Total execution time: 0.4336
DEBUG - 2012-02-03 20:51:40 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:40 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:40 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:40 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:40 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:40 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:40 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:40 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:40 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:41 --> File loaded: application/views/admin/comment_edit.php
DEBUG - 2012-02-03 20:51:41 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:41 --> Total execution time: 0.5037
DEBUG - 2012-02-03 20:51:42 --> Config Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:51:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:51:42 --> URI Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Router Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Output Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Security Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Input Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:51:42 --> Language Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Loader Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:51:42 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Session Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:51:42 --> Session routines successfully run
DEBUG - 2012-02-03 20:51:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Controller Class Initialized
DEBUG - 2012-02-03 20:51:42 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:51:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 20:51:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 20:51:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 20:51:42 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 20:51:42 --> Final output sent to browser
DEBUG - 2012-02-03 20:51:42 --> Total execution time: 0.4423
DEBUG - 2012-02-03 20:53:15 --> Config Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:53:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:53:15 --> URI Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Router Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Output Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Security Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Input Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:53:15 --> Language Class Initialized
DEBUG - 2012-02-03 20:53:15 --> Loader Class Initialized
DEBUG - 2012-02-03 20:53:16 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:53:16 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:53:16 --> Session Class Initialized
DEBUG - 2012-02-03 20:53:16 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:53:16 --> Session routines successfully run
DEBUG - 2012-02-03 20:53:16 --> Model Class Initialized
DEBUG - 2012-02-03 20:53:16 --> Model Class Initialized
DEBUG - 2012-02-03 20:53:16 --> Controller Class Initialized
DEBUG - 2012-02-03 20:53:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:53:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:53:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:53:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 20:53:16 --> Final output sent to browser
DEBUG - 2012-02-03 20:53:16 --> Total execution time: 0.4541
DEBUG - 2012-02-03 20:53:18 --> Config Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:53:18 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:53:18 --> URI Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Router Class Initialized
DEBUG - 2012-02-03 20:53:18 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:53:18 --> Output Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Security Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Input Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:53:18 --> Language Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Loader Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:53:18 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Session Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:53:18 --> Session routines successfully run
DEBUG - 2012-02-03 20:53:18 --> Model Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Model Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Controller Class Initialized
DEBUG - 2012-02-03 20:53:18 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:53:18 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:53:18 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:53:18 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:53:18 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:53:18 --> Final output sent to browser
DEBUG - 2012-02-03 20:53:18 --> Total execution time: 0.4850
DEBUG - 2012-02-03 20:54:09 --> Config Class Initialized
DEBUG - 2012-02-03 20:54:09 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:54:09 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:54:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:54:09 --> URI Class Initialized
DEBUG - 2012-02-03 20:54:09 --> Router Class Initialized
ERROR - 2012-02-03 20:54:09 --> 404 Page Not Found --> blog
DEBUG - 2012-02-03 20:55:13 --> Config Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:55:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:55:13 --> URI Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Router Class Initialized
DEBUG - 2012-02-03 20:55:13 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:55:13 --> Output Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Security Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Input Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:55:13 --> Language Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Loader Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:55:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Session Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:55:13 --> Session routines successfully run
DEBUG - 2012-02-03 20:55:13 --> Model Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Model Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Controller Class Initialized
DEBUG - 2012-02-03 20:55:13 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:55:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:55:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:55:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:55:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:55:13 --> Final output sent to browser
DEBUG - 2012-02-03 20:55:13 --> Total execution time: 0.4718
DEBUG - 2012-02-03 20:55:16 --> Config Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:55:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:55:16 --> URI Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Router Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Output Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Security Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Input Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:55:16 --> Language Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Loader Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:55:16 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Session Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:55:16 --> Session routines successfully run
DEBUG - 2012-02-03 20:55:16 --> Model Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Model Class Initialized
DEBUG - 2012-02-03 20:55:16 --> Controller Class Initialized
DEBUG - 2012-02-03 20:55:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:55:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:55:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:55:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 20:55:16 --> Final output sent to browser
DEBUG - 2012-02-03 20:55:16 --> Total execution time: 0.4654
DEBUG - 2012-02-03 20:57:22 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:22 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:22 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:22 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:22 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:22 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:23 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 20:57:23 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:23 --> Total execution time: 0.4800
DEBUG - 2012-02-03 20:57:27 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:27 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:27 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:27 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:27 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:28 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:28 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:28 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:28 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:28 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:28 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:28 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:28 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:28 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:28 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:28 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:28 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 20:57:28 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:28 --> Total execution time: 0.4673
DEBUG - 2012-02-03 20:57:34 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:34 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:34 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:34 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:34 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:34 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:34 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:34 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 20:57:34 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:34 --> Total execution time: 0.4581
DEBUG - 2012-02-03 20:57:40 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:40 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:40 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:40 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:40 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:40 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:40 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 20:57:41 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:41 --> Total execution time: 1.1476
DEBUG - 2012-02-03 20:57:42 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:42 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:42 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:42 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:42 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:42 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:43 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 20:57:43 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:43 --> Total execution time: 0.4747
DEBUG - 2012-02-03 20:57:47 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:47 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:47 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:47 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:47 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:47 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:47 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:48 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:48 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:48 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:48 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:48 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:48 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:48 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 20:57:48 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:48 --> Total execution time: 0.4080
DEBUG - 2012-02-03 20:57:53 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:53 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:53 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:57:53 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:53 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:53 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:53 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:54 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:54 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:54 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:54 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:54 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:54 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:54 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:57:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:57:54 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:54 --> Total execution time: 1.0165
DEBUG - 2012-02-03 20:57:56 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:56 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:56 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:56 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:56 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:56 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:56 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:56 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:57 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:57 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:57 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:57 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:57 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:57 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:57 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:57 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:57 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:57 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:57:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:57:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:57:57 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 20:57:57 --> Final output sent to browser
DEBUG - 2012-02-03 20:57:57 --> Total execution time: 0.4681
DEBUG - 2012-02-03 20:57:59 --> Config Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:57:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:57:59 --> URI Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Router Class Initialized
DEBUG - 2012-02-03 20:57:59 --> No URI present. Default controller set.
DEBUG - 2012-02-03 20:57:59 --> Output Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Security Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Input Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:57:59 --> Language Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Loader Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:57:59 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Session Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:57:59 --> Session routines successfully run
DEBUG - 2012-02-03 20:57:59 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Model Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Controller Class Initialized
DEBUG - 2012-02-03 20:57:59 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:58:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:58:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:58:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:58:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:58:00 --> Final output sent to browser
DEBUG - 2012-02-03 20:58:00 --> Total execution time: 1.1414
DEBUG - 2012-02-03 20:58:03 --> Config Class Initialized
DEBUG - 2012-02-03 20:58:03 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:58:03 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:58:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:58:04 --> URI Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Router Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Output Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Security Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Input Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:58:04 --> Language Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Loader Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:58:04 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Session Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:58:04 --> Session routines successfully run
DEBUG - 2012-02-03 20:58:04 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Controller Class Initialized
DEBUG - 2012-02-03 20:58:04 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:58:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:58:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:58:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:58:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:58:04 --> Final output sent to browser
DEBUG - 2012-02-03 20:58:04 --> Total execution time: 1.0253
DEBUG - 2012-02-03 20:58:22 --> Config Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:58:22 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:58:22 --> URI Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Router Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Output Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Security Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Input Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:58:22 --> Language Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Loader Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:58:22 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Session Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:58:22 --> Session routines successfully run
DEBUG - 2012-02-03 20:58:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Controller Class Initialized
DEBUG - 2012-02-03 20:58:22 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:58:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:58:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:58:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:58:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:58:22 --> Final output sent to browser
DEBUG - 2012-02-03 20:58:22 --> Total execution time: 0.4781
DEBUG - 2012-02-03 20:58:25 --> Config Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:58:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:58:25 --> URI Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Router Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Output Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Security Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Input Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:58:25 --> Language Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Loader Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:58:25 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Session Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:58:25 --> Session routines successfully run
DEBUG - 2012-02-03 20:58:25 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Controller Class Initialized
DEBUG - 2012-02-03 20:58:25 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:58:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:58:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:58:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:58:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:58:25 --> Final output sent to browser
DEBUG - 2012-02-03 20:58:25 --> Total execution time: 0.5361
DEBUG - 2012-02-03 20:58:35 --> Config Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:58:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:58:35 --> URI Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Router Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Output Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Security Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Input Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:58:35 --> Language Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Loader Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:58:35 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Session Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:58:35 --> Session routines successfully run
DEBUG - 2012-02-03 20:58:35 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Controller Class Initialized
DEBUG - 2012-02-03 20:58:35 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:58:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:58:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:58:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:58:36 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:58:36 --> Final output sent to browser
DEBUG - 2012-02-03 20:58:36 --> Total execution time: 0.4599
DEBUG - 2012-02-03 20:58:52 --> Config Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:58:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:58:52 --> URI Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Router Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Output Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Security Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Input Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:58:52 --> Language Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Loader Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:58:52 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Session Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:58:52 --> Session routines successfully run
DEBUG - 2012-02-03 20:58:52 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:52 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:53 --> Controller Class Initialized
DEBUG - 2012-02-03 20:58:53 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:58:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:58:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:58:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:58:53 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:58:53 --> Final output sent to browser
DEBUG - 2012-02-03 20:58:53 --> Total execution time: 0.5195
DEBUG - 2012-02-03 20:58:57 --> Config Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:58:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:58:57 --> URI Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Router Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Output Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Security Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Input Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:58:57 --> Language Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Loader Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:58:57 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Session Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:58:57 --> Session routines successfully run
DEBUG - 2012-02-03 20:58:57 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Model Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Controller Class Initialized
DEBUG - 2012-02-03 20:58:57 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:58:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:58:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:58:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:58:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:58:58 --> Final output sent to browser
DEBUG - 2012-02-03 20:58:58 --> Total execution time: 1.2403
DEBUG - 2012-02-03 20:59:01 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:01 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:01 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:01 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:01 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:02 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:02 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:02 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:02 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:02 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:02 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:02 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:02 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:02 --> Total execution time: 0.6677
DEBUG - 2012-02-03 20:59:05 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:05 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:05 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:05 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:05 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:05 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:05 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:05 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:05 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:05 --> Total execution time: 0.4994
DEBUG - 2012-02-03 20:59:08 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:08 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:08 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:08 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:09 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:09 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:09 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:09 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:09 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:09 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:09 --> Total execution time: 0.5036
DEBUG - 2012-02-03 20:59:24 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:24 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:24 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:24 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:24 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:24 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:24 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:24 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:24 --> Total execution time: 0.4270
DEBUG - 2012-02-03 20:59:34 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:34 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:34 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:34 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:34 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:34 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:34 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:34 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:34 --> Total execution time: 0.4418
DEBUG - 2012-02-03 20:59:40 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:41 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:41 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:41 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:41 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:41 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:41 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:41 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:41 --> Total execution time: 0.4883
DEBUG - 2012-02-03 20:59:47 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:47 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:47 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:47 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:47 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:47 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:47 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:48 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:48 --> Total execution time: 0.5123
DEBUG - 2012-02-03 20:59:53 --> Config Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Hooks Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Utf8 Class Initialized
DEBUG - 2012-02-03 20:59:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 20:59:53 --> URI Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Router Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Output Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Security Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Input Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 20:59:53 --> Language Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Loader Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Helper loaded: url_helper
DEBUG - 2012-02-03 20:59:53 --> Database Driver Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Session Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Helper loaded: string_helper
DEBUG - 2012-02-03 20:59:53 --> Session routines successfully run
DEBUG - 2012-02-03 20:59:53 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:53 --> Model Class Initialized
DEBUG - 2012-02-03 20:59:54 --> Controller Class Initialized
DEBUG - 2012-02-03 20:59:54 --> Pagination Class Initialized
DEBUG - 2012-02-03 20:59:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 20:59:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 20:59:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 20:59:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 20:59:54 --> Final output sent to browser
DEBUG - 2012-02-03 20:59:54 --> Total execution time: 0.5053
DEBUG - 2012-02-03 21:00:13 --> Config Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:00:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:00:13 --> URI Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Router Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Output Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Security Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Input Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:00:13 --> Language Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Loader Class Initialized
DEBUG - 2012-02-03 21:00:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:00:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:00:14 --> Session Class Initialized
DEBUG - 2012-02-03 21:00:14 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:00:14 --> Session routines successfully run
DEBUG - 2012-02-03 21:00:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:14 --> Controller Class Initialized
DEBUG - 2012-02-03 21:00:14 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:00:14 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:00:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:00:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:00:14 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:00:14 --> Final output sent to browser
DEBUG - 2012-02-03 21:00:14 --> Total execution time: 0.4484
DEBUG - 2012-02-03 21:00:43 --> Config Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:00:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:00:43 --> URI Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Router Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Output Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Security Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Input Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:00:43 --> Language Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Loader Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:00:43 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Session Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:00:43 --> Session routines successfully run
DEBUG - 2012-02-03 21:00:43 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Controller Class Initialized
DEBUG - 2012-02-03 21:00:43 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:00:43 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:00:43 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:00:43 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:00:43 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:00:43 --> Final output sent to browser
DEBUG - 2012-02-03 21:00:43 --> Total execution time: 0.4485
DEBUG - 2012-02-03 21:00:45 --> Config Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:00:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:00:45 --> URI Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Router Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Output Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Security Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Input Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:00:45 --> Language Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Loader Class Initialized
DEBUG - 2012-02-03 21:00:45 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:00:46 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:00:46 --> Session Class Initialized
DEBUG - 2012-02-03 21:00:46 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:00:46 --> Session routines successfully run
DEBUG - 2012-02-03 21:00:46 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:46 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:46 --> Controller Class Initialized
DEBUG - 2012-02-03 21:00:46 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:00:46 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:00:46 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:00:46 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:00:46 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:00:46 --> Final output sent to browser
DEBUG - 2012-02-03 21:00:46 --> Total execution time: 1.2486
DEBUG - 2012-02-03 21:00:48 --> Config Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:00:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:00:48 --> URI Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Router Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Output Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Security Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Input Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:00:48 --> Language Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Loader Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:00:48 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Session Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:00:48 --> Session routines successfully run
DEBUG - 2012-02-03 21:00:48 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Controller Class Initialized
DEBUG - 2012-02-03 21:00:48 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:00:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:00:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:00:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:00:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:00:48 --> Final output sent to browser
DEBUG - 2012-02-03 21:00:48 --> Total execution time: 0.5488
DEBUG - 2012-02-03 21:00:50 --> Config Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:00:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:00:50 --> URI Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Router Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Output Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Security Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Input Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:00:50 --> Language Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Loader Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:00:50 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Session Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:00:50 --> Session routines successfully run
DEBUG - 2012-02-03 21:00:50 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Model Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Controller Class Initialized
DEBUG - 2012-02-03 21:00:50 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:00:50 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:00:50 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:00:50 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:00:50 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:00:50 --> Final output sent to browser
DEBUG - 2012-02-03 21:00:50 --> Total execution time: 0.6355
DEBUG - 2012-02-03 21:08:47 --> Config Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:08:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:08:47 --> URI Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Router Class Initialized
DEBUG - 2012-02-03 21:08:47 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:08:47 --> Output Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Security Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Input Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:08:47 --> Language Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Loader Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:08:47 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Session Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:08:47 --> Session routines successfully run
DEBUG - 2012-02-03 21:08:47 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Controller Class Initialized
DEBUG - 2012-02-03 21:08:47 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:08:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:08:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:08:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:08:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:08:48 --> Final output sent to browser
DEBUG - 2012-02-03 21:08:48 --> Total execution time: 0.6253
DEBUG - 2012-02-03 21:08:50 --> Config Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:08:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:08:50 --> URI Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Router Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Output Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Security Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Input Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:08:50 --> Language Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Loader Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:08:50 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Session Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:08:50 --> Session routines successfully run
DEBUG - 2012-02-03 21:08:50 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:50 --> Controller Class Initialized
DEBUG - 2012-02-03 21:08:50 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:08:50 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:08:50 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:08:50 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 21:08:50 --> Final output sent to browser
DEBUG - 2012-02-03 21:08:50 --> Total execution time: 0.4399
DEBUG - 2012-02-03 21:08:51 --> Config Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:08:51 --> URI Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Router Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Output Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Security Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Input Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:08:51 --> Language Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Loader Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:08:51 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:08:51 --> Session Class Initialized
DEBUG - 2012-02-03 21:08:52 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:08:52 --> Session routines successfully run
DEBUG - 2012-02-03 21:08:52 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:52 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:52 --> Controller Class Initialized
DEBUG - 2012-02-03 21:08:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:08:52 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:08:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:08:52 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 21:08:52 --> Final output sent to browser
DEBUG - 2012-02-03 21:08:52 --> Total execution time: 0.4437
DEBUG - 2012-02-03 21:08:53 --> Config Class Initialized
DEBUG - 2012-02-03 21:08:53 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:08:53 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:08:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:08:53 --> URI Class Initialized
DEBUG - 2012-02-03 21:08:53 --> Router Class Initialized
DEBUG - 2012-02-03 21:08:53 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:08:53 --> Output Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Security Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Input Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:08:54 --> Language Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Loader Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:08:54 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Session Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:08:54 --> Session routines successfully run
DEBUG - 2012-02-03 21:08:54 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Controller Class Initialized
DEBUG - 2012-02-03 21:08:54 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:08:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:08:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:08:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:08:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:08:54 --> Final output sent to browser
DEBUG - 2012-02-03 21:08:54 --> Total execution time: 1.0386
DEBUG - 2012-02-03 21:08:56 --> Config Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:08:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:08:56 --> URI Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Router Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Output Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Security Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Input Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:08:56 --> Language Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Loader Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:08:56 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Session Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:08:56 --> Session routines successfully run
DEBUG - 2012-02-03 21:08:56 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Model Class Initialized
DEBUG - 2012-02-03 21:08:56 --> Controller Class Initialized
DEBUG - 2012-02-03 21:08:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:08:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:08:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:08:56 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 21:08:56 --> Final output sent to browser
DEBUG - 2012-02-03 21:08:56 --> Total execution time: 0.5297
DEBUG - 2012-02-03 21:08:59 --> Config Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:08:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:08:59 --> URI Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Router Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Output Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Security Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Input Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:08:59 --> Language Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Loader Class Initialized
DEBUG - 2012-02-03 21:08:59 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:09:00 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:09:00 --> Session Class Initialized
DEBUG - 2012-02-03 21:09:00 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:09:00 --> Session routines successfully run
DEBUG - 2012-02-03 21:09:00 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:00 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:00 --> Controller Class Initialized
DEBUG - 2012-02-03 21:09:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:09:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:09:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:09:00 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 21:09:00 --> Final output sent to browser
DEBUG - 2012-02-03 21:09:00 --> Total execution time: 1.0460
DEBUG - 2012-02-03 21:09:04 --> Config Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:09:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:09:04 --> URI Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Router Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Output Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Security Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Input Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:09:04 --> Language Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Loader Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:09:04 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Session Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:09:04 --> Session routines successfully run
DEBUG - 2012-02-03 21:09:04 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Controller Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Config Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:09:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:09:04 --> URI Class Initialized
DEBUG - 2012-02-03 21:09:04 --> Router Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Output Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Security Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Input Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:09:05 --> Language Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Loader Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:09:05 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Session Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:09:05 --> Session routines successfully run
DEBUG - 2012-02-03 21:09:05 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:05 --> Controller Class Initialized
DEBUG - 2012-02-03 21:09:05 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-03 21:09:06 --> Final output sent to browser
DEBUG - 2012-02-03 21:09:06 --> Total execution time: 1.3689
DEBUG - 2012-02-03 21:09:07 --> Config Class Initialized
DEBUG - 2012-02-03 21:09:07 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:09:07 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:09:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:09:07 --> URI Class Initialized
DEBUG - 2012-02-03 21:09:07 --> Router Class Initialized
DEBUG - 2012-02-03 21:09:07 --> Output Class Initialized
DEBUG - 2012-02-03 21:09:07 --> Security Class Initialized
DEBUG - 2012-02-03 21:09:07 --> Input Class Initialized
DEBUG - 2012-02-03 21:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:09:08 --> Language Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Loader Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:09:08 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Session Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:09:08 --> Session routines successfully run
DEBUG - 2012-02-03 21:09:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Controller Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Config Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:09:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:09:08 --> URI Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Router Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Output Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Security Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Input Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:09:08 --> Language Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Loader Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:09:08 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:09:08 --> Session Class Initialized
DEBUG - 2012-02-03 21:09:09 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:09:09 --> Session routines successfully run
DEBUG - 2012-02-03 21:09:09 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:09 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:09 --> Controller Class Initialized
DEBUG - 2012-02-03 21:09:09 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:09:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:09:09 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:09:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:09:09 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:09:09 --> Final output sent to browser
DEBUG - 2012-02-03 21:09:09 --> Total execution time: 0.5445
DEBUG - 2012-02-03 21:09:11 --> Config Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:09:11 --> URI Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Router Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Output Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Security Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Input Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:09:11 --> Language Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Loader Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:09:11 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Session Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:09:11 --> Session routines successfully run
DEBUG - 2012-02-03 21:09:11 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:11 --> Controller Class Initialized
DEBUG - 2012-02-03 21:09:12 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:09:12 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:09:12 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:09:12 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 21:09:12 --> Final output sent to browser
DEBUG - 2012-02-03 21:09:12 --> Total execution time: 1.0351
DEBUG - 2012-02-03 21:09:17 --> Config Class Initialized
DEBUG - 2012-02-03 21:09:17 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:09:17 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:09:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:09:17 --> URI Class Initialized
DEBUG - 2012-02-03 21:09:17 --> Router Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Output Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Security Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Input Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:09:18 --> Language Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Loader Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:09:18 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Session Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:09:18 --> Session routines successfully run
DEBUG - 2012-02-03 21:09:18 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Model Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Controller Class Initialized
DEBUG - 2012-02-03 21:09:18 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:09:18 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:09:18 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:09:18 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:09:18 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:09:18 --> Final output sent to browser
DEBUG - 2012-02-03 21:09:18 --> Total execution time: 1.2269
DEBUG - 2012-02-03 21:10:54 --> Config Class Initialized
DEBUG - 2012-02-03 21:10:54 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:10:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:10:55 --> URI Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Router Class Initialized
DEBUG - 2012-02-03 21:10:55 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:10:55 --> Output Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Security Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Input Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:10:55 --> Language Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Loader Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:10:55 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Session Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:10:55 --> Session routines successfully run
DEBUG - 2012-02-03 21:10:55 --> Model Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Model Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Controller Class Initialized
DEBUG - 2012-02-03 21:10:55 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:10:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:10:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:10:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:10:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:10:56 --> Final output sent to browser
DEBUG - 2012-02-03 21:10:56 --> Total execution time: 1.2083
DEBUG - 2012-02-03 21:13:25 --> Config Class Initialized
DEBUG - 2012-02-03 21:13:25 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:13:25 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:13:25 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:13:25 --> URI Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Router Class Initialized
DEBUG - 2012-02-03 21:13:26 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:13:26 --> Output Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Security Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Input Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:13:26 --> Language Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Loader Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:13:26 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Session Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:13:26 --> Session routines successfully run
DEBUG - 2012-02-03 21:13:26 --> Model Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Model Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Controller Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:13:26 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:13:26 --> Final output sent to browser
DEBUG - 2012-02-03 21:13:26 --> Total execution time: 0.6302
DEBUG - 2012-02-03 21:13:26 --> Config Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:13:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:13:26 --> URI Class Initialized
DEBUG - 2012-02-03 21:13:26 --> Router Class Initialized
ERROR - 2012-02-03 21:13:26 --> 404 Page Not Found --> images
DEBUG - 2012-02-03 21:14:10 --> Config Class Initialized
DEBUG - 2012-02-03 21:14:10 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:14:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:14:11 --> URI Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Router Class Initialized
DEBUG - 2012-02-03 21:14:11 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:14:11 --> Output Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Security Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Input Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:14:11 --> Language Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Loader Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:14:11 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Session Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:14:11 --> Session routines successfully run
DEBUG - 2012-02-03 21:14:11 --> Model Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Model Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Controller Class Initialized
DEBUG - 2012-02-03 21:14:11 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:14:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:14:11 --> Final output sent to browser
DEBUG - 2012-02-03 21:14:11 --> Total execution time: 1.2718
DEBUG - 2012-02-03 21:18:17 --> Config Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:18:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:18:17 --> URI Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Router Class Initialized
DEBUG - 2012-02-03 21:18:17 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:18:17 --> Output Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Security Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Input Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:18:17 --> Language Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Loader Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:18:17 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Session Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:18:17 --> A session cookie was not found.
DEBUG - 2012-02-03 21:18:17 --> Session routines successfully run
DEBUG - 2012-02-03 21:18:17 --> Model Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Model Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Controller Class Initialized
DEBUG - 2012-02-03 21:18:17 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:18:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:18:17 --> Final output sent to browser
DEBUG - 2012-02-03 21:18:17 --> Total execution time: 0.4947
DEBUG - 2012-02-03 21:19:12 --> Config Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:19:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:19:13 --> URI Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Router Class Initialized
DEBUG - 2012-02-03 21:19:13 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:19:13 --> Output Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Security Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Input Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:19:13 --> Language Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Loader Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:19:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Session Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:19:13 --> Session routines successfully run
DEBUG - 2012-02-03 21:19:13 --> Model Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Model Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Controller Class Initialized
DEBUG - 2012-02-03 21:19:13 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:19:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:19:13 --> Final output sent to browser
DEBUG - 2012-02-03 21:19:13 --> Total execution time: 0.5140
DEBUG - 2012-02-03 21:20:56 --> Config Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:20:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:20:56 --> URI Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Router Class Initialized
DEBUG - 2012-02-03 21:20:56 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:20:56 --> Output Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Security Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Input Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:20:56 --> Language Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Loader Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:20:56 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Session Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:20:56 --> Session routines successfully run
DEBUG - 2012-02-03 21:20:56 --> Model Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Model Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Controller Class Initialized
DEBUG - 2012-02-03 21:20:56 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:20:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:20:56 --> Final output sent to browser
DEBUG - 2012-02-03 21:20:56 --> Total execution time: 0.5157
DEBUG - 2012-02-03 21:21:10 --> Config Class Initialized
DEBUG - 2012-02-03 21:21:10 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:21:10 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:21:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:21:10 --> URI Class Initialized
DEBUG - 2012-02-03 21:21:10 --> Router Class Initialized
DEBUG - 2012-02-03 21:21:10 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:21:10 --> Output Class Initialized
DEBUG - 2012-02-03 21:21:10 --> Security Class Initialized
DEBUG - 2012-02-03 21:21:10 --> Input Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:21:11 --> Language Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Loader Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:21:11 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Session Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:21:11 --> Session routines successfully run
DEBUG - 2012-02-03 21:21:11 --> Model Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Model Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Controller Class Initialized
DEBUG - 2012-02-03 21:21:11 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:21:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:21:11 --> Final output sent to browser
DEBUG - 2012-02-03 21:21:11 --> Total execution time: 0.6074
DEBUG - 2012-02-03 21:21:24 --> Config Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:21:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:21:24 --> URI Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Router Class Initialized
DEBUG - 2012-02-03 21:21:24 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:21:24 --> Output Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Security Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Input Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:21:24 --> Language Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Loader Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:21:24 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Session Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:21:24 --> Session routines successfully run
DEBUG - 2012-02-03 21:21:24 --> Model Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Model Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Controller Class Initialized
DEBUG - 2012-02-03 21:21:24 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:21:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:21:24 --> Final output sent to browser
DEBUG - 2012-02-03 21:21:24 --> Total execution time: 0.4772
DEBUG - 2012-02-03 21:22:04 --> Config Class Initialized
DEBUG - 2012-02-03 21:22:04 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:22:04 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:22:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:22:04 --> URI Class Initialized
DEBUG - 2012-02-03 21:22:04 --> Router Class Initialized
DEBUG - 2012-02-03 21:22:04 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:22:04 --> Output Class Initialized
DEBUG - 2012-02-03 21:22:04 --> Security Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Input Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:22:05 --> Language Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Loader Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:22:05 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Session Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:22:05 --> Session routines successfully run
DEBUG - 2012-02-03 21:22:05 --> Model Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Model Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Controller Class Initialized
DEBUG - 2012-02-03 21:22:05 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:22:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:22:05 --> Final output sent to browser
DEBUG - 2012-02-03 21:22:05 --> Total execution time: 0.5144
DEBUG - 2012-02-03 21:22:07 --> Config Class Initialized
DEBUG - 2012-02-03 21:22:07 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:22:07 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:22:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:22:07 --> URI Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Router Class Initialized
DEBUG - 2012-02-03 21:22:08 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:22:08 --> Output Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Security Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Input Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:22:08 --> Language Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Loader Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:22:08 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Session Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:22:08 --> Session routines successfully run
DEBUG - 2012-02-03 21:22:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:22:08 --> Controller Class Initialized
DEBUG - 2012-02-03 21:22:09 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:22:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:22:09 --> Final output sent to browser
DEBUG - 2012-02-03 21:22:09 --> Total execution time: 2.1689
DEBUG - 2012-02-03 21:22:38 --> Config Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:22:38 --> URI Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Router Class Initialized
DEBUG - 2012-02-03 21:22:38 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:22:38 --> Output Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Security Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Input Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:22:38 --> Language Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Loader Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:22:38 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Session Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:22:38 --> Session routines successfully run
DEBUG - 2012-02-03 21:22:38 --> Model Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Model Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Controller Class Initialized
DEBUG - 2012-02-03 21:22:38 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:22:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:22:38 --> Final output sent to browser
DEBUG - 2012-02-03 21:22:38 --> Total execution time: 0.6346
DEBUG - 2012-02-03 21:23:20 --> Config Class Initialized
DEBUG - 2012-02-03 21:23:20 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:23:20 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:23:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:23:20 --> URI Class Initialized
DEBUG - 2012-02-03 21:23:20 --> Router Class Initialized
DEBUG - 2012-02-03 21:23:20 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:23:21 --> Output Class Initialized
DEBUG - 2012-02-03 21:23:21 --> Security Class Initialized
DEBUG - 2012-02-03 21:23:21 --> Input Class Initialized
DEBUG - 2012-02-03 21:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:23:21 --> Language Class Initialized
DEBUG - 2012-02-03 21:23:21 --> Loader Class Initialized
DEBUG - 2012-02-03 21:23:21 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:23:22 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:23:22 --> Session Class Initialized
DEBUG - 2012-02-03 21:23:22 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:23:22 --> Session routines successfully run
DEBUG - 2012-02-03 21:23:22 --> Model Class Initialized
DEBUG - 2012-02-03 21:23:22 --> Model Class Initialized
DEBUG - 2012-02-03 21:23:22 --> Controller Class Initialized
DEBUG - 2012-02-03 21:23:22 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:23:22 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:23:22 --> Final output sent to browser
DEBUG - 2012-02-03 21:23:22 --> Total execution time: 1.8085
DEBUG - 2012-02-03 21:25:54 --> Config Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:25:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:25:54 --> URI Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Router Class Initialized
DEBUG - 2012-02-03 21:25:54 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:25:54 --> Output Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Security Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Input Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:25:54 --> Language Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Loader Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:25:54 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Session Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:25:54 --> Session routines successfully run
DEBUG - 2012-02-03 21:25:54 --> Model Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Model Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Controller Class Initialized
DEBUG - 2012-02-03 21:25:54 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:25:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:25:54 --> Final output sent to browser
DEBUG - 2012-02-03 21:25:54 --> Total execution time: 0.4584
DEBUG - 2012-02-03 21:26:30 --> Config Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:26:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:26:30 --> URI Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Router Class Initialized
DEBUG - 2012-02-03 21:26:30 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:26:30 --> Output Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Security Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Input Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:26:30 --> Language Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Loader Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:26:30 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Session Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:26:30 --> Session routines successfully run
DEBUG - 2012-02-03 21:26:30 --> Model Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Model Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Controller Class Initialized
DEBUG - 2012-02-03 21:26:30 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:26:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:26:30 --> Final output sent to browser
DEBUG - 2012-02-03 21:26:30 --> Total execution time: 1.2268
DEBUG - 2012-02-03 21:27:06 --> Config Class Initialized
DEBUG - 2012-02-03 21:27:06 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:27:06 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:27:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:27:06 --> URI Class Initialized
DEBUG - 2012-02-03 21:27:06 --> Router Class Initialized
DEBUG - 2012-02-03 21:27:06 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:27:06 --> Output Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Security Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Input Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:27:07 --> Language Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Loader Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:27:07 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Session Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:27:07 --> Session routines successfully run
DEBUG - 2012-02-03 21:27:07 --> Model Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Model Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Controller Class Initialized
DEBUG - 2012-02-03 21:27:07 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:27:07 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:27:07 --> Final output sent to browser
DEBUG - 2012-02-03 21:27:07 --> Total execution time: 0.4636
DEBUG - 2012-02-03 21:28:32 --> Config Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:28:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:28:32 --> URI Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Router Class Initialized
DEBUG - 2012-02-03 21:28:32 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:28:32 --> Output Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Security Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Input Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:28:32 --> Language Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Loader Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:28:32 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Session Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:28:32 --> Session routines successfully run
DEBUG - 2012-02-03 21:28:32 --> Model Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Model Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Controller Class Initialized
DEBUG - 2012-02-03 21:28:32 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:28:32 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:28:32 --> Final output sent to browser
DEBUG - 2012-02-03 21:28:32 --> Total execution time: 1.3239
DEBUG - 2012-02-03 21:29:19 --> Config Class Initialized
DEBUG - 2012-02-03 21:29:19 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:29:19 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:29:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:29:20 --> URI Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Router Class Initialized
DEBUG - 2012-02-03 21:29:20 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:29:20 --> Output Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Security Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Input Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:29:20 --> Language Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Loader Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:29:20 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Session Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:29:20 --> Session routines successfully run
DEBUG - 2012-02-03 21:29:20 --> Model Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Model Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Controller Class Initialized
DEBUG - 2012-02-03 21:29:20 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:29:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:29:20 --> Final output sent to browser
DEBUG - 2012-02-03 21:29:20 --> Total execution time: 1.4020
DEBUG - 2012-02-03 21:29:33 --> Config Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:29:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:29:33 --> URI Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Router Class Initialized
DEBUG - 2012-02-03 21:29:33 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:29:33 --> Output Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Security Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Input Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:29:33 --> Language Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Loader Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:29:33 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Session Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:29:33 --> Session routines successfully run
DEBUG - 2012-02-03 21:29:33 --> Model Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Model Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Controller Class Initialized
DEBUG - 2012-02-03 21:29:33 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:29:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:29:33 --> Final output sent to browser
DEBUG - 2012-02-03 21:29:33 --> Total execution time: 0.4106
DEBUG - 2012-02-03 21:29:56 --> Config Class Initialized
DEBUG - 2012-02-03 21:29:56 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:29:56 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:29:56 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:29:56 --> URI Class Initialized
DEBUG - 2012-02-03 21:29:56 --> Router Class Initialized
DEBUG - 2012-02-03 21:29:56 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:29:56 --> Output Class Initialized
DEBUG - 2012-02-03 21:29:56 --> Security Class Initialized
DEBUG - 2012-02-03 21:29:56 --> Input Class Initialized
DEBUG - 2012-02-03 21:29:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:29:57 --> Language Class Initialized
DEBUG - 2012-02-03 21:29:57 --> Loader Class Initialized
DEBUG - 2012-02-03 21:29:57 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:29:57 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:29:57 --> Session Class Initialized
DEBUG - 2012-02-03 21:29:57 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:29:57 --> Session routines successfully run
DEBUG - 2012-02-03 21:29:57 --> Model Class Initialized
DEBUG - 2012-02-03 21:29:57 --> Model Class Initialized
DEBUG - 2012-02-03 21:29:57 --> Controller Class Initialized
DEBUG - 2012-02-03 21:29:57 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:29:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:29:57 --> Final output sent to browser
DEBUG - 2012-02-03 21:29:57 --> Total execution time: 0.3920
DEBUG - 2012-02-03 21:30:20 --> Config Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:30:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:30:20 --> URI Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Router Class Initialized
DEBUG - 2012-02-03 21:30:20 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:30:20 --> Output Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Security Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Input Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:30:20 --> Language Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Loader Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:30:20 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Session Class Initialized
DEBUG - 2012-02-03 21:30:20 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:30:21 --> Session routines successfully run
DEBUG - 2012-02-03 21:30:21 --> Model Class Initialized
DEBUG - 2012-02-03 21:30:21 --> Model Class Initialized
DEBUG - 2012-02-03 21:30:21 --> Controller Class Initialized
DEBUG - 2012-02-03 21:30:21 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:30:21 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:30:21 --> Final output sent to browser
DEBUG - 2012-02-03 21:30:21 --> Total execution time: 0.4376
DEBUG - 2012-02-03 21:31:14 --> Config Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:31:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:31:14 --> URI Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Router Class Initialized
DEBUG - 2012-02-03 21:31:14 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:31:14 --> Output Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Security Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Input Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:31:14 --> Language Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Loader Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:31:14 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Session Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:31:14 --> Session routines successfully run
DEBUG - 2012-02-03 21:31:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Controller Class Initialized
DEBUG - 2012-02-03 21:31:14 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:31:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:31:14 --> Final output sent to browser
DEBUG - 2012-02-03 21:31:14 --> Total execution time: 0.4384
DEBUG - 2012-02-03 21:31:42 --> Config Class Initialized
DEBUG - 2012-02-03 21:31:42 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:31:42 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:31:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:31:43 --> URI Class Initialized
DEBUG - 2012-02-03 21:31:43 --> Router Class Initialized
DEBUG - 2012-02-03 21:31:43 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:31:43 --> Output Class Initialized
DEBUG - 2012-02-03 21:31:43 --> Security Class Initialized
DEBUG - 2012-02-03 21:31:43 --> Input Class Initialized
DEBUG - 2012-02-03 21:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:31:43 --> Language Class Initialized
DEBUG - 2012-02-03 21:31:44 --> Loader Class Initialized
DEBUG - 2012-02-03 21:31:44 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:31:44 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:31:44 --> Session Class Initialized
DEBUG - 2012-02-03 21:31:44 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:31:44 --> Session routines successfully run
DEBUG - 2012-02-03 21:31:44 --> Model Class Initialized
DEBUG - 2012-02-03 21:31:44 --> Model Class Initialized
DEBUG - 2012-02-03 21:31:44 --> Controller Class Initialized
DEBUG - 2012-02-03 21:31:44 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:31:44 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:31:44 --> Final output sent to browser
DEBUG - 2012-02-03 21:31:44 --> Total execution time: 1.6577
DEBUG - 2012-02-03 21:32:08 --> Config Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:32:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:32:08 --> URI Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Router Class Initialized
DEBUG - 2012-02-03 21:32:08 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:32:08 --> Output Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Security Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Input Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:32:08 --> Language Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Loader Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:32:08 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Session Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:32:08 --> Session routines successfully run
DEBUG - 2012-02-03 21:32:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Controller Class Initialized
DEBUG - 2012-02-03 21:32:08 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:32:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:32:08 --> Final output sent to browser
DEBUG - 2012-02-03 21:32:08 --> Total execution time: 0.4823
DEBUG - 2012-02-03 21:32:47 --> Config Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:32:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:32:47 --> URI Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Router Class Initialized
DEBUG - 2012-02-03 21:32:47 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:32:47 --> Output Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Security Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Input Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:32:47 --> Language Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Loader Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:32:47 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Session Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:32:47 --> Session routines successfully run
DEBUG - 2012-02-03 21:32:47 --> Model Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Model Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Controller Class Initialized
DEBUG - 2012-02-03 21:32:47 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:32:47 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:32:47 --> Final output sent to browser
DEBUG - 2012-02-03 21:32:47 --> Total execution time: 0.4783
DEBUG - 2012-02-03 21:33:08 --> Config Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:33:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:33:08 --> URI Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Router Class Initialized
DEBUG - 2012-02-03 21:33:08 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:33:08 --> Output Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Security Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Input Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:33:08 --> Language Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Loader Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:33:08 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Session Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:33:08 --> Session routines successfully run
DEBUG - 2012-02-03 21:33:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Model Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Controller Class Initialized
DEBUG - 2012-02-03 21:33:08 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:33:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:33:08 --> Final output sent to browser
DEBUG - 2012-02-03 21:33:08 --> Total execution time: 0.3870
DEBUG - 2012-02-03 21:34:23 --> Config Class Initialized
DEBUG - 2012-02-03 21:34:23 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:34:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:34:24 --> URI Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Router Class Initialized
DEBUG - 2012-02-03 21:34:24 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:34:24 --> Output Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Security Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Input Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:34:24 --> Language Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Loader Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:34:24 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Session Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:34:24 --> Session routines successfully run
DEBUG - 2012-02-03 21:34:24 --> Model Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Model Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Controller Class Initialized
DEBUG - 2012-02-03 21:34:24 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:34:24 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:34:24 --> Final output sent to browser
DEBUG - 2012-02-03 21:34:24 --> Total execution time: 0.4846
DEBUG - 2012-02-03 21:35:31 --> Config Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:35:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:35:31 --> URI Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Router Class Initialized
DEBUG - 2012-02-03 21:35:31 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:35:31 --> Output Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Security Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Input Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:35:31 --> Language Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Loader Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:35:31 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Session Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:35:31 --> Session routines successfully run
DEBUG - 2012-02-03 21:35:31 --> Model Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Model Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Controller Class Initialized
DEBUG - 2012-02-03 21:35:31 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:35:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:35:31 --> Final output sent to browser
DEBUG - 2012-02-03 21:35:31 --> Total execution time: 1.3656
DEBUG - 2012-02-03 21:35:57 --> Config Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:35:57 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:35:57 --> URI Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Router Class Initialized
DEBUG - 2012-02-03 21:35:57 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:35:57 --> Output Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Security Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Input Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:35:57 --> Language Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Loader Class Initialized
DEBUG - 2012-02-03 21:35:57 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:35:58 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:35:58 --> Session Class Initialized
DEBUG - 2012-02-03 21:35:58 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:35:58 --> Session routines successfully run
DEBUG - 2012-02-03 21:35:58 --> Model Class Initialized
DEBUG - 2012-02-03 21:35:58 --> Model Class Initialized
DEBUG - 2012-02-03 21:35:58 --> Controller Class Initialized
DEBUG - 2012-02-03 21:35:58 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:35:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:35:58 --> Final output sent to browser
DEBUG - 2012-02-03 21:35:58 --> Total execution time: 0.5139
DEBUG - 2012-02-03 21:36:38 --> Config Class Initialized
DEBUG - 2012-02-03 21:36:38 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:36:38 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:36:38 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:36:38 --> URI Class Initialized
DEBUG - 2012-02-03 21:36:38 --> Router Class Initialized
DEBUG - 2012-02-03 21:36:38 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:36:38 --> Output Class Initialized
DEBUG - 2012-02-03 21:36:38 --> Security Class Initialized
DEBUG - 2012-02-03 21:36:38 --> Input Class Initialized
DEBUG - 2012-02-03 21:36:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:36:38 --> Language Class Initialized
DEBUG - 2012-02-03 21:36:39 --> Loader Class Initialized
DEBUG - 2012-02-03 21:36:39 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:36:39 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:36:39 --> Session Class Initialized
DEBUG - 2012-02-03 21:36:39 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:36:39 --> Session routines successfully run
DEBUG - 2012-02-03 21:36:39 --> Model Class Initialized
DEBUG - 2012-02-03 21:36:39 --> Model Class Initialized
DEBUG - 2012-02-03 21:36:39 --> Controller Class Initialized
DEBUG - 2012-02-03 21:36:39 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:36:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:36:39 --> Final output sent to browser
DEBUG - 2012-02-03 21:36:39 --> Total execution time: 1.9175
DEBUG - 2012-02-03 21:37:40 --> Config Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:37:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:37:40 --> URI Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Router Class Initialized
DEBUG - 2012-02-03 21:37:40 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:37:40 --> Output Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Security Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Input Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:37:40 --> Language Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Loader Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:37:40 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Session Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:37:40 --> Session routines successfully run
DEBUG - 2012-02-03 21:37:40 --> Model Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Model Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Controller Class Initialized
DEBUG - 2012-02-03 21:37:40 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:37:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:37:41 --> Final output sent to browser
DEBUG - 2012-02-03 21:37:41 --> Total execution time: 1.2024
DEBUG - 2012-02-03 21:40:13 --> Config Class Initialized
DEBUG - 2012-02-03 21:40:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:40:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:40:13 --> URI Class Initialized
DEBUG - 2012-02-03 21:40:13 --> Router Class Initialized
DEBUG - 2012-02-03 21:40:13 --> Output Class Initialized
DEBUG - 2012-02-03 21:40:13 --> Security Class Initialized
DEBUG - 2012-02-03 21:40:13 --> Input Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:40:14 --> Language Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Loader Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:40:14 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Session Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:40:14 --> Session routines successfully run
DEBUG - 2012-02-03 21:40:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Controller Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Config Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:40:14 --> URI Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Router Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Output Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Security Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Input Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:40:14 --> Language Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Loader Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:40:14 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Session Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:40:14 --> Session routines successfully run
DEBUG - 2012-02-03 21:40:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Model Class Initialized
DEBUG - 2012-02-03 21:40:14 --> Controller Class Initialized
DEBUG - 2012-02-03 21:40:14 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-03 21:40:14 --> Final output sent to browser
DEBUG - 2012-02-03 21:40:14 --> Total execution time: 0.3290
DEBUG - 2012-02-03 21:40:57 --> Config Class Initialized
DEBUG - 2012-02-03 21:40:57 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:40:57 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:40:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:40:58 --> URI Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Router Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Output Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Security Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Input Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:40:58 --> Language Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Loader Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:40:58 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Session Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:40:58 --> Session routines successfully run
DEBUG - 2012-02-03 21:40:58 --> Model Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Model Class Initialized
DEBUG - 2012-02-03 21:40:58 --> Controller Class Initialized
DEBUG - 2012-02-03 21:40:58 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-03 21:40:58 --> Final output sent to browser
DEBUG - 2012-02-03 21:40:58 --> Total execution time: 1.4497
DEBUG - 2012-02-03 21:41:01 --> Config Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:41:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:41:01 --> URI Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Router Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Output Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Security Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Input Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:41:01 --> Language Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Loader Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:41:01 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Session Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:41:01 --> Session routines successfully run
DEBUG - 2012-02-03 21:41:01 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:01 --> Controller Class Initialized
DEBUG - 2012-02-03 21:41:01 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-03 21:41:01 --> Final output sent to browser
DEBUG - 2012-02-03 21:41:01 --> Total execution time: 1.0681
DEBUG - 2012-02-03 21:41:09 --> Config Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:41:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:41:09 --> URI Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Router Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Output Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Security Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Input Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:41:09 --> Language Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Loader Class Initialized
DEBUG - 2012-02-03 21:41:09 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:41:10 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Session Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:41:10 --> Session routines successfully run
DEBUG - 2012-02-03 21:41:10 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Controller Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Config Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:41:10 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:41:10 --> URI Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Router Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Output Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Security Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Input Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:41:10 --> Language Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Loader Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:41:10 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Session Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:41:10 --> Session routines successfully run
DEBUG - 2012-02-03 21:41:10 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Controller Class Initialized
DEBUG - 2012-02-03 21:41:10 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:41:10 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:41:10 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:41:10 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:41:10 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:41:10 --> Final output sent to browser
DEBUG - 2012-02-03 21:41:10 --> Total execution time: 0.5943
DEBUG - 2012-02-03 21:41:21 --> Config Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:41:21 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:41:21 --> URI Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Router Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Output Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Security Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Input Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:41:21 --> Language Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Loader Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:41:21 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Session Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:41:21 --> Session routines successfully run
DEBUG - 2012-02-03 21:41:21 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Controller Class Initialized
DEBUG - 2012-02-03 21:41:21 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:41:21 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:41:21 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:41:21 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:41:21 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 21:41:21 --> Final output sent to browser
DEBUG - 2012-02-03 21:41:21 --> Total execution time: 0.5849
DEBUG - 2012-02-03 21:41:39 --> Config Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:41:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:41:39 --> URI Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Router Class Initialized
DEBUG - 2012-02-03 21:41:39 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:41:39 --> Output Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Security Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Input Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:41:39 --> Language Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Loader Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:41:39 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Session Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:41:39 --> Session routines successfully run
DEBUG - 2012-02-03 21:41:39 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Controller Class Initialized
DEBUG - 2012-02-03 21:41:39 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:41:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:41:39 --> Final output sent to browser
DEBUG - 2012-02-03 21:41:39 --> Total execution time: 0.5025
DEBUG - 2012-02-03 21:41:59 --> Config Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:41:59 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:41:59 --> URI Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Router Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Output Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Security Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Input Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:41:59 --> Language Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Loader Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:41:59 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Session Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:41:59 --> Session routines successfully run
DEBUG - 2012-02-03 21:41:59 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Model Class Initialized
DEBUG - 2012-02-03 21:41:59 --> Controller Class Initialized
DEBUG - 2012-02-03 21:41:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:41:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:41:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:41:59 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 21:41:59 --> Final output sent to browser
DEBUG - 2012-02-03 21:41:59 --> Total execution time: 0.5263
DEBUG - 2012-02-03 21:42:06 --> Config Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:42:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:42:06 --> URI Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Router Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Output Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Security Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Input Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:42:06 --> Language Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Loader Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:42:06 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Session Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:42:06 --> Session routines successfully run
DEBUG - 2012-02-03 21:42:06 --> Model Class Initialized
DEBUG - 2012-02-03 21:42:06 --> Model Class Initialized
DEBUG - 2012-02-03 21:42:07 --> Controller Class Initialized
DEBUG - 2012-02-03 21:42:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 21:42:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 21:42:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 21:42:07 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-02-03 21:42:07 --> Final output sent to browser
DEBUG - 2012-02-03 21:42:07 --> Total execution time: 1.2281
DEBUG - 2012-02-03 21:44:24 --> Config Class Initialized
DEBUG - 2012-02-03 21:44:24 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:44:24 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:44:24 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:44:24 --> URI Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Router Class Initialized
DEBUG - 2012-02-03 21:44:25 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:44:25 --> Output Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Security Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Input Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:44:25 --> Language Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Loader Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:44:25 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Session Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:44:25 --> Session routines successfully run
DEBUG - 2012-02-03 21:44:25 --> Model Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Model Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Controller Class Initialized
DEBUG - 2012-02-03 21:44:25 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:44:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:44:25 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:44:25 --> Final output sent to browser
DEBUG - 2012-02-03 21:44:25 --> Total execution time: 0.5132
DEBUG - 2012-02-03 21:47:14 --> Config Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:47:14 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:47:14 --> URI Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Router Class Initialized
DEBUG - 2012-02-03 21:47:14 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:47:14 --> Output Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Security Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Input Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:47:14 --> Language Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Loader Class Initialized
DEBUG - 2012-02-03 21:47:14 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:47:15 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:47:15 --> Session Class Initialized
DEBUG - 2012-02-03 21:47:15 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:47:15 --> Session routines successfully run
DEBUG - 2012-02-03 21:47:15 --> Model Class Initialized
DEBUG - 2012-02-03 21:47:15 --> Model Class Initialized
DEBUG - 2012-02-03 21:47:15 --> Controller Class Initialized
DEBUG - 2012-02-03 21:47:15 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:47:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:47:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:47:15 --> Final output sent to browser
DEBUG - 2012-02-03 21:47:15 --> Total execution time: 0.9119
DEBUG - 2012-02-03 21:47:50 --> Config Class Initialized
DEBUG - 2012-02-03 21:47:50 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:47:50 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:47:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:47:51 --> URI Class Initialized
DEBUG - 2012-02-03 21:47:51 --> Router Class Initialized
DEBUG - 2012-02-03 21:47:51 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:47:51 --> Output Class Initialized
DEBUG - 2012-02-03 21:47:51 --> Security Class Initialized
DEBUG - 2012-02-03 21:47:51 --> Input Class Initialized
DEBUG - 2012-02-03 21:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:47:52 --> Language Class Initialized
DEBUG - 2012-02-03 21:47:52 --> Loader Class Initialized
DEBUG - 2012-02-03 21:47:52 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:47:52 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:47:52 --> Session Class Initialized
DEBUG - 2012-02-03 21:47:52 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:47:52 --> Session routines successfully run
DEBUG - 2012-02-03 21:47:52 --> Model Class Initialized
DEBUG - 2012-02-03 21:47:52 --> Model Class Initialized
DEBUG - 2012-02-03 21:47:52 --> Controller Class Initialized
DEBUG - 2012-02-03 21:47:52 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:47:52 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:47:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:47:52 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:47:52 --> Final output sent to browser
DEBUG - 2012-02-03 21:47:52 --> Total execution time: 1.5246
DEBUG - 2012-02-03 21:51:04 --> Config Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:51:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:51:04 --> URI Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Router Class Initialized
DEBUG - 2012-02-03 21:51:04 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:51:04 --> Output Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Security Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Input Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:51:04 --> Language Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Loader Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:51:04 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Session Class Initialized
DEBUG - 2012-02-03 21:51:04 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:51:04 --> Session routines successfully run
DEBUG - 2012-02-03 21:51:04 --> Model Class Initialized
DEBUG - 2012-02-03 21:51:05 --> Model Class Initialized
DEBUG - 2012-02-03 21:51:05 --> Controller Class Initialized
DEBUG - 2012-02-03 21:51:05 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:51:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:51:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:51:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:51:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:51:05 --> Final output sent to browser
DEBUG - 2012-02-03 21:51:05 --> Total execution time: 0.5313
DEBUG - 2012-02-03 21:51:17 --> Config Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:51:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:51:17 --> URI Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Router Class Initialized
DEBUG - 2012-02-03 21:51:17 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:51:17 --> Output Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Security Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Input Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:51:17 --> Language Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Loader Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:51:17 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Session Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:51:17 --> Session routines successfully run
DEBUG - 2012-02-03 21:51:17 --> Model Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Model Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Controller Class Initialized
DEBUG - 2012-02-03 21:51:17 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:51:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:51:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:51:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:51:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:51:17 --> Final output sent to browser
DEBUG - 2012-02-03 21:51:17 --> Total execution time: 0.4897
DEBUG - 2012-02-03 21:53:58 --> Config Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:53:58 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:53:58 --> URI Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Router Class Initialized
DEBUG - 2012-02-03 21:53:58 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:53:58 --> Output Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Security Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Input Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:53:58 --> Language Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Loader Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:53:58 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Session Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:53:58 --> Session routines successfully run
DEBUG - 2012-02-03 21:53:58 --> Model Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Model Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Controller Class Initialized
DEBUG - 2012-02-03 21:53:58 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:53:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:53:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:53:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:53:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:53:58 --> Final output sent to browser
DEBUG - 2012-02-03 21:53:58 --> Total execution time: 0.5495
DEBUG - 2012-02-03 21:56:04 --> Config Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:56:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:56:04 --> URI Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Router Class Initialized
DEBUG - 2012-02-03 21:56:04 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:56:04 --> Output Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Security Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Input Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:56:04 --> Language Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Loader Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:56:04 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Session Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:56:04 --> Session routines successfully run
DEBUG - 2012-02-03 21:56:04 --> Model Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Model Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Controller Class Initialized
DEBUG - 2012-02-03 21:56:04 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:56:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:56:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:56:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:56:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:56:05 --> Final output sent to browser
DEBUG - 2012-02-03 21:56:05 --> Total execution time: 0.5376
DEBUG - 2012-02-03 21:57:09 --> Config Class Initialized
DEBUG - 2012-02-03 21:57:09 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:57:09 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:57:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:57:09 --> URI Class Initialized
DEBUG - 2012-02-03 21:57:09 --> Router Class Initialized
DEBUG - 2012-02-03 21:57:09 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:57:09 --> Output Class Initialized
DEBUG - 2012-02-03 21:57:09 --> Security Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Input Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:57:10 --> Language Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Loader Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:57:10 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Session Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:57:10 --> Session routines successfully run
DEBUG - 2012-02-03 21:57:10 --> Model Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Model Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Controller Class Initialized
DEBUG - 2012-02-03 21:57:10 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:57:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:57:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:57:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:57:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:57:10 --> Final output sent to browser
DEBUG - 2012-02-03 21:57:10 --> Total execution time: 0.5194
DEBUG - 2012-02-03 21:57:30 --> Config Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:57:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:57:30 --> URI Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Router Class Initialized
DEBUG - 2012-02-03 21:57:30 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:57:30 --> Output Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Security Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Input Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:57:30 --> Language Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Loader Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:57:30 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Session Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:57:30 --> Session routines successfully run
DEBUG - 2012-02-03 21:57:30 --> Model Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Model Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Controller Class Initialized
DEBUG - 2012-02-03 21:57:30 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:57:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:57:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:57:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:57:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:57:30 --> Final output sent to browser
DEBUG - 2012-02-03 21:57:30 --> Total execution time: 0.5629
DEBUG - 2012-02-03 21:59:55 --> Config Class Initialized
DEBUG - 2012-02-03 21:59:55 --> Hooks Class Initialized
DEBUG - 2012-02-03 21:59:55 --> Utf8 Class Initialized
DEBUG - 2012-02-03 21:59:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 21:59:55 --> URI Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Router Class Initialized
DEBUG - 2012-02-03 21:59:56 --> No URI present. Default controller set.
DEBUG - 2012-02-03 21:59:56 --> Output Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Security Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Input Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 21:59:56 --> Language Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Loader Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Helper loaded: url_helper
DEBUG - 2012-02-03 21:59:56 --> Database Driver Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Session Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Helper loaded: string_helper
DEBUG - 2012-02-03 21:59:56 --> Session routines successfully run
DEBUG - 2012-02-03 21:59:56 --> Model Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Model Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Controller Class Initialized
DEBUG - 2012-02-03 21:59:56 --> Pagination Class Initialized
DEBUG - 2012-02-03 21:59:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 21:59:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 21:59:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 21:59:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 21:59:56 --> Final output sent to browser
DEBUG - 2012-02-03 21:59:56 --> Total execution time: 1.7724
DEBUG - 2012-02-03 22:00:12 --> Config Class Initialized
DEBUG - 2012-02-03 22:00:12 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:00:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:00:13 --> URI Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Router Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Output Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Security Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Input Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:00:13 --> Language Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Loader Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:00:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Session Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:00:13 --> Session routines successfully run
DEBUG - 2012-02-03 22:00:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Controller Class Initialized
DEBUG - 2012-02-03 22:00:13 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:00:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:00:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:00:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:00:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:00:13 --> Final output sent to browser
DEBUG - 2012-02-03 22:00:13 --> Total execution time: 0.6229
DEBUG - 2012-02-03 22:00:16 --> Config Class Initialized
DEBUG - 2012-02-03 22:00:16 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:00:16 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:00:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:00:16 --> URI Class Initialized
DEBUG - 2012-02-03 22:00:16 --> Router Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Output Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Security Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Input Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:00:17 --> Language Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Loader Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:00:17 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Session Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:00:17 --> Session routines successfully run
DEBUG - 2012-02-03 22:00:17 --> Model Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Model Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Controller Class Initialized
DEBUG - 2012-02-03 22:00:17 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:00:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:00:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:00:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:00:17 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:00:17 --> Final output sent to browser
DEBUG - 2012-02-03 22:00:17 --> Total execution time: 0.6963
DEBUG - 2012-02-03 22:00:19 --> Config Class Initialized
DEBUG - 2012-02-03 22:00:19 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:00:19 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:00:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:00:19 --> URI Class Initialized
DEBUG - 2012-02-03 22:00:19 --> Router Class Initialized
DEBUG - 2012-02-03 22:00:19 --> Output Class Initialized
DEBUG - 2012-02-03 22:00:19 --> Security Class Initialized
DEBUG - 2012-02-03 22:00:19 --> Input Class Initialized
DEBUG - 2012-02-03 22:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:00:20 --> Language Class Initialized
DEBUG - 2012-02-03 22:00:20 --> Loader Class Initialized
DEBUG - 2012-02-03 22:00:20 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:00:20 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:00:20 --> Session Class Initialized
DEBUG - 2012-02-03 22:00:20 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:00:20 --> Session routines successfully run
DEBUG - 2012-02-03 22:00:20 --> Model Class Initialized
DEBUG - 2012-02-03 22:00:20 --> Model Class Initialized
DEBUG - 2012-02-03 22:00:20 --> Controller Class Initialized
DEBUG - 2012-02-03 22:00:20 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:00:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:00:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:00:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:00:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:00:20 --> Final output sent to browser
DEBUG - 2012-02-03 22:00:20 --> Total execution time: 0.6759
DEBUG - 2012-02-03 22:02:48 --> Config Class Initialized
DEBUG - 2012-02-03 22:02:48 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:02:48 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:02:48 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:02:48 --> URI Class Initialized
DEBUG - 2012-02-03 22:02:48 --> Router Class Initialized
DEBUG - 2012-02-03 22:02:48 --> Output Class Initialized
DEBUG - 2012-02-03 22:02:48 --> Security Class Initialized
DEBUG - 2012-02-03 22:02:48 --> Input Class Initialized
DEBUG - 2012-02-03 22:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:02:49 --> Language Class Initialized
DEBUG - 2012-02-03 22:02:49 --> Loader Class Initialized
DEBUG - 2012-02-03 22:02:49 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:02:49 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:02:49 --> Session Class Initialized
DEBUG - 2012-02-03 22:02:49 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:02:49 --> Session routines successfully run
DEBUG - 2012-02-03 22:02:49 --> Model Class Initialized
DEBUG - 2012-02-03 22:02:49 --> Model Class Initialized
DEBUG - 2012-02-03 22:02:49 --> Controller Class Initialized
DEBUG - 2012-02-03 22:02:49 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:02:49 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:02:49 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:02:49 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:02:49 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:02:49 --> Final output sent to browser
DEBUG - 2012-02-03 22:02:49 --> Total execution time: 1.5713
DEBUG - 2012-02-03 22:10:13 --> Config Class Initialized
DEBUG - 2012-02-03 22:10:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:10:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:10:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:10:13 --> URI Class Initialized
DEBUG - 2012-02-03 22:10:13 --> Router Class Initialized
DEBUG - 2012-02-03 22:10:14 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:10:14 --> Output Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Security Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Input Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:10:14 --> Language Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Loader Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:10:14 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Session Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:10:14 --> Session routines successfully run
DEBUG - 2012-02-03 22:10:14 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Controller Class Initialized
DEBUG - 2012-02-03 22:10:14 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:10:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:10:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:10:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:10:14 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:10:14 --> Final output sent to browser
DEBUG - 2012-02-03 22:10:14 --> Total execution time: 0.5179
DEBUG - 2012-02-03 22:10:37 --> Config Class Initialized
DEBUG - 2012-02-03 22:10:37 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:10:37 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:10:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:10:37 --> URI Class Initialized
DEBUG - 2012-02-03 22:10:37 --> Router Class Initialized
DEBUG - 2012-02-03 22:10:37 --> Output Class Initialized
DEBUG - 2012-02-03 22:10:37 --> Security Class Initialized
DEBUG - 2012-02-03 22:10:37 --> Input Class Initialized
DEBUG - 2012-02-03 22:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:10:37 --> Language Class Initialized
DEBUG - 2012-02-03 22:10:38 --> Loader Class Initialized
DEBUG - 2012-02-03 22:10:38 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:10:38 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:10:38 --> Session Class Initialized
DEBUG - 2012-02-03 22:10:38 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:10:38 --> Session routines successfully run
DEBUG - 2012-02-03 22:10:38 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:38 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:38 --> Controller Class Initialized
DEBUG - 2012-02-03 22:10:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:10:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:10:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:10:38 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 22:10:38 --> Final output sent to browser
DEBUG - 2012-02-03 22:10:38 --> Total execution time: 0.5071
DEBUG - 2012-02-03 22:10:47 --> Config Class Initialized
DEBUG - 2012-02-03 22:10:47 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:10:47 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:10:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:10:48 --> URI Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Router Class Initialized
DEBUG - 2012-02-03 22:10:48 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:10:48 --> Output Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Security Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Input Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:10:48 --> Language Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Loader Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:10:48 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Session Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:10:48 --> Session routines successfully run
DEBUG - 2012-02-03 22:10:48 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Controller Class Initialized
DEBUG - 2012-02-03 22:10:48 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:10:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:10:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:10:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:10:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:10:48 --> Final output sent to browser
DEBUG - 2012-02-03 22:10:48 --> Total execution time: 0.4745
DEBUG - 2012-02-03 22:10:51 --> Config Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:10:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:10:51 --> URI Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Router Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Output Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Security Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Input Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:10:51 --> Language Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Loader Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:10:51 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Session Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:10:51 --> Session routines successfully run
DEBUG - 2012-02-03 22:10:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:10:51 --> Controller Class Initialized
DEBUG - 2012-02-03 22:10:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:10:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:10:52 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:10:52 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:10:52 --> Final output sent to browser
DEBUG - 2012-02-03 22:10:52 --> Total execution time: 0.4700
DEBUG - 2012-02-03 22:11:44 --> Config Class Initialized
DEBUG - 2012-02-03 22:11:44 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:11:44 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:11:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:11:44 --> URI Class Initialized
DEBUG - 2012-02-03 22:11:44 --> Router Class Initialized
DEBUG - 2012-02-03 22:11:44 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:11:44 --> Output Class Initialized
DEBUG - 2012-02-03 22:11:44 --> Security Class Initialized
DEBUG - 2012-02-03 22:11:44 --> Input Class Initialized
DEBUG - 2012-02-03 22:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:11:44 --> Language Class Initialized
DEBUG - 2012-02-03 22:11:44 --> Loader Class Initialized
DEBUG - 2012-02-03 22:11:45 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:11:45 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:11:45 --> Session Class Initialized
DEBUG - 2012-02-03 22:11:45 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:11:45 --> Session routines successfully run
DEBUG - 2012-02-03 22:11:45 --> Model Class Initialized
DEBUG - 2012-02-03 22:11:45 --> Model Class Initialized
DEBUG - 2012-02-03 22:11:45 --> Controller Class Initialized
DEBUG - 2012-02-03 22:11:45 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:11:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:11:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:11:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:11:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:11:45 --> Final output sent to browser
DEBUG - 2012-02-03 22:11:45 --> Total execution time: 0.4401
DEBUG - 2012-02-03 22:11:51 --> Config Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:11:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:11:51 --> URI Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Router Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Output Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Security Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Input Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:11:51 --> Language Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Loader Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:11:51 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Session Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:11:51 --> Session routines successfully run
DEBUG - 2012-02-03 22:11:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:11:51 --> Controller Class Initialized
DEBUG - 2012-02-03 22:11:51 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:11:51 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:11:51 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:11:51 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:11:51 --> Final output sent to browser
DEBUG - 2012-02-03 22:11:51 --> Total execution time: 0.4701
DEBUG - 2012-02-03 22:11:53 --> Config Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:11:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:11:53 --> URI Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Router Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Output Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Security Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Input Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:11:53 --> Language Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Loader Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:11:53 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Session Class Initialized
DEBUG - 2012-02-03 22:11:53 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:11:53 --> Session routines successfully run
DEBUG - 2012-02-03 22:11:53 --> Model Class Initialized
DEBUG - 2012-02-03 22:11:54 --> Model Class Initialized
DEBUG - 2012-02-03 22:11:54 --> Controller Class Initialized
DEBUG - 2012-02-03 22:11:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:11:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:11:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:11:54 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 22:11:54 --> Final output sent to browser
DEBUG - 2012-02-03 22:11:54 --> Total execution time: 0.4626
DEBUG - 2012-02-03 22:12:00 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:00 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:00 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:00 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:00 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:00 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:00 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:00 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:00 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:12:00 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:00 --> Total execution time: 0.4483
DEBUG - 2012-02-03 22:12:02 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:02 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:02 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:02 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:02 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:02 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:02 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:02 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 22:12:02 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:02 --> Total execution time: 0.4607
DEBUG - 2012-02-03 22:12:04 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:04 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:04 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:05 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:05 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:05 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:05 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:05 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:05 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:05 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:12:05 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:05 --> Total execution time: 0.4533
DEBUG - 2012-02-03 22:12:07 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:07 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:07 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:07 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:07 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:07 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:07 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 22:12:07 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:07 --> Total execution time: 0.5500
DEBUG - 2012-02-03 22:12:09 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:09 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:09 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:09 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:09 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:09 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:09 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:09 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:12:09 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:10 --> Total execution time: 0.4529
DEBUG - 2012-02-03 22:12:11 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:11 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:11 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:11 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:11 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:11 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:11 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:12 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:12:12 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:12 --> Total execution time: 0.4398
DEBUG - 2012-02-03 22:12:16 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:16 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:16 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:16 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:16 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:16 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:17 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:17 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:17 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:17 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:17 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:17 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:12:17 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:17 --> Total execution time: 0.7149
DEBUG - 2012-02-03 22:12:35 --> Config Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:12:35 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:12:35 --> URI Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Router Class Initialized
DEBUG - 2012-02-03 22:12:35 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:12:35 --> Output Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Security Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Input Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:12:35 --> Language Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Loader Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:12:35 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Session Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:12:35 --> Session routines successfully run
DEBUG - 2012-02-03 22:12:35 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Model Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Controller Class Initialized
DEBUG - 2012-02-03 22:12:35 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:12:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:12:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:12:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:12:35 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:12:35 --> Final output sent to browser
DEBUG - 2012-02-03 22:12:35 --> Total execution time: 0.4569
DEBUG - 2012-02-03 22:13:13 --> Config Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:13:13 --> URI Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Router Class Initialized
DEBUG - 2012-02-03 22:13:13 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:13:13 --> Output Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Security Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Input Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:13:13 --> Language Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Loader Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:13:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Session Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:13:13 --> Session routines successfully run
DEBUG - 2012-02-03 22:13:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Controller Class Initialized
DEBUG - 2012-02-03 22:13:13 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:13:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:13:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:13:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:13:13 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:13:13 --> Final output sent to browser
DEBUG - 2012-02-03 22:13:13 --> Total execution time: 0.4544
DEBUG - 2012-02-03 22:13:15 --> Config Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:13:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:13:15 --> URI Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Router Class Initialized
DEBUG - 2012-02-03 22:13:15 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:13:15 --> Output Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Security Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Input Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:13:15 --> Language Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Loader Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:13:15 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Session Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:13:15 --> Session routines successfully run
DEBUG - 2012-02-03 22:13:15 --> Model Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Model Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Controller Class Initialized
DEBUG - 2012-02-03 22:13:15 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:13:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:13:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:13:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:13:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:13:16 --> Final output sent to browser
DEBUG - 2012-02-03 22:13:16 --> Total execution time: 0.6519
DEBUG - 2012-02-03 22:19:09 --> Config Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:19:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:19:09 --> URI Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Router Class Initialized
DEBUG - 2012-02-03 22:19:09 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:19:09 --> Output Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Security Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Input Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:19:09 --> Language Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Loader Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:19:09 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Session Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:19:09 --> Session routines successfully run
DEBUG - 2012-02-03 22:19:09 --> Model Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Model Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Controller Class Initialized
DEBUG - 2012-02-03 22:19:09 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:19:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:19:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:19:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:19:09 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:19:09 --> Final output sent to browser
DEBUG - 2012-02-03 22:19:09 --> Total execution time: 0.5170
DEBUG - 2012-02-03 22:20:12 --> Config Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:20:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:20:12 --> URI Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Router Class Initialized
DEBUG - 2012-02-03 22:20:12 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:20:12 --> Output Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Security Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Input Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:20:12 --> Language Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Loader Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:20:12 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Session Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:20:12 --> Session routines successfully run
DEBUG - 2012-02-03 22:20:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Controller Class Initialized
DEBUG - 2012-02-03 22:20:12 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:20:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:20:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:20:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:20:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:20:12 --> Final output sent to browser
DEBUG - 2012-02-03 22:20:12 --> Total execution time: 0.5020
DEBUG - 2012-02-03 22:20:19 --> Config Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:20:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:20:19 --> URI Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Router Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Output Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Security Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Input Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:20:19 --> Language Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Loader Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:20:19 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Session Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:20:19 --> Session routines successfully run
DEBUG - 2012-02-03 22:20:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Controller Class Initialized
DEBUG - 2012-02-03 22:20:19 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:20:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:20:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:20:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:20:19 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:20:19 --> Final output sent to browser
DEBUG - 2012-02-03 22:20:19 --> Total execution time: 0.6278
DEBUG - 2012-02-03 22:20:40 --> Config Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:20:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:20:40 --> URI Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Router Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Output Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Security Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Input Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:20:40 --> Language Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Loader Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:20:40 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Session Class Initialized
DEBUG - 2012-02-03 22:20:40 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:20:41 --> Session routines successfully run
DEBUG - 2012-02-03 22:20:41 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:41 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:41 --> Controller Class Initialized
DEBUG - 2012-02-03 22:20:41 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:20:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:20:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:20:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:20:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:20:41 --> Final output sent to browser
DEBUG - 2012-02-03 22:20:41 --> Total execution time: 0.6764
DEBUG - 2012-02-03 22:20:53 --> Config Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:20:53 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:20:53 --> URI Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Router Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Output Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Security Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Input Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:20:53 --> Language Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Loader Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:20:53 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Session Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:20:53 --> Session routines successfully run
DEBUG - 2012-02-03 22:20:53 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Model Class Initialized
DEBUG - 2012-02-03 22:20:53 --> Controller Class Initialized
DEBUG - 2012-02-03 22:20:53 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:20:53 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:20:53 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:20:53 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 22:20:53 --> Final output sent to browser
DEBUG - 2012-02-03 22:20:53 --> Total execution time: 0.5329
DEBUG - 2012-02-03 22:26:31 --> Config Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:26:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:26:31 --> URI Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Router Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Output Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Security Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Input Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:26:31 --> Language Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Loader Class Initialized
DEBUG - 2012-02-03 22:26:31 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:26:32 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:26:32 --> Session Class Initialized
DEBUG - 2012-02-03 22:26:32 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:26:32 --> Session routines successfully run
DEBUG - 2012-02-03 22:26:32 --> Model Class Initialized
DEBUG - 2012-02-03 22:26:32 --> Model Class Initialized
DEBUG - 2012-02-03 22:26:32 --> Controller Class Initialized
DEBUG - 2012-02-03 22:26:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:26:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:26:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:26:32 --> File loaded: application/views/user/article.php
DEBUG - 2012-02-03 22:26:32 --> Final output sent to browser
DEBUG - 2012-02-03 22:26:32 --> Total execution time: 0.6300
DEBUG - 2012-02-03 22:26:39 --> Config Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:26:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:26:39 --> URI Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Router Class Initialized
DEBUG - 2012-02-03 22:26:39 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:26:39 --> Output Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Security Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Input Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:26:39 --> Language Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Loader Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:26:39 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Session Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:26:39 --> Session routines successfully run
DEBUG - 2012-02-03 22:26:39 --> Model Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Model Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Controller Class Initialized
DEBUG - 2012-02-03 22:26:39 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:26:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:26:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:26:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:26:39 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:26:39 --> Final output sent to browser
DEBUG - 2012-02-03 22:26:39 --> Total execution time: 0.6034
DEBUG - 2012-02-03 22:37:12 --> Config Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:37:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:37:12 --> URI Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Router Class Initialized
DEBUG - 2012-02-03 22:37:12 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:37:12 --> Output Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Security Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Input Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:37:12 --> Language Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Loader Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:37:12 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Session Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:37:12 --> Session routines successfully run
DEBUG - 2012-02-03 22:37:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Controller Class Initialized
DEBUG - 2012-02-03 22:37:12 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:37:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:37:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:37:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:37:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:37:12 --> Final output sent to browser
DEBUG - 2012-02-03 22:37:12 --> Total execution time: 0.6715
DEBUG - 2012-02-03 22:37:19 --> Config Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:37:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:37:19 --> URI Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Router Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Output Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Security Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Input Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:37:19 --> Language Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Loader Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:37:19 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Session Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:37:19 --> Session routines successfully run
DEBUG - 2012-02-03 22:37:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Controller Class Initialized
DEBUG - 2012-02-03 22:37:19 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:37:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:37:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:37:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:37:19 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 22:37:19 --> Final output sent to browser
DEBUG - 2012-02-03 22:37:19 --> Total execution time: 0.6707
DEBUG - 2012-02-03 22:37:25 --> Config Class Initialized
DEBUG - 2012-02-03 22:37:25 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:37:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:37:26 --> URI Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Router Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Output Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Security Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Input Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:37:26 --> Language Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Loader Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:37:26 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Session Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:37:26 --> Session routines successfully run
DEBUG - 2012-02-03 22:37:26 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Controller Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Config Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:37:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:37:26 --> URI Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Router Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Output Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Security Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Input Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:37:26 --> Language Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Loader Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:37:26 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Session Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:37:26 --> Session routines successfully run
DEBUG - 2012-02-03 22:37:26 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Controller Class Initialized
DEBUG - 2012-02-03 22:37:26 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:37:27 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:37:27 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:37:27 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:37:27 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 22:37:27 --> Final output sent to browser
DEBUG - 2012-02-03 22:37:27 --> Total execution time: 0.5659
DEBUG - 2012-02-03 22:37:28 --> Config Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:37:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:37:28 --> URI Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Router Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Output Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Security Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Input Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:37:28 --> Language Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Loader Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:37:28 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Session Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:37:28 --> Session routines successfully run
DEBUG - 2012-02-03 22:37:28 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Controller Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Config Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:37:28 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:37:28 --> URI Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Router Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Output Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Security Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Input Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:37:28 --> Language Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Loader Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:37:28 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:37:28 --> Session Class Initialized
DEBUG - 2012-02-03 22:37:29 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:37:29 --> Session routines successfully run
DEBUG - 2012-02-03 22:37:29 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:29 --> Model Class Initialized
DEBUG - 2012-02-03 22:37:29 --> Controller Class Initialized
DEBUG - 2012-02-03 22:37:29 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:37:29 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:37:29 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:37:29 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:37:29 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 22:37:29 --> Final output sent to browser
DEBUG - 2012-02-03 22:37:29 --> Total execution time: 0.7274
DEBUG - 2012-02-03 22:38:08 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:08 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:08 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:08 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:08 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:08 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:08 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:38:08 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:38:08 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:38:08 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:38:08 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 22:38:08 --> Final output sent to browser
DEBUG - 2012-02-03 22:38:08 --> Total execution time: 0.6295
DEBUG - 2012-02-03 22:38:11 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:11 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:12 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:12 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:38:12 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:12 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:12 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:12 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:12 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:38:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:38:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:38:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:38:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:38:12 --> Final output sent to browser
DEBUG - 2012-02-03 22:38:12 --> Total execution time: 0.5839
DEBUG - 2012-02-03 22:38:17 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:17 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:17 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:17 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:17 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:17 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:17 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:17 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:38:17 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:38:17 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:38:17 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-02-03 22:38:17 --> Final output sent to browser
DEBUG - 2012-02-03 22:38:17 --> Total execution time: 0.5913
DEBUG - 2012-02-03 22:38:37 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:37 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:37 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:37 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:37 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:37 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:37 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:37 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:38 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:38 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:38 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:38 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:38 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:38:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:38:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:38:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:38:38 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 22:38:38 --> Final output sent to browser
DEBUG - 2012-02-03 22:38:38 --> Total execution time: 0.7494
DEBUG - 2012-02-03 22:38:40 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:40 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:40 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:40 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:40 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:41 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:41 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:41 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:41 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:41 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:41 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:41 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:38:41 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:38:41 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:38:41 --> File loaded: application/views/admin/category_edit.php
DEBUG - 2012-02-03 22:38:41 --> Final output sent to browser
DEBUG - 2012-02-03 22:38:41 --> Total execution time: 0.5580
DEBUG - 2012-02-03 22:38:50 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:50 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:50 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:50 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:50 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:50 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:50 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:50 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:50 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:51 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:51 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:51 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:51 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:51 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:51 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:51 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:51 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:38:51 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:38:51 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:38:51 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:38:51 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 22:38:51 --> Final output sent to browser
DEBUG - 2012-02-03 22:38:51 --> Total execution time: 0.5703
DEBUG - 2012-02-03 22:38:54 --> Config Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:38:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:38:54 --> URI Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Router Class Initialized
DEBUG - 2012-02-03 22:38:54 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:38:54 --> Output Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Security Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Input Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:38:54 --> Language Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Loader Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:38:54 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Session Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:38:54 --> Session routines successfully run
DEBUG - 2012-02-03 22:38:54 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Model Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Controller Class Initialized
DEBUG - 2012-02-03 22:38:54 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:38:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:38:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:38:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:38:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:38:54 --> Final output sent to browser
DEBUG - 2012-02-03 22:38:54 --> Total execution time: 0.6095
DEBUG - 2012-02-03 22:39:04 --> Config Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:39:04 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:39:04 --> URI Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Router Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Output Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Security Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Input Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:39:04 --> Language Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Loader Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:39:04 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Session Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:39:04 --> Session routines successfully run
DEBUG - 2012-02-03 22:39:04 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:04 --> Controller Class Initialized
DEBUG - 2012-02-03 22:39:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:39:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:39:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:39:04 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:39:04 --> Final output sent to browser
DEBUG - 2012-02-03 22:39:04 --> Total execution time: 0.4964
DEBUG - 2012-02-03 22:39:08 --> Config Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:39:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:39:08 --> URI Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Router Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Output Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Security Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Input Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:39:08 --> Language Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Loader Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:39:08 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Session Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:39:08 --> Session routines successfully run
DEBUG - 2012-02-03 22:39:08 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:08 --> Controller Class Initialized
DEBUG - 2012-02-03 22:39:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:39:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:39:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:39:08 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:39:08 --> Final output sent to browser
DEBUG - 2012-02-03 22:39:08 --> Total execution time: 0.5232
DEBUG - 2012-02-03 22:39:11 --> Config Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:39:11 --> URI Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Router Class Initialized
DEBUG - 2012-02-03 22:39:11 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:39:11 --> Output Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Security Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Input Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:39:11 --> Language Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Loader Class Initialized
DEBUG - 2012-02-03 22:39:11 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:39:12 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:39:12 --> Session Class Initialized
DEBUG - 2012-02-03 22:39:12 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:39:12 --> Session routines successfully run
DEBUG - 2012-02-03 22:39:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:12 --> Controller Class Initialized
DEBUG - 2012-02-03 22:39:12 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:39:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:39:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:39:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:39:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:39:12 --> Final output sent to browser
DEBUG - 2012-02-03 22:39:12 --> Total execution time: 0.5073
DEBUG - 2012-02-03 22:39:15 --> Config Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:39:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:39:15 --> URI Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Router Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Output Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Security Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Input Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:39:15 --> Language Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Loader Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:39:15 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Session Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:39:15 --> Session routines successfully run
DEBUG - 2012-02-03 22:39:15 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Model Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Controller Class Initialized
DEBUG - 2012-02-03 22:39:15 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:39:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:39:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:39:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:39:15 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:39:15 --> Final output sent to browser
DEBUG - 2012-02-03 22:39:15 --> Total execution time: 0.6186
DEBUG - 2012-02-03 22:49:30 --> Config Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:49:30 --> URI Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Router Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Output Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Security Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Input Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:49:30 --> Language Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Loader Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:49:30 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Session Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:49:30 --> Session routines successfully run
DEBUG - 2012-02-03 22:49:30 --> Model Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Model Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Controller Class Initialized
DEBUG - 2012-02-03 22:49:30 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:49:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:49:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:49:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:49:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:49:30 --> Final output sent to browser
DEBUG - 2012-02-03 22:49:30 --> Total execution time: 0.7212
DEBUG - 2012-02-03 22:50:55 --> Config Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:50:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:50:55 --> URI Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Router Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Output Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Security Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Input Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:50:55 --> Language Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Loader Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:50:55 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Session Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:50:55 --> Session routines successfully run
DEBUG - 2012-02-03 22:50:55 --> Model Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Model Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Controller Class Initialized
DEBUG - 2012-02-03 22:50:55 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:50:55 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:50:55 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:50:55 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:50:55 --> File loaded: application/views/admin/home.php
DEBUG - 2012-02-03 22:50:55 --> Final output sent to browser
DEBUG - 2012-02-03 22:50:55 --> Total execution time: 0.5056
DEBUG - 2012-02-03 22:51:06 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:06 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:06 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:06 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:06 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:06 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:06 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:06 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:06 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:06 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:07 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:07 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:07 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:07 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:07 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:07 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:07 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:51:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:51:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:51:07 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 22:51:07 --> Final output sent to browser
DEBUG - 2012-02-03 22:51:07 --> Total execution time: 0.3009
DEBUG - 2012-02-03 22:51:08 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:08 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:08 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:08 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:08 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:08 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:08 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:08 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:08 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:08 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:09 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:09 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:09 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:09 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:09 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:09 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:09 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:09 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:09 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:09 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:51:09 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:51:09 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:51:09 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:51:09 --> Final output sent to browser
DEBUG - 2012-02-03 22:51:09 --> Total execution time: 0.3375
DEBUG - 2012-02-03 22:51:13 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:13 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:13 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:13 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:13 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:13 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:13 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:13 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:13 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:14 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:51:14 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:51:14 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:51:14 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:51:14 --> Final output sent to browser
DEBUG - 2012-02-03 22:51:14 --> Total execution time: 0.2266
DEBUG - 2012-02-03 22:51:15 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:15 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:15 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:15 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:16 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:16 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:16 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:16 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:16 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:16 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:16 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:16 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:16 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:51:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:51:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:51:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:51:16 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:51:16 --> Final output sent to browser
DEBUG - 2012-02-03 22:51:16 --> Total execution time: 0.2753
DEBUG - 2012-02-03 22:51:20 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:20 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:20 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:51:20 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:20 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:20 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:20 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:20 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:20 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:51:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:51:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:51:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:51:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:51:20 --> Final output sent to browser
DEBUG - 2012-02-03 22:51:20 --> Total execution time: 0.2883
DEBUG - 2012-02-03 22:51:50 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:50 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:51 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:51 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:51 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:51 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:52 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:52 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:52 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:52 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:52 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:52 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:51:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:51:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:51:53 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:51:53 --> Final output sent to browser
DEBUG - 2012-02-03 22:51:53 --> Total execution time: 0.2359
DEBUG - 2012-02-03 22:51:55 --> Config Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:51:55 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:51:55 --> URI Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Router Class Initialized
DEBUG - 2012-02-03 22:51:55 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:51:55 --> Output Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Security Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Input Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:51:55 --> Language Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Loader Class Initialized
DEBUG - 2012-02-03 22:51:55 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:51:56 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:51:56 --> Session Class Initialized
DEBUG - 2012-02-03 22:51:56 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:51:56 --> Session routines successfully run
DEBUG - 2012-02-03 22:51:56 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:56 --> Model Class Initialized
DEBUG - 2012-02-03 22:51:56 --> Controller Class Initialized
DEBUG - 2012-02-03 22:51:56 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:51:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:51:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:51:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:51:56 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:51:56 --> Final output sent to browser
DEBUG - 2012-02-03 22:51:56 --> Total execution time: 0.2883
DEBUG - 2012-02-03 22:52:01 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:01 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:01 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:01 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:01 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:01 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:01 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:01 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:01 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 22:52:01 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:01 --> Total execution time: 0.2527
DEBUG - 2012-02-03 22:52:02 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:02 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:02 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:02 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:03 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:03 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:03 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:03 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:03 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:03 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:03 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:03 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:03 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:03 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:03 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:52:03 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:03 --> Total execution time: 0.2866
DEBUG - 2012-02-03 22:52:07 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:07 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:07 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:07 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:07 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:07 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:07 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:07 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:07 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:07 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:07 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:07 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:07 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:07 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:07 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:52:07 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:07 --> Total execution time: 0.2408
DEBUG - 2012-02-03 22:52:09 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:09 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:09 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:09 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:09 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:09 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:52:09 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:09 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:09 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:09 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:10 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:10 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:10 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:10 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:10 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:10 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:10 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:10 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:10 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:10 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:52:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:52:10 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:10 --> Total execution time: 0.2838
DEBUG - 2012-02-03 22:52:12 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:12 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:12 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:12 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:52:12 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:12 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:12 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:12 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:12 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:52:12 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:12 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:12 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:12 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:52:12 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:12 --> Total execution time: 0.2684
DEBUG - 2012-02-03 22:52:15 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:15 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:15 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:15 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:15 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:19 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:19 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:19 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:19 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:19 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:19 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:19 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:19 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:19 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:19 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:52:19 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:19 --> Total execution time: 0.2292
DEBUG - 2012-02-03 22:52:20 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:20 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:20 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:52:20 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:20 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:20 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:20 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:20 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:20 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:52:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:52:20 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:20 --> Total execution time: 0.2753
DEBUG - 2012-02-03 22:52:25 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:25 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:26 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:26 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:26 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:26 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:26 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:26 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:26 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:26 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:26 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:26 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:26 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 22:52:26 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:26 --> Total execution time: 0.2709
DEBUG - 2012-02-03 22:52:30 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:30 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:30 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:30 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:52:30 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:30 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:30 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:30 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:30 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:30 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:52:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:30 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:52:30 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:30 --> Total execution time: 0.2639
DEBUG - 2012-02-03 22:52:31 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:31 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:31 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:31 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:31 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:32 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:32 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:32 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:32 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:32 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:32 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:32 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:32 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:32 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:32 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:52:32 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:32 --> Total execution time: 0.2901
DEBUG - 2012-02-03 22:52:34 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:34 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:34 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:34 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:34 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:34 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:34 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-02-03 22:52:34 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:34 --> Total execution time: 0.2355
DEBUG - 2012-02-03 22:52:37 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:37 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:37 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:37 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:52:37 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:37 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:37 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:37 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:38 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:38 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:38 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:38 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:38 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:38 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:38 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:52:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:38 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:52:38 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:38 --> Total execution time: 0.2732
DEBUG - 2012-02-03 22:52:39 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:39 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:39 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:39 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:39 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:39 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:39 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:39 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:39 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:39 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:39 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:39 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 22:52:39 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:39 --> Total execution time: 0.2575
DEBUG - 2012-02-03 22:52:42 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:42 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:42 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:42 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:42 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:42 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:42 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:42 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:42 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:42 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:42 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:42 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:52:42 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:42 --> Total execution time: 0.2670
DEBUG - 2012-02-03 22:52:45 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:45 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:45 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:45 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:45 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:45 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:45 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:45 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:45 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:45 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:45 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:45 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:46 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:46 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:46 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:46 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:52:46 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:46 --> Total execution time: 0.2439
DEBUG - 2012-02-03 22:52:47 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:47 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:47 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:47 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:47 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:47 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:47 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:47 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:47 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:47 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:47 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:47 --> File loaded: application/views/admin/category.php
DEBUG - 2012-02-03 22:52:47 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:47 --> Total execution time: 0.2484
DEBUG - 2012-02-03 22:52:48 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:49 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:49 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:49 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:49 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:49 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:49 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:49 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:49 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:49 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:49 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:49 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:52:49 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:49 --> Total execution time: 0.2681
DEBUG - 2012-02-03 22:52:52 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:52 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:52 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:52 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:52 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:52 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:52 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:52 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:52 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:52 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:52 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:52 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-02-03 22:52:52 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:52 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-02-03 22:52:52 --> File loaded: application/views/admin/article.php
DEBUG - 2012-02-03 22:52:52 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:52 --> Total execution time: 0.2368
DEBUG - 2012-02-03 22:52:54 --> Config Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:52:54 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:52:54 --> URI Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Router Class Initialized
DEBUG - 2012-02-03 22:52:54 --> No URI present. Default controller set.
DEBUG - 2012-02-03 22:52:54 --> Output Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Security Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Input Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:52:54 --> Language Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Loader Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:52:54 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Session Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:52:54 --> Session routines successfully run
DEBUG - 2012-02-03 22:52:54 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Model Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Controller Class Initialized
DEBUG - 2012-02-03 22:52:54 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:52:54 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:52:54 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:52:54 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:52:54 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:52:54 --> Final output sent to browser
DEBUG - 2012-02-03 22:52:54 --> Total execution time: 0.2649
DEBUG - 2012-02-03 22:53:33 --> Config Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Hooks Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Utf8 Class Initialized
DEBUG - 2012-02-03 22:53:33 --> UTF-8 Support Enabled
DEBUG - 2012-02-03 22:53:33 --> URI Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Router Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Output Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Security Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Input Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-03 22:53:33 --> Language Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Loader Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Helper loaded: url_helper
DEBUG - 2012-02-03 22:53:33 --> Database Driver Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Session Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Helper loaded: string_helper
DEBUG - 2012-02-03 22:53:33 --> Session routines successfully run
DEBUG - 2012-02-03 22:53:33 --> Model Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Model Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Controller Class Initialized
DEBUG - 2012-02-03 22:53:33 --> Pagination Class Initialized
DEBUG - 2012-02-03 22:53:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-03 22:53:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-03 22:53:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-03 22:53:34 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-03 22:53:34 --> Final output sent to browser
DEBUG - 2012-02-03 22:53:34 --> Total execution time: 0.3770

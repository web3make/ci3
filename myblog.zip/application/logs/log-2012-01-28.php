<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-28 01:49:43 --> Config Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Hooks Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Utf8 Class Initialized
DEBUG - 2012-01-28 01:49:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 01:49:43 --> URI Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Router Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Output Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Security Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Input Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 01:49:43 --> Language Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Loader Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Helper loaded: url_helper
DEBUG - 2012-01-28 01:49:43 --> Database Driver Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Session Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Helper loaded: string_helper
DEBUG - 2012-01-28 01:49:43 --> A session cookie was not found.
DEBUG - 2012-01-28 01:49:43 --> Session routines successfully run
DEBUG - 2012-01-28 01:49:43 --> Model Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Model Class Initialized
DEBUG - 2012-01-28 01:49:43 --> Controller Class Initialized
DEBUG - 2012-01-28 01:49:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 01:49:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 01:49:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 01:49:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-28 01:49:43 --> Final output sent to browser
DEBUG - 2012-01-28 01:49:43 --> Total execution time: 0.7970
DEBUG - 2012-01-28 01:49:44 --> Config Class Initialized
DEBUG - 2012-01-28 01:49:44 --> Hooks Class Initialized
DEBUG - 2012-01-28 01:49:44 --> Utf8 Class Initialized
DEBUG - 2012-01-28 01:49:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 01:49:44 --> URI Class Initialized
DEBUG - 2012-01-28 01:49:44 --> Router Class Initialized
ERROR - 2012-01-28 01:49:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 02:24:29 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:29 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:29 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:29 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:29 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:29 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:29 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:29 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:29 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:29 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:29 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:29 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-28 02:24:29 --> Final output sent to browser
DEBUG - 2012-01-28 02:24:29 --> Total execution time: 0.1757
DEBUG - 2012-01-28 02:24:29 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:29 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:29 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:29 --> Router Class Initialized
ERROR - 2012-01-28 02:24:29 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 02:24:30 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:30 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:30 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:30 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:30 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:30 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:30 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:31 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:31 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:31 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:31 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:31 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Pagination Class Initialized
DEBUG - 2012-01-28 02:24:31 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 02:24:31 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 02:24:31 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 02:24:31 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-28 02:24:31 --> Final output sent to browser
DEBUG - 2012-01-28 02:24:31 --> Total execution time: 0.2393
DEBUG - 2012-01-28 02:24:31 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:31 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:31 --> Router Class Initialized
ERROR - 2012-01-28 02:24:31 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 02:24:33 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:33 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:33 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:33 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:33 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:33 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 02:24:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 02:24:33 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 02:24:33 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-28 02:24:33 --> Final output sent to browser
DEBUG - 2012-01-28 02:24:33 --> Total execution time: 0.4156
DEBUG - 2012-01-28 02:24:33 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:33 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:33 --> Router Class Initialized
ERROR - 2012-01-28 02:24:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 02:24:53 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:53 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:53 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:53 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:53 --> A session cookie was not found.
DEBUG - 2012-01-28 02:24:53 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:53 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:53 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:54 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:55 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:55 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:55 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:55 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:55 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:55 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:55 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-28 02:24:55 --> Final output sent to browser
DEBUG - 2012-01-28 02:24:55 --> Total execution time: 0.2148
DEBUG - 2012-01-28 02:24:57 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:57 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:58 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:58 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:58 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:58 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:58 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Config Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:24:58 --> URI Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Router Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Output Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Security Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Input Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:24:58 --> Language Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Loader Class Initialized
DEBUG - 2012-01-28 02:24:58 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:24:58 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:24:59 --> Session Class Initialized
DEBUG - 2012-01-28 02:24:59 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:24:59 --> Session routines successfully run
DEBUG - 2012-01-28 02:24:59 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:59 --> Model Class Initialized
DEBUG - 2012-01-28 02:24:59 --> Controller Class Initialized
DEBUG - 2012-01-28 02:24:59 --> Pagination Class Initialized
DEBUG - 2012-01-28 02:24:59 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 02:24:59 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 02:24:59 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 02:24:59 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-28 02:24:59 --> Final output sent to browser
DEBUG - 2012-01-28 02:24:59 --> Total execution time: 0.7115
DEBUG - 2012-01-28 02:25:38 --> Config Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:25:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:25:38 --> URI Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Router Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Output Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Security Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Input Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:25:38 --> Language Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Loader Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:25:38 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Session Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:25:38 --> Session routines successfully run
DEBUG - 2012-01-28 02:25:38 --> Model Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Model Class Initialized
DEBUG - 2012-01-28 02:25:38 --> Controller Class Initialized
DEBUG - 2012-01-28 02:25:38 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 02:25:38 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 02:25:38 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 02:25:38 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-28 02:25:38 --> Final output sent to browser
DEBUG - 2012-01-28 02:25:38 --> Total execution time: 0.2349
DEBUG - 2012-01-28 02:26:13 --> Config Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:26:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:26:13 --> URI Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Router Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Output Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Security Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Input Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 02:26:13 --> Language Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Loader Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Helper loaded: url_helper
DEBUG - 2012-01-28 02:26:13 --> Database Driver Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Session Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Helper loaded: string_helper
DEBUG - 2012-01-28 02:26:13 --> Session routines successfully run
DEBUG - 2012-01-28 02:26:13 --> Model Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Model Class Initialized
DEBUG - 2012-01-28 02:26:13 --> Controller Class Initialized
DEBUG - 2012-01-28 02:26:13 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 02:26:13 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 02:26:13 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 02:26:13 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-28 02:26:13 --> Final output sent to browser
DEBUG - 2012-01-28 02:26:13 --> Total execution time: 0.2413
DEBUG - 2012-01-28 02:26:14 --> Config Class Initialized
DEBUG - 2012-01-28 02:26:14 --> Hooks Class Initialized
DEBUG - 2012-01-28 02:26:14 --> Utf8 Class Initialized
DEBUG - 2012-01-28 02:26:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 02:26:14 --> URI Class Initialized
DEBUG - 2012-01-28 02:26:14 --> Router Class Initialized
ERROR - 2012-01-28 02:26:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:07 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:07 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:07 --> No URI present. Default controller set.
DEBUG - 2012-01-28 14:20:07 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:07 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:07 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:07 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:08 --> A session cookie was not found.
DEBUG - 2012-01-28 14:20:08 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:08 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Pagination Class Initialized
DEBUG - 2012-01-28 14:20:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-28 14:20:08 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:08 --> Total execution time: 1.0063
DEBUG - 2012-01-28 14:20:08 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:08 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:08 --> Router Class Initialized
ERROR - 2012-01-28 14:20:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:34 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:34 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:34 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:34 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:34 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:34 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:34 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-28 14:20:34 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:34 --> Total execution time: 0.2258
DEBUG - 2012-01-28 14:20:35 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:35 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Router Class Initialized
ERROR - 2012-01-28 14:20:35 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:35 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:35 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:35 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:35 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:35 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:35 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:35 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:36 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:36 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:36 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:36 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-28 14:20:36 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:36 --> Total execution time: 0.1907
DEBUG - 2012-01-28 14:20:36 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:36 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:36 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:36 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:36 --> Router Class Initialized
ERROR - 2012-01-28 14:20:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:37 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:37 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:37 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:37 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:37 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:37 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-28 14:20:37 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:37 --> Total execution time: 0.1629
DEBUG - 2012-01-28 14:20:37 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:37 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:37 --> Router Class Initialized
ERROR - 2012-01-28 14:20:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:38 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:38 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:38 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:38 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:38 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:38 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-28 14:20:38 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:38 --> Total execution time: 0.1681
DEBUG - 2012-01-28 14:20:38 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:38 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:38 --> Router Class Initialized
ERROR - 2012-01-28 14:20:38 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:40 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:40 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:40 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:40 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:40 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:40 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-28 14:20:40 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:40 --> Total execution time: 0.1903
DEBUG - 2012-01-28 14:20:40 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:40 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:40 --> Router Class Initialized
ERROR - 2012-01-28 14:20:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:41 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:41 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:41 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:41 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:41 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:41 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:41 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-28 14:20:41 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:41 --> Total execution time: 0.2202
DEBUG - 2012-01-28 14:20:42 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:42 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:42 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:42 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:42 --> Router Class Initialized
ERROR - 2012-01-28 14:20:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:43 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:43 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:43 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:43 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:43 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:43 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:43 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:44 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:44 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-28 14:20:44 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:44 --> Total execution time: 0.2820
DEBUG - 2012-01-28 14:20:44 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:44 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:44 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:44 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:44 --> Router Class Initialized
ERROR - 2012-01-28 14:20:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:46 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:46 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:46 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:46 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:46 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:46 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:46 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:46 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:46 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:47 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:47 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:47 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:47 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-28 14:20:47 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:47 --> Total execution time: 0.1749
DEBUG - 2012-01-28 14:20:47 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:47 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:47 --> Router Class Initialized
ERROR - 2012-01-28 14:20:47 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:48 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:48 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:48 --> No URI present. Default controller set.
DEBUG - 2012-01-28 14:20:48 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:48 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:48 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:48 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:48 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:48 --> Pagination Class Initialized
DEBUG - 2012-01-28 14:20:48 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-28 14:20:48 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:48 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-28 14:20:48 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-28 14:20:48 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:48 --> Total execution time: 0.1810
DEBUG - 2012-01-28 14:20:49 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:49 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:49 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:49 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:49 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:49 --> Router Class Initialized
ERROR - 2012-01-28 14:20:49 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:51 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:51 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:51 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:51 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:51 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:51 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:51 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:51 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:51 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:51 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:51 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:51 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-28 14:20:51 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:51 --> Total execution time: 0.1834
DEBUG - 2012-01-28 14:20:51 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:51 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:51 --> Router Class Initialized
ERROR - 2012-01-28 14:20:51 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:52 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:52 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:52 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:52 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:52 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:52 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:52 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:53 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:53 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:53 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:53 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:53 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:53 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:53 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:53 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:53 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Pagination Class Initialized
DEBUG - 2012-01-28 14:20:53 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 14:20:53 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:53 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 14:20:53 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-28 14:20:53 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:53 --> Total execution time: 0.2669
DEBUG - 2012-01-28 14:20:53 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:53 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:53 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:53 --> Router Class Initialized
ERROR - 2012-01-28 14:20:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:56 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:56 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:56 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:56 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:56 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:56 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:56 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 14:20:56 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:56 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 14:20:56 --> File loaded: application/views/admin/article.php
DEBUG - 2012-01-28 14:20:56 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:56 --> Total execution time: 0.2560
DEBUG - 2012-01-28 14:20:56 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:56 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:57 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:57 --> Router Class Initialized
ERROR - 2012-01-28 14:20:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:20:58 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:58 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Router Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Output Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Security Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Input Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:20:58 --> Language Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Loader Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:20:58 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Session Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:20:58 --> Session routines successfully run
DEBUG - 2012-01-28 14:20:58 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Model Class Initialized
DEBUG - 2012-01-28 14:20:58 --> Controller Class Initialized
DEBUG - 2012-01-28 14:20:58 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 14:20:58 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 14:20:58 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 14:20:58 --> File loaded: application/views/admin/comments.php
DEBUG - 2012-01-28 14:20:58 --> Final output sent to browser
DEBUG - 2012-01-28 14:20:58 --> Total execution time: 0.2404
DEBUG - 2012-01-28 14:20:59 --> Config Class Initialized
DEBUG - 2012-01-28 14:20:59 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:20:59 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:20:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:20:59 --> URI Class Initialized
DEBUG - 2012-01-28 14:20:59 --> Router Class Initialized
ERROR - 2012-01-28 14:20:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:21:00 --> Config Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:21:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:21:00 --> URI Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Router Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Output Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Security Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Input Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:21:00 --> Language Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Loader Class Initialized
DEBUG - 2012-01-28 14:21:00 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:21:00 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:21:01 --> Session Class Initialized
DEBUG - 2012-01-28 14:21:01 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:21:01 --> Session routines successfully run
DEBUG - 2012-01-28 14:21:01 --> Model Class Initialized
DEBUG - 2012-01-28 14:21:01 --> Model Class Initialized
DEBUG - 2012-01-28 14:21:01 --> Controller Class Initialized
DEBUG - 2012-01-28 14:21:01 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 14:21:01 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 14:21:01 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 14:21:01 --> File loaded: application/views/admin/comment_edit.php
DEBUG - 2012-01-28 14:21:01 --> Final output sent to browser
DEBUG - 2012-01-28 14:21:01 --> Total execution time: 0.2669
DEBUG - 2012-01-28 14:21:01 --> Config Class Initialized
DEBUG - 2012-01-28 14:21:01 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:21:01 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:21:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:21:01 --> URI Class Initialized
DEBUG - 2012-01-28 14:21:01 --> Router Class Initialized
ERROR - 2012-01-28 14:21:01 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-28 14:21:48 --> Config Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:21:48 --> URI Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Router Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Output Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Security Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Input Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-28 14:21:48 --> Language Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Loader Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Helper loaded: url_helper
DEBUG - 2012-01-28 14:21:48 --> Database Driver Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Session Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Helper loaded: string_helper
DEBUG - 2012-01-28 14:21:48 --> Session routines successfully run
DEBUG - 2012-01-28 14:21:48 --> Model Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Model Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Controller Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Pagination Class Initialized
DEBUG - 2012-01-28 14:21:48 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-28 14:21:48 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-28 14:21:48 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-28 14:21:48 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-28 14:21:48 --> Final output sent to browser
DEBUG - 2012-01-28 14:21:48 --> Total execution time: 0.1793
DEBUG - 2012-01-28 14:21:48 --> Config Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Hooks Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Utf8 Class Initialized
DEBUG - 2012-01-28 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-28 14:21:48 --> URI Class Initialized
DEBUG - 2012-01-28 14:21:48 --> Router Class Initialized
ERROR - 2012-01-28 14:21:48 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-27 21:45:01 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:01 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:01 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:01 --> No URI present. Default controller set.
DEBUG - 2012-01-27 21:45:01 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:01 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:01 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:01 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:01 --> A session cookie was not found.
DEBUG - 2012-01-27 21:45:01 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:01 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:02 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:02 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:02 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:45:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:45:02 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:02 --> Total execution time: 1.4177
DEBUG - 2012-01-27 21:45:03 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:03 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:03 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:03 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:03 --> Router Class Initialized
ERROR - 2012-01-27 21:45:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:05 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:05 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:05 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:05 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:05 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:05 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:45:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:45:05 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:05 --> Total execution time: 0.1848
DEBUG - 2012-01-27 21:45:05 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:05 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:05 --> Router Class Initialized
ERROR - 2012-01-27 21:45:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:08 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:08 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:08 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:08 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:08 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:08 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:45:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:08 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:45:08 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:08 --> Total execution time: 0.1984
DEBUG - 2012-01-27 21:45:08 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:08 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:08 --> Router Class Initialized
ERROR - 2012-01-27 21:45:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:09 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:09 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:09 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:09 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:09 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:09 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:09 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:45:10 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:10 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:10 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:10 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:45:10 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:10 --> Total execution time: 0.2152
DEBUG - 2012-01-27 21:45:10 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:10 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:10 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:10 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:10 --> Router Class Initialized
ERROR - 2012-01-27 21:45:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:11 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:11 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:11 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:11 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:11 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:11 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:11 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:11 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:11 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:11 --> Total execution time: 0.2348
DEBUG - 2012-01-27 21:45:12 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:12 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:12 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:12 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:12 --> Router Class Initialized
ERROR - 2012-01-27 21:45:12 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:12 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:12 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:12 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:12 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:12 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:13 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:13 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:13 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:13 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:13 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:13 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:13 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:13 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:13 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:13 --> Total execution time: 0.2050
DEBUG - 2012-01-27 21:45:13 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:13 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:13 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:13 --> Router Class Initialized
ERROR - 2012-01-27 21:45:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:14 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:14 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:14 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:14 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:14 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:14 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:14 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:14 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:14 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:14 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:14 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:14 --> Total execution time: 0.1910
DEBUG - 2012-01-27 21:45:14 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:14 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:14 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:14 --> Router Class Initialized
ERROR - 2012-01-27 21:45:14 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:15 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:15 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:15 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:15 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:15 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:15 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:15 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:15 --> Total execution time: 0.1684
DEBUG - 2012-01-27 21:45:15 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:15 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:15 --> Router Class Initialized
ERROR - 2012-01-27 21:45:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:16 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:16 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:16 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:16 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:16 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:16 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:16 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:16 --> Total execution time: 0.1824
DEBUG - 2012-01-27 21:45:16 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:16 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:16 --> Router Class Initialized
ERROR - 2012-01-27 21:45:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:17 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:17 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:17 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:17 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:17 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:17 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:17 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-27 21:45:17 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:17 --> Total execution time: 0.2260
DEBUG - 2012-01-27 21:45:17 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:17 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:17 --> Router Class Initialized
ERROR - 2012-01-27 21:45:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:19 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:19 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:19 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:19 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:19 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:19 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:19 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:19 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:19 --> Total execution time: 0.1815
DEBUG - 2012-01-27 21:45:19 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:19 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:19 --> Router Class Initialized
ERROR - 2012-01-27 21:45:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:20 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:20 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:20 --> No URI present. Default controller set.
DEBUG - 2012-01-27 21:45:20 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:20 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:20 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:20 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:20 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:45:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:45:20 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:20 --> Total execution time: 0.2157
DEBUG - 2012-01-27 21:45:20 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:20 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:20 --> Router Class Initialized
ERROR - 2012-01-27 21:45:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:22 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:22 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:22 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:22 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:22 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:22 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:22 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:22 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:22 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:22 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-27 21:45:22 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:22 --> Total execution time: 0.2520
DEBUG - 2012-01-27 21:45:22 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:22 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:22 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:22 --> Router Class Initialized
ERROR - 2012-01-27 21:45:22 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:23 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:23 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:23 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:23 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:23 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:23 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:24 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:24 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:24 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:24 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:24 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:24 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:24 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:24 --> Total execution time: 0.1922
DEBUG - 2012-01-27 21:45:24 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:24 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Router Class Initialized
ERROR - 2012-01-27 21:45:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:24 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:24 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:24 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:24 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:25 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:25 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:25 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:25 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:25 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:25 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:25 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:25 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:25 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:25 --> Total execution time: 0.2134
DEBUG - 2012-01-27 21:45:25 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:25 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:25 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:25 --> Router Class Initialized
ERROR - 2012-01-27 21:45:25 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:26 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:26 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:26 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:26 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:26 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:26 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:26 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:26 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:26 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:26 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:26 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:26 --> Total execution time: 0.2101
DEBUG - 2012-01-27 21:45:26 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:26 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:26 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:26 --> Router Class Initialized
ERROR - 2012-01-27 21:45:26 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:27 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:27 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:27 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:27 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:27 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:27 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:27 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:27 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:27 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:27 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:27 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:27 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:27 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:27 --> Total execution time: 0.1835
DEBUG - 2012-01-27 21:45:28 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:28 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:28 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:28 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:28 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:28 --> Router Class Initialized
ERROR - 2012-01-27 21:45:28 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:30 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:30 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:30 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:30 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:30 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:30 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:30 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:30 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:30 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:30 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-27 21:45:30 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:30 --> Total execution time: 0.1982
DEBUG - 2012-01-27 21:45:30 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:30 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:30 --> Router Class Initialized
ERROR - 2012-01-27 21:45:30 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:33 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:33 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:33 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:33 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:33 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:33 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:33 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:33 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:33 --> Total execution time: 0.1989
DEBUG - 2012-01-27 21:45:33 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:33 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:33 --> Router Class Initialized
ERROR - 2012-01-27 21:45:33 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:34 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:34 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:34 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:34 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:34 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:34 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:34 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:34 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:34 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:34 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:34 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:34 --> Total execution time: 0.1947
DEBUG - 2012-01-27 21:45:34 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:34 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:34 --> Router Class Initialized
ERROR - 2012-01-27 21:45:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:35 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:35 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:35 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:35 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:35 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:35 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:35 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:35 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:35 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:35 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:35 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:35 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:35 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:35 --> Total execution time: 0.1687
DEBUG - 2012-01-27 21:45:36 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:36 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:36 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:36 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:36 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:36 --> Router Class Initialized
ERROR - 2012-01-27 21:45:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:37 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:37 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:37 --> No URI present. Default controller set.
DEBUG - 2012-01-27 21:45:37 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:37 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:37 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:37 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:37 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:45:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:37 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:45:37 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:37 --> Total execution time: 0.2025
DEBUG - 2012-01-27 21:45:37 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:37 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:37 --> Router Class Initialized
ERROR - 2012-01-27 21:45:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:38 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:38 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:38 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:38 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:38 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:38 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:38 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:38 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:38 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:38 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:38 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:38 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:38 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:38 --> Total execution time: 0.1509
DEBUG - 2012-01-27 21:45:39 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:39 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:39 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:39 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:39 --> Router Class Initialized
ERROR - 2012-01-27 21:45:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:41 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:41 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:41 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:41 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:41 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:41 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:41 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:41 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:41 --> Total execution time: 0.1477
DEBUG - 2012-01-27 21:45:41 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:41 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:41 --> Router Class Initialized
ERROR - 2012-01-27 21:45:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:43 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:43 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:43 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:43 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:43 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:43 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:43 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:43 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:43 --> Total execution time: 0.1573
DEBUG - 2012-01-27 21:45:43 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:43 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:43 --> Router Class Initialized
ERROR - 2012-01-27 21:45:43 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:55 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:55 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:55 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:55 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:55 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:55 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:55 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:55 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:55 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:55 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:55 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:55 --> Total execution time: 0.1516
DEBUG - 2012-01-27 21:45:55 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:55 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:55 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:55 --> Router Class Initialized
ERROR - 2012-01-27 21:45:55 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:56 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:56 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:56 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:56 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:56 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:56 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:56 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:56 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:56 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:56 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:56 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:56 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-27 21:45:56 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:56 --> Total execution time: 0.1811
DEBUG - 2012-01-27 21:45:57 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:57 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:57 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:57 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:57 --> Router Class Initialized
ERROR - 2012-01-27 21:45:57 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:45:58 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:58 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Router Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Output Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Security Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Input Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:45:58 --> Language Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Loader Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:45:58 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Session Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:45:58 --> Session routines successfully run
DEBUG - 2012-01-27 21:45:58 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Model Class Initialized
DEBUG - 2012-01-27 21:45:58 --> Controller Class Initialized
DEBUG - 2012-01-27 21:45:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:45:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:45:59 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:45:59 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 21:45:59 --> Final output sent to browser
DEBUG - 2012-01-27 21:45:59 --> Total execution time: 0.1888
DEBUG - 2012-01-27 21:45:59 --> Config Class Initialized
DEBUG - 2012-01-27 21:45:59 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:45:59 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:45:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:45:59 --> URI Class Initialized
DEBUG - 2012-01-27 21:45:59 --> Router Class Initialized
ERROR - 2012-01-27 21:45:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:46:00 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:00 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:00 --> No URI present. Default controller set.
DEBUG - 2012-01-27 21:46:00 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:00 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:00 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:00 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:00 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:46:00 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:46:00 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:46:00 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:46:00 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:46:00 --> Final output sent to browser
DEBUG - 2012-01-27 21:46:00 --> Total execution time: 0.2044
DEBUG - 2012-01-27 21:46:00 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:00 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:00 --> Router Class Initialized
ERROR - 2012-01-27 21:46:00 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:46:02 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:02 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:02 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:02 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:02 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:02 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:46:02 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:46:02 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:46:02 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:46:02 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:46:02 --> Final output sent to browser
DEBUG - 2012-01-27 21:46:02 --> Total execution time: 0.1637
DEBUG - 2012-01-27 21:46:02 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:02 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:02 --> Router Class Initialized
ERROR - 2012-01-27 21:46:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:46:04 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:04 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:04 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:04 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:04 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:04 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:46:04 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:46:04 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:46:04 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:46:04 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:46:04 --> Final output sent to browser
DEBUG - 2012-01-27 21:46:04 --> Total execution time: 0.1902
DEBUG - 2012-01-27 21:46:04 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:04 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:04 --> Router Class Initialized
ERROR - 2012-01-27 21:46:04 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:46:05 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:05 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:05 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:05 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:05 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:05 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:46:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:46:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:46:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:46:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:46:05 --> Final output sent to browser
DEBUG - 2012-01-27 21:46:05 --> Total execution time: 0.1974
DEBUG - 2012-01-27 21:46:05 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:05 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:05 --> Router Class Initialized
ERROR - 2012-01-27 21:46:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:46:07 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:07 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:07 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:07 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:08 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:08 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:08 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:08 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:08 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:08 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:08 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:08 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:46:08 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:46:08 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:46:08 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-27 21:46:08 --> Final output sent to browser
DEBUG - 2012-01-27 21:46:08 --> Total execution time: 0.1928
DEBUG - 2012-01-27 21:46:08 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:08 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:08 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:08 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:08 --> Router Class Initialized
ERROR - 2012-01-27 21:46:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:46:09 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:09 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:09 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:09 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:09 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:09 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:09 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:09 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:09 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:09 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:09 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:09 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:09 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:09 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:46:09 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:46:09 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:46:09 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-27 21:46:09 --> Final output sent to browser
DEBUG - 2012-01-27 21:46:09 --> Total execution time: 0.1596
DEBUG - 2012-01-27 21:46:10 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:10 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:10 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:10 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:10 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:10 --> Router Class Initialized
ERROR - 2012-01-27 21:46:10 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 21:46:11 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:11 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Router Class Initialized
DEBUG - 2012-01-27 21:46:11 --> No URI present. Default controller set.
DEBUG - 2012-01-27 21:46:11 --> Output Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Security Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Input Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 21:46:11 --> Language Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Loader Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Helper loaded: url_helper
DEBUG - 2012-01-27 21:46:11 --> Database Driver Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Session Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Helper loaded: string_helper
DEBUG - 2012-01-27 21:46:11 --> Session routines successfully run
DEBUG - 2012-01-27 21:46:11 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Model Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Controller Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Pagination Class Initialized
DEBUG - 2012-01-27 21:46:11 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 21:46:11 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 21:46:11 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 21:46:11 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 21:46:11 --> Final output sent to browser
DEBUG - 2012-01-27 21:46:11 --> Total execution time: 0.2214
DEBUG - 2012-01-27 21:46:11 --> Config Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Hooks Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Utf8 Class Initialized
DEBUG - 2012-01-27 21:46:11 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 21:46:11 --> URI Class Initialized
DEBUG - 2012-01-27 21:46:11 --> Router Class Initialized
ERROR - 2012-01-27 21:46:11 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 22:45:15 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:15 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Router Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Output Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Security Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Input Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 22:45:15 --> Language Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Loader Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Helper loaded: url_helper
DEBUG - 2012-01-27 22:45:15 --> Database Driver Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Session Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Helper loaded: string_helper
DEBUG - 2012-01-27 22:45:15 --> Session routines successfully run
DEBUG - 2012-01-27 22:45:15 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Controller Class Initialized
DEBUG - 2012-01-27 22:45:15 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 22:45:15 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 22:45:15 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 22:45:15 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 22:45:15 --> Final output sent to browser
DEBUG - 2012-01-27 22:45:15 --> Total execution time: 0.1781
DEBUG - 2012-01-27 22:45:15 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:15 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:15 --> Router Class Initialized
ERROR - 2012-01-27 22:45:15 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 22:45:16 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:16 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Router Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Output Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Security Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Input Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 22:45:16 --> Language Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Loader Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Helper loaded: url_helper
DEBUG - 2012-01-27 22:45:16 --> Database Driver Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Session Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Helper loaded: string_helper
DEBUG - 2012-01-27 22:45:16 --> Session routines successfully run
DEBUG - 2012-01-27 22:45:16 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Controller Class Initialized
DEBUG - 2012-01-27 22:45:16 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 22:45:16 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 22:45:16 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 22:45:16 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 22:45:16 --> Final output sent to browser
DEBUG - 2012-01-27 22:45:16 --> Total execution time: 0.2360
DEBUG - 2012-01-27 22:45:16 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:16 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:16 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:16 --> Router Class Initialized
ERROR - 2012-01-27 22:45:16 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 22:45:17 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:17 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:17 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Router Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Output Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Security Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Input Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 22:45:17 --> Language Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Loader Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Helper loaded: url_helper
DEBUG - 2012-01-27 22:45:17 --> Database Driver Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Session Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Helper loaded: string_helper
DEBUG - 2012-01-27 22:45:17 --> Session routines successfully run
DEBUG - 2012-01-27 22:45:17 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:17 --> Controller Class Initialized
DEBUG - 2012-01-27 22:45:17 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 22:45:17 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 22:45:17 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 22:45:17 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-27 22:45:17 --> Final output sent to browser
DEBUG - 2012-01-27 22:45:17 --> Total execution time: 0.2457
DEBUG - 2012-01-27 22:45:18 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:18 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Router Class Initialized
ERROR - 2012-01-27 22:45:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 22:45:18 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:18 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:18 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Router Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Output Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Security Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Input Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 22:45:18 --> Language Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Loader Class Initialized
DEBUG - 2012-01-27 22:45:18 --> Helper loaded: url_helper
DEBUG - 2012-01-27 22:45:19 --> Database Driver Class Initialized
DEBUG - 2012-01-27 22:45:19 --> Session Class Initialized
DEBUG - 2012-01-27 22:45:19 --> Helper loaded: string_helper
DEBUG - 2012-01-27 22:45:19 --> Session routines successfully run
DEBUG - 2012-01-27 22:45:19 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:19 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:19 --> Controller Class Initialized
DEBUG - 2012-01-27 22:45:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 22:45:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 22:45:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 22:45:19 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-27 22:45:19 --> Final output sent to browser
DEBUG - 2012-01-27 22:45:19 --> Total execution time: 0.2083
DEBUG - 2012-01-27 22:45:19 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:19 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:19 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:19 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:19 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:19 --> Router Class Initialized
ERROR - 2012-01-27 22:45:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 22:45:20 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:20 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:20 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Router Class Initialized
DEBUG - 2012-01-27 22:45:20 --> No URI present. Default controller set.
DEBUG - 2012-01-27 22:45:20 --> Output Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Security Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Input Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 22:45:20 --> Language Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Loader Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Helper loaded: url_helper
DEBUG - 2012-01-27 22:45:20 --> Database Driver Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Session Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Helper loaded: string_helper
DEBUG - 2012-01-27 22:45:20 --> Session routines successfully run
DEBUG - 2012-01-27 22:45:20 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Model Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Controller Class Initialized
DEBUG - 2012-01-27 22:45:20 --> Pagination Class Initialized
DEBUG - 2012-01-27 22:45:20 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 22:45:20 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 22:45:20 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 22:45:20 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 22:45:20 --> Final output sent to browser
DEBUG - 2012-01-27 22:45:20 --> Total execution time: 0.1990
DEBUG - 2012-01-27 22:45:21 --> Config Class Initialized
DEBUG - 2012-01-27 22:45:21 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:45:21 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:45:21 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:45:21 --> URI Class Initialized
DEBUG - 2012-01-27 22:45:21 --> Router Class Initialized
ERROR - 2012-01-27 22:45:21 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 22:46:39 --> Config Class Initialized
DEBUG - 2012-01-27 22:46:39 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:46:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:46:40 --> URI Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Router Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Output Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Security Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Input Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 22:46:40 --> Language Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Loader Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Helper loaded: url_helper
DEBUG - 2012-01-27 22:46:40 --> Database Driver Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Session Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Helper loaded: string_helper
DEBUG - 2012-01-27 22:46:40 --> Session routines successfully run
DEBUG - 2012-01-27 22:46:40 --> Model Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Model Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Controller Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Pagination Class Initialized
DEBUG - 2012-01-27 22:46:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 22:46:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 22:46:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 22:46:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 22:46:40 --> Final output sent to browser
DEBUG - 2012-01-27 22:46:40 --> Total execution time: 0.1774
DEBUG - 2012-01-27 22:46:40 --> Config Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:46:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:46:40 --> URI Class Initialized
DEBUG - 2012-01-27 22:46:40 --> Router Class Initialized
ERROR - 2012-01-27 22:46:40 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-27 22:46:41 --> Config Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:46:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:46:41 --> URI Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Router Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Output Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Security Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Input Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-27 22:46:41 --> Language Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Loader Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Helper loaded: url_helper
DEBUG - 2012-01-27 22:46:41 --> Database Driver Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Session Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Helper loaded: string_helper
DEBUG - 2012-01-27 22:46:41 --> Session routines successfully run
DEBUG - 2012-01-27 22:46:41 --> Model Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Model Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Controller Class Initialized
DEBUG - 2012-01-27 22:46:41 --> Pagination Class Initialized
DEBUG - 2012-01-27 22:46:41 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-27 22:46:41 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-27 22:46:41 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-27 22:46:41 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-27 22:46:41 --> Final output sent to browser
DEBUG - 2012-01-27 22:46:41 --> Total execution time: 0.2595
DEBUG - 2012-01-27 22:46:42 --> Config Class Initialized
DEBUG - 2012-01-27 22:46:42 --> Hooks Class Initialized
DEBUG - 2012-01-27 22:46:42 --> Utf8 Class Initialized
DEBUG - 2012-01-27 22:46:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-27 22:46:42 --> URI Class Initialized
DEBUG - 2012-01-27 22:46:42 --> Router Class Initialized
ERROR - 2012-01-27 22:46:42 --> 404 Page Not Found --> favicon.ico

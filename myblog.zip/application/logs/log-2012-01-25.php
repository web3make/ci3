<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-01-25 22:14:44 --> Config Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Hooks Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Utf8 Class Initialized
DEBUG - 2012-01-25 22:14:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 22:14:44 --> URI Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Router Class Initialized
DEBUG - 2012-01-25 22:14:44 --> No URI present. Default controller set.
DEBUG - 2012-01-25 22:14:44 --> Output Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Security Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Input Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 22:14:44 --> Language Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Loader Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Helper loaded: url_helper
DEBUG - 2012-01-25 22:14:44 --> Database Driver Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Session Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Helper loaded: string_helper
DEBUG - 2012-01-25 22:14:44 --> A session cookie was not found.
DEBUG - 2012-01-25 22:14:44 --> Session routines successfully run
DEBUG - 2012-01-25 22:14:44 --> Model Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Model Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Controller Class Initialized
DEBUG - 2012-01-25 22:14:44 --> Pagination Class Initialized
DEBUG - 2012-01-25 22:14:44 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 22:14:44 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 22:14:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 22:14:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-25 22:14:45 --> Final output sent to browser
DEBUG - 2012-01-25 22:14:45 --> Total execution time: 0.8176
DEBUG - 2012-01-25 22:14:45 --> Config Class Initialized
DEBUG - 2012-01-25 22:14:45 --> Hooks Class Initialized
DEBUG - 2012-01-25 22:14:45 --> Utf8 Class Initialized
DEBUG - 2012-01-25 22:14:45 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 22:14:45 --> URI Class Initialized
DEBUG - 2012-01-25 22:14:45 --> Router Class Initialized
ERROR - 2012-01-25 22:14:45 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:00:33 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:33 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Router Class Initialized
DEBUG - 2012-01-25 23:00:33 --> No URI present. Default controller set.
DEBUG - 2012-01-25 23:00:33 --> Output Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Security Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Input Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:00:33 --> Language Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Loader Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:00:33 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Session Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:00:33 --> Session routines successfully run
DEBUG - 2012-01-25 23:00:33 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Controller Class Initialized
DEBUG - 2012-01-25 23:00:33 --> Pagination Class Initialized
DEBUG - 2012-01-25 23:00:33 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:00:33 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:00:33 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:00:33 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-25 23:00:33 --> Final output sent to browser
DEBUG - 2012-01-25 23:00:33 --> Total execution time: 0.2274
DEBUG - 2012-01-25 23:00:34 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:34 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:34 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:34 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:34 --> Router Class Initialized
ERROR - 2012-01-25 23:00:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:00:37 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:37 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Router Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Output Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Security Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Input Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:00:37 --> Language Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Loader Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:00:37 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Session Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:00:37 --> Session routines successfully run
DEBUG - 2012-01-25 23:00:37 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Controller Class Initialized
DEBUG - 2012-01-25 23:00:37 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:00:37 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:00:37 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:00:37 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-25 23:00:37 --> Final output sent to browser
DEBUG - 2012-01-25 23:00:37 --> Total execution time: 0.3193
DEBUG - 2012-01-25 23:00:37 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:37 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:37 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:37 --> Router Class Initialized
ERROR - 2012-01-25 23:00:37 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:00:39 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:39 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Router Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Output Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Security Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Input Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:00:39 --> Language Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Loader Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:00:39 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Session Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:00:39 --> Session routines successfully run
DEBUG - 2012-01-25 23:00:39 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Controller Class Initialized
DEBUG - 2012-01-25 23:00:39 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:00:39 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:00:39 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:00:39 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-25 23:00:39 --> Final output sent to browser
DEBUG - 2012-01-25 23:00:39 --> Total execution time: 0.2098
DEBUG - 2012-01-25 23:00:39 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:39 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:39 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:39 --> Router Class Initialized
ERROR - 2012-01-25 23:00:39 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:00:40 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:40 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Router Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Output Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Security Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Input Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:00:40 --> Language Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Loader Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:00:40 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Session Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:00:40 --> Session routines successfully run
DEBUG - 2012-01-25 23:00:40 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:40 --> Controller Class Initialized
DEBUG - 2012-01-25 23:00:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:00:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:00:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:00:40 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-25 23:00:40 --> Final output sent to browser
DEBUG - 2012-01-25 23:00:40 --> Total execution time: 0.2219
DEBUG - 2012-01-25 23:00:41 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:41 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Router Class Initialized
ERROR - 2012-01-25 23:00:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:00:41 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:41 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:41 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Router Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Output Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Security Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Input Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:00:41 --> Language Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Loader Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:00:41 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Session Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:00:41 --> Session routines successfully run
DEBUG - 2012-01-25 23:00:41 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:41 --> Controller Class Initialized
DEBUG - 2012-01-25 23:00:42 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:00:42 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:00:42 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:00:42 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-25 23:00:42 --> Final output sent to browser
DEBUG - 2012-01-25 23:00:42 --> Total execution time: 0.1863
DEBUG - 2012-01-25 23:00:42 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:42 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:42 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:42 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:42 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:42 --> Router Class Initialized
ERROR - 2012-01-25 23:00:42 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:00:43 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:43 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:43 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Router Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Output Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Security Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Input Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:00:43 --> Language Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Loader Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:00:43 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Session Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:00:43 --> Session routines successfully run
DEBUG - 2012-01-25 23:00:43 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Model Class Initialized
DEBUG - 2012-01-25 23:00:43 --> Controller Class Initialized
DEBUG - 2012-01-25 23:00:43 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:00:43 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:00:43 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:00:43 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-25 23:00:43 --> Final output sent to browser
DEBUG - 2012-01-25 23:00:43 --> Total execution time: 0.2940
DEBUG - 2012-01-25 23:00:44 --> Config Class Initialized
DEBUG - 2012-01-25 23:00:44 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:00:44 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:00:44 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:00:44 --> URI Class Initialized
DEBUG - 2012-01-25 23:00:44 --> Router Class Initialized
ERROR - 2012-01-25 23:00:44 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:25:30 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:30 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:30 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:30 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:30 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:30 --> Router Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Output Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Security Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Input Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:25:31 --> Language Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Loader Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:25:31 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Session Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:25:31 --> Session routines successfully run
DEBUG - 2012-01-25 23:25:31 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Controller Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:31 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:31 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Router Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Output Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Security Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Input Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:25:31 --> Language Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Loader Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:25:31 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Session Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:25:31 --> Session routines successfully run
DEBUG - 2012-01-25 23:25:31 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:31 --> Controller Class Initialized
DEBUG - 2012-01-25 23:25:31 --> File loaded: application/views/admin/login.php
DEBUG - 2012-01-25 23:25:31 --> Final output sent to browser
DEBUG - 2012-01-25 23:25:31 --> Total execution time: 0.2569
DEBUG - 2012-01-25 23:25:32 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:32 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:32 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:32 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:32 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:32 --> Router Class Initialized
ERROR - 2012-01-25 23:25:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:25:33 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:33 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Router Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Output Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Security Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Input Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:25:33 --> Language Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Loader Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:25:33 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Session Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:25:33 --> Session routines successfully run
DEBUG - 2012-01-25 23:25:33 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Controller Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:33 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:33 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Router Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Output Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Security Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Input Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:25:33 --> Language Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Loader Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:25:33 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Session Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:25:33 --> Session routines successfully run
DEBUG - 2012-01-25 23:25:33 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Controller Class Initialized
DEBUG - 2012-01-25 23:25:33 --> Pagination Class Initialized
DEBUG - 2012-01-25 23:25:33 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-25 23:25:33 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-25 23:25:33 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-25 23:25:33 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-25 23:25:33 --> Final output sent to browser
DEBUG - 2012-01-25 23:25:33 --> Total execution time: 0.2622
DEBUG - 2012-01-25 23:25:34 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:34 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:34 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:34 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:34 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:34 --> Router Class Initialized
ERROR - 2012-01-25 23:25:34 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:25:58 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:58 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Router Class Initialized
DEBUG - 2012-01-25 23:25:58 --> No URI present. Default controller set.
DEBUG - 2012-01-25 23:25:58 --> Output Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Security Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Input Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:25:58 --> Language Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Loader Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:25:58 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Session Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:25:58 --> Session routines successfully run
DEBUG - 2012-01-25 23:25:58 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Model Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Controller Class Initialized
DEBUG - 2012-01-25 23:25:58 --> Pagination Class Initialized
DEBUG - 2012-01-25 23:25:58 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:25:58 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:25:58 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:25:58 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-25 23:25:58 --> Final output sent to browser
DEBUG - 2012-01-25 23:25:58 --> Total execution time: 0.2319
DEBUG - 2012-01-25 23:25:59 --> Config Class Initialized
DEBUG - 2012-01-25 23:25:59 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:25:59 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:25:59 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:25:59 --> URI Class Initialized
DEBUG - 2012-01-25 23:25:59 --> Router Class Initialized
ERROR - 2012-01-25 23:25:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:28:02 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:02 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:02 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:02 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:02 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:02 --> Router Class Initialized
DEBUG - 2012-01-25 23:28:02 --> Output Class Initialized
DEBUG - 2012-01-25 23:28:02 --> Security Class Initialized
DEBUG - 2012-01-25 23:28:02 --> Input Class Initialized
DEBUG - 2012-01-25 23:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:28:02 --> Language Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Loader Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:28:03 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Session Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:28:03 --> Session routines successfully run
DEBUG - 2012-01-25 23:28:03 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Controller Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Pagination Class Initialized
DEBUG - 2012-01-25 23:28:03 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:28:03 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:28:03 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:28:03 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-25 23:28:03 --> Final output sent to browser
DEBUG - 2012-01-25 23:28:03 --> Total execution time: 0.5467
DEBUG - 2012-01-25 23:28:03 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:03 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:03 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:03 --> Router Class Initialized
ERROR - 2012-01-25 23:28:03 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:28:04 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:04 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:04 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Router Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Output Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Security Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Input Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:28:04 --> Language Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Loader Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:28:04 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Session Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:28:04 --> Session routines successfully run
DEBUG - 2012-01-25 23:28:04 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Controller Class Initialized
DEBUG - 2012-01-25 23:28:04 --> Pagination Class Initialized
DEBUG - 2012-01-25 23:28:05 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:28:05 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:28:05 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:28:05 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-25 23:28:05 --> Final output sent to browser
DEBUG - 2012-01-25 23:28:05 --> Total execution time: 0.5450
DEBUG - 2012-01-25 23:28:05 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:05 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:05 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:05 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:05 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:05 --> Router Class Initialized
ERROR - 2012-01-25 23:28:05 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:28:07 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:07 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:07 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Router Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Output Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Security Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Input Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:28:07 --> Language Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Loader Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:28:07 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Session Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:28:07 --> Session routines successfully run
DEBUG - 2012-01-25 23:28:07 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:07 --> Controller Class Initialized
DEBUG - 2012-01-25 23:28:07 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:28:07 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:28:07 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:28:08 --> File loaded: application/views/user/article.php
DEBUG - 2012-01-25 23:28:08 --> Final output sent to browser
DEBUG - 2012-01-25 23:28:08 --> Total execution time: 0.6064
DEBUG - 2012-01-25 23:28:08 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:08 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:08 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:08 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:08 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:08 --> Router Class Initialized
ERROR - 2012-01-25 23:28:08 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:28:47 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:47 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:47 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Router Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Output Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Security Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Input Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:28:47 --> Language Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Loader Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:28:47 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Session Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:28:47 --> Session routines successfully run
DEBUG - 2012-01-25 23:28:47 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Model Class Initialized
DEBUG - 2012-01-25 23:28:47 --> Controller Class Initialized
DEBUG - 2012-01-25 23:28:47 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:28:47 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:28:47 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:28:47 --> File loaded: application/views/user/category.php
DEBUG - 2012-01-25 23:28:47 --> Final output sent to browser
DEBUG - 2012-01-25 23:28:47 --> Total execution time: 0.5203
DEBUG - 2012-01-25 23:28:48 --> Config Class Initialized
DEBUG - 2012-01-25 23:28:48 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:28:48 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:28:48 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:28:48 --> URI Class Initialized
DEBUG - 2012-01-25 23:28:48 --> Router Class Initialized
ERROR - 2012-01-25 23:28:48 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:41:57 --> Config Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:41:57 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:41:57 --> URI Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Router Class Initialized
DEBUG - 2012-01-25 23:41:57 --> No URI present. Default controller set.
DEBUG - 2012-01-25 23:41:57 --> Output Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Security Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Input Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:41:57 --> Language Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Loader Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:41:57 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Session Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:41:57 --> Session routines successfully run
DEBUG - 2012-01-25 23:41:57 --> Model Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Model Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Controller Class Initialized
DEBUG - 2012-01-25 23:41:57 --> Pagination Class Initialized
DEBUG - 2012-01-25 23:41:57 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-01-25 23:41:57 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-01-25 23:41:57 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-01-25 23:41:57 --> File loaded: application/views/user/home.php
DEBUG - 2012-01-25 23:41:57 --> Final output sent to browser
DEBUG - 2012-01-25 23:41:57 --> Total execution time: 0.1965
DEBUG - 2012-01-25 23:41:58 --> Config Class Initialized
DEBUG - 2012-01-25 23:41:58 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:41:58 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:41:58 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:41:58 --> URI Class Initialized
DEBUG - 2012-01-25 23:41:58 --> Router Class Initialized
ERROR - 2012-01-25 23:41:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-01-25 23:42:00 --> Config Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:42:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:42:00 --> URI Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Router Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Output Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Security Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Input Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2012-01-25 23:42:00 --> Language Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Loader Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Helper loaded: url_helper
DEBUG - 2012-01-25 23:42:00 --> Database Driver Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Session Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Helper loaded: string_helper
DEBUG - 2012-01-25 23:42:00 --> Session routines successfully run
DEBUG - 2012-01-25 23:42:00 --> Model Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Model Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Controller Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Pagination Class Initialized
DEBUG - 2012-01-25 23:42:00 --> File loaded: application/views//admin/blocks/header.php
DEBUG - 2012-01-25 23:42:00 --> File loaded: application/views//admin/blocks/sidebar.php
DEBUG - 2012-01-25 23:42:00 --> File loaded: application/views//admin/blocks/footer.php
DEBUG - 2012-01-25 23:42:00 --> File loaded: application/views/admin/home.php
DEBUG - 2012-01-25 23:42:00 --> Final output sent to browser
DEBUG - 2012-01-25 23:42:00 --> Total execution time: 0.2504
DEBUG - 2012-01-25 23:42:00 --> Config Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Hooks Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Utf8 Class Initialized
DEBUG - 2012-01-25 23:42:00 --> UTF-8 Support Enabled
DEBUG - 2012-01-25 23:42:00 --> URI Class Initialized
DEBUG - 2012-01-25 23:42:00 --> Router Class Initialized
ERROR - 2012-01-25 23:42:00 --> 404 Page Not Found --> favicon.ico

<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-02-05 21:50:17 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:17 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Router Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Output Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Security Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Input Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-05 21:50:17 --> Language Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Loader Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Helper loaded: url_helper
DEBUG - 2012-02-05 21:50:17 --> Database Driver Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Session Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Helper loaded: string_helper
DEBUG - 2012-02-05 21:50:17 --> A session cookie was not found.
DEBUG - 2012-02-05 21:50:17 --> Session routines successfully run
DEBUG - 2012-02-05 21:50:17 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Controller Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:17 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Router Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Output Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Security Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Input Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-05 21:50:17 --> Language Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Loader Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Helper loaded: url_helper
DEBUG - 2012-02-05 21:50:17 --> Database Driver Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Session Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Helper loaded: string_helper
DEBUG - 2012-02-05 21:50:17 --> Session routines successfully run
DEBUG - 2012-02-05 21:50:17 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Controller Class Initialized
DEBUG - 2012-02-05 21:50:17 --> File loaded: application/views/admin/login.php
DEBUG - 2012-02-05 21:50:17 --> Final output sent to browser
DEBUG - 2012-02-05 21:50:17 --> Total execution time: 0.1323
DEBUG - 2012-02-05 21:50:17 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:17 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:17 --> Router Class Initialized
ERROR - 2012-02-05 21:50:17 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-05 21:50:19 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:19 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Router Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Output Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Security Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Input Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-05 21:50:19 --> Language Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Loader Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Helper loaded: url_helper
DEBUG - 2012-02-05 21:50:19 --> Database Driver Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Session Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Helper loaded: string_helper
DEBUG - 2012-02-05 21:50:19 --> Session routines successfully run
DEBUG - 2012-02-05 21:50:19 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:19 --> Controller Class Initialized
DEBUG - 2012-02-05 21:50:19 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-05 21:50:19 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-05 21:50:19 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-05 21:50:19 --> File loaded: application/views/user/page.php
DEBUG - 2012-02-05 21:50:19 --> Final output sent to browser
DEBUG - 2012-02-05 21:50:19 --> Total execution time: 0.2085
DEBUG - 2012-02-05 21:50:20 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:20 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:20 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:20 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:20 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:20 --> Router Class Initialized
ERROR - 2012-02-05 21:50:20 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-05 21:50:31 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:31 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:31 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Router Class Initialized
DEBUG - 2012-02-05 21:50:31 --> No URI present. Default controller set.
DEBUG - 2012-02-05 21:50:31 --> Output Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Security Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Input Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-05 21:50:31 --> Language Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Loader Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Helper loaded: url_helper
DEBUG - 2012-02-05 21:50:31 --> Database Driver Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Session Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Helper loaded: string_helper
DEBUG - 2012-02-05 21:50:31 --> Session routines successfully run
DEBUG - 2012-02-05 21:50:31 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Controller Class Initialized
DEBUG - 2012-02-05 21:50:31 --> Pagination Class Initialized
DEBUG - 2012-02-05 21:50:31 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-05 21:50:31 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-05 21:50:31 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-05 21:50:31 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-05 21:50:31 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-05 21:50:31 --> Final output sent to browser
DEBUG - 2012-02-05 21:50:31 --> Total execution time: 0.2167
DEBUG - 2012-02-05 21:50:32 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:32 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:32 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:32 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:32 --> Router Class Initialized
ERROR - 2012-02-05 21:50:32 --> 404 Page Not Found --> lessons
DEBUG - 2012-02-05 21:50:32 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:32 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:32 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:32 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:32 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:32 --> Router Class Initialized
ERROR - 2012-02-05 21:50:32 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-05 21:50:40 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:40 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:40 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Router Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Output Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Security Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Input Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-05 21:50:40 --> Language Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Loader Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Helper loaded: url_helper
DEBUG - 2012-02-05 21:50:40 --> Database Driver Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Session Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Helper loaded: string_helper
DEBUG - 2012-02-05 21:50:40 --> Session routines successfully run
DEBUG - 2012-02-05 21:50:40 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Controller Class Initialized
DEBUG - 2012-02-05 21:50:40 --> Pagination Class Initialized
DEBUG - 2012-02-05 21:50:40 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-05 21:50:40 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-05 21:50:40 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-05 21:50:40 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-05 21:50:40 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-05 21:50:40 --> Final output sent to browser
DEBUG - 2012-02-05 21:50:40 --> Total execution time: 0.2291
DEBUG - 2012-02-05 21:50:41 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:41 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:41 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:41 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:41 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:41 --> Router Class Initialized
ERROR - 2012-02-05 21:50:41 --> 404 Page Not Found --> favicon.ico
DEBUG - 2012-02-05 21:50:44 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:44 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:44 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Router Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Output Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Security Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Input Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-05 21:50:44 --> Language Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Loader Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Helper loaded: url_helper
DEBUG - 2012-02-05 21:50:44 --> Database Driver Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Session Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Helper loaded: string_helper
DEBUG - 2012-02-05 21:50:44 --> Session routines successfully run
DEBUG - 2012-02-05 21:50:44 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Model Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Controller Class Initialized
DEBUG - 2012-02-05 21:50:44 --> Pagination Class Initialized
DEBUG - 2012-02-05 21:50:45 --> File loaded: application/views/user/blocks/header.php
DEBUG - 2012-02-05 21:50:45 --> File loaded: application/views/user/blocks/sidebar.php
DEBUG - 2012-02-05 21:50:45 --> File loaded: application/views/user/blocks/articles.php
DEBUG - 2012-02-05 21:50:45 --> File loaded: application/views/user/blocks/footer.php
DEBUG - 2012-02-05 21:50:45 --> File loaded: application/views/user/home.php
DEBUG - 2012-02-05 21:50:45 --> Final output sent to browser
DEBUG - 2012-02-05 21:50:45 --> Total execution time: 0.3149
DEBUG - 2012-02-05 21:50:45 --> Config Class Initialized
DEBUG - 2012-02-05 21:50:45 --> Hooks Class Initialized
DEBUG - 2012-02-05 21:50:45 --> Utf8 Class Initialized
DEBUG - 2012-02-05 21:50:45 --> UTF-8 Support Enabled
DEBUG - 2012-02-05 21:50:45 --> URI Class Initialized
DEBUG - 2012-02-05 21:50:45 --> Router Class Initialized
ERROR - 2012-02-05 21:50:45 --> 404 Page Not Found --> favicon.ico
